import {
  verifyPassword,
  createSessionToken,
  createSessionCookie,
  createClearSessionCookie,
  getSessionFromRequest,
  getSessionSecret,
  createResetToken,
  verifyResetToken,
  generateSalt,
  hashPassword,
  hmacHex,
  timingSafeEqualHex,
  type UserRow,
  type UserRole
} from '../auth';
import { json, safeJson } from '../lib/utils';
import { buildResetEmail, brand } from '../lib/emailTemplate';
import { WorkerMailer } from '@ryyr/worker-mailer';

const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_COOLDOWN_MS = 60 * 1000;
const OTP_WINDOW_MS = 15 * 60 * 1000;
const OTP_MAX_SENDS_PER_WINDOW = 3;
const OTP_MAX_ATTEMPTS = 5;
const RESET_TOKEN_TTL_SEC = 10 * 60;
const PASSWORD_MIN_LENGTH = 8;

const FORGOT_GENERIC = {
  success: true,
  message: 'Jika email terdaftar, kode verifikasi sudah dikirim (berlaku 10 menit).'
};

export async function handleLogin(req: Request, env: Env) {
  const body = await safeJson(req);
  const username = typeof body.username === 'string' ? body.username.trim() : '';
  const password = typeof body.password === 'string' ? body.password : '';

  if (!username || !password) {
    return json({ error: "INVALID_INPUT", message: "Username and password are required" }, { status: 400 });
  }

  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const user = await env.DB.prepare(
    "SELECT id, username, password_hash, salt, role, name, email, active FROM users WHERE username = ? OR LOWER(email) = LOWER(?) LIMIT 1"
  ).bind(username, username).first<UserRow>();

  if (!user) {
    return json({ error: "INVALID_CREDENTIALS", message: "Invalid username or password" }, { status: 401 });
  }
  // Akun nonaktif: jawaban sama dengan password salah (tanpa probing).
  if (user.active === 0) {
    return json({ error: "INVALID_CREDENTIALS", message: "Invalid username or password" }, { status: 401 });
  }

  const isValid = await verifyPassword(password, user.salt, user.password_hash);
  if (!isValid) {
    return json({ error: "INVALID_CREDENTIALS", message: "Invalid username or password" }, { status: 401 });
  }

  let secret: string;
  try {
    secret = getSessionSecret(env, req.url);
  } catch {
    return json({ error: "SERVER_CONFIG_ERROR", message: "Session secret is not configured on this server" }, { status: 500 });
  }
  const token = await createSessionToken({
    userId: user.id,
    username: user.username,
    role: user.role
  }, secret);

  const isSecure = new URL(req.url).protocol === 'https:';
  const cookieHeader = createSessionCookie(token, 60 * 60 * 24 * 7, isSecure);

  return json(
    {
      success: true,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        name: user.name
      }
    },
    {
      headers: {
        "Set-Cookie": cookieHeader
      }
    }
  );
}

export async function handleLogout(req: Request) {
  const isSecure = new URL(req.url).protocol === 'https:';
  const cookieHeader = createClearSessionCookie(isSecure);
  return json(
    { success: true, message: "Logged out successfully" },
    {
      headers: {
        "Set-Cookie": cookieHeader
      }
    }
  );
}

export async function handleMe(req: Request, env: Env) {
  const session = await getSessionFromRequest(req, env);
  if (!session) {
    return json({ authenticated: false }, { status: 401 });
  }

  // Baca role + active dari DB (bukan dari cookie) supaya perubahan oleh
  // superadmin (nonaktif / promote) langsung terlihat saat frontend reload.
  let displayName: string | undefined;
  let dbRole: UserRole = session.role;
  if (env.DB) {
    const user = await env.DB.prepare("SELECT name, role, active FROM users WHERE id = ?").bind(session.userId)
      .first<{ name: string | null; role: UserRole; active?: number }>();
    if (!user || user.active === 0) {
      // User dihapus/dinonaktifkan → session lama tidak berlaku.
      return json({ authenticated: false }, { status: 401 });
    }
    displayName = user.name ?? undefined;
    dbRole = user.role;
  }

  return json({
    authenticated: true,
    user: {
      id: session.userId,
      username: session.username,
      role: dbRole,
      name: displayName
    }
  });
}

function normalizeEmail(value: unknown): string {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function generateResetCode(): string {
  return (crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).toString().padStart(6, '0');
}

async function sendResetEmail(env: Env, to: string, code: string): Promise<void> {
  // Logo (opsional) dari app_settings untuk header email — gagal tidak memblokir kirim
  let logo: string | null = null;
  try {
    const row = await env.DB?.prepare("SELECT value FROM app_settings WHERE key = 'logo' LIMIT 1")
      .first<{ value: string }>();
    logo = row?.value || null;
  } catch { /* logo tidak wajib */ }

  const { subject, text, html } = buildResetEmail(code, logo);

  const mailer = await WorkerMailer.connect({
    host: 'smtp.gmail.com',
    port: 465,
    username: env.SMTP_USER,
    password: env.SMTP_PASS,
    authType: ['plain']
  });
  try {
    await mailer.send({
      from: { name: brand.name, email: env.SMTP_USER },
      to,
      subject,
      text,
      html
    });
  } finally {
    await mailer.close();
  }
}

export async function handleForgotPassword(req: Request, env: Env) {
  const body = await safeJson(req);
  const email = normalizeEmail(body.email);

  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  if (!env.SMTP_USER || !env.SMTP_PASS) {
    return json({ error: "SERVER_CONFIG_ERROR", message: "Email service is not configured on this server" }, { status: 500 });
  }
  // Same answer whether the email exists or not — no account probing.
  if (!email || !email.includes('@')) {
    return json(FORGOT_GENERIC);
  }

  let secret: string;
  try {
    secret = getSessionSecret(env, req.url);
  } catch {
    return json({ error: "SERVER_CONFIG_ERROR", message: "Session secret is not configured on this server" }, { status: 500 });
  }

  const now = Date.now();
  const recent = await env.DB.prepare(
    "SELECT created_at FROM password_reset_codes WHERE email = ? ORDER BY created_at DESC LIMIT 5"
  ).bind(email).all<{ created_at: string }>();
  const sentAt = (recent.results || [])
    .map((r) => Date.parse(r.created_at))
    .filter((t) => !isNaN(t));
  const lastSentAt = sentAt.length > 0 ? sentAt[0] : 0;
  const sendsInWindow = sentAt.filter((t) => now - t < OTP_WINDOW_MS).length;
  if (lastSentAt && now - lastSentAt < OTP_COOLDOWN_MS) return json(FORGOT_GENERIC);
  if (sendsInWindow >= OTP_MAX_SENDS_PER_WINDOW) return json(FORGOT_GENERIC);

  const user = await env.DB.prepare(
    "SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1"
  ).bind(email).first<{ id: string }>();

  await env.DB.prepare(
    "DELETE FROM password_reset_codes WHERE email = ? AND expires_at < ?"
  ).bind(email, new Date(now).toISOString()).run();

  // The code row is created even for unknown emails: otherwise the verify step
  // would answer differently for registered vs unregistered addresses and leak
  // which admin emails exist. No email is sent for the decoy row.
  const code = generateResetCode();
  const codeId = crypto.randomUUID();
  await env.DB.prepare(
    "INSERT INTO password_reset_codes (id, email, code_hash, attempts, expires_at, created_at) VALUES (?, ?, ?, 0, ?, ?)"
  ).bind(codeId, email, await hmacHex(secret, `${email}:${code}`), new Date(now + OTP_TTL_MS).toISOString(), new Date(now).toISOString()).run();

  if (!user) return json(FORGOT_GENERIC);

  try {
    await sendResetEmail(env, email, code);
  } catch (e) {
    await env.DB.prepare("DELETE FROM password_reset_codes WHERE id = ?").bind(codeId).run();
    console.error("Failed to send password reset email:", e);
    return json({ error: "EMAIL_SEND_FAILED", message: "Gagal mengirim email verifikasi. Coba lagi nanti." }, { status: 502 });
  }

  return json(FORGOT_GENERIC);
}

export async function handleVerifyResetCode(req: Request, env: Env) {
  const body = await safeJson(req);
  const email = normalizeEmail(body.email);
  const code = typeof body.code === 'string' ? body.code.trim() : '';

  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  if (!email || !/^\d{6}$/.test(code)) {
    return json({ error: "CODE_INVALID", message: "Kode salah atau kedaluwarsa. Minta kode baru." }, { status: 400 });
  }

  let secret: string;
  try {
    secret = getSessionSecret(env, req.url);
  } catch {
    return json({ error: "SERVER_CONFIG_ERROR", message: "Session secret is not configured on this server" }, { status: 500 });
  }

  const nowIso = new Date().toISOString();
  const row = await env.DB.prepare(
    "SELECT id, code_hash, attempts FROM password_reset_codes WHERE email = ? AND consumed_at IS NULL AND expires_at > ? ORDER BY created_at DESC LIMIT 1"
  ).bind(email, nowIso).first<{ id: string; code_hash: string; attempts: number }>();

  if (!row) {
    return json({ error: "CODE_INVALID", message: "Kode salah atau kedaluwarsa. Minta kode baru." }, { status: 400 });
  }
  if (row.attempts >= OTP_MAX_ATTEMPTS) {
    await env.DB.prepare("DELETE FROM password_reset_codes WHERE id = ?").bind(row.id).run();
    return json({ error: "CODE_INVALID", message: "Terlalu banyak percobaan. Minta kode baru." }, { status: 400 });
  }

  const expected = await hmacHex(secret, `${email}:${code}`);
  if (!timingSafeEqualHex(expected, row.code_hash)) {
    const attempts = row.attempts + 1;
    await env.DB.prepare("UPDATE password_reset_codes SET attempts = ? WHERE id = ?").bind(attempts, row.id).run();
    const remaining = Math.max(0, OTP_MAX_ATTEMPTS - attempts);
    return json({
      error: "CODE_INVALID",
      message: remaining > 0
        ? `Kode salah. Sisa percobaan: ${remaining}`
        : "Terlalu banyak percobaan. Minta kode baru."
    }, { status: 400 });
  }

  await env.DB.prepare(
    "UPDATE password_reset_codes SET consumed_at = ? WHERE id = ?"
  ).bind(nowIso, row.id).run();

  const user = await env.DB.prepare(
    "SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1"
  ).bind(email).first<{ id: string }>();
  if (!user) {
    return json({ error: "CODE_INVALID", message: "Kode salah atau kedaluwarsa. Minta kode baru." }, { status: 400 });
  }

  return json({
    success: true,
    reset_token: await createResetToken(user.id, secret, RESET_TOKEN_TTL_SEC),
    expires_in: RESET_TOKEN_TTL_SEC
  });
}

export async function handleResetPassword(req: Request, env: Env) {
  const body = await safeJson(req);
  const resetToken = typeof body.reset_token === 'string' ? body.reset_token : '';
  const password = typeof body.password === 'string' ? body.password : '';
  const confirm = typeof body.confirm === 'string' ? body.confirm : '';

  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  if (!resetToken) {
    return json({ error: "RESET_TOKEN_INVALID", message: "Sesi reset kedaluwarsa. Mulai dari awal." }, { status: 400 });
  }
  if (password.length < PASSWORD_MIN_LENGTH) {
    return json({ error: "PASSWORD_TOO_SHORT", message: `Password minimal ${PASSWORD_MIN_LENGTH} karakter.` }, { status: 400 });
  }
  if (password !== confirm) {
    return json({ error: "PASSWORD_MISMATCH", message: "Password tidak sama." }, { status: 400 });
  }

  let secret: string;
  try {
    secret = getSessionSecret(env, req.url);
  } catch {
    return json({ error: "SERVER_CONFIG_ERROR", message: "Session secret is not configured on this server" }, { status: 500 });
  }

  const userId = await verifyResetToken(resetToken, secret);
  if (!userId) {
    return json({ error: "RESET_TOKEN_INVALID", message: "Sesi reset kedaluwarsa. Mulai dari awal." }, { status: 400 });
  }

  const user = await env.DB.prepare(
    "SELECT id, email FROM users WHERE id = ? LIMIT 1"
  ).bind(userId).first<{ id: string; email?: string | null }>();
  if (!user) {
    return json({ error: "RESET_TOKEN_INVALID", message: "Sesi reset kedaluwarsa. Mulai dari awal." }, { status: 400 });
  }

  const salt = generateSalt();
  const hash = await hashPassword(password, salt);
  await env.DB.prepare(
    "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?"
  ).bind(hash, salt, user.id).run();

  const email = normalizeEmail(user.email);
  if (email) {
    await env.DB.prepare("DELETE FROM password_reset_codes WHERE email = ?").bind(email).run();
  }

  return json({ success: true, message: "Password berhasil diubah. Silakan sign in." });
}
