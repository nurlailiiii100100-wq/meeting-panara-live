import { getSessionFromRequest, isOperatorRole, hmacHex, type RecordingRow } from '../auth';
import {
  json,
  resolveMeetingId,
  getMeetingRetentionHours,
  safeJson
} from '../lib/utils';
import { verifyHostUploadToken } from '../lib/uploadToken';

// Ekstensi/MIME rekaman ditentukan saat diunggah oleh klien: MediaRecorder
// (web) menghasilkan video/webm, MediaMuxer (Android) menghasilkan mp4.
// Worker hanya menerima dan menyimpan — tidak ada encoding/transcode.
function contentTypeFromKey(storageKey: string): string {
  return /\.webm$/i.test(storageKey) ? 'video/webm' : 'video/mp4';
}

function clampInt(value: unknown, min: number, max: number): number {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function str(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

// Batas unggah chunked (R2 multipart): semua part kecuali yang terakhir
// minimal 5 MiB, maksimal 10.000 part. Client web memakai potongan 12 MiB.
const MIN_PART_BYTES = 5 * 1024 * 1024;
const MAX_PART_BYTES = 64 * 1024 * 1024;
const MAX_PARTS = 10000;
const MAX_UPLOAD_BYTES = 50 * 1024 * 1024 * 1024; // 50 GiB — batas kewajaran

// Autentikasi unggahan rekaman: session admin (cookie) ATAU token unggah host
// yang ditandatangani saat join. Kredensial dicek SEBELUM meeting di-resolve
// agar request tanpa kredensial tidak bisa dipakai menguji keberadaan meeting.
async function authorizeRecordingUpload(
  env: Env,
  req: Request,
  session: Awaited<ReturnType<typeof getSessionFromRequest>>,
  meetingIdRaw: string,
  uploadTokenRaw: string
): Promise<{ ok: true; resolved: string } | { ok: false; response: Response }> {
  const meetingId = meetingIdRaw.trim();
  const uploadToken = uploadTokenRaw.trim();
  const hasAdminSession = Boolean(session && isOperatorRole(session.role));
  if (!meetingId) {
    return {
      ok: false,
      response: json({ error: "INVALID_INPUT", message: "meeting_id is required" }, { status: 400 }),
    };
  }
  if (!hasAdminSession && !uploadToken) {
    return {
      ok: false,
      response: json(
        { error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Only the meeting host may upload recordings" },
        { status: session ? 403 : 401 }
      ),
    };
  }
  const resolved = await resolveMeetingId(meetingId, env);
  if (!resolved) {
    return {
      ok: false,
      response: json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 }),
    };
  }
  const hasHostToken = uploadToken ? await verifyHostUploadToken(env, req.url, resolved, uploadToken) : false;
  if (!hasAdminSession && !hasHostToken) {
    return {
      ok: false,
      response: json(
        { error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Only the meeting host may upload recordings" },
        { status: session ? 403 : 401 }
      ),
    };
  }
  return { ok: true, resolved };
}

// Catat rekaman ke D1 dengan status 'ready'. Null kalau gagal — pemanggil
// wajib menghapus objek R2 yang sudah terlanjur dibuat (kompensasi).
async function insertRecordingRow(
  db: D1Database,
  env: Env,
  params: {
    id: string;
    meetingId: string;
    storageKey: string;
    fileName: string;
    durationSeconds: number;
    sizeBytes: number;
    resolutionWidth: number;
    resolutionHeight: number;
    source?: string;
    storage?: string;
    vpsFilePath?: string;
  }
): Promise<{ expiresAt: string } | null> {
  const retentionHours = await getMeetingRetentionHours(env, params.meetingId);
  const expiresAt = new Date(Date.now() + retentionHours * 60 * 60 * 1000).toISOString();
  try {
    await db
      .prepare(
        "INSERT INTO recordings (id, meeting_id, storage_key, file_name, duration_seconds, size_bytes, resolution_width, resolution_height, status, expires_at, source, storage, vps_file_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ready', ?, ?, ?, ?)"
      )
      .bind(
        params.id,
        params.meetingId,
        params.storageKey,
        params.fileName,
        params.durationSeconds,
        params.sizeBytes,
        params.resolutionWidth || null,
        params.resolutionHeight || null,
        expiresAt,
        params.source || 'manual',
        params.storage || 'r2',
        params.vpsFilePath || null
      )
      .run();
    return { expiresAt };
  } catch (e) {
    console.error("Client recording metadata insert failed:", e);
    return null;
  }
}


export async function handleRecordingsApi(req: Request, env: Env): Promise<Response> {
  const url = new URL(req.url);
  const session = await getSessionFromRequest(req, env);

  // List recordings: GET /api/recordings OR /api/recordings?meeting_id=:id
  if (url.pathname === "/api/recordings" && req.method === "GET") {
    if (!session) {
      return json({ error: "UNAUTHORIZED", message: "Login required to access recordings" }, { status: 401 });
    }

    if (!env.DB) {
      return json({ error: "SERVER_ERROR", message: "Database binding missing" }, { status: 500 });
    }

    const meetingId = url.searchParams.get("meeting_id");

    // Bulk: no meeting_id → return all recordings (admin only)
    if (!meetingId) {
      if (!isOperatorRole(session.role)) {
        return json({ error: "FORBIDDEN", message: "Admin access required to view all recordings" }, { status: 403 });
      }
      const rows = await env.DB.prepare(
        "SELECT * FROM recordings WHERE status != 'deleted' ORDER BY created_at DESC"
      ).all<RecordingRow>();
      return json({ recordings: rows.results || [] });
    }

    // Single meeting: with meeting_id → return recordings for that meeting
    const resolved = await resolveMeetingId(meetingId, env);
    if (!resolved) {
      return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
    }
    // Authorization: admin operator only (superadmin is not an operator)
    if (!isOperatorRole(session.role)) {
      return json({ error: "FORBIDDEN", message: "You are not authorized to view recordings for this meeting" }, { status: 403 });
    }

    const rows = await env.DB.prepare(
      "SELECT * FROM recordings WHERE meeting_id = ? AND status != 'deleted' ORDER BY created_at DESC"
    ).bind(resolved).all<RecordingRow>();

    return json({ recordings: rows.results || [] });
  }

  // Stream/Download single recording: GET /api/recordings/:id/stream OR /download
  const streamMatch = url.pathname.match(/^\/api\/recordings\/([^/]+)\/(stream|download)$/);
  if (streamMatch && req.method === "GET") {
    if (!session) {
      return json({ error: "UNAUTHORIZED", message: "Login required to access recordings" }, { status: 401 });
    }

    const recordingId = streamMatch[1];
    const isDownload = streamMatch[2] === "download";

    if (!env.DB) {
      return json({ error: "SERVER_ERROR", message: "Database binding missing" }, { status: 500 });
    }

    const rec = await env.DB.prepare(
      "SELECT * FROM recordings WHERE id = ? LIMIT 1"
    ).bind(recordingId).first<RecordingRow>();

    if (!rec) {
      return json({ error: "NOT_FOUND", message: "Recording not found" }, { status: 404 });
    }

    // Authorization: admin operator only (superadmin is not an operator)
    if (!isOperatorRole(session.role)) {
      return json({ error: "FORBIDDEN", message: "You are not authorized to access this recording" }, { status: 403 });
    }

    // Check expiration first, then status
    const nowIso = new Date().toISOString();
    if (rec.expires_at <= nowIso) {
      return json({ error: "RECORDING_EXPIRED", message: "Recording file has expired and is no longer available" }, { status: 410 });
    }

    // Check status (after expiry so we can surface expiry separately)
    if (rec.status !== 'ready') {
      return json({ error: "RECORDING_NOT_READY", message: `Recording is not ready (status: ${rec.status})` }, { status: 409 });
    }

    // Increment download counter
    if (isDownload) {
      try {
        await env.DB.prepare("UPDATE recordings SET download_count = COALESCE(download_count, 0) + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
          .bind(recordingId).run();
      } catch { /* ignore */ }
    }

    // VPS storage: redirect ke VPS recorder dengan signed URL
    if (rec.storage === 'vps' && rec.vps_file_path) {
      if (!env.VPS_RECORDER_URL || !env.RECORDING_HMAC_SECRET) {
        return json({ error: "SERVER_ERROR", message: "VPS recorder configuration missing" }, { status: 500 });
      }
      const exp = Math.floor(Date.now() / 1000) + 3600; // URL valid 1 jam
      const payload = `${rec.vps_file_path}.${exp}`;
      const sig = await hmacHex(env.RECORDING_HMAC_SECRET, payload);
      const action = isDownload ? 'download' : 'stream';
      const signedUrl = `${env.VPS_RECORDER_URL}/api/${action}/${encodeURIComponent(rec.vps_file_path)}?sig=${sig}&exp=${exp}`;
      return Response.redirect(signedUrl, 302);
    }

    if (!env.RECORDINGS_BUCKET) {
      return json({ error: "SERVER_ERROR", message: "R2 Bucket binding missing" }, { status: 500 });
    }

    const safeFileName = rec.file_name.replace(/[^a-zA-Z0-9._-]/g, '_');

    // Handle range request for video streaming
    let object: R2ObjectBody | null = null;
    if (!isDownload && req.headers.has("range")) {
      object = await env.RECORDINGS_BUCKET.get(rec.storage_key, { range: req.headers });
    } else {
      object = await env.RECORDINGS_BUCKET.get(rec.storage_key);
    }

    if (!object) {
      return json({ error: "NOT_FOUND", message: "Recording file not found in storage" }, { status: 404 });
    }

    const headers = new Headers();
    // Metadata R2 menyimpan content-type saat object diunggah (video/webm dari
    // MediaRecorder web, video/mp4 dari MediaMuxer Android) — baca dinamis,
    // fallback ke tebak dari ekstensi key untuk object lama tanpa metadata.
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    if (!headers.get("content-type")) {
      headers.set("content-type", contentTypeFromKey(rec.storage_key));
    }
    headers.set("accept-ranges", "bytes");

    if (isDownload) {
      headers.set("content-disposition", `attachment; filename="${safeFileName}"`);
      headers.set("content-length", String(object.size));
      return new Response(object.body, { headers });
    }

    headers.set("content-disposition", `inline; filename="${safeFileName}"`);

    // Hanya balas 206 bila klien benar-benar mengirim header Range
    if (req.headers.has("range") && object.range) {
      const range = object.range;
      const start = 'offset' in range && range.offset !== undefined ? range.offset : 0;
      const length = 'length' in range && range.length !== undefined ? range.length : object.size;
      const end = start + length - 1;
      headers.set("content-range", `bytes ${start}-${end}/${object.size}`);
      headers.set("content-length", String(length));
      return new Response(object.body, { headers, status: 206 });
    }

    headers.set("content-length", String(object.size));
    return new Response(object.body, { headers, status: 200 });
  }

  // ---------- Unggah client chunked (web): init → chunk → complete/abort ----------
  // File besar dipecah di browser per 12 MiB agar lolos limit 100 MB/request,
  // lalu digabung kembali di sini lewat R2 multipart upload menjadi SATU file
  // utuh — tampilan dashboard tetap sama (satu kartu per rekaman).
  if (url.pathname === "/api/recordings/upload/init" && req.method === "POST") {
    if (!env.DB || !env.RECORDINGS_BUCKET) {
      return json({ error: "SERVER_ERROR", message: "R2 Bucket or DB binding missing" }, { status: 500 });
    }

    const body = await safeJson(req);
    const auth = await authorizeRecordingUpload(env, req, session, str(body.meeting_id), str(body.upload_token));
    if (!auth.ok) return auth.response;

    const fileSize = Number(body.file_size);
    const totalParts = Number(body.total_parts);
    if (!Number.isFinite(fileSize) || fileSize <= 0 || fileSize > MAX_UPLOAD_BYTES) {
      return json({ error: "INVALID_INPUT", message: "file_size is invalid" }, { status: 400 });
    }
    if (!Number.isInteger(totalParts) || totalParts < 1 || totalParts > MAX_PARTS) {
      return json({ error: "INVALID_INPUT", message: "total_parts is invalid" }, { status: 400 });
    }

    const originalName = str(body.file_name);
    const mimeType = str(body.mime_type);
    const extension = pickRecordingUploadExtension(originalName, mimeType);
    const contentType = mimeType || (extension === "mp4" ? "video/mp4" : "video/webm");
    const id = crypto.randomUUID();
    const storageKey = `recordings/${auth.resolved}/${id}_${Date.now()}.${extension}`;

    try {
      const multipart = await env.RECORDINGS_BUCKET.createMultipartUpload(storageKey, {
        httpMetadata: { contentType },
      });
      return json({ upload_id: multipart.uploadId, storage_key: storageKey }, { status: 201 });
    } catch (e) {
      console.error("createMultipartUpload failed:", e);
      return json({ error: "STORAGE_ERROR", message: "Failed to start the recording upload" }, { status: 502 });
    }
  }

  const chunkMatch = url.pathname.match(/^\/api\/recordings\/upload\/chunk\/([^/]+)\/(\d+)$/);
  if (chunkMatch && req.method === "PUT") {
    if (!env.RECORDINGS_BUCKET) {
      return json({ error: "SERVER_ERROR", message: "R2 Bucket binding missing" }, { status: 500 });
    }

    const uploadId = decodeURIComponent(chunkMatch[1]);
    const partNumber = parseInt(chunkMatch[2], 10);
    if (!uploadId || !Number.isInteger(partNumber) || partNumber < 1 || partNumber > MAX_PARTS) {
      return json({ error: "INVALID_INPUT", message: "Invalid chunk coordinates" }, { status: 400 });
    }

    const auth = await authorizeRecordingUpload(
      env,
      req,
      session,
      req.headers.get("x-meeting-id") ?? "",
      req.headers.get("x-upload-token") ?? ""
    );
    if (!auth.ok) return auth.response;

    // storage_key harus tetap di dalam folder meeting yang sama — mencegah
    // token meeting lain dipakai menulis objek ke area yang bukan miliknya.
    const storageKey = (req.headers.get("x-storage-key") ?? "").trim();
    if (!storageKey.startsWith(`recordings/${auth.resolved}/`) || !/\.(webm|mp4)$/i.test(storageKey)) {
      return json({ error: "INVALID_INPUT", message: "storage_key does not belong to this meeting" }, { status: 400 });
    }

    const isLast = req.headers.get("x-last-part") === "1";
    const body = await req.arrayBuffer().catch(() => null);
    if (!body || body.byteLength === 0) {
      return json({ error: "INVALID_INPUT", message: "Chunk is empty" }, { status: 400 });
    }
    if (body.byteLength > MAX_PART_BYTES) {
      return json({ error: "INVALID_INPUT", message: "Chunk is too large" }, { status: 413 });
    }
    // Aturan multipart R2/S3: semua part kecuali yang terakhir minimal 5 MiB.
    if (!isLast && body.byteLength < MIN_PART_BYTES) {
      return json(
        { error: "INVALID_INPUT", message: "Non-final chunks must be at least 5 MiB" },
        { status: 400 }
      );
    }

    try {
      const multipart = env.RECORDINGS_BUCKET.resumeMultipartUpload(storageKey, uploadId);
      const part = await multipart.uploadPart(partNumber, body);
      return json({ partNumber: part.partNumber, etag: part.etag });
    } catch (e) {
      console.error("uploadPart failed:", e);
      return json(
        { error: "UPLOAD_INVALID", message: "Upload session is invalid or already ended" },
        { status: 400 }
      );
    }
  }

  if (url.pathname === "/api/recordings/upload/complete" && req.method === "POST") {
    if (!env.DB || !env.RECORDINGS_BUCKET) {
      return json({ error: "SERVER_ERROR", message: "R2 Bucket or DB binding missing" }, { status: 500 });
    }

    const body = await safeJson(req);
    const auth = await authorizeRecordingUpload(env, req, session, str(body.meeting_id), str(body.upload_token));
    if (!auth.ok) return auth.response;

    const uploadId = str(body.upload_id);
    const storageKey = str(body.storage_key);
    if (!uploadId || !storageKey.startsWith(`recordings/${auth.resolved}/`) || !/\.(webm|mp4)$/i.test(storageKey)) {
      return json({ error: "INVALID_INPUT", message: "upload_id/storage_key tidak valid" }, { status: 400 });
    }

    const partsRaw = Array.isArray(body.parts) ? body.parts : [];
    if (partsRaw.length === 0 || partsRaw.length > MAX_PARTS) {
      return json({ error: "INVALID_INPUT", message: "parts is invalid" }, { status: 400 });
    }
    const parts: R2UploadedPart[] = [];
    for (const partRaw of partsRaw) {
      const partNumber = Number((partRaw as { partNumber?: unknown } | null)?.partNumber);
      const etag = str((partRaw as { etag?: unknown } | null)?.etag);
      if (!Number.isInteger(partNumber) || partNumber < 1 || partNumber > MAX_PARTS || !etag) {
        return json({ error: "INVALID_INPUT", message: "parts contains an invalid entry" }, { status: 400 });
      }
      parts.push({ partNumber, etag });
    }

    let sizeBytes = 0;
    try {
      const multipart = env.RECORDINGS_BUCKET.resumeMultipartUpload(storageKey, uploadId);
      const completed = await multipart.complete(parts);
      sizeBytes = completed.size;
    } catch (e) {
      console.error("completeMultipartUpload failed:", e);
      return json(
        { error: "UPLOAD_INVALID", message: "Gagal menggabungkan bagian rekaman" },
        { status: 400 }
      );
    }

    const originalName = str(body.file_name);
    const extension = /\.mp4$/i.test(storageKey) ? "mp4" : "webm";
    const id = crypto.randomUUID();
    const fileName = (originalName || `recording-${id}.${extension}`).replace(/[^a-zA-Z0-9._-]/g, "_");
    const durationSeconds = clampInt(body.duration_seconds, 0, 86400);
    const resolutionWidth = clampInt(body.resolution_width, 0, 16384);
    const resolutionHeight = clampInt(body.resolution_height, 0, 16384);

    const saved = await insertRecordingRow(env.DB, env, {
      id,
      meetingId: auth.resolved,
      storageKey,
      fileName,
      durationSeconds,
      sizeBytes,
      resolutionWidth,
      resolutionHeight,
    });
    if (!saved) {
      try { await env.RECORDINGS_BUCKET.delete(storageKey); } catch { /* ignore */ }
      return json({ error: "SERVER_ERROR", message: "Failed to save the recording metadata" }, { status: 500 });
    }

    return json({
      id,
      meeting_id: auth.resolved,
      storage_key: storageKey,
      file_name: fileName,
      duration_seconds: durationSeconds,
      size_bytes: sizeBytes,
      resolution_width: resolutionWidth || null,
      resolution_height: resolutionHeight || null,
      status: 'ready',
      expires_at: saved.expiresAt
    }, { status: 201 });
  }

  if (url.pathname === "/api/recordings/upload/abort" && req.method === "POST") {
    if (!env.RECORDINGS_BUCKET) {
      return json({ error: "SERVER_ERROR", message: "R2 Bucket binding missing" }, { status: 500 });
    }

    const body = await safeJson(req);
    const auth = await authorizeRecordingUpload(env, req, session, str(body.meeting_id), str(body.upload_token));
    if (!auth.ok) return auth.response;

    const uploadId = str(body.upload_id);
    const storageKey = str(body.storage_key);
    if (!uploadId || !storageKey.startsWith(`recordings/${auth.resolved}/`) || !/\.(webm|mp4)$/i.test(storageKey)) {
      return json({ error: "INVALID_INPUT", message: "upload_id/storage_key tidak valid" }, { status: 400 });
    }

    try {
      await env.RECORDINGS_BUCKET.resumeMultipartUpload(storageKey, uploadId).abort();
    } catch {
      /* sudah selesai/dibatalkan sebelumnya — tidak masalah */
    }
    return json({ ok: true });
  }

  // Client-side recording upload (web: MediaRecorder → webm, Android:
  // MediaMuxer → mp4): POST /api/recordings/upload, multipart → R2 + D1.
  // Jalur satu request untuk file kecil (≤12 MiB) dan app Android.
  if (url.pathname === "/api/recordings/upload" && req.method === "POST") {
    if (!env.DB || !env.RECORDINGS_BUCKET) {
      return json({ error: "SERVER_ERROR", message: "R2 Bucket or DB binding missing" }, { status: 500 });
    }

    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      return json(
        { error: "INVALID_INPUT", message: "Expected multipart/form-data body (file may exceed the request size limit)" },
        { status: 413 }
      );
    }

    const meetingIdEntry = form.get("meeting_id");
    const meetingIdRaw = typeof meetingIdEntry === "string" ? meetingIdEntry.trim() : "";
    if (!meetingIdRaw) {
      return json({ error: "INVALID_INPUT", message: "meeting_id is required" }, { status: 400 });
    }

    // Kredensial wajib ada SEBELUM meeting di-resolve, agar request tanpa
    // session/token tidak dipakai untuk mengeksistensi meeting (404 vs 401).
    const uploadTokenEntry = form.get("upload_token");
    const uploadToken = typeof uploadTokenEntry === "string" ? uploadTokenEntry.trim() : "";
    const hasAdminSession = Boolean(session && isOperatorRole(session.role));
    if (!hasAdminSession && !uploadToken) {
      return json(
        { error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Only the meeting host may upload recordings" },
        { status: session ? 403 : 401 }
      );
    }

    const resolved = await resolveMeetingId(meetingIdRaw, env);
    if (!resolved) {
      return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
    }

    const file = form.get("file");
    if (!(file instanceof Blob) || file.size === 0) {
      return json({ error: "INVALID_INPUT", message: "file is required and must not be empty" }, { status: 400 });
    }

    // Autentikasi: session admin (cookie learnly_session) ATAU token unggah
    // host yang ditandatangani saat token join diterbitkan (diverifikasi
    // terhadap meeting yang sudah di-resolve).
    const hasHostToken = uploadToken ? await verifyHostUploadToken(env, req.url, resolved, uploadToken) : false;
    if (!hasAdminSession && !hasHostToken) {
      return json(
        { error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Only the meeting host may upload recordings" },
        { status: session ? 403 : 401 }
      );
    }

    const originalName = typeof file.name === "string" ? file.name : "";
    const extension = pickRecordingUploadExtension(originalName, file.type);
    const contentType = file.type || (extension === "mp4" ? "video/mp4" : "video/webm");
    const durationSeconds = clampInt(form.get("duration_seconds"), 0, 86400);
    const resolutionWidth = clampInt(form.get("resolution_width"), 0, 16384);
    const resolutionHeight = clampInt(form.get("resolution_height"), 0, 16384);

    const id = crypto.randomUUID();
    const storageKey = `recordings/${resolved}/${id}_${Date.now()}.${extension}`;
    const fileName = (originalName || `recording-${id}.${extension}`).replace(/[^a-zA-Z0-9._-]/g, "_");
    const sizeBytes = file.size;

    try {
      await env.RECORDINGS_BUCKET.put(storageKey, file, { httpMetadata: { contentType } });
    } catch (e) {
      console.error("Client recording upload to R2 failed:", e);
      return json({ error: "STORAGE_ERROR", message: "Failed to store the recording file" }, { status: 502 });
    }

    const saved = await insertRecordingRow(env.DB, env, {
      id,
      meetingId: resolved,
      storageKey,
      fileName,
      durationSeconds,
      sizeBytes,
      resolutionWidth,
      resolutionHeight,
    });
    if (!saved) {
      try { await env.RECORDINGS_BUCKET.delete(storageKey); } catch { /* ignore */ }
      return json({ error: "SERVER_ERROR", message: "Failed to save the recording metadata" }, { status: 500 });
    }

    return json({
      id,
      meeting_id: resolved,
      storage_key: storageKey,
      file_name: fileName,
      duration_seconds: durationSeconds,
      size_bytes: sizeBytes,
      resolution_width: resolutionWidth || null,
      resolution_height: resolutionHeight || null,
      status: 'ready',
      expires_at: saved.expiresAt
    }, { status: 201 });
  }

  return json({ error: "NOT_FOUND", message: "Endpoint not found" }, { status: 404 });
}

function pickRecordingUploadExtension(originalName: string, type: string): 'mp4' | 'webm' {
  const fromName = /\.([A-Za-z0-9]{2,4})$/.exec(originalName.trim());
  const fromType = type.includes("mp4") ? "mp4" : type.includes("webm") ? "webm" : null;
  const ext = (fromName?.[1] || fromType || "webm").toLowerCase();
  return ext === "mp4" ? "mp4" : "webm";
}

export async function handleScheduledCleanups(env: Env): Promise<void> {
  if (!env.DB || !env.RECORDINGS_BUCKET) return;

  const nowIso = new Date().toISOString();
  const expiredRecordings = await env.DB.prepare(
    "SELECT id, storage_key FROM recordings WHERE expires_at <= ? AND status NOT IN ('expired', 'deleted')"
  ).bind(nowIso).all<{ id: string; storage_key: string }>();

  if (expiredRecordings.results && expiredRecordings.results.length > 0) {
    for (const rec of expiredRecordings.results) {
      try {
        await env.DB.prepare(
          "UPDATE recordings SET status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
        ).bind(rec.id).run();
      } catch (e) {
        console.error(`Failed to update D1 recording to expired (id: ${rec.id})`, e);
        continue;
      }
      try {
        await env.RECORDINGS_BUCKET.delete(rec.storage_key);
      } catch (e) {
        console.error(`Failed to delete R2 object key: ${rec.storage_key} (id: ${rec.id})`, e);
      }
    }
  }

  // Purge rows older than 30 days so stale cards stop piling up in the dashboard.
  // expires_at is checked so the R2 object (already removed above) never outlives its row.
  await env.DB.prepare(
    "DELETE FROM recordings WHERE datetime(created_at) <= datetime('now', '-30 days') AND expires_at <= ?"
  ).bind(nowIso).run();
}
