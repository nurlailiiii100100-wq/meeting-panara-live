import type { SettingsRow } from '../auth';
import { json, safeJson } from '../lib/utils';

export async function getSettingValue(env: Env, key: string, fallback: string): Promise<string> {
  if (!env.DB) return fallback;
  try {
    const row = await env.DB.prepare("SELECT value FROM app_settings WHERE key = ? LIMIT 1").bind(key).first<{ value: string }>();
    return row?.value ?? fallback;
  } catch {
    return fallback;
  }
}

export async function getPublicSettings(env: Env) {
  const logo = await getSettingValue(env, 'logo', '');
  const title = await getSettingValue(env, 'title', '');
  return new Response(JSON.stringify({ logo, title }), {
    headers: {
      "content-type": "application/json",
      // Logo/title can change on every settings save — never let browsers reuse a stale body.
      "cache-control": "no-store"
    }
  });
}

export async function getAllSettings(env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const rows = await env.DB.prepare("SELECT key, value, updated_at FROM app_settings").all<SettingsRow>();
  const settings: Record<string, string> = {};
  for (const row of rows.results || []) {
    settings[row.key] = row.value;
  }
  return json({ settings });
}

export async function updateSettings(req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const body = await safeJson(req);

  const allowedKeys: Record<string, (val: string) => string | null> = {
    logo: (val) => {
      const v = typeof val === 'string' ? val.trim() : '';
      if (!v) return '';
      const isDataUrl = v.startsWith('data:image/') && v.includes(';base64,');
      const isUrl = /^https?:\/\//.test(v);
      const sizeOk = !isDataUrl || v.length <= 700000;
      return (isDataUrl || isUrl) && sizeOk ? v : null;
    },
    title: (val) => {
      const v = typeof val === 'string' ? val.trim() : '';
      return v.length <= 60 ? v : null;
    }
  };

  if (body.logo !== undefined) {
    const normalized = allowedKeys.logo(String(body.logo));
    if (normalized === null) {
      return json({ error: "INVALID_LOGO", message: "Logo must be a data:image base64 URL or an http(s) URL under ~700KB." }, { status: 400 });
    }
    await env.DB.prepare("INSERT INTO app_settings (key, value, updated_at) VALUES ('logo', ?, CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP").bind(normalized).run();
  }

  if (body.title !== undefined) {
    const normalized = allowedKeys.title(String(body.title));
    if (normalized === null) {
      return json({ error: "INVALID_TITLE", message: "Judul aplikasi maksimal 60 karakter." }, { status: 400 });
    }
    await env.DB.prepare("INSERT INTO app_settings (key, value, updated_at) VALUES ('title', ?, CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP").bind(normalized).run();
  }

  return json({ success: true });
}
