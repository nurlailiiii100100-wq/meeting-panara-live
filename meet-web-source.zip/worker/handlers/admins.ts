import { generateSalt, hashPassword, type UserRole } from '../auth';
import { json, safeJson } from '../lib/utils';

const PASSWORD_MIN_LENGTH = 8;

interface AdminListRow {
  id: string;
  username: string;
  name: string | null;
  email: string | null;
  role: UserRole;
  active: number;
  created_at: string;
}

function normalizeEmail(value: unknown): string {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

// GET /api/admins — hanya daftar akun admin/superadmin.
// Tidak pernah mengembalikan password_hash / salt / data auth lain.
export async function listAdmins(env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const result = await env.DB.prepare(
    "SELECT id, username, name, email, role, active, created_at FROM users WHERE role IN ('admin', 'superadmin') ORDER BY CASE WHEN role = 'superadmin' THEN 0 ELSE 1 END, created_at ASC, username ASC"
  ).all<AdminListRow>();

  return json({ admins: result.results || [] });
}

// POST /api/admins — buat akun admin baru (role selalu 'admin', active selalu 1).
export async function createAdmin(req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const body = await safeJson(req);
  const username = typeof body.username === 'string' ? body.username.trim() : '';
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const email = normalizeEmail(body.email);
  const password = typeof body.password === 'string' ? body.password : '';

  if (!username) {
    return json({ error: "INVALID_INPUT", message: "Username wajib diisi." }, { status: 400 });
  }
  if (email && !email.includes('@')) {
    return json({ error: "INVALID_INPUT", message: "Email tidak valid." }, { status: 400 });
  }
  if (password.length < PASSWORD_MIN_LENGTH) {
    return json({ error: "PASSWORD_TOO_SHORT", message: `Password minimal ${PASSWORD_MIN_LENGTH} karakter.` }, { status: 400 });
  }

  const dupUser = await env.DB.prepare("SELECT id FROM users WHERE username = ? LIMIT 1").bind(username).first();
  if (dupUser) {
    return json({ error: "USERNAME_EXISTS", message: "Username sudah dipakai." }, { status: 409 });
  }
  if (email) {
    const dupEmail = await env.DB.prepare("SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1").bind(email).first();
    if (dupEmail) {
      return json({ error: "EMAIL_EXISTS", message: "Email sudah dipakai." }, { status: 409 });
    }
  }

  const salt = generateSalt();
  const hash = await hashPassword(password, salt);
  const userId = crypto.randomUUID();
  try {
    await env.DB.prepare(
      "INSERT INTO users (id, username, password_hash, salt, role, name, email, active, created_at) VALUES (?, ?, ?, ?, 'admin', ?, ?, 1, CURRENT_TIMESTAMP)"
    ).bind(userId, username, hash, salt, name || null, email || null).run();
  } catch {
    return json({ error: "USERNAME_EXISTS", message: "Username sudah dipakai." }, { status: 409 });
  }

  return json({
    success: true,
    admin: { id: userId, username, name: name || null, email: email || null, role: 'admin', active: 1 }
  }, { status: 201 });
}

// PATCH /api/admins/:id — ubah akun admin lain.
// TIDAK menerima/menerapkan role (superadmin hanya lewat bootstrap) dan tidak ada DELETE.
export async function updateAdmin(adminId: string, req: Request, env: Env, sessionUserId: string) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const existing = await env.DB.prepare(
    "SELECT id, username, role, active FROM users WHERE id = ? LIMIT 1"
  ).bind(adminId).first<{ id: string; username: string; role: UserRole; active: number }>();
  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Akun tidak ditemukan." }, { status: 404 });
  }
  if (existing.role === 'superadmin') {
    // Termasuk diri sendiri: profil superadmin di luar scope endpoint ini.
    return json({ error: "FORBIDDEN", message: "Akun superadmin tidak dapat diubah lewat Kelola Admin." }, { status: 403 });
  }

  const body = await safeJson(req);
  if ('role' in body) {
    // Role hanya lewat bootstrap (ensureSuperAdmin) — endpoint ini tidak mengubah role.
    return json({ error: "FORBIDDEN", message: "Role tidak dapat diubah dari Kelola Admin." }, { status: 403 });
  }
  if ('password' in body) {
    // Ganti/reset password = urusan admin masing-masing via "Lupa password?" (OTP email).
    return json({ error: "FORBIDDEN", message: "Password tidak dapat diubah dari Kelola Admin." }, { status: 403 });
  }
  const rawUsername = typeof body.username === 'string' ? body.username : null;
  const hasUsername = rawUsername !== null;
  const hasEmail = 'email' in body;
  const hasName = 'name' in body;
  const hasActive = typeof body.active === 'boolean';

  if (!hasUsername && !hasEmail && !hasName && !hasActive) {
    return json({ error: "INVALID_INPUT", message: "Tidak ada perubahan yang diberikan." }, { status: 400 });
  }

  if (adminId === sessionUserId && hasActive && body.active === false) {
    return json({ error: "CANNOT_DEACTIVATE_SELF", message: "Tidak bisa menonaktifkan akun sendiri." }, { status: 403 });
  }

  const updates: string[] = [];
  const binds: (string | number | null)[] = [];

  if (hasUsername) {
    const username = (rawUsername || '').trim();
    if (!username) {
      return json({ error: "INVALID_INPUT", message: "Username tidak boleh kosong." }, { status: 400 });
    }
    if (username !== existing.username) {
      const dup = await env.DB.prepare("SELECT id FROM users WHERE username = ? AND id != ? LIMIT 1").bind(username, adminId).first();
      if (dup) {
        return json({ error: "USERNAME_EXISTS", message: "Username sudah dipakai." }, { status: 409 });
      }
    }
    updates.push("username = ?");
    binds.push(username);
  }

  if (hasEmail) {
    const email = normalizeEmail(body.email);
    if (email && !email.includes('@')) {
      return json({ error: "INVALID_INPUT", message: "Email tidak valid." }, { status: 400 });
    }
    if (email) {
      const dup = await env.DB.prepare("SELECT id FROM users WHERE LOWER(email) = ? AND id != ? LIMIT 1").bind(email, adminId).first();
      if (dup) {
        return json({ error: "EMAIL_EXISTS", message: "Email sudah dipakai." }, { status: 409 });
      }
    }
    updates.push("email = ?");
    binds.push(email || null);
  }

  if (hasName) {
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    updates.push("name = ?");
    binds.push(name || null);
  }

  if (hasActive) {
    updates.push("active = ?");
    binds.push(body.active ? 1 : 0);
  }

  await env.DB.prepare(
    `UPDATE users SET ${updates.join(', ')} WHERE id = ?`
  ).bind(...binds, adminId).run();

  return json({ success: true });
}
