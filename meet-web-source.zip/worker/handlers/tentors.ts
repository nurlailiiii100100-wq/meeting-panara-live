import type { TentorRow } from '../auth';
import { json, safeJson } from '../lib/utils';

export async function listTentors(meetingId: string, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const result = await env.DB.prepare("SELECT id, meeting_id, name, created_at FROM tentors WHERE meeting_id = ? ORDER BY name ASC").bind(meetingId).all<TentorRow>();
  return json({ tentors: result.results || [] });
}

export async function createTentor(req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const body = await safeJson(req);
  const meetingId = typeof body.meeting_id === 'string' ? body.meeting_id.trim() : '';
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!meetingId) {
    return json({ error: "INVALID_INPUT", message: "meeting_id is required" }, { status: 400 });
  }
  if (!name) {
    return json({ error: "INVALID_INPUT", message: "Tentor name is required" }, { status: 400 });
  }
  const duplicate = await env.DB.prepare("SELECT id FROM tentors WHERE meeting_id = ? AND name = ? LIMIT 1").bind(meetingId, name).first();
  if (duplicate) {
    return json({ error: "TENTOR_NAME_EXISTS", message: "A tentor with this name already exists in this meeting" }, { status: 409 });
  }
  const tentorId = crypto.randomUUID();
  try {
    await env.DB.prepare("INSERT INTO tentors (id, meeting_id, name, created_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)").bind(tentorId, meetingId, name).run();
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes('UNIQUE') || msg.includes('unique')) {
      return json({ error: "TENTOR_NAME_EXISTS", message: "A tentor with this name already exists in this meeting" }, { status: 409 });
    }
    console.error('[Tentor] createTentor DB error:', msg);
    return json({ error: "SERVER_ERROR", message: "Failed to create tentor: " + msg }, { status: 500 });
  }
  return json({ success: true, tentor: { id: tentorId, meeting_id: meetingId, name } }, { status: 201 });
}

export async function updateTentor(tentorId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const existing = await env.DB.prepare("SELECT id, meeting_id, name FROM tentors WHERE id = ? LIMIT 1").bind(tentorId).first<TentorRow>();
  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Tentor not found" }, { status: 404 });
  }
  const body = await safeJson(req);
  const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : existing.name;
  if (name !== existing.name) {
    const duplicate = await env.DB.prepare("SELECT id FROM tentors WHERE meeting_id = ? AND name = ? AND id != ? LIMIT 1").bind(existing.meeting_id, name, existing.id).first();
    if (duplicate) {
      return json({ error: "TENTOR_NAME_EXISTS", message: "A tentor with this name already exists in this meeting" }, { status: 409 });
    }
  }
  await env.DB.prepare("UPDATE tentors SET name = ? WHERE id = ?").bind(name, existing.id).run();
  return json({ success: true, tentor: { id: existing.id, meeting_id: existing.meeting_id, name } });
}

export async function deleteTentor(tentorId: string, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const existing = await env.DB.prepare("SELECT id FROM tentors WHERE id = ? LIMIT 1").bind(tentorId).first();
  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Tentor not found" }, { status: 404 });
  }
  await env.DB.prepare("DELETE FROM tentors WHERE id = ?").bind(tentorId).run();
  return json({ success: true, message: "Tentor deleted successfully" });
}
