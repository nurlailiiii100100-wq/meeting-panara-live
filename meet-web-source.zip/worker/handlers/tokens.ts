import { getSessionFromRequest, isOperatorRole, type MeetingRow, type TentorRow } from '../auth';
import { evaluateHostCode, type HostCodeReason } from '../lib/hostCode';
import { createHostUploadToken } from '../lib/uploadToken';
import {
  json,
  safeJson,
  normalizeRetentionHours,
  fetchKitParticipants,
  DEFAULT_HOST_RESOLUTION,
  DEFAULT_MEMBER_RESOLUTION,
  DEFAULT_LATE_JOIN_MINUTES
} from '../lib/utils';

type IssueTokenResponse = { data?: { token?: string }; token?: string; auth_token?: string };

export async function issueToken(req: Request, env: Env) {
  const input = await safeJson(req);
  const requestedMeetingId = typeof input.meetingId === 'string' ? input.meetingId.trim() : undefined;
  const userId = typeof input.userId === 'string' ? input.userId.trim() : undefined;
  const name = typeof input.name === 'string' ? input.name.trim() : undefined;
  const hostCode = typeof input.hostCode === 'string' ? input.hostCode.trim() : '';
  let presetName = typeof input.presetName === 'string' ? input.presetName.trim() : undefined;

  if (!requestedMeetingId || !userId) {
    return json({ error: "INVALID_INPUT", message: "meetingId and userId are required" }, { status: 400 });
  }

  const session = await getSessionFromRequest(req, env);
  // Superadmin is an account manager, not an operator: never allowed to
  // obtain a meeting token (host OR member). Checked before any DB write,
  // schedule handling, tentor elevation, or provider call.
  if (session && session.role === 'superadmin') {
    return json({ error: "FORBIDDEN", message: "Superadmin is not allowed to join meetings." }, { status: 403 });
  }
  let isAdmin = session != null && isOperatorRole(session.role);
  let isTentor = false;
  // Kode host: elevasi nama tentor hanya bila meetings.host_join_code cocok.
  // hostCodeVerified = kode benar (boleh menembus cek okupansi nama).
  let hostCodeVerified = false;
  let hostCodeError: Exclude<HostCodeReason, 'no_code' | 'not_tentor'> | null = null;

  let providerMeetingId = requestedMeetingId;
  let meetingRecord: MeetingRow | null = null;

  if (env.DB) {
    // public_id is only unique among live rows (older databases were created without
    // the UNIQUE constraint, so soft-deleted rows can share one). Order so a live row
    // always wins; a deleted row is only returned when nothing else matches, which is
    // what the 404 below is for.
    meetingRecord = await env.DB.prepare(
      "SELECT id, public_id, provider_meeting_id, name, max_participants, duration_minutes, host_resolution, member_resolution, allow_member_whiteboard, allow_member_annotation, category_id, auto_record, recording_retention_hours, host_join_code, late_join_minutes, max_active_cameras, status, scheduled_at, timezone, started_at, expires_at FROM meetings WHERE (id = ? OR public_id = ? OR provider_meeting_id = ?) ORDER BY CASE WHEN status = 'deleted' THEN 1 ELSE 0 END, updated_at DESC LIMIT 1"
    ).bind(requestedMeetingId, requestedMeetingId, requestedMeetingId).first<MeetingRow>();

    if (meetingRecord) {
      if (meetingRecord.status === 'deleted') {
        return json({ error: "MEETING_NOT_FOUND", message: "This meeting does not exist or has been deleted." }, { status: 404 });
      }

      providerMeetingId = meetingRecord.provider_meeting_id;

      // Elevate registered tentor to host BEFORE any join gates (schedule etc).
      // When the meeting has a host_join_code, the name alone is not enough:
      // the client must present the code, otherwise they join as a member.
      if (!isAdmin && name) {
        const tentor = await env.DB.prepare(
          "SELECT id FROM tentors WHERE meeting_id = ? AND lower(name) = lower(?) LIMIT 1"
        ).bind(meetingRecord.id, name).first<TentorRow>();
        if (tentor) {
          const verdict = evaluateHostCode({
            meetingId: meetingRecord.id,
            ip: req.headers.get('CF-Connecting-IP') || 'unknown',
            expected: meetingRecord.host_join_code,
            provided: hostCode,
            tentorNameMatched: true
          });
          if (verdict.granted) {
            isTentor = true;
            isAdmin = true;
            hostCodeVerified = Boolean((meetingRecord.host_join_code || '').trim());
          } else {
            hostCodeError = verdict.reason === 'locked' ? 'locked' : verdict.reason === 'required' ? 'required' : 'invalid';
          }
        }
      }

      // Closed lifecycle states never come back to life via a NULL timer.
      if (meetingRecord.status === 'ended' || meetingRecord.status === 'expired') {
        return json(
          meetingRecord.status === 'ended'
            ? { error: "MEETING_ENDED", message: "This meeting has ended. Ask the host to reopen it." }
            : { error: "MEETING_EXPIRED", message: "This meeting has expired. Ask the host to reopen it." },
          { status: 403 }
        );
      }

      // 0. Schedule Enforcement — only before the meeting is started for the first time.
      const now = new Date();
      const scheduledMs = meetingRecord.scheduled_at ? new Date(meetingRecord.scheduled_at).getTime() : NaN;
      // An unparseable scheduled_at is treated as "no schedule" (never blocks), as before.
      const scheduleReached = Number.isNaN(scheduledMs) || now.getTime() >= scheduledMs;
      // Class slot = [scheduled_at, scheduled_at + duration]. A meeting that was
      // never opened by the end of its slot is missed: nobody may join (the host
      // reopens it via "Buka Kembali"/"Mulai Sekarang" on the dashboard).
      if (meetingRecord.scheduled_at && !meetingRecord.started_at && !Number.isNaN(scheduledMs)) {
        const windowEndMs = scheduledMs + (meetingRecord.duration_minutes || 60) * 60_000;
        if (now.getTime() > windowEndMs) {
          return json(
            { error: "MEETING_MISSED", message: "This class's scheduled time has passed. Ask the host to reopen the meeting." },
            { status: 403 }
          );
        }
      }
      if (meetingRecord.scheduled_at && !meetingRecord.started_at && !isAdmin && !scheduleReached) {
        return json({ error: "MEETING_NOT_STARTED", message: "This meeting is scheduled for a future time. Please wait until the scheduled time." }, { status: 403 });
      }

      // 0b. Kick cooldown — a member who was just kicked waits out the meeting's
      // jeda (kick_cooldown_minutes, 0 = none) before rejoining. Hosts exempt.
      if (!isAdmin) {
        const activeKick = await env.DB.prepare(
          "SELECT expires_at FROM meeting_kicks WHERE meeting_id = ? AND user_id = ? AND expires_at > ? ORDER BY expires_at DESC LIMIT 1"
        ).bind(meetingRecord.id, userId, now.toISOString()).first<{ expires_at: string }>();
        if (activeKick) {
          const retryAfterSeconds = Math.max(1, Math.ceil((new Date(activeKick.expires_at).getTime() - now.getTime()) / 1000));
          const remainingMinutes = Math.ceil(retryAfterSeconds / 60);
          return json(
            {
              error: "KICKED_COOLDOWN",
              message: `You were removed from this meeting. You can rejoin in ${remainingMinutes} minute${remainingMinutes === 1 ? "" : "s"}.`,
              retry_after_seconds: retryAfterSeconds
            },
            { status: 403 }
          );
        }
      }
      if (meetingRecord.scheduled_at && !meetingRecord.started_at && !isAdmin && !scheduleReached) {
        return json({ error: "MEETING_NOT_STARTED", message: "This meeting is scheduled for a future time. Please wait until the scheduled time." }, { status: 403 });
      }

      // 1. Duration & Expiration Check
      if (meetingRecord.expires_at) {
        const expiresAt = new Date(meetingRecord.expires_at);
        if (now > expiresAt) {
          // status here can only be 'scheduled' | 'active' (closed states returned above)
          await env.DB.prepare("UPDATE meetings SET status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE id = ?").bind(meetingRecord.id).run();
          return json({ error: "MEETING_EXPIRED", message: "This meeting has reached its duration limit and expired." }, { status: 403 });
        }
      } else if ((meetingRecord.status === 'scheduled' || meetingRecord.status === 'active') && scheduleReached) {
        // First token starts the timer (§40a) — but ONLY once the schedule is due.
        // An admin/tentor previewing before scheduled_at must not start the duration
        // and must not lift the schedule gate for members (started_at stays NULL).
        const durationMin = meetingRecord.duration_minutes || 60;
        const startedAtStr = now.toISOString();
        const expiresAtStr = new Date(now.getTime() + durationMin * 60 * 1000).toISOString();
        await env.DB.prepare(
          "UPDATE meetings SET started_at = ?, expires_at = ?, status = 'active', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
        ).bind(startedAtStr, expiresAtStr, meetingRecord.id).run();
        // Refleksikan ke record di memori: respons token (expires_at) harus
        // memuat deadline baru juga bagi joiner pertama yang memulai timer.
        // Tanpa ini klien tanpa polling (mobile) tidak menerima waktu berakhir.
        meetingRecord.started_at = startedAtStr;
        meetingRecord.expires_at = expiresAtStr;
      }

      // 2. Participant Limit & Reconnect Check + Tentor Name Occupancy
      if (env.ACCOUNT_ID && env.APP_ID && env.CF_API_TOKEN) {
        const currentParts = await fetchKitParticipants(env, providerMeetingId);

        if (currentParts === null) {
          // Fail-closed: the provider could not be asked, so capacity is unknown.
          // Never hand out a participant token when the limit cannot be verified
          // (hosts are exempt — they are not counted against max_participants).
          if (!isAdmin) {
            return json({
              error: "CAPACITY_CHECK_UNAVAILABLE",
              message: "Participant capacity could not be verified because the video provider is unavailable. Please try again in a moment."
            }, { status: 503 });
          }
        } else {
          const knownParts = currentParts;

          const isExistingParticipant = knownParts.some((p) => {
            const customId = typeof p.custom_participant_id === 'string' ? p.custom_participant_id : (typeof p.customParticipantId === 'string' ? p.customParticipantId : undefined);
            const pid = typeof p.id === 'string' ? p.id : undefined;
            return customId === userId || pid === userId;
          });

          // 2b. Late-join cutoff — late_join_minutes after scheduled_at, members
          // only (hosts exempt). A participant already in the room reconnecting
          // is not blocked; only someone arriving fresh past the cutoff is.
          // 0 disables the cutoff. Meetings without a schedule have no cutoff.
          const lateJoinMinutes = meetingRecord.late_join_minutes ?? DEFAULT_LATE_JOIN_MINUTES;
          if (
            !isAdmin &&
            lateJoinMinutes > 0 &&
            meetingRecord.scheduled_at &&
            !Number.isNaN(scheduledMs) &&
            now.getTime() > scheduledMs + lateJoinMinutes * 60_000 &&
            !isExistingParticipant
          ) {
            return json(
              {
                error: "LATE_JOIN_CLOSED",
                message: `This meeting's join cutoff has passed (more than ${lateJoinMinutes} minute${lateJoinMinutes === 1 ? "" : "s"} after the scheduled start). Ask the host if you still need to join.`
              },
              { status: 403 }
            );
          }

          // A code-verified tentor keeps host even if someone else already uses
          // the name (the code proves who they are); without a code the old
          // occupancy guard still demotes them.
          if (isTentor && !hostCodeVerified && !isExistingParticipant && name) {
            const nameTaken = knownParts.some((p) => {
              const pName = typeof p.name === 'string' ? p.name : undefined;
              return pName && pName.toLowerCase() === name.toLowerCase();
            });
            if (nameTaken) {
              isAdmin = false;
              isTentor = false;
            }
          }

          if (!isAdmin && !isExistingParticipant) {
            const guestParts = knownParts.filter((p) => p.preset_name !== 'group_call_host');
            const uniqueGuestIds = new Set<string>();
            for (const p of guestParts) {
              const uid = (typeof p.custom_participant_id === 'string' && p.custom_participant_id) || (typeof p.id === 'string' && p.id);
              if (uid) uniqueGuestIds.add(uid);
            }

            if (uniqueGuestIds.size >= meetingRecord.max_participants) {
              return json({
                error: "MEETING_FULL",
                message: `Meeting is full. Maximum participant limit (${meetingRecord.max_participants}) reached.`,
                participants: uniqueGuestIds.size
              }, { status: 403 });
            }
          }
        }
      }
    }
  }

  if (isAdmin) {
    presetName = 'group_call_host';
  } else if (presetName && presetName !== 'group_call_participant') {
    presetName = 'group_call_participant';
  } else if (!presetName) {
    presetName = 'group_call_participant';
  }

  const accountId = env.ACCOUNT_ID;
  const appId = env.APP_ID;
  const apiToken = env.CF_API_TOKEN;

  if (!accountId || !appId || !apiToken) {
    return json({ error: "SERVER_CONFIG_ERROR", message: "RealtimeKit credentials missing in environment" }, { status: 500 });
  }

  const r = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/realtime/kit/${appId}/meetings/${providerMeetingId}/participants`,
    {
      method: "POST",
      headers: {
        authorization: `Bearer ${apiToken}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        name: name || (isAdmin ? 'Admin' : 'Guest'),
        preset_name: presetName,
        custom_participant_id: userId
      })
    }
  );

  if (!r.ok) {
    return json({ error: "TOKEN_ISSUE_FAILED", message: "Failed to issue participant token" }, { status: r.status });
  }

  const body = (await r.json()) as unknown as IssueTokenResponse;
  const auth_token = body.data?.token ?? body.auth_token ?? body.token;

  const hostRes = meetingRecord?.host_resolution || DEFAULT_HOST_RESOLUTION;
  const memberRes = meetingRecord?.member_resolution || DEFAULT_MEMBER_RESOLUTION;
  const maxAllowedRes = isAdmin ? hostRes : memberRes;

  // Rekaman client-side butuh izin unggah ke /api/recordings/upload.
  // Hanya host (admin login / tentor berkode host) yang menerimanya.
  let uploadToken: string | null = null;
  if (isAdmin && meetingRecord) {
    try {
      const meetingExpiryMs = meetingRecord.expires_at ? Date.parse(meetingRecord.expires_at) : NaN;
      const tokenExpiryMs = Number.isFinite(meetingExpiryMs)
        ? meetingExpiryMs
        : Date.now() + 12 * 60 * 60 * 1000;
      uploadToken = await createHostUploadToken(env, req.url, meetingRecord.id, tokenExpiryMs);
    } catch (e) {
      console.warn('Host upload token issuance failed:', e);
    }
  }

  return json({
    auth_token,
    meeting_id: meetingRecord ? (meetingRecord.public_id || meetingRecord.id) : providerMeetingId,
    public_id: meetingRecord?.public_id || null,
    provider_meeting_id: providerMeetingId,
    expires_at: meetingRecord?.expires_at || null,
    duration_minutes: meetingRecord?.duration_minutes || null,
    host_resolution: hostRes,
    member_resolution: memberRes,
    max_allowed_resolution: maxAllowedRes,
    allow_member_whiteboard: meetingRecord?.allow_member_whiteboard === 1 || meetingRecord?.allow_member_whiteboard === true,
    allow_member_annotation: meetingRecord?.allow_member_annotation === 1 || meetingRecord?.allow_member_annotation === true,
    max_active_cameras: Math.max(0, Math.floor(Number(meetingRecord?.max_active_cameras) || 0)),
    auto_record: meetingRecord?.auto_record === 1 || meetingRecord?.auto_record === true,
    recording_retention_hours: normalizeRetentionHours(meetingRecord?.recording_retention_hours),
    scheduled_at: meetingRecord?.scheduled_at || null,
    user_role: isAdmin ? 'admin' : 'member',
    ...(uploadToken ? { upload_token: uploadToken } : {}),
    ...(hostCodeError ? { host_code_error: hostCodeError } : {})
  });
}
