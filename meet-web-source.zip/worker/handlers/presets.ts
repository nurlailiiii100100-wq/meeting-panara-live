import type { PresetRow } from '../auth';
import { json, safeJson, VALID_RESOLUTIONS, DEFAULT_HOST_RESOLUTION, DEFAULT_MEMBER_RESOLUTION } from '../lib/utils';

export async function listPresets(env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const result = await env.DB.prepare(
    "SELECT id, name, max_participants, duration_minutes, host_resolution, member_resolution, created_by, created_at, updated_at FROM presets ORDER BY name ASC"
  ).all<PresetRow>();

  const presets = result.results || [];
  return json({ presets });
}

export async function createPreset(req: Request, env: Env, createdByUserId: string) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const body = await safeJson(req);
  const name = typeof body.name === 'string' ? body.name.trim() : '';

  if (!name) {
    return json({ error: "INVALID_INPUT", message: "Preset name is required" }, { status: 400 });
  }

  const duplicate = await env.DB.prepare("SELECT id FROM presets WHERE name = ? LIMIT 1").bind(name).first();
  if (duplicate) {
    return json({ error: "PRESET_NAME_EXISTS", message: "A preset with this name already exists" }, { status: 409 });
  }

  const maxParticipants = typeof body.max_participants === 'number' && body.max_participants >= 1 && body.max_participants <= 500
    ? Math.floor(body.max_participants)
    : (typeof body.maxParticipants === 'number' && body.maxParticipants >= 1 && body.maxParticipants <= 500 ? Math.floor(body.maxParticipants) : 20);

  const durationMinutes = typeof body.duration_minutes === 'number' && body.duration_minutes >= 1 && body.duration_minutes <= 1440
    ? Math.floor(body.duration_minutes)
    : (typeof body.durationMinutes === 'number' && body.durationMinutes >= 1 && body.durationMinutes <= 1440 ? Math.floor(body.durationMinutes) : 60);

  const hostResolution = typeof body.host_resolution === 'string' && VALID_RESOLUTIONS.includes(body.host_resolution)
    ? body.host_resolution
    : (typeof body.hostResolution === 'string' && VALID_RESOLUTIONS.includes(body.hostResolution) ? body.hostResolution : DEFAULT_HOST_RESOLUTION);

  const memberResolution = typeof body.member_resolution === 'string' && VALID_RESOLUTIONS.includes(body.member_resolution)
    ? body.member_resolution
    : (typeof body.memberResolution === 'string' && VALID_RESOLUTIONS.includes(body.memberResolution) ? body.memberResolution : DEFAULT_MEMBER_RESOLUTION);

  const presetId = crypto.randomUUID();
  await env.DB.prepare(
    "INSERT INTO presets (id, name, max_participants, duration_minutes, host_resolution, member_resolution, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
  ).bind(presetId, name, maxParticipants, durationMinutes, hostResolution, memberResolution, createdByUserId).run();

  return json({
    success: true,
    preset: {
      id: presetId,
      name,
      max_participants: maxParticipants,
      duration_minutes: durationMinutes,
      host_resolution: hostResolution,
      member_resolution: memberResolution
    }
  }, { status: 201 });
}

export async function updatePreset(presetId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const existing = await env.DB.prepare("SELECT * FROM presets WHERE id = ? LIMIT 1").bind(presetId).first<PresetRow>();
  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Preset not found" }, { status: 404 });
  }

  const body = await safeJson(req);
  const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : existing.name;

  if (name !== existing.name) {
    const duplicate = await env.DB.prepare("SELECT id FROM presets WHERE name = ? AND id != ? LIMIT 1").bind(name, existing.id).first();
    if (duplicate) {
      return json({ error: "PRESET_NAME_EXISTS", message: "A preset with this name already exists" }, { status: 409 });
    }
  }

  let maxParticipants = existing.max_participants;
  if (typeof body.max_participants === 'number' && body.max_participants >= 1 && body.max_participants <= 500) {
    maxParticipants = Math.floor(body.max_participants);
  } else if (typeof body.maxParticipants === 'number' && body.maxParticipants >= 1 && body.maxParticipants <= 500) {
    maxParticipants = Math.floor(body.maxParticipants);
  }

  let durationMinutes = existing.duration_minutes;
  if (typeof body.duration_minutes === 'number' && body.duration_minutes >= 1 && body.duration_minutes <= 1440) {
    durationMinutes = Math.floor(body.duration_minutes);
  } else if (typeof body.durationMinutes === 'number' && body.durationMinutes >= 1 && body.durationMinutes <= 1440) {
    durationMinutes = Math.floor(body.durationMinutes);
  }

  let hostResolution = existing.host_resolution;
  const rawHostRes = body.host_resolution || body.hostResolution;
  if (typeof rawHostRes === 'string' && VALID_RESOLUTIONS.includes(rawHostRes)) {
    hostResolution = rawHostRes;
  }

  let memberResolution = existing.member_resolution;
  const rawMemberRes = body.member_resolution || body.memberResolution;
  if (typeof rawMemberRes === 'string' && VALID_RESOLUTIONS.includes(rawMemberRes)) {
    memberResolution = rawMemberRes;
  }

  await env.DB.prepare(
    "UPDATE presets SET name = ?, max_participants = ?, duration_minutes = ?, host_resolution = ?, member_resolution = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(name, maxParticipants, durationMinutes, hostResolution, memberResolution, existing.id).run();

  return json({
    success: true,
    preset: {
      id: existing.id,
      name,
      max_participants: maxParticipants,
      duration_minutes: durationMinutes,
      host_resolution: hostResolution,
      member_resolution: memberResolution
    }
  });
}

export async function deletePreset(presetId: string, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const existing = await env.DB.prepare("SELECT id FROM presets WHERE id = ? LIMIT 1").bind(presetId).first();
  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Preset not found" }, { status: 404 });
  }

  await env.DB.prepare("DELETE FROM presets WHERE id = ?").bind(presetId).run();
  return json({ success: true, message: "Preset deleted successfully" });
}
