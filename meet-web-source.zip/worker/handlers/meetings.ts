import { getSessionFromRequest, isOperatorRole, type MeetingRow, type TentorRow } from '../auth';
import { evaluateHostCode, type HostCodeReason } from '../lib/hostCode';
import {
  json,
  safeJson,
  isValidPublicId,
  generatePublicId,
  normalizeRetentionHours,
  isValidHostCode,
  randomHostCode,
  fetchKitParticipants,
  VALID_RESOLUTIONS,
  DEFAULT_HOST_RESOLUTION,
  DEFAULT_MEMBER_RESOLUTION,
  VALID_SHARE_RESOLUTIONS,
  DEFAULT_SHARE_RESOLUTION,
  parseLateJoinMinutes,
  DEFAULT_LATE_JOIN_MINUTES,
  parseMaxActiveCameras,
  DEFAULT_MAX_ACTIVE_CAMERAS,
  resolveMeetingId
} from '../lib/utils';

export const DEFAULT_KICK_COOLDOWN_MINUTES = 15;

// --- Kunci rekaman (recording lock) -----------------------------------------
// Aturan: SATU perekaman per sesi meeting. Host/admin yang menekan Start
// mengklaim kunci; selama kunci dipegang, host/admin lain tidak bisa memulai
// rekaman, dan hanya operator yang boleh pause/resume/stop.
//
// Kunci dianggap KADALUARSA bila denyut (heartbeat) terakhir lebih tua dari
// RECORDING_LOCK_STALE_SECONDS — mis. tab operator crash atau putus — supaya
// rekaman tidak terkunci selamanya dan host lain bisa mengambil alih.
// (Rekaman otomatis dari VPS pada fase berikutnya memakai kunci yang sama
// dengan sumber 'auto', sehingga aturannya seragam.)
export const RECORDING_LOCK_STALE_SECONDS = 90;

// Kolom opsional karena MeetingRow memakai field opsional (NULL = tanpa kunci).
interface RecordingLockColumns {
  recording_operator_id?: string | null;
  recording_started_at?: string | null;
  recording_heartbeat_at?: string | null;
  recording_source?: string | null;
}

// Timestamp ditulis sebagai ISO-8601 UTC dari JS (bukan CURRENT_TIMESTAMP)
// supaya bisa dibandingkan sebagai teks dan tidak bergantung zona waktu SQLite.
function isoNow(offsetMs = 0): string {
  return new Date(Date.now() + offsetMs).toISOString();
}

// Bentuk kunci rekaman untuk klien. Perhitungan kadaluarsa dilakukan DI SERVER
// sehingga klien cukup mempercayai `active` — tidak perlu menghitung waktu,
// dan semua host/admin melihat kesimpulan yang sama.
function recordingLockInfo(row: RecordingLockColumns) {
  const operatorId = row.recording_operator_id || null;
  if (!operatorId) {
    return { active: false, operator_id: null, source: null, started_at: null };
  }
  const lastBeat = row.recording_heartbeat_at ? Date.parse(row.recording_heartbeat_at) : NaN;
  const stale = !Number.isFinite(lastBeat) || Date.now() - lastBeat > RECORDING_LOCK_STALE_SECONDS * 1000;
  if (stale) {
    return { active: false, operator_id: null, source: null, started_at: null };
  }
  return {
    active: true,
    operator_id: operatorId,
    source: row.recording_source || null,
    started_at: row.recording_started_at || null
  };
}

async function readOperatorId(req: Request): Promise<string> {
  const body = await safeJson(req);
  return typeof body.operator_id === 'string' ? body.operator_id.trim() : '';
}

// Klaim kunci rekaman. Dilakukan sebagai SATU UPDATE bersyarat (atomik) sehingga
// dua host/admin yang menekan Start pada saat bersamaan tidak sama-sama menang —
// hanya satu yang mendapat perubahan baris, satunya menerima 409.
export async function claimRecordingLock(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  // Catatan: body hanya boleh dibaca SEKALI (req.json() menghabiskan stream),
  // jadi operator_id dan source diambil dari pembacaan yang sama.
  const body = await safeJson(req);
  const operatorId = typeof body.operator_id === 'string' ? body.operator_id.trim() : '';
  if (!operatorId) {
    return json({ error: "INVALID_INPUT", message: "operator_id is required" }, { status: 400 });
  }
  const resolved = await resolveMeetingId(meetingId, env);
  if (!resolved) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  const now = isoNow();
  const staleBefore = isoNow(-RECORDING_LOCK_STALE_SECONDS * 1000);
  const source = body.source === 'auto' ? 'auto' : 'manual';

  const result = await env.DB.prepare(
    `UPDATE meetings
        SET recording_operator_id = ?, recording_started_at = ?, recording_heartbeat_at = ?,
            recording_source = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND status != 'deleted'
        AND ( recording_operator_id IS NULL              -- kunci kosong
           OR recording_operator_id = ?                  -- operator yang sama boleh klaim ulang (mis. reload)
           OR recording_heartbeat_at IS NULL             -- kunci tanpa denyut → dianggap kadaluarsa
           OR recording_heartbeat_at < ? )`
  ).bind(operatorId, now, now, source, resolved, operatorId, staleBefore).run();

  if (!result.meta.changes) {
    return json(
      { error: "LOCKED", message: "Meeting ini sedang direkam oleh host lain" },
      { status: 409 }
    );
  }
  return json({ ok: true, recording_lock: { active: true, operator_id: operatorId, source, started_at: now } });
}

// Denyut (heartbeat) — dipanggil operator selama merekam. 409 berarti kunci
// sudah diambil alih host lain, jadi operator harus menghentikan rekamannya.
export async function heartbeatRecordingLock(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const operatorId = await readOperatorId(req);
  if (!operatorId) {
    return json({ error: "INVALID_INPUT", message: "operator_id is required" }, { status: 400 });
  }
  const resolved = await resolveMeetingId(meetingId, env);
  if (!resolved) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  const result = await env.DB.prepare(
    `UPDATE meetings SET recording_heartbeat_at = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND recording_operator_id = ?`
  ).bind(isoNow(), resolved, operatorId).run();

  if (!result.meta.changes) {
    return json(
      { error: "LOCKED", message: "Kunci rekaman sudah diambil alih" },
      { status: 409 }
    );
  }
  return json({ ok: true });
}

// Lepas kunci rekaman setelah berhenti, supaya host lain boleh memulai rekaman
// berikutnya. Idempoten: melepas kunci yang bukan milik kita tetap dianggap
// sukses (tidak merusak kunci milik operator lain).
export async function releaseRecordingLock(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const operatorId = await readOperatorId(req);
  if (!operatorId) {
    return json({ error: "INVALID_INPUT", message: "operator_id is required" }, { status: 400 });
  }
  const resolved = await resolveMeetingId(meetingId, env);
  if (!resolved) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  const result = await env.DB.prepare(
    `UPDATE meetings
        SET recording_operator_id = NULL, recording_started_at = NULL,
            recording_heartbeat_at = NULL, recording_source = NULL,
            updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND recording_operator_id = ?`
  ).bind(resolved, operatorId).run();

  return json({ ok: true, released: Boolean(result.meta.changes) });
}

// Lama jeda join ulang setelah di-kick (menit). 0 = tanpa jeda, maks 24 jam.
function parseKickCooldownMinutes(raw: unknown, fallback: number): number {
  if (raw === undefined || raw === null || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(1440, Math.max(0, Math.floor(n)));
}

export async function updateAnnotationPermission(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const body = await safeJson(req);
  const allowed = body.allow_member_annotation === true || body.allow_member_annotation === 1 ? 1 : 0;

  await env.DB.prepare(
    "UPDATE meetings SET allow_member_annotation = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(allowed, meetingId).run();

  return json({ ok: true, allow_member_annotation: allowed === 1 });
}

export async function listMeetings(_req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  try {
    // Auto-expire meetings whose duration has passed
    const now = new Date().toISOString();
    await env.DB.prepare(
      "UPDATE meetings SET status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= ?"
    ).bind(now).run();

    // Auto-expire never-opened meetings whose slot [scheduled_at, scheduled_at
    // + duration] has passed — otherwise they linger in "Upcoming" forever.
    await env.DB.prepare(
      "UPDATE meetings SET status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE status = 'scheduled' AND started_at IS NULL AND scheduled_at IS NOT NULL AND datetime(scheduled_at, printf('+%d minutes', COALESCE(duration_minutes, 60))) <= datetime(?)"
    ).bind(now).run();

    const result = await env.DB.prepare(
      "SELECT m.id, m.public_id, m.provider_meeting_id, m.name, m.created_by, m.max_participants, m.duration_minutes, m.host_resolution, m.member_resolution, m.screenshare_resolution, m.allow_member_whiteboard, m.allow_member_annotation, m.category_id, m.auto_record, m.recording_retention_hours, m.kick_cooldown_minutes, m.late_join_minutes, m.max_active_cameras, m.status, m.scheduled_at, m.timezone, m.started_at, m.expires_at, m.created_at, m.updated_at, (SELECT c.name FROM categories c WHERE c.id = m.category_id) AS category_name, (SELECT group_concat(t.name, ', ') FROM tentors t WHERE t.meeting_id = m.id) AS tentor_names FROM meetings m WHERE m.status != 'deleted' ORDER BY m.created_at DESC"
    ).all<MeetingRow & { tentor_names?: string | null }>();

    const meetings = result.results || [];
    return json({ meetings });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return json({ error: "SERVER_ERROR", message: "Failed to list meetings: " + msg }, { status: 500 });
  }
}

export async function createMeeting(req: Request, env: Env, createdByUserId: string) {
  const body = await safeJson(req);
  const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : (typeof body.title === 'string' && body.title.trim() ? body.title.trim() : '');

  if (!name) {
    return json({ error: "INVALID_INPUT", message: "Meeting name is required" }, { status: 400 });
  }

  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  // Handle Custom Public ID
  let publicId = typeof body.public_id === 'string' && body.public_id.trim()
    ? body.public_id.trim()
    : (typeof body.publicId === 'string' && body.publicId.trim() ? body.publicId.trim() : '');

  if (publicId) {
    if (!isValidPublicId(publicId)) {
      return json({
        error: "INVALID_CUSTOM_ID",
        message: "Meeting ID must be 3-50 characters long and contain only letters, numbers, hyphens, and underscores."
      }, { status: 400 });
    }

    const existing = await env.DB.prepare(
      "SELECT id FROM meetings WHERE public_id = ? AND status != 'deleted' LIMIT 1"
    ).bind(publicId).first();

    if (existing) {
      return json({
        error: "MEETING_ID_ALREADY_EXISTS",
        message: "This Meeting ID is already taken. Please choose another one."
      }, { status: 409 });
    }
  } else {
    let uniqueFound = false;
    let attempts = 0;
    while (!uniqueFound && attempts < 5) {
      const candidate = generatePublicId(name);
      const exists = await env.DB.prepare(
        "SELECT id FROM meetings WHERE public_id = ? AND status != 'deleted' LIMIT 1"
      ).bind(candidate).first();
      if (!exists) {
        publicId = candidate;
        uniqueFound = true;
      }
      attempts++;
    }
    if (!publicId) {
      publicId = `meet-${crypto.randomUUID().slice(0, 8)}`;
    }
  }

  const maxParticipants = typeof body.max_participants === 'number' && body.max_participants >= 1 && body.max_participants <= 500
    ? Math.floor(body.max_participants)
    : (typeof body.maxParticipants === 'number' && body.maxParticipants >= 1 && body.maxParticipants <= 500 ? Math.floor(body.maxParticipants) : 20);

  const durationMinutes = typeof body.duration_minutes === 'number' && body.duration_minutes >= 1 && body.duration_minutes <= 1440
    ? Math.floor(body.duration_minutes)
    : (typeof body.durationMinutes === 'number' && body.durationMinutes >= 1 && body.durationMinutes <= 1440 ? Math.floor(body.durationMinutes) : 60);

  // Resolution policy validation
  const hostResolution = typeof body.host_resolution === 'string' && VALID_RESOLUTIONS.includes(body.host_resolution)
    ? body.host_resolution
    : (typeof body.hostResolution === 'string' && VALID_RESOLUTIONS.includes(body.hostResolution) ? body.hostResolution : DEFAULT_HOST_RESOLUTION);

  const memberResolution = typeof body.member_resolution === 'string' && VALID_RESOLUTIONS.includes(body.member_resolution)
    ? body.member_resolution
    : (typeof body.memberResolution === 'string' && VALID_RESOLUTIONS.includes(body.memberResolution) ? body.memberResolution : DEFAULT_MEMBER_RESOLUTION);

  // Resolusi screen share: cuma 480p/720p (pilihan admin, otomatis dipakai di room)
  const screenshareResolution = typeof body.screenshare_resolution === 'string' && VALID_SHARE_RESOLUTIONS.includes(body.screenshare_resolution)
    ? body.screenshare_resolution
    : (typeof body.screenshareResolution === 'string' && VALID_SHARE_RESOLUTIONS.includes(body.screenshareResolution) ? body.screenshareResolution : DEFAULT_SHARE_RESOLUTION);

  const allowMemberWhiteboard = body.allow_member_whiteboard === true || body.allow_member_whiteboard === 1 ? 1 : 0;
  const allowMemberAnnotation = body.allow_member_annotation === true || body.allow_member_annotation === 1 ? 1 : 0;
  const autoRecord = body.auto_record === true || body.auto_record === 1 ? 1 : 0;
  const recordingRetentionHours = normalizeRetentionHours(body.recording_retention_hours ?? body.recordingRetentionHours ?? 48);
  const kickCooldownMinutes = parseKickCooldownMinutes(
    body.kick_cooldown_minutes ?? body.kickCooldownMinutes,
    DEFAULT_KICK_COOLDOWN_MINUTES
  );
  const lateJoinMinutes = parseLateJoinMinutes(
    body.late_join_minutes ?? body.lateJoinMinutes,
    DEFAULT_LATE_JOIN_MINUTES
  );
  const maxActiveCameras = parseMaxActiveCameras(
    body.max_active_cameras ?? body.maxActiveCameras,
    DEFAULT_MAX_ACTIVE_CAMERAS
  );

  const rawHostJoinCode = typeof body.host_join_code === 'string'
    ? body.host_join_code.trim()
    : (typeof body.hostJoinCode === 'string' ? body.hostJoinCode.trim() : '');
  if (rawHostJoinCode && !isValidHostCode(rawHostJoinCode)) {
    return json({ error: "INVALID_HOST_CODE", message: "Kode host harus 4-10 digit angka." }, { status: 400 });
  }
  const hostJoinCode = rawHostJoinCode || randomHostCode();

  const categoryId = typeof body.category_id === 'string' && body.category_id.trim() ? body.category_id.trim() : (typeof body.categoryId === 'string' && body.categoryId.trim() ? body.categoryId.trim() : null);
  if (categoryId) {
    const cat = await env.DB.prepare("SELECT id FROM categories WHERE id = ? LIMIT 1").bind(categoryId).first<{ id: string }>();
    if (!cat) {
      return json({ error: "INVALID_CATEGORY", message: "Invalid category selected." }, { status: 400 });
    }
  }

  // Schedule & Timezone handling
  let scheduledAt: string | null = null;
  const rawScheduled = body.scheduled_at || body.scheduledAt;
  if (typeof rawScheduled === 'string' && rawScheduled.trim()) {
    const parsedDate = new Date(rawScheduled.trim());
    if (isNaN(parsedDate.getTime())) {
      return json({ error: "INVALID_SCHEDULE_DATE", message: "Invalid scheduled date/time provided." }, { status: 400 });
    }
    if (parsedDate.getTime() < Date.now() - 5 * 60 * 1000) {
      return json({ error: "PAST_SCHEDULE_DATE", message: "Cannot schedule a meeting in the past." }, { status: 400 });
    }
    scheduledAt = parsedDate.toISOString();
  }

  const timezone = typeof body.timezone === 'string' && body.timezone.trim() ? body.timezone.trim() : 'UTC';

  const accountId = env.ACCOUNT_ID;
  const appId = env.APP_ID;
  const apiToken = env.CF_API_TOKEN;

  if (!accountId || !appId || !apiToken) {
    return json({ error: "SERVER_CONFIG_ERROR", message: "RealtimeKit credentials missing in environment" }, { status: 500 });
  }

  // 1. Create meeting on Cloudflare RealtimeKit
  const r = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/realtime/kit/${appId}/meetings`,
    {
      method: "POST",
      headers: {
        authorization: `Bearer ${apiToken}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({ title: name })
    }
  );

  if (!r.ok) {
    return json({ error: "MEETING_CREATE_FAILED", message: "Failed to create meeting with video provider" }, { status: r.status });
  }

  const providerData = (await r.json()) as { id?: string; result?: { id?: string }; data?: { id?: string } };
  const providerMeetingId = providerData.result?.id ?? providerData.data?.id ?? providerData.id;

  if (!providerMeetingId) {
    return json({ error: "PROVIDER_ERROR", message: "Invalid meeting response from video provider" }, { status: 502 });
  }

  // 2. Save meeting metadata snapshot to D1
  const meetingId = crypto.randomUUID();
  await env.DB.prepare(
    "INSERT INTO meetings (id, public_id, provider_meeting_id, name, created_by, max_participants, duration_minutes, host_resolution, member_resolution, screenshare_resolution, allow_member_whiteboard, allow_member_annotation, category_id, auto_record, recording_retention_hours, kick_cooldown_minutes, late_join_minutes, host_join_code, max_active_cameras, status, scheduled_at, timezone, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
  ).bind(meetingId, publicId, providerMeetingId, name, createdByUserId, maxParticipants, durationMinutes, hostResolution, memberResolution, screenshareResolution, allowMemberWhiteboard, allowMemberAnnotation, categoryId, autoRecord, recordingRetentionHours, kickCooldownMinutes, lateJoinMinutes, hostJoinCode, maxActiveCameras, scheduledAt, timezone).run();

  return json({
    id: meetingId,
    public_id: publicId,
    provider_meeting_id: providerMeetingId,
    name,
    max_participants: maxParticipants,
    duration_minutes: durationMinutes,
    host_resolution: hostResolution,
    member_resolution: memberResolution,
    screenshare_resolution: screenshareResolution,
    allow_member_whiteboard: allowMemberWhiteboard === 1,
    allow_member_annotation: allowMemberAnnotation === 1,
    category_id: categoryId,
    auto_record: autoRecord === 1,
    recording_retention_hours: recordingRetentionHours,
    kick_cooldown_minutes: kickCooldownMinutes,
    late_join_minutes: lateJoinMinutes,
    host_join_code: hostJoinCode,
    max_active_cameras: maxActiveCameras,
    status: 'scheduled',
    scheduled_at: scheduledAt,
    timezone
  }, { status: 201 });
}

export async function getMeetingDetail(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  // Auto-expire sebelum dibaca: endpoint ini dipolling klien desktop (3 detik)
  // dan dipakai aplikasi mobile saat join, jadi status 'expired' harus selalu
  // segar di sini — bukan hanya di listMeetings/issueToken (issue #83).
  const nowIso = new Date().toISOString();
  await env.DB.prepare(
    "UPDATE meetings SET status = 'expired', updated_at = CURRENT_TIMESTAMP WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= ?"
  ).bind(nowIso).run();

  const meeting = await env.DB.prepare(
    "SELECT m.id, m.public_id, m.provider_meeting_id, m.name, m.created_by, m.max_participants, m.duration_minutes, m.host_resolution, m.member_resolution, m.screenshare_resolution, m.allow_member_whiteboard, m.allow_member_annotation, m.category_id, m.auto_record, m.recording_retention_hours, m.recording_operator_id, m.recording_started_at, m.recording_heartbeat_at, m.recording_source, m.kick_cooldown_minutes, m.late_join_minutes, m.host_join_code, m.max_active_cameras, m.status, m.scheduled_at, m.timezone, m.started_at, m.expires_at, m.created_at, m.updated_at, (SELECT c.name FROM categories c WHERE c.id = m.category_id) AS category_name FROM meetings m WHERE (m.id = ? OR m.public_id = ? OR m.provider_meeting_id = ?) AND m.status != 'deleted' LIMIT 1"
  ).bind(meetingId, meetingId, meetingId).first<MeetingRow>();

  if (!meeting) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  // Nama tentor + status kode host untuk gate join di klien. Kode ASLINYA hanya
  // untuk operator (panel dashboard); publik cukup tahu "perlu kode atau tidak".
  let tentorNames: string[] = [];
  try {
    const tentorRows = await env.DB.prepare(
      "SELECT name FROM tentors WHERE meeting_id = ? ORDER BY name"
    ).bind(meeting.id).all<{ name: string }>();
    tentorNames = (tentorRows.results || []).map((t) => t.name);
  } catch {
    tentorNames = [];
  }
  const session = await getSessionFromRequest(req, env);
  const canSeeHostCode = Boolean(session && isOperatorRole(session.role));
  const { host_join_code: hostJoinCode, ...publicMeeting } = meeting;

  // Fetch live participants from RealtimeKit (accessible for room presence & kick detection)
  let participantsError: string | null = null;
  let participants: { id?: string; name?: string | null; custom_participant_id?: string; [k: string]: unknown }[] = [];
  if (env.ACCOUNT_ID && env.APP_ID && env.CF_API_TOKEN) {
    const fetched = await fetchKitParticipants(env, meeting.provider_meeting_id);
    if (fetched === null) {
      participantsError = "Provider tidak dapat dihubungi, daftar peserta tidak lengkap";
    } else {
      participants = fetched;
    }
  }

  // Merge persisted name overrides so renamed names show for new joiners / page reloads
  if (env.DB && participants.length > 0) {
    try {
      const overrides = await env.DB.prepare(
        "SELECT custom_participant_id, name FROM participant_name_overrides WHERE meeting_id = ?"
      ).bind(meeting.provider_meeting_id).all<{ custom_participant_id: string; name: string }>();
      if (overrides.results && overrides.results.length > 0) {
        const overrideMap = new Map(overrides.results.map(o => [o.custom_participant_id, o.name]));
        for (const p of participants) {
          const raw = p as Record<string, unknown>;
          const customId = (typeof raw.custom_participant_id === 'string' ? raw.custom_participant_id : '')
            || (typeof raw.customParticipantId === 'string' ? raw.customParticipantId : '');
          const overrideName = overrideMap.get(customId);
          if (overrideName) p.name = overrideName;
        }
      }
    } catch (e) {
      console.warn("Failed to merge name overrides:", e);
    }
  }

  return json({
    meeting: canSeeHostCode ? meeting : publicMeeting,
    // Kunci rekaman ikut dikirim ke semua peserta (bukan data sensitif: hanya
    // menandai "ada rekaman" + siapa operatornya). Klien memakai ini untuk
    // menyembunyikan tombol rekam pada host/admin lain dan tombol pause/stop
    // pada yang bukan operator — lihat §12 planning-rekaman-vps-otomatis.
    recording_lock: recordingLockInfo(meeting),
    tentor_names: tentorNames,
    host_code_set: Boolean((hostJoinCode || '').trim()),
    participants,
    participants_error: participantsError
  });
}

// Cek kode host SEBELUM minta token (client tidak perlu mengirim token kalau
// kode salah, sehingga tidak mendaftarkan diri ke provider sebagai member).
export async function checkHostJoinCode(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const body = await safeJson(req);
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const code = typeof body.code === 'string' ? body.code.trim() : '';
  if (!name) {
    return json({ error: "INVALID_INPUT", message: "name is required" }, { status: 400 });
  }

  const meeting = await env.DB.prepare(
    "SELECT id, host_join_code FROM meetings WHERE (id = ? OR public_id = ? OR provider_meeting_id = ?) AND status != 'deleted' LIMIT 1"
  ).bind(meetingId, meetingId, meetingId).first<MeetingRow>();
  if (!meeting) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  // Kode belum diaktifkan / nama bukan tentor → tidak ada yang perlu dicek.
  if (!(meeting.host_join_code || '').trim()) {
    return json({ required: false, valid: true });
  }
  const tentor = await env.DB.prepare(
    "SELECT id FROM tentors WHERE meeting_id = ? AND lower(name) = lower(?) LIMIT 1"
  ).bind(meeting.id, name).first<TentorRow>();
  if (!tentor) {
    return json({ required: false, valid: true });
  }

  const verdict = evaluateHostCode({
    meetingId: meeting.id,
    ip: req.headers.get('CF-Connecting-IP') || 'unknown',
    expected: meeting.host_join_code,
    provided: code,
    tentorNameMatched: true
  });
  const reason: HostCodeReason | undefined = verdict.reason;
  return json({
    required: true,
    valid: verdict.granted,
    ...(verdict.granted ? {} : { reason: reason || 'invalid' }),
    ...(verdict.retryAfterSeconds ? { retry_after_seconds: verdict.retryAfterSeconds } : {})
  });
}

export async function updateMeeting(meetingId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const existing = await env.DB.prepare(
    "SELECT id, public_id, provider_meeting_id, name, max_participants, duration_minutes, host_resolution, member_resolution, screenshare_resolution, allow_member_whiteboard, allow_member_annotation, category_id, auto_record, recording_retention_hours, kick_cooldown_minutes, late_join_minutes, max_active_cameras, status, scheduled_at, timezone, started_at, expires_at FROM meetings WHERE (id = ? OR public_id = ? OR provider_meeting_id = ?) AND status != 'deleted' LIMIT 1"
  ).bind(meetingId, meetingId, meetingId).first<MeetingRow>();

  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  const body = await safeJson(req);
  const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : existing.name;

  let publicId = existing.public_id;
  const rawPublicId = body.public_id ?? body.publicId;
  if (typeof rawPublicId === 'string' && rawPublicId.trim()) {
    const candidate = rawPublicId.trim();
    if (candidate !== existing.public_id) {
      if (!isValidPublicId(candidate)) {
        return json({
          error: "INVALID_CUSTOM_ID",
          message: "Meeting ID must be 3-50 characters long and contain only letters, numbers, hyphens, and underscores."
        }, { status: 400 });
      }

      const duplicate = await env.DB.prepare(
        "SELECT id FROM meetings WHERE public_id = ? AND id != ? AND status != 'deleted' LIMIT 1"
      ).bind(candidate, existing.id).first();

      if (duplicate) {
        return json({
          error: "MEETING_ID_ALREADY_EXISTS",
          message: "This Meeting ID is already taken by another meeting."
        }, { status: 409 });
      }
      publicId = candidate;
    }
  }

  let maxParticipants = existing.max_participants;
  if (typeof body.max_participants === 'number' && body.max_participants >= 1 && body.max_participants <= 500) {
    maxParticipants = Math.floor(body.max_participants);
  } else if (typeof body.maxParticipants === 'number' && body.maxParticipants >= 1 && body.maxParticipants <= 500) {
    maxParticipants = Math.floor(body.maxParticipants);
  }

  let durationMinutes = existing.duration_minutes;
  if (typeof body.duration_minutes === 'number' && body.duration_minutes >= 1 && body.duration_minutes <= 1440) {
    durationMinutes = Math.floor(body.duration_minutes);
  } else if (typeof body.durationMinutes === 'number' && body.durationMinutes >= 1 && body.durationMinutes <= 1440) {
    durationMinutes = Math.floor(body.durationMinutes);
  }

  const kickCooldownMinutes = parseKickCooldownMinutes(
    body.kick_cooldown_minutes ?? body.kickCooldownMinutes,
    existing.kick_cooldown_minutes ?? DEFAULT_KICK_COOLDOWN_MINUTES
  );

  const lateJoinMinutes = parseLateJoinMinutes(
    body.late_join_minutes ?? body.lateJoinMinutes,
    existing.late_join_minutes ?? DEFAULT_LATE_JOIN_MINUTES
  );

  const maxActiveCameras = parseMaxActiveCameras(
    body.max_active_cameras ?? body.maxActiveCameras,
    existing.max_active_cameras ?? DEFAULT_MAX_ACTIVE_CAMERAS
  );

  let hostResolution = existing.host_resolution || DEFAULT_HOST_RESOLUTION;
  const rawHostRes = body.host_resolution || body.hostResolution;
  if (typeof rawHostRes === 'string' && VALID_RESOLUTIONS.includes(rawHostRes)) {
    hostResolution = rawHostRes;
  }

  let memberResolution = existing.member_resolution || DEFAULT_MEMBER_RESOLUTION;
  const rawMemberRes = body.member_resolution || body.memberResolution;
  if (typeof rawMemberRes === 'string' && VALID_RESOLUTIONS.includes(rawMemberRes)) {
    memberResolution = rawMemberRes;
  }

  let screenshareResolution = existing.screenshare_resolution || DEFAULT_SHARE_RESOLUTION;
  const rawShareRes = body.screenshare_resolution || body.screenshareResolution;
  if (typeof rawShareRes === 'string' && VALID_SHARE_RESOLUTIONS.includes(rawShareRes)) {
    screenshareResolution = rawShareRes;
  }

  let allowMemberWhiteboard = existing.allow_member_whiteboard ? 1 : 0;
  if (body.allow_member_whiteboard === true || body.allow_member_whiteboard === 1) allowMemberWhiteboard = 1;
  if (body.allow_member_whiteboard === false || body.allow_member_whiteboard === 0) allowMemberWhiteboard = 0;

  let allowMemberAnnotation = existing.allow_member_annotation ? 1 : 0;
  if (body.allow_member_annotation === true || body.allow_member_annotation === 1) allowMemberAnnotation = 1;
  if (body.allow_member_annotation === false || body.allow_member_annotation === 0) allowMemberAnnotation = 0;

  let autoRecord = existing.auto_record ? 1 : 0;
  if (body.auto_record === true || body.auto_record === 1) autoRecord = 1;
  if (body.auto_record === false || body.auto_record === 0) autoRecord = 0;

  let recordingRetentionHours = normalizeRetentionHours(existing.recording_retention_hours);
  if (body.recording_retention_hours !== undefined) {
    recordingRetentionHours = normalizeRetentionHours(body.recording_retention_hours);
  }

  let categoryId: string | null = existing.category_id ?? null;
  if (body.category_id !== undefined && body.category_id !== null) {
    const rawCat = typeof body.category_id === 'string' ? body.category_id.trim() : (typeof body.categoryId === 'string' ? body.categoryId.trim() : '');
    if (rawCat) {
      const cat = await env.DB.prepare("SELECT id FROM categories WHERE id = ? LIMIT 1").bind(rawCat).first<{ id: string }>();
      if (!cat) {
        return json({ error: "INVALID_CATEGORY", message: "Invalid category selected." }, { status: 400 });
      }
      categoryId = rawCat;
    }
  } else if (body.category_id === null) {
    categoryId = null;
  }

  let scheduledAt = existing.scheduled_at;
  const rawScheduled = body.scheduled_at ?? body.scheduledAt;
  if (rawScheduled !== undefined) {
    if (typeof rawScheduled === 'string' && rawScheduled.trim()) {
      const parsed = new Date(rawScheduled.trim());
      if (isNaN(parsed.getTime())) {
        return json({ error: "INVALID_SCHEDULE_DATE", message: "Invalid scheduled date/time provided." }, { status: 400 });
      }
      // Same rule as createMeeting (PAST_SCHEDULE_DATE / INVALID_SCHEDULE_DATE).
      // Re-saving the existing value stays allowed, otherwise a meeting whose
      // schedule has already passed could never be edited again.
      const existingMs = existing.scheduled_at ? new Date(existing.scheduled_at).getTime() : NaN;
      const unchanged = !isNaN(existingMs) && existingMs === parsed.getTime();
      if (!unchanged && parsed.getTime() < Date.now() - 5 * 60 * 1000) {
        return json({ error: "PAST_SCHEDULE_DATE", message: "Cannot schedule a meeting in the past." }, { status: 400 });
      }
      scheduledAt = parsed.toISOString();
    } else if (rawScheduled === null) {
      scheduledAt = null;
    }
  }

  const timezone = typeof body.timezone === 'string' && body.timezone.trim() ? body.timezone.trim() : existing.timezone || 'UTC';

  const allowedStatuses = ['scheduled', 'active', 'ended', 'expired'];
  const statusFromClient = typeof body.status === 'string' && allowedStatuses.includes(body.status)
    ? (body.status as MeetingRow['status'])
    : null;
  let status: MeetingRow['status'] = statusFromClient ?? existing.status;

  // --- Lifecycle timer ---------------------------------------------------
  // status + started_at + expires_at are always written together in the
  // single UPDATE below so the row can never show a status that disagrees
  // with its timer (see the lifecycle contract in PROJECT.md).
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  let startedAt: string | null = existing.started_at ?? null;
  let expiresAt: string | null = existing.expires_at ?? null;
  const durationChanged = durationMinutes !== existing.duration_minutes;

  // An "active" row whose timer already ran out must not stay active.
  if (status === 'active' && expiresAt && new Date(expiresAt).getTime() <= nowMs) {
    status = 'expired';
  }

  if (status === 'scheduled') {
    // Fresh meeting or "Buka Kembali" from expired/ended → timer must be NULL.
    startedAt = null;
    expiresAt = null;
    // "Buka Kembali" on a meeting whose slot [scheduled_at, scheduled_at + duration]
    // already passed: drop the stale schedule so it reopens as an instant meeting
    // — keeping it would trip the missed-window gate and close it right away.
    if (statusFromClient === 'scheduled' && scheduledAt && new Date(scheduledAt).getTime() + durationMinutes * 60_000 <= nowMs) {
      scheduledAt = null;
    }
  } else if (status === 'active') {
    if (!startedAt || !expiresAt) {
      // "Mulai Sekarang" → start the timer from now with the current duration.
      startedAt = nowIso;
      expiresAt = new Date(nowMs + durationMinutes * 60000).toISOString();
    } else if (durationChanged) {
      // Extend/shorten from started_at (never "now + duration").
      const nextExpiresMs = new Date(startedAt).getTime() + durationMinutes * 60000;
      expiresAt = new Date(nextExpiresMs).toISOString();
      if (nextExpiresMs <= nowMs) status = 'expired';
    }
  } else if (status === 'ended') {
    // Manual stop: halt the timer; the status itself blocks joins.
    expiresAt = null;
  } else if (status === 'expired') {
    // Never started → timer stays NULL (status gate blocks joins).
    // Already started → make the time gate agree with the manual close.
    if (startedAt && (!expiresAt || new Date(expiresAt).getTime() > nowMs)) {
      expiresAt = nowIso;
    }
  }

  await env.DB.prepare(
    "UPDATE meetings SET name = ?, public_id = ?, max_participants = ?, duration_minutes = ?, host_resolution = ?, member_resolution = ?, screenshare_resolution = ?, allow_member_whiteboard = ?, allow_member_annotation = ?, category_id = ?, auto_record = ?, recording_retention_hours = ?, kick_cooldown_minutes = ?, late_join_minutes = ?, max_active_cameras = ?, status = ?, scheduled_at = ?, timezone = ?, started_at = ?, expires_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(name, publicId, maxParticipants, durationMinutes, hostResolution, memberResolution, screenshareResolution, allowMemberWhiteboard, allowMemberAnnotation, categoryId, autoRecord, recordingRetentionHours, kickCooldownMinutes, lateJoinMinutes, maxActiveCameras, status, scheduledAt, timezone, startedAt, expiresAt, existing.id).run();

  return json({
    success: true,
    meeting: {
      id: existing.id,
      public_id: publicId,
      provider_meeting_id: existing.provider_meeting_id,
      name,
      max_participants: maxParticipants,
      duration_minutes: durationMinutes,
      host_resolution: hostResolution,
      member_resolution: memberResolution,
      screenshare_resolution: screenshareResolution,
      allow_member_whiteboard: allowMemberWhiteboard === 1,
      allow_member_annotation: allowMemberAnnotation === 1,
      category_id: categoryId,
      auto_record: autoRecord === 1,
      recording_retention_hours: recordingRetentionHours,
      kick_cooldown_minutes: kickCooldownMinutes,
      late_join_minutes: lateJoinMinutes,
      max_active_cameras: maxActiveCameras,
      status,
      scheduled_at: scheduledAt,
      timezone,
      started_at: startedAt,
      expires_at: expiresAt
    }
  });
}

export async function deleteMeeting(meetingId: string, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }

  const existing = await env.DB.prepare(
    "SELECT id, public_id, provider_meeting_id FROM meetings WHERE (id = ? OR public_id = ? OR provider_meeting_id = ?) AND status != 'deleted' LIMIT 1"
  ).bind(meetingId, meetingId, meetingId).first<MeetingRow>();

  if (!existing) {
    return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
  }

  await env.DB.prepare(
    "UPDATE meetings SET status = 'deleted', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(existing.id).run();

  // Invalidate provider meeting
  if (env.ACCOUNT_ID && env.APP_ID && env.CF_API_TOKEN) {
    try {
      await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${env.ACCOUNT_ID}/realtime/kit/${env.APP_ID}/meetings/${existing.provider_meeting_id}`,
        {
          method: "DELETE",
          headers: { authorization: `Bearer ${env.CF_API_TOKEN}` }
        }
      );
    } catch {
      /* ignore provider deletion errors */
    }
  }

  return json({ success: true, message: "Meeting deleted successfully" });
}

export async function removeParticipant(
  meetingId: string,
  participantId: string,
  env: Env,
  opts: { kickedByUserId?: string | null; kickedUserId?: string | null } = {}
) {
  if (!env.ACCOUNT_ID || !env.APP_ID || !env.CF_API_TOKEN) {
    return json({ error: "SERVER_CONFIG_ERROR", message: "RealtimeKit credentials missing" }, { status: 500 });
  }

  let providerMeetingId = meetingId;
  let meetingRowId: string | null = null;
  let kickCooldownMinutes = DEFAULT_KICK_COOLDOWN_MINUTES;
  if (env.DB) {
    const meeting = await env.DB.prepare(
      // Prefer a live row: public_id is unique only among non-deleted meetings
      // (legacy schemas lack the UNIQUE constraint, so duplicates can exist).
      "SELECT id, provider_meeting_id, kick_cooldown_minutes FROM meetings WHERE id = ? OR public_id = ? OR provider_meeting_id = ? ORDER BY CASE WHEN status = 'deleted' THEN 1 ELSE 0 END, updated_at DESC LIMIT 1"
    ).bind(meetingId, meetingId, meetingId).first<MeetingRow>();
    if (meeting) {
      providerMeetingId = meeting.provider_meeting_id;
      meetingRowId = meeting.id ?? null;
      kickCooldownMinutes = meeting.kick_cooldown_minutes ?? DEFAULT_KICK_COOLDOWN_MINUTES;
    }
  }

  // Verify participant is not a Host before deleting
  let lookedUpUserId: string | null = null;
  try {
    const getRes = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${env.ACCOUNT_ID}/realtime/kit/${env.APP_ID}/meetings/${providerMeetingId}/participants/${participantId}`,
      { headers: { authorization: `Bearer ${env.CF_API_TOKEN}` } }
    );
    if (getRes.ok) {
      const pData = (await getRes.json()) as { data?: { preset_name?: string; custom_participant_id?: string; customParticipantId?: string }; result?: { preset_name?: string; custom_participant_id?: string; customParticipantId?: string } };
      const preset = pData.data?.preset_name ?? pData.result?.preset_name;
      if (preset === 'group_call_host') {
        return json({ error: "FORBIDDEN", message: "Host tidak dapat dikeluarkan dari meeting." }, { status: 403 });
      }
      lookedUpUserId =
        (typeof pData.data?.custom_participant_id === 'string' ? pData.data.custom_participant_id : '') ||
        (typeof pData.data?.customParticipantId === 'string' ? pData.data.customParticipantId : '') ||
        (typeof pData.result?.custom_participant_id === 'string' ? pData.result.custom_participant_id : '') ||
        (typeof pData.result?.customParticipantId === 'string' ? pData.result.customParticipantId : '') ||
        null;
    }
  } catch {
    /* continue if lookup fails */
  }

  const r = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${env.ACCOUNT_ID}/realtime/kit/${env.APP_ID}/meetings/${providerMeetingId}/participants/${participantId}`,
    {
      method: "DELETE",
      headers: { authorization: `Bearer ${env.CF_API_TOKEN}` }
    }
  );

  if (!r.ok && r.status !== 404) {
    return json({ error: "PARTICIPANT_REMOVE_FAILED", message: "Failed to remove participant from session" }, { status: r.status });
  }
  // 404 = sudah keluar (kick realtime dari SDK mendahului request ini) → tetap
  // anggap berhasil dan tetap catat jeda kick di bawah.

  // Catat jeda kick (best-effort): peserta tidak boleh join lagi sebelum
  // expires_at. Gagal mencatat tidak membatalkan kick yang sudah terjadi.
  const kickedUserId = opts.kickedUserId || lookedUpUserId;
  let cooldownRecorded = false;
  if (env.DB && kickedUserId && meetingRowId) {
    try {
      await env.DB.prepare(
        "DELETE FROM meeting_kicks WHERE meeting_id = ? AND user_id = ?"
      ).bind(meetingRowId, kickedUserId).run();
      if (kickCooldownMinutes > 0) {
        const now = new Date();
        await env.DB.prepare(
          "INSERT INTO meeting_kicks (id, meeting_id, user_id, kicked_by, kicked_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)"
        ).bind(
          crypto.randomUUID(),
          meetingRowId,
          kickedUserId,
          opts.kickedByUserId ?? null,
          now.toISOString(),
          new Date(now.getTime() + kickCooldownMinutes * 60_000).toISOString()
        ).run();
        cooldownRecorded = true;
      }
    } catch (e) {
      console.warn("Failed to record kick cooldown:", e);
    }
  }

  return json({
    success: true,
    message: "Participant removed successfully",
    cooldown_recorded: cooldownRecorded,
    kick_cooldown_minutes: kickCooldownMinutes
  });
}

export async function renameParticipant(meetingId: string, participantId: string, req: Request, env: Env, session: { role?: string } | null) {
  if (!env.ACCOUNT_ID || !env.APP_ID || !env.CF_API_TOKEN) {
    return json({ error: "SERVER_CONFIG_ERROR", message: "RealtimeKit credentials missing" }, { status: 500 });
  }

  const body = await safeJson(req);
  const rawName = typeof body.name === 'string' ? body.name.trim() : '';
  if (!rawName) {
    return json({ error: "INVALID_NAME", message: "Nama peserta tidak boleh kosong." }, { status: 400 });
  }
  if (rawName.length > 80) {
    return json({ error: "INVALID_NAME", message: "Nama peserta maksimal 80 karakter." }, { status: 400 });
  }
  const requesterCustomId = typeof body.customParticipantId === 'string' ? body.customParticipantId.trim() : '';
  const isAdmin = isOperatorRole(session?.role);

  let providerMeetingId = meetingId;
  if (env.DB) {
    const meeting = await env.DB.prepare(
      // Prefer a live row: public_id is unique only among non-deleted meetings
      // (legacy schemas lack the UNIQUE constraint, so duplicates can exist).
      "SELECT provider_meeting_id FROM meetings WHERE id = ? OR public_id = ? OR provider_meeting_id = ? ORDER BY CASE WHEN status = 'deleted' THEN 1 ELSE 0 END, updated_at DESC LIMIT 1"
    ).bind(meetingId, meetingId, meetingId).first<{ provider_meeting_id: string }>();
    if (meeting) {
      providerMeetingId = meeting.provider_meeting_id;
    }
  }

  // Verify target participant record before renaming
  let targetCustomId = '';
  try {
    const getRes = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${env.ACCOUNT_ID}/realtime/kit/${env.APP_ID}/meetings/${providerMeetingId}/participants/${participantId}`,
      { headers: { authorization: `Bearer ${env.CF_API_TOKEN}` } }
    );
    if (getRes.ok) {
      const pData = (await getRes.json()) as { data?: { preset_name?: string; name?: string | null; custom_participant_id?: string; customParticipantId?: string }; result?: { preset_name?: string; name?: string | null; custom_participant_id?: string; customParticipantId?: string } };
      const preset = pData.data?.preset_name ?? pData.result?.preset_name;
      if (preset === 'group_call_host' && !isAdmin) {
        return json({ error: "FORBIDDEN", message: "Host tidak dapat diubah namanya oleh member." }, { status: 403 });
      }
      targetCustomId =
        (typeof pData.data?.custom_participant_id === 'string' ? pData.data.custom_participant_id : '') ||
        (typeof pData.data?.customParticipantId === 'string' ? pData.data.customParticipantId : '') ||
        (typeof pData.result?.custom_participant_id === 'string' ? pData.result.custom_participant_id : '') ||
        (typeof pData.result?.customParticipantId === 'string' ? pData.result.customParticipantId : '');
    }
  } catch {
    /* continue if lookup fails */
  }

  if (!isAdmin) {
    if (!requesterCustomId) {
      return json({ error: "FORBIDDEN", message: "ID peserta diperlukan untuk mengubah nama." }, { status: 403 });
    }
    if (targetCustomId && requesterCustomId !== targetCustomId) {
      return json({ error: "FORBIDDEN", message: "Kamu hanya bisa mengubah nama sendiri." }, { status: 403 });
    }
  }

  const customId = requesterCustomId || targetCustomId || '';
  if (env.DB && customId) {
    try {
      await env.DB.prepare(
        "INSERT INTO participant_name_overrides (meeting_id, custom_participant_id, name, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(meeting_id, custom_participant_id) DO UPDATE SET name = excluded.name, updated_at = CURRENT_TIMESTAMP"
      ).bind(providerMeetingId, customId, rawName).run();
    } catch (e) {
      console.warn("Failed to save name override:", e);
    }
  }

  return json({
    success: true,
    message: "Participant renamed successfully",
    participant: { id: participantId, name: rawName }
  });
}
