import type { CategoryRow } from '../auth';
import { json, safeJson } from '../lib/utils';

export async function listCategories(env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const result = await env.DB.prepare("SELECT id, name, created_at FROM categories ORDER BY name ASC").all<CategoryRow>();
  return json({ categories: result.results || [] });
}

export async function createCategory(req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const body = await safeJson(req);
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name || name.length > 60) {
    return json({ error: "INVALID_INPUT", message: "Category name is required (max 60 characters)" }, { status: 400 });
  }
  const id = `cat_${crypto.randomUUID().slice(0, 12)}`;
  try {
    await env.DB.prepare("INSERT INTO categories (id, name) VALUES (?, ?)").bind(id, name).run();
  } catch {
    return json({ error: "CATEGORY_EXISTS", message: "A category with this name already exists." }, { status: 409 });
  }
  return json({ id, name }, { status: 201 });
}

export async function updateCategory(categoryId: string, req: Request, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  const body = await safeJson(req);
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name || name.length > 60) {
    return json({ error: "INVALID_INPUT", message: "Category name is required (max 60 characters)" }, { status: 400 });
  }
  try {
    await env.DB.prepare("UPDATE categories SET name = ? WHERE id = ?").bind(name, categoryId).run();
  } catch {
    return json({ error: "CATEGORY_EXISTS", message: "A category with this name already exists." }, { status: 409 });
  }
  return json({ success: true, name });
}

export async function deleteCategory(categoryId: string, env: Env) {
  if (!env.DB) {
    return json({ error: "SERVER_ERROR", message: "Database not configured" }, { status: 500 });
  }
  await env.DB.prepare("DELETE FROM categories WHERE id = ?").bind(categoryId).run();
  await env.DB.prepare("UPDATE meetings SET category_id = NULL WHERE category_id = ?").bind(categoryId).run();
  return json({ success: true, message: "Category deleted" });
}
