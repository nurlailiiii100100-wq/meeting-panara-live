import { hmacHex, timingSafeEqualHex } from '../auth';
import { json } from '../lib/utils';

const HMAC_MAX_AGE_SECONDS = 300; // Tolak request lebih tua dari 5 menit

/**
 * Verifikasi HMAC signature dari VPS recorder.
 * Format: X-Timestamp + X-Signature header.
 * Payload yang di-sign: "<timestamp>.<rawBody>"
 */
async function verifyVpsHmac(
  req: Request,
  rawBody: string,
  secret: string
): Promise<boolean> {
  const timestamp = req.headers.get('X-Timestamp');
  const signature = req.headers.get('X-Signature');
  if (!timestamp || !signature) return false;

  const ts = parseInt(timestamp, 10);
  if (!Number.isFinite(ts)) return false;

  // Replay protection: tolak jika timestamp terlalu lama
  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - ts) > HMAC_MAX_AGE_SECONDS) return false;

  const payload = `${timestamp}.${rawBody}`;
  const expected = await hmacHex(secret, payload);
  return timingSafeEqualHex(expected, signature);
}

/**
 * Hitung retention hours untuk sebuah meeting.
 * Reuse logika dari recordings.ts (query app_settings lalu meeting-specific).
 */
async function getMeetingRetentionHours(env: Env, meetingId: string): Promise<number> {
  const DEFAULT = 48;
  try {
    // Meeting-specific override
    const meeting = await env.DB.prepare(
      'SELECT recording_retention_hours FROM meetings WHERE id = ? LIMIT 1'
    ).bind(meetingId).first<{ recording_retention_hours: number | null }>();
    if (meeting?.recording_retention_hours != null && meeting.recording_retention_hours > 0) {
      return meeting.recording_retention_hours;
    }
    // Global setting
    const setting = await env.DB.prepare(
      "SELECT value FROM app_settings WHERE key = 'recording_retention_hours' LIMIT 1"
    ).first<{ value: string }>();
    if (setting?.value) {
      const parsed = parseInt(setting.value, 10);
      if (parsed > 0) return parsed;
    }
  } catch { /* fallback to default */ }
  return DEFAULT;
}

export async function handleVpsCallback(
  req: Request,
  env: Env,
  url: URL
): Promise<Response> {
  if (req.method !== 'POST') {
    return json({ error: 'METHOD_NOT_ALLOWED' }, { status: 405 });
  }

  if (!env.RECORDING_HMAC_SECRET) {
    return json({ error: 'SERVER_ERROR', message: 'RECORDING_HMAC_SECRET not configured' }, { status: 500 });
  }

  const rawBody = await req.text();
  const valid = await verifyVpsHmac(req, rawBody, env.RECORDING_HMAC_SECRET);
  if (!valid) {
    return json({ error: 'UNAUTHORIZED', message: 'Invalid HMAC signature' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return json({ error: 'INVALID_INPUT', message: 'Invalid JSON body' }, { status: 400 });
  }

  const subPath = url.pathname.replace('/api/internal/vps/', '');

  // ---- recording-completed ----
  if (subPath === 'recording-completed') {
    const meetingId = typeof body.meeting_id === 'string' ? body.meeting_id : '';
    const fileName = typeof body.file_name === 'string' ? body.file_name : '';
    const vpsFilePath = typeof body.vps_file_path === 'string' ? body.vps_file_path : '';
    const durationSeconds = typeof body.duration_seconds === 'number' ? body.duration_seconds : 0;
    const sizeBytes = typeof body.size_bytes === 'number' ? body.size_bytes : 0;
    const resolutionWidth = typeof body.resolution_width === 'number' ? body.resolution_width : 1280;
    const resolutionHeight = typeof body.resolution_height === 'number' ? body.resolution_height : 720;

    if (!meetingId || !fileName || !vpsFilePath) {
      return json({ error: 'INVALID_INPUT', message: 'meeting_id, file_name, vps_file_path are required' }, { status: 400 });
    }

    const id = crypto.randomUUID();
    const retentionHours = await getMeetingRetentionHours(env, meetingId);
    const expiresAt = new Date(Date.now() + retentionHours * 60 * 60 * 1000).toISOString();

    try {
      await env.DB.prepare(
        `INSERT INTO recordings
          (id, meeting_id, storage_key, file_name, duration_seconds, size_bytes,
           resolution_width, resolution_height, status, expires_at, source, storage, vps_file_path)
         VALUES (?, ?, '', ?, ?, ?, ?, ?, 'ready', ?, 'auto', 'vps', ?)`
      ).bind(
        id, meetingId, fileName, durationSeconds, sizeBytes,
        resolutionWidth, resolutionHeight, expiresAt, vpsFilePath
      ).run();

      return json({ ok: true, recording_id: id, expires_at: expiresAt }, { status: 201 });
    } catch (e) {
      console.error('VPS recording insert failed:', e);
      return json({ error: 'SERVER_ERROR', message: 'Failed to insert recording' }, { status: 500 });
    }
  }

  // ---- recording-failed ----
  if (subPath === 'recording-failed') {
    const meetingId = typeof body.meeting_id === 'string' ? body.meeting_id : '';
    const reason = typeof body.reason === 'string' ? body.reason : 'unknown';
    console.error(`VPS recording failed for meeting ${meetingId}: ${reason}`);

    // Optional: buat baris recording dengan status 'failed' untuk audit
    if (meetingId) {
      try {
        const id = crypto.randomUUID();
        const fileName = typeof body.file_name === 'string' ? body.file_name : 'failed-recording.mp4';
        await env.DB.prepare(
          `INSERT INTO recordings
            (id, meeting_id, storage_key, file_name, status, expires_at, source, storage)
           VALUES (?, ?, '', ?, 'failed', datetime('now', '+48 hours'), 'auto', 'vps')`
        ).bind(id, meetingId, fileName).run();
      } catch { /* best effort */ }
    }

    return json({ ok: true });
  }

  // ---- recording-deleted ----
  if (subPath === 'recording-deleted') {
    const filePath = typeof body.file_path === 'string' ? body.file_path : '';
    if (!filePath) {
      return json({ error: 'INVALID_INPUT', message: 'file_path required' }, { status: 400 });
    }
    try {
      await env.DB.prepare(
        "UPDATE recordings SET status = 'deleted', updated_at = CURRENT_TIMESTAMP WHERE vps_file_path = ? AND storage = 'vps'"
      ).bind(filePath).run();
    } catch (e) {
      console.error('VPS recording delete update failed:', e);
    }
    return json({ ok: true });
  }

  return json({ error: 'NOT_FOUND', message: 'Unknown VPS callback endpoint' }, { status: 404 });
}
