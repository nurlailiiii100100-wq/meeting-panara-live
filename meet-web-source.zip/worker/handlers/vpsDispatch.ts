import { hmacHex, type MeetingRow } from '../auth';

/**
 * Dipanggil oleh cron tiap 1 menit.
 * Query meeting yang auto_record = true dan belum di-dispatch,
 * lalu kirim job ke VPS recorder service.
 */
export async function dispatchAutoRecordJobs(env: Env): Promise<void> {
  if (!env.DB || !env.VPS_RECORDER_URL || !env.RECORDING_HMAC_SECRET) return;

  try {
    const windowISO = new Date(Date.now() + 60_000).toISOString();

    // Cari meeting yang perlu di-dispatch:
    // - auto_record aktif
    // - status scheduled (belum mulai) atau active (sedang berlangsung)
    // - jadwal dalam 1 menit ke depan atau sudah lewat
    // - belum pernah di-dispatch
    const rows = await env.DB.prepare(`
      SELECT id, public_id, duration_minutes, host_resolution
      FROM meetings
      WHERE auto_record = 1
        AND status IN ('scheduled', 'active')
        AND scheduled_at IS NOT NULL
        AND scheduled_at <= ?
        AND vps_dispatched_at IS NULL
      ORDER BY scheduled_at ASC
      LIMIT 10
    `).bind(windowISO).all<MeetingRow>();

    if (!rows.results || rows.results.length === 0) return;

    const nowISO = new Date().toISOString();

    for (const meeting of rows.results) {
      try {
        const body = JSON.stringify({
          meeting_id: meeting.id,
          meeting_url: `${meeting.public_id}`,
          duration_minutes: meeting.duration_minutes,
          resolution: meeting.host_resolution || '720p',
        });

        // Sign request dengan HMAC (format: timestamp.body)
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const signaturePayload = `${timestamp}.${body}`;
        const signature = await hmacHex(env.RECORDING_HMAC_SECRET, signaturePayload);

        const res = await fetch(`${env.VPS_RECORDER_URL}/api/jobs`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Timestamp': timestamp,
            'X-Signature': signature,
          },
          body,
        });

        if (res.ok) {
          // Tandai sudah dispatch — mencegah dispatch ganda di cron berikutnya
          await env.DB.prepare(
            'UPDATE meetings SET vps_dispatched_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
          ).bind(nowISO, meeting.id).run();
        } else {
          const errText = await res.text().catch(() => '');
          console.error(`VPS dispatch failed for meeting ${meeting.id}: ${res.status} ${errText}`);
          // Tidak tandai — akan retry di cron menit berikutnya
        }
      } catch (err) {
        console.error(`VPS dispatch error for meeting ${meeting.id}:`, err);
        // Tidak tandai — akan retry
      }
    }
  } catch (err) {
    console.error('dispatchAutoRecordJobs error:', err);
  }
}
