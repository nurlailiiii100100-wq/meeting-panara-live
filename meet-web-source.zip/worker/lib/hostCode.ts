// Rate limit percobaan kode host: per meeting + IP (in-memory, per isolate).
//
// Kode angka bisa ditebak, jadi dibatasi 5 percobaan salah → elevasi dikunci
// 10 menit untuk kombinasi meeting+IP itu. Percobaan tanpa kode TIDAK dihitung
// agar orang lain tidak bisa mengunci kenaikan tentor asli hanya dengan
// mengetik nama tentor berulang kali.

type AttemptEntry = { count: number; firstAt: number; lockedUntil: number };

const attempts = new Map<string, AttemptEntry>();

const MAX_ATTEMPTS = 5;
const WINDOW_MS = 10 * 60_000; // hitungan salah dianggap basi setelah 10 menit tenang
const LOCK_MS = 10 * 60_000; // kunci elevasi selama 10 menit setelah MAX_ATTEMPTS salah

export type HostCodeReason = 'no_code' | 'not_tentor' | 'required' | 'invalid' | 'locked';

export type HostCodeVerdict = {
  granted: boolean;
  reason?: HostCodeReason;
  retryAfterSeconds?: number;
};

function prune(now: number): void {
  if (attempts.size <= 500) return;
  for (const [key, entry] of attempts) {
    if (entry.lockedUntil <= now && now - entry.firstAt > WINDOW_MS) attempts.delete(key);
  }
}

export function evaluateHostCode(input: {
  meetingId: string;
  ip: string;
  expected: string | null | undefined;
  provided: string;
  tentorNameMatched: boolean;
}): HostCodeVerdict {
  const expected = (input.expected || '').trim();
  if (!input.tentorNameMatched) return { granted: true, reason: 'not_tentor' };
  if (!expected) return { granted: true, reason: 'no_code' };

  const now = Date.now();
  prune(now);
  const key = `${input.meetingId}|${input.ip}`;
  const entry = attempts.get(key);
  if (entry && entry.lockedUntil > now) {
    return { granted: false, reason: 'locked', retryAfterSeconds: Math.ceil((entry.lockedUntil - now) / 1000) };
  }

  const provided = input.provided.trim();
  if (provided && provided === expected) {
    attempts.delete(key);
    return { granted: true };
  }

  // Nama tentor tanpa kode: tolak elevasi tapi jangan dicatat (anti-lockout).
  if (!provided) return { granted: false, reason: 'required' };

  const fresh = !entry || now - entry.firstAt > WINDOW_MS;
  const next: AttemptEntry = fresh
    ? { count: 1, firstAt: now, lockedUntil: 0 }
    : { count: entry.count + 1, firstAt: entry.firstAt, lockedUntil: 0 };

  if (next.count >= MAX_ATTEMPTS) {
    next.lockedUntil = now + LOCK_MS;
    attempts.set(key, next);
    return { granted: false, reason: 'locked', retryAfterSeconds: Math.ceil(LOCK_MS / 1000) };
  }
  attempts.set(key, next);
  return { granted: false, reason: 'invalid' };
}
