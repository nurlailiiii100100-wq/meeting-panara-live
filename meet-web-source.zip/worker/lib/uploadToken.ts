import { getSessionSecret, hmacHex, timingSafeEqualHex } from '../auth';

// Token tanda tangan untuk host meeting mengunggah rekaman client-side.
// Diterbitkan bersama token join (hanya untuk host) dan diverifikasi pada
// POST /api/recordings/upload, sehingga peserta biasa tidak bisa mengunggah.
// Format: `<meeting_id>.<exp_detik>.<hex hmac-sha256>`.

// Masa tenggang token unggah: 24 jam setelah meeting berakhir, agar berkas
// rekaman panjang (1–2 jam / ~1–2 GB) yang lambat diunggah atau kirim ulang
// dari cadangan IndexedDB tidak tertolak karena token kedaluwarsa.
const UPLOAD_TOKEN_GRACE_MS = 24 * 60 * 60 * 1000;

export async function createHostUploadToken(
  env: Env,
  reqUrl: string,
  meetingId: string,
  expiresAtMs: number
): Promise<string> {
  const secret = getSessionSecret(env, reqUrl);
  const exp = Math.floor((expiresAtMs + UPLOAD_TOKEN_GRACE_MS) / 1000);
  const payload = `${meetingId}.${exp}`;
  const signature = await hmacHex(secret, payload);
  return `${payload}.${signature}`;
}

export async function verifyHostUploadToken(
  env: Env,
  reqUrl: string,
  meetingId: string,
  token: string
): Promise<boolean> {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return false;
    const [tokenMeetingId, expStr, signature] = parts;
    if (!tokenMeetingId || !expStr || !signature) return false;

    const secret = getSessionSecret(env, reqUrl);
    const expected = await hmacHex(secret, `${tokenMeetingId}.${expStr}`);
    if (!timingSafeEqualHex(expected, signature)) return false;
    if (tokenMeetingId !== meetingId) return false;

    const exp = parseInt(expStr, 10);
    return Number.isFinite(exp) && exp * 1000 >= Date.now();
  } catch {
    return false;
  }
}
