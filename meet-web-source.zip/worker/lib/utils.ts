export const json = (data: unknown, init: ResponseInit = {}) =>
  new Response(JSON.stringify(data), {
    headers: { "content-type": "application/json" },
    ...init
  });

export const VALID_RESOLUTIONS = ['140p', '240p', '360p', '480p', '720p', '1080p'];
export const DEFAULT_HOST_RESOLUTION = '360p';
export const DEFAULT_MEMBER_RESOLUTION = '240p';

// Resolusi screen share: cuma 2 pilihan (sama dengan dialog lama di room).
export const VALID_SHARE_RESOLUTIONS = ['480p', '720p'];
export const DEFAULT_SHARE_RESOLUTION = '720p';

// Batas terlambat join (menit setelah scheduled_at) untuk member. 0 = tanpa batas, maks 24 jam.
export const DEFAULT_LATE_JOIN_MINUTES = 30;

export function parseLateJoinMinutes(raw: unknown, fallback: number): number {
  if (raw === undefined || raw === null || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(1440, Math.max(0, Math.floor(n)));
}

// Batas jumlah kamera peserta (non-host) yang boleh menyala serentak. 0 = tanpa batas.
export const DEFAULT_MAX_ACTIVE_CAMERAS = 0;

export function parseMaxActiveCameras(raw: unknown, fallback: number): number {
  if (raw === undefined || raw === null || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(500, Math.max(0, Math.floor(n)));
}

export function isValidPublicId(id: string): boolean {
  return /^[a-zA-Z0-9_-]{3,50}$/.test(id);
}

// Resolve any meeting id form (uuid | public_id | provider id) to the canonical row id.
export async function resolveMeetingId(meetingId: string, env: Env): Promise<string | null> {
  if (!env.DB) return null;
  const row = await env.DB.prepare(
    "SELECT id FROM meetings WHERE (id = ? OR public_id = ? OR provider_meeting_id = ?) AND status != 'deleted' LIMIT 1"
  ).bind(meetingId, meetingId, meetingId).first<{ id: string }>();
  return row?.id ?? null;
}

export function generatePublicId(name: string): string {
  const cleanSlug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 15);
  const rand = Math.random().toString(36).substring(2, 7);
  return cleanSlug ? `${cleanSlug}-${rand}` : `meet-${rand}`;
}

export function isValidHostCode(code: string): boolean {
  return /^\d{4,10}$/.test(code);
}

export function randomHostCode(): string {
  const bytes = new Uint8Array(4);
  crypto.getRandomValues(bytes);
  return String(100000 + (bytes[0] * 16777216 + bytes[1] * 65536 + bytes[2] * 256 + bytes[3]) % 900000);
}

export function normalizeRetentionHours(val: unknown): number {
  const n = typeof val === 'number' ? val : parseInt(String(val ?? ''), 10);
  if (typeof n !== 'number' || isNaN(n) || n < 1) return 48;
  return Math.min(Math.floor(n), 720);
}

export async function getMeetingRetentionHours(env: Env, meetingId: string): Promise<number> {
  if (!env.DB) return 48;
  try {
    const row = await env.DB.prepare(
      "SELECT recording_retention_hours FROM meetings WHERE id = ? LIMIT 1"
    ).bind(meetingId).first<{ recording_retention_hours: number | null }>();
    return normalizeRetentionHours(row?.recording_retention_hours);
  } catch {
    return 48;
  }
}

export async function safeJson(req: Request): Promise<Record<string, unknown>> {
  try { return (await req.json()) as Record<string, unknown>; } catch { return {}; }
}

const KIT_PARTICIPANTS_PER_PAGE = 100;
const KIT_PARTICIPANTS_MAX_PAGES = 10;

export async function fetchKitParticipants(
  env: Env,
  providerMeetingId: string
): Promise<Record<string, unknown>[] | null> {
  if (!env.ACCOUNT_ID || !env.APP_ID || !env.CF_API_TOKEN) return null;

  const url = (pageNo: number | null) =>
    `https://api.cloudflare.com/client/v4/accounts/${env.ACCOUNT_ID}/realtime/kit/${env.APP_ID}` +
    `/meetings/${providerMeetingId}/participants?per_page=${KIT_PARTICIPANTS_PER_PAGE}` +
    (pageNo === null ? '' : `&page_no=${pageNo}`);

  const all: Record<string, unknown>[] = [];
  const seen = new Set<string>();

  // Halaman pertama dikirim tanpa page_no (pakai default API) supaya selalu dapat
  // halaman awal seperti perilaku lama; base offset dari response dipakai untuk
  // penomoran halaman berikutnya (API bisa 0-based atau 1-based).
  let pageNo: number | null = null;
  let basePage: number | null = null;
  let totalCount: number | undefined;
  let fetchedAny = false;

  for (let attempt = 0; attempt < KIT_PARTICIPANTS_MAX_PAGES; attempt++) {
    let page: Record<string, unknown>[] = [];
    let startOffset: number | undefined;
    let endOffset: number | undefined;

    try {
      const res = await fetch(url(pageNo), {
        headers: { authorization: `Bearer ${env.CF_API_TOKEN}` }
      });
      if (!res.ok) {
        console.warn(`Kit participants page ${pageNo ?? 'default'} failed with status ${res.status}.`);
        break;
      }
      const body = (await res.json()) as {
        data?: unknown[];
        result?: unknown[];
        paging?: { total_count?: number; start_offset?: number; end_offset?: number };
      };
      page = ((Array.isArray(body) ? body : body.result ?? body.data) || []) as Record<string, unknown>[];
      totalCount = body.paging?.total_count;
      startOffset = body.paging?.start_offset;
      endOffset = body.paging?.end_offset;
      fetchedAny = true;
    } catch (e) {
      console.warn(`Kit participants page ${pageNo ?? 'default'} failed:`, e);
      break;
    }

    if (pageNo === null) {
      basePage = startOffset === 0 ? 0 : 1;
      pageNo = basePage;
    }

    let added = 0;
    for (const p of page) {
      const key = typeof p.id === 'string' ? p.id : JSON.stringify(p);
      if (seen.has(key)) continue;
      seen.add(key);
      all.push(p);
      added++;
    }

    if (typeof totalCount !== 'number') break;
    if (all.length >= totalCount) break;
    if (added === 0) break;
    if (typeof startOffset === 'number' && typeof endOffset === 'number' && endOffset < startOffset) break;

    pageNo = (basePage ?? 1) + (attempt + 1);
  }

  if (!fetchedAny) return null;

  if (typeof totalCount === 'number' && totalCount > all.length && all.length >= KIT_PARTICIPANTS_PER_PAGE) {
    console.warn(`Kit participants incomplete: ${all.length}/${totalCount}.`);
    return null;
  }

  return all;
}
