// ============================================================
//  Template email OTP "Lupa Password"
//  Semua yang bisa dikustom ada di file ini saja.
//  Dipakai oleh: worker/handlers/auth.ts -> sendResetEmail()
// ============================================================

export const brand = {
  // Nama yang tampil di pengirim, header, dan footer
  name: 'Learnly',
  // Subjek email (nama brand otomatis ditambahkan di belakang)
  subject: 'Kode verifikasi reset password',
  // Warna utama (header, aksen)
  primaryColor: '#059669',
  // Warna halaman di luar kartu
  backgroundColor: '#f1f5f9',
  // Warna teks utama / teks redup
  textColor: '#0f172a',
  mutedColor: '#64748b',
  // Masa berlaku kode (menit) — harus sama dengan OTP_TTL_MS di worker/handlers/auth.ts
  validMinutes: 10,
  // Judul & isi kartu
  title: 'Reset password kamu',
  intro: 'Masukkan kode verifikasi di bawah ini untuk melanjutkan proses reset password.',
  ignoreHint: 'Jika kamu tidak meminta kode ini, abaikan email ini.',
  footer: 'Email ini dikirim otomatis, mohon tidak membalas.',
};

export function buildResetEmail(
  code: string,
  logo?: string | null
): { subject: string; text: string; html: string } {
  const b = brand;
  const subject = `${b.subject} - ${b.name}`;

  const text = [
    `${b.title}`,
    '',
    `Kode verifikasi kamu: ${code}`,
    '',
    `Berlaku ${b.validMinutes} menit.`,
    b.ignoreHint,
  ].join('\n');

  // Logo opsional (dari app_settings). Catatan: Gmail memblokir gambar data URI,
  // jadi pakai URL https kalau ingin logo selalu tampil.
  const logoHtml = logo
    ? `<img src="${logo}" alt="${b.name}" style="display:block;max-height:48px;max-width:180px;margin:0 0 20px;">`
    : '';

  const html = `<!doctype html>
<html>
  <body style="margin:0;padding:0;background-color:${b.backgroundColor};font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:${b.backgroundColor};padding:32px 12px;">
      <tr>
        <td align="center">
          <table role="presentation" width="520" cellpadding="0" cellspacing="0" style="width:100%;max-width:520px;background-color:#ffffff;border-radius:16px;border:1px solid #e2e8f0;overflow:hidden;">
            <!-- Header -->
            <tr>
              <td style="background-color:${b.primaryColor};padding:20px 32px;">
                <span style="font-size:18px;font-weight:700;color:#ffffff;">${b.name}</span>
              </td>
            </tr>
            <!-- Body -->
            <tr>
              <td style="padding:32px;">
                ${logoHtml}
                <h1 style="margin:0 0 8px;font-size:20px;line-height:1.3;color:${b.textColor};">${b.title}</h1>
                <p style="margin:0 0 24px;font-size:14px;line-height:1.6;color:${b.mutedColor};">${b.intro}</p>
                <div style="text-align:center;background-color:#f8fafc;border:1px dashed ${b.primaryColor};border-radius:12px;padding:22px 12px;font-size:34px;font-weight:700;letter-spacing:10px;font-family:ui-monospace,'Menlo','Consolas',monospace;color:${b.textColor};">${code}</div>
                <p style="margin:24px 0 0;font-size:14px;line-height:1.6;color:${b.textColor};">
                  Kode berlaku <strong>${b.validMinutes} menit</strong>. Segera masukkan kode di halaman reset password.
                </p>
                <p style="margin:8px 0 0;font-size:13px;line-height:1.6;color:${b.mutedColor};">${b.ignoreHint}</p>
              </td>
            </tr>
            <!-- Footer -->
            <tr>
              <td style="background-color:#f8fafc;padding:16px 32px;text-align:center;font-size:12px;color:${b.mutedColor};border-top:1px solid #e2e8f0;">
                &copy; ${b.name} &middot; ${b.footer}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`;

  return { subject, text, html };
}
