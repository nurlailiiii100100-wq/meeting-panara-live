import { ensureSeeded, getSessionFromRequest, isOperatorRole } from './auth';
import { json, resolveMeetingId } from './lib/utils';
import { handleLogin, handleLogout, handleMe, handleForgotPassword, handleVerifyResetCode, handleResetPassword } from './handlers/auth';
import { listPresets, createPreset, updatePreset, deletePreset } from './handlers/presets';
import { listTentors, createTentor, updateTentor, deleteTentor } from './handlers/tentors';
import { listCategories, createCategory, updateCategory, deleteCategory } from './handlers/categories';
import { getPublicSettings, getAllSettings, updateSettings } from './handlers/settings';
import { handleRecordingsApi, handleScheduledCleanups } from './handlers/recordings';
import { handleVpsCallback } from './handlers/vpsRecording';
import {
  listMeetings,
  createMeeting,
  getMeetingDetail,
  updateMeeting,
  deleteMeeting,
  removeParticipant,
  renameParticipant,
  updateAnnotationPermission,
  checkHostJoinCode,
  claimRecordingLock,
  heartbeatRecordingLock,
  releaseRecordingLock
} from './handlers/meetings';
import { issueToken } from './handlers/tokens';
import { listAdmins, createAdmin, updateAdmin } from './handlers/admins';

export default {
  async scheduled(_event: ScheduledEvent, env: Env): Promise<void> {
    await handleScheduledCleanups(env);
  },

  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);

    // Seed default admin user & ensure schema if DB is configured (once per isolate)
    if (env.DB) {
      try {
        await ensureSeeded(env.DB, env);
      } catch (e) {
        console.error("Admin seed error:", e);
      }
    }

    // --- Authentication Endpoints ---
    if (url.pathname === "/api/auth/login" && req.method === "POST") {
      return handleLogin(req, env);
    }

    if (url.pathname === "/api/auth/logout" && req.method === "POST") {
      return handleLogout(req);
    }

    if (url.pathname === "/api/auth/me" && req.method === "GET") {
      return handleMe(req, env);
    }

    if (url.pathname === "/api/auth/forgot" && req.method === "POST") {
      return handleForgotPassword(req, env);
    }

    if (url.pathname === "/api/auth/forgot/verify" && req.method === "POST") {
      return handleVerifyResetCode(req, env);
    }

    if (url.pathname === "/api/auth/forgot/reset" && req.method === "POST") {
      return handleResetPassword(req, env);
    }

    // --- Recording Endpoints ---
    // Semua rekaman client-side: list, stream/download, dan upload
    // (POST /api/recordings/upload, multipart → R2 + D1, tanpa transcode).
    if (url.pathname.startsWith("/api/recordings")) {
      return handleRecordingsApi(req, env);
    }

    // --- Meeting Management Endpoints ---
    if (url.pathname === "/api/meetings" && req.method === "GET") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      return listMeetings(req, env);
    }

    if (url.pathname === "/api/meetings" && req.method === "POST") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required to create a meeting" }, { status: session ? 403 : 401 });
      }
      return createMeeting(req, env, session.userId);
    }

    // Single meeting routes (/api/meetings/:id and sub-resources)
    const meetingMatch = url.pathname.match(/^\/api\/meetings\/([^/]+)(\/.*)?$/);
    if (meetingMatch) {
      const meetingId = decodeURIComponent(meetingMatch[1]);
      const subPath = meetingMatch[2] || '';

      if (subPath.match(/^\/participants\/([^/]+)(\/remove)?$/) && (req.method === "DELETE" || req.method === "POST")) {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin privileges required to remove a participant" }, { status: session ? 403 : 401 });
        }
        const participantMatch = subPath.match(/^\/participants\/([^/]+)(\/remove)?$/)!;
        const participantId = decodeURIComponent(participantMatch[1]);
        // ?user=<custom_participant_id>: kirim id peserta dari klien karena RTK
        // sudah menghapusnya (kick realtime) sehingga lookup bisa 404.
        const kickedUserId = url.searchParams.get('user');
        return removeParticipant(meetingId, participantId, env, {
          kickedByUserId: session.userId,
          kickedUserId: kickedUserId && kickedUserId.trim() ? kickedUserId.trim() : null
        });
      }

      if (subPath.match(/^\/participants\/([^/]+)$/) && req.method === "PATCH") {
        const session = await getSessionFromRequest(req, env);
        if (session && session.role === 'superadmin') {
          return json({ error: "FORBIDDEN", message: "Superadmin cannot access meeting operations" }, { status: 403 });
        }
        const renameMatch = subPath.match(/^\/participants\/([^/]+)$/)!;
        const participantId = decodeURIComponent(renameMatch[1]);
        return renameParticipant(meetingId, participantId, req, env, session);
      }

      if (subPath === '/annotation' && req.method === "PATCH") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        const resolvedAnnotation = await resolveMeetingId(meetingId, env);
        if (!resolvedAnnotation) {
          return json({ error: "NOT_FOUND", message: "Meeting not found" }, { status: 404 });
        }
        return updateAnnotationPermission(resolvedAnnotation, req, env);
      }

      // Kunci rekaman (recording lock): klaim saat Start, denyut selama
      // merekam, lepas saat Stop. Hanya host/admin (operator role) yang boleh.
      if (subPath === '/recording-claim' && req.method === "POST") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required to record" }, { status: session ? 403 : 401 });
        }
        return claimRecordingLock(meetingId, req, env);
      }

      if (subPath === '/recording-heartbeat' && req.method === "POST") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return heartbeatRecordingLock(meetingId, req, env);
      }

      if (subPath === '/recording-release' && req.method === "POST") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return releaseRecordingLock(meetingId, req, env);
      }

      // Host join code: cek kode saat join (publik) — kodenya ditetapkan sekali saat meeting dibuat
      if (subPath === '/host-code' && req.method === "POST") {
        return checkHostJoinCode(meetingId, req, env);
      }

      if (subPath === '' && req.method === "GET") {
        return getMeetingDetail(meetingId, req, env);
      }

      if (subPath === '' && req.method === "PATCH") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return updateMeeting(meetingId, req, env);
      }

      if (subPath === '' && req.method === "DELETE") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return deleteMeeting(meetingId, env);
      }
    }

    // --- Preset Management Endpoints ---
    if (url.pathname === "/api/presets" && req.method === "GET") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required to view presets" }, { status: session ? 403 : 401 });
      }
      return listPresets(env);
    }

    if (url.pathname === "/api/presets" && req.method === "POST") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required to create a preset" }, { status: session ? 403 : 401 });
      }
      return createPreset(req, env, session.userId);
    }

    const presetMatch = url.pathname.match(/^\/api\/presets\/([^/]+)$/);
    if (presetMatch) {
      const presetId = decodeURIComponent(presetMatch[1]);
      if (req.method === "PATCH") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required to update preset" }, { status: session ? 403 : 401 });
        }
        return updatePreset(presetId, req, env);
      }
      if (req.method === "DELETE") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required to delete preset" }, { status: session ? 403 : 401 });
        }
        return deletePreset(presetId, env);
      }
    }

    // --- Tentor Management Endpoints ---
    if (url.pathname === "/api/tentors" && req.method === "GET") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      const meetingId = url.searchParams.get('meeting_id') || '';
      if (!meetingId) {
        return json({ error: "INVALID_INPUT", message: "meeting_id query param is required" }, { status: 400 });
      }
      return listTentors(meetingId, env);
    }

    if (url.pathname === "/api/tentors" && req.method === "POST") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      return createTentor(req, env);
    }

    const tentorMatch = url.pathname.match(/^\/api\/tentors\/([^/]+)$/);
    if (tentorMatch) {
      const tentorId = decodeURIComponent(tentorMatch[1]);
      if (req.method === "PATCH") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return updateTentor(tentorId, req, env);
      }
      if (req.method === "DELETE") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return deleteTentor(tentorId, env);
      }
    }

    // --- Settings Endpoints ---
    if (url.pathname === "/api/settings/public" && req.method === "GET") {
      return getPublicSettings(env);
    }

    if (url.pathname === "/api/settings" && req.method === "GET") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      return getAllSettings(env);
    }

    if (url.pathname === "/api/settings" && req.method === "PUT") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      return updateSettings(req, env);
    }

    // --- Category Management Endpoints ---
    if (url.pathname === "/api/categories" && req.method === "GET") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      return listCategories(env);
    }

    if (url.pathname === "/api/categories" && req.method === "POST") {
      const session = await getSessionFromRequest(req, env);
      if (!session || !isOperatorRole(session.role)) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
      }
      return createCategory(req, env);
    }

    const categoryMatch = url.pathname.match(/^\/api\/categories\/([^/]+)$/);
    if (categoryMatch) {
      const categoryId = decodeURIComponent(categoryMatch[1]);
      if (req.method === "PATCH") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return updateCategory(categoryId, req, env);
      }
      if (req.method === "DELETE") {
        const session = await getSessionFromRequest(req, env);
        if (!session || !isOperatorRole(session.role)) {
          return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Admin access required" }, { status: session ? 403 : 401 });
        }
        return deleteCategory(categoryId, env);
      }
    }

    // --- Superadmin: Account Management (hanya role 'superadmin') ---
    if (url.pathname === "/api/admins" || url.pathname.startsWith("/api/admins/")) {
      const session = await getSessionFromRequest(req, env);
      if (!session) {
        return json({ error: session ? "FORBIDDEN" : "UNAUTHORIZED", message: "Login required" }, { status: session ? 403 : 401 });
      }
      if (session.role !== 'superadmin') {
        return json({ error: "FORBIDDEN", message: "Superadmin access required" }, { status: 403 });
      }
      if (url.pathname === "/api/admins" && req.method === "GET") return listAdmins(env);
      if (url.pathname === "/api/admins" && req.method === "POST") return createAdmin(req, env);
      const adminMatch = url.pathname.match(/^\/api\/admins\/([^/]+)$/);
      if (adminMatch && req.method === "PATCH") {
        return updateAdmin(decodeURIComponent(adminMatch[1]), req, env, session.userId);
      }
      return json({ error: "NOT_FOUND", message: "Not found" }, { status: 404 });
    }

    // --- Token Issuance (Guest & Admin) ---
    if (url.pathname === "/api/tokens" && req.method === "POST") {
      return issueToken(req, env);
    }

    // --- VPS Recorder Callbacks ---
    if (url.pathname.startsWith("/api/internal/vps/")) {
      return handleVpsCallback(req, env, url);
    }

    return new Response(null, { status: 404 });
  }
};
