// Password hashing using PBKDF2 with Web Crypto API
// Session tokens using HMAC-SHA256 Signed Cookies

export interface PresetRow {
  id: string;
  name: string;
  max_participants: number;
  duration_minutes: number;
  host_resolution: string;
  member_resolution: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface TentorRow {
  id: string;
  meeting_id: string;
  name: string;
  created_at: string;
}

export interface CategoryRow {
  id: string;
  name: string;
  created_at: string;
}

export interface SettingsRow {
  key: string;
  value: string;
  updated_at: string;
}

export interface RecordingRow {
  id: string;
  meeting_id: string;
  storage_key: string;
  file_name: string;
  duration_seconds: number | null;
  size_bytes: number | null;
  resolution_width: number | null;
  resolution_height: number | null;
  download_count: number;
  status: 'processing' | 'ready' | 'failed' | 'expired' | 'deleted';
  expires_at: string; // ISO 8601 string (48h after creation/meeting end)
  source?: 'manual' | 'auto';
  storage?: 'r2' | 'vps';
  vps_file_path?: string | null;
  created_at: string;
  updated_at: string;
}

export interface MeetingRow {
  id: string;
  public_id: string;
  provider_meeting_id: string;
  name: string;
  created_by: string;
  max_participants: number;
  duration_minutes: number;
  host_resolution: string;
  member_resolution: string;
  screenshare_resolution?: string | null;
  allow_member_whiteboard?: number | boolean;
  allow_member_annotation?: number | boolean;
  category_id?: string | null;
  auto_record?: number | boolean;
  recording_retention_hours?: number | null;
  // Kunci rekaman (recording lock) — satu perekaman per sesi meeting.
  recording_operator_id?: string | null;
  recording_started_at?: string | null;
  recording_heartbeat_at?: string | null;
  recording_source?: string | null;
  vps_dispatched_at?: string | null;
  kick_cooldown_minutes?: number | null;
  host_join_code?: string | null;
  late_join_minutes?: number | null;
  max_active_cameras?: number | null;
  status: 'scheduled' | 'active' | 'ended' | 'expired' | 'deleted';
  scheduled_at: string | null;
  timezone: string | null;
  started_at: string | null;
  expires_at: string | null;
  created_at: string;
  updated_at: string;
}

export type UserRole = 'admin' | 'superadmin' | 'member';

export interface UserRow {
  id: string;
  username: string;
  password_hash: string;
  salt: string;
  role: UserRole;
  name?: string;
  email?: string | null;
  active?: number;
  created_at: string;
}

export interface SessionPayload {
  userId: string;
  username: string;
  role: UserRole;
  exp: number; // Unix timestamp in seconds
}

// Single source of truth for "this session may use operational features"
// (meetings, presets, categories, tentors, recordings, settings, host join).
// Only role 'admin' is an operator. 'superadmin' is restricted to account
// management (/api/admins) and is rejected on operational endpoints.
export function isOperatorRole(role: string | null | undefined): boolean {
  return role === 'admin';
}

const SESSION_COOKIE_NAME = 'learnly_session';
const DEFAULT_EXPIRATION_SECONDS = 60 * 60 * 24 * 7; // 7 days

function isLocalDevelopment(reqUrl: string): boolean {
  const hostname = new URL(reqUrl).hostname;
  return hostname === 'localhost' || hostname === '127.0.0.1';
}

export function getSessionSecret(env: Env, reqUrl: string): string {
  if (env.SESSION_SECRET) return env.SESSION_SECRET;
  if (isLocalDevelopment(reqUrl)) {
    return 'learnly-dev-only-local-secret-not-for-production';
  }
  throw new Error('SESSION_SECRET is not configured. Set it via wrangler secret put SESSION_SECRET or in your .dev.vars file.');
}

// Ensure schema, default admin user, and initial presets exist.
// Runs at most once per isolate — running this on every request causes
// dozens of remote D1 round-trips and can hang concurrent dashboard fetches.
let seedPromise: Promise<void> | null = null;

export function ensureSeeded(db: D1Database, env: Env): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedAdmin(db, env).catch((e) => {
      // Allow retry on next request if seed failed
      seedPromise = null;
      throw e;
    });
  }
  return seedPromise;
}

async function schemaLooksReady(db: D1Database): Promise<boolean> {
  try {
    const admin = await db.prepare("SELECT id FROM users WHERE role IN ('admin', 'superadmin') LIMIT 1").first();
    const meetings = await db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'meetings' LIMIT 1").first();
    const tentors = await db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'tentors' LIMIT 1").first();
    const recordings = await db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'recordings' LIMIT 1").first();
    // The fast path must also see the newer columns: otherwise it would skip the
    // idempotent ALTERs below forever and every insert referencing them would fail.
    let hasResolutionColumns = true;
    try {
      await db.prepare("SELECT resolution_width, resolution_height FROM recordings LIMIT 1").all();
    } catch {
      hasResolutionColumns = false;
    }
    let hasEmailColumn = true;
    try {
      await db.prepare("SELECT email FROM users LIMIT 1").all();
    } catch {
      hasEmailColumn = false;
    }
    let hasActiveColumn = true;
    try {
      await db.prepare("SELECT active FROM users LIMIT 1").all();
    } catch {
      hasActiveColumn = false;
    }
    let hasMaxActiveCamerasColumn = true;
    try {
      await db.prepare("SELECT max_active_cameras FROM meetings LIMIT 1").all();
    } catch {
      hasMaxActiveCamerasColumn = false;
    }
    let hasShareResColumn = true;
    try {
      await db.prepare("SELECT screenshare_resolution FROM meetings LIMIT 1").all();
    } catch {
      hasShareResColumn = false;
    }
    // Kunci rekaman (migration 0015) — wajib ikut diperiksa di fast path,
    // kalau tidak ALTER-nya dilewati selamanya dan setiap klaim rekaman gagal.
    let hasRecordingLockColumns = true;
    try {
      await db.prepare("SELECT recording_operator_id, recording_heartbeat_at FROM meetings LIMIT 1").all();
    } catch {
      hasRecordingLockColumns = false;
    }
    // Kolom rekaman VPS (migration 0016)
    let hasVpsColumns = true;
    try {
      await db.prepare("SELECT source, storage, vps_file_path FROM recordings LIMIT 1").all();
      await db.prepare("SELECT vps_dispatched_at FROM meetings LIMIT 1").all();
    } catch {
      hasVpsColumns = false;
    }
    const passwordResetTable = await db.prepare(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'password_reset_codes' LIMIT 1"
    ).first();
    return Boolean(
      admin && meetings && tentors && recordings && hasResolutionColumns && hasEmailColumn && hasActiveColumn &&
      hasMaxActiveCamerasColumn && hasShareResColumn && hasRecordingLockColumns && hasVpsColumns && passwordResetTable
    );
  } catch {
    return false;
  }
}

// Bootstrap superadmin: memastikan ada TEPAT SATU akun role 'superadmin',
// diadopsi/dibuat dari INITIAL_ADMIN_USERNAME / INITIAL_ADMIN_PASSWORD.
// Password diatur hanya saat pembuatan/adopsi — reset password tidak ditimpa env.
// Setelah superadmin ditemukan, cold start berikutnya TIDAK menyentuh akun lain:
//   - TIDAK menghapus user (admin boleh banyak)
//   - TIDAK memindahkan created_by meetings/presets (histori data utuh)
async function ensureSuperAdmin(db: D1Database, env: Env): Promise<void> {
  const username = (env.INITIAL_ADMIN_USERNAME || '').trim() || 'admin';
  const password = env.INITIAL_ADMIN_PASSWORD || 'admin123';
  const email = username.includes('@') ? username : null;

  const existing = await db.prepare(
    "SELECT id, email, active FROM users WHERE role = 'superadmin' ORDER BY created_at, id LIMIT 1"
  ).first<{ id: string; email: string | null; active?: number }>();

  if (existing) {
    // Superadmin sudah ada — jangan pernah mempromosikan akun lain lagi.
    if (email) {
      // Email env menjadi milik superadmin; baris lain dilepas dari keunikan email.
      await db.prepare("UPDATE users SET email = NULL WHERE email = ? AND id != ?").bind(email, existing.id).run();
      if (existing.email !== email) {
        await db.prepare("UPDATE users SET email = ? WHERE id = ?").bind(email, existing.id).run();
      }
    }
    // Superadmin tidak boleh nonaktif — kalau nonaktif tidak ada yang bisa kelola admin.
    if (existing.active !== 1) {
      await db.prepare("UPDATE users SET active = 1 WHERE id = ?").bind(existing.id).run();
    }
    // Invariant "maksimal 1 superadmin" — defensif, no-op bila sudah terpenuhi.
    await db.prepare("UPDATE users SET role = 'admin' WHERE role = 'superadmin' AND id != ?").bind(existing.id).run();
    return;
  }

  // Belum ada superadmin → promosikan akun yang terikat INITIAL_ADMIN_*.
  const target = await db.prepare("SELECT id, email FROM users WHERE username = ?").bind(username)
    .first<{ id: string; email: string | null }>();
  let superadminId = target?.id;

  if (!superadminId) {
    const salt = generateSalt();
    const hash = await hashPassword(password, salt);
    const legacy = await db.prepare("SELECT id, email FROM users WHERE role = 'admin' ORDER BY created_at, id LIMIT 1")
      .first<{ id: string; email: string | null }>();
    if (legacy) {
      superadminId = legacy.id;
      // Email lama dipertahankan bila username bukan alamat email.
      const mergedEmail = email ?? legacy.email;
      if (email) {
        await db.prepare("UPDATE users SET email = NULL WHERE email = ? AND id != ?").bind(email, superadminId).run();
      }
      await db.prepare(
        "UPDATE users SET username = ?, email = ?, password_hash = ?, salt = ?, role = 'superadmin', active = 1 WHERE id = ?"
      ).bind(username, mergedEmail, hash, salt, superadminId).run();
    } else {
      superadminId = crypto.randomUUID();
      await db.prepare(
        "INSERT INTO users (id, username, password_hash, salt, role, name, email, active) VALUES (?, ?, ?, ?, 'superadmin', 'Administrator', ?, 1)"
      ).bind(superadminId, username, hash, salt, email).run();
    }
  } else if (email) {
    await db.prepare("UPDATE users SET email = NULL WHERE email = ? AND id != ?").bind(email, superadminId).run();
    await db.prepare("UPDATE users SET email = ?, role = 'superadmin', active = 1 WHERE id = ?").bind(email, superadminId).run();
  } else {
    // Username env cocok tapi role belum superadmin → promosikan (sekali).
    await db.prepare("UPDATE users SET role = 'superadmin', active = 1 WHERE id = ?").bind(superadminId).run();
  }
}

export async function seedAdmin(db: D1Database, env: Env): Promise<void> {
  // Fast path: production schema is already migrated — skip heavy DDL.
  // Full path still runs for empty/new databases.
  if (await schemaLooksReady(db)) {
    await ensureSuperAdmin(db, env);
    return;
  }

  await db.exec("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, salt TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', name TEXT, email TEXT, active INTEGER NOT NULL DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  try { await db.exec("ALTER TABLE users ADD COLUMN email TEXT"); } catch { /* column already exists */ }
  try { await db.exec("ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1"); } catch { /* column already exists */ }
  // Akun demo dari migrations/0001 (password hardcoded di repo) → nonaktifkan,
  // tanpa menghapus baris (histori tetap utuh). Idempoten; 0009 juga melakukan ini.
  try {
    await db.exec(
      "UPDATE users SET active = 0 WHERE active = 1 AND ((id = 'usr_teacher_01' AND username = 'teacher1') OR (id = 'usr_student_01' AND username = 'student1') OR (id = 'usr_student_02' AND username = 'student2'))"
    );
  } catch { /* ignore */ }
  try {
    await db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL");
  } catch { /* duplicate emails — fix those rows first (see migration 0008) */ }

  // One-time codes for password reset (HMAC of the code only — never the code itself)
  await db.exec("CREATE TABLE IF NOT EXISTS password_reset_codes (id TEXT PRIMARY KEY, email TEXT NOT NULL, code_hash TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, expires_at DATETIME NOT NULL, consumed_at DATETIME, created_at DATETIME NOT NULL)");
  await db.exec("CREATE INDEX IF NOT EXISTS idx_password_reset_codes_email ON password_reset_codes(email, created_at)");
  await db.exec("CREATE TABLE IF NOT EXISTS presets (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, max_participants INTEGER NOT NULL DEFAULT 20, duration_minutes INTEGER NOT NULL DEFAULT 60, host_resolution TEXT NOT NULL DEFAULT '360p', member_resolution TEXT NOT NULL DEFAULT '240p', created_by TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  await db.exec("CREATE TABLE IF NOT EXISTS meetings (id TEXT PRIMARY KEY, public_id TEXT UNIQUE, provider_meeting_id TEXT NOT NULL, name TEXT NOT NULL, created_by TEXT NOT NULL, max_participants INTEGER NOT NULL DEFAULT 20, duration_minutes INTEGER NOT NULL DEFAULT 60, host_resolution TEXT NOT NULL DEFAULT '360p', member_resolution TEXT NOT NULL DEFAULT '240p', screenshare_resolution TEXT NOT NULL DEFAULT '720p', allow_member_whiteboard INTEGER NOT NULL DEFAULT 0, allow_member_annotation INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'scheduled', scheduled_at DATETIME, timezone TEXT DEFAULT 'UTC', started_at DATETIME, expires_at DATETIME, recording_retention_hours INTEGER DEFAULT 48, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)");

  // Migration helper for existing tables lacking new columns
  try { await db.exec("ALTER TABLE meetings ADD COLUMN public_id TEXT"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN scheduled_at DATETIME"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN timezone TEXT DEFAULT 'UTC'"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN host_resolution TEXT DEFAULT '360p'"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN member_resolution TEXT DEFAULT '240p'"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN allow_member_whiteboard INTEGER DEFAULT 0"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN allow_member_annotation INTEGER DEFAULT 0"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN category_id TEXT"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN auto_record INTEGER DEFAULT 0"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN recording_retention_hours INTEGER DEFAULT 48"); } catch { /* ignore */ }
  // Kunci rekaman (recording lock) — migration 0015
  try { await db.exec("ALTER TABLE meetings ADD COLUMN recording_operator_id TEXT"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN recording_started_at TEXT"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN recording_heartbeat_at TEXT"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN recording_source TEXT"); } catch { /* ignore */ }
  // Rekaman VPS (migration 0016)
  try { await db.exec("ALTER TABLE meetings ADD COLUMN vps_dispatched_at TEXT"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN late_join_minutes INTEGER NOT NULL DEFAULT 30"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN max_active_cameras INTEGER NOT NULL DEFAULT 0"); } catch { /* ignore */ }
  try { await db.exec("ALTER TABLE meetings ADD COLUMN screenshare_resolution TEXT NOT NULL DEFAULT '720p'"); } catch { /* ignore */ }

  // public_id is unique only among live meetings: legacy schemas were created without the
  // UNIQUE constraint, and a soft-deleted row must not block a replacement reusing the id.
  try {
    await db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_meetings_public_id_live ON meetings(public_id) WHERE status != 'deleted'");
  } catch { /* duplicate live public_id — clean those rows up first (see migration 0007) */ }

  // Categories + app settings tables — global meeting link categories and app config
  await db.exec("CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  await db.exec("CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name)");
  await db.exec("CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)");

  // Tentors table — stores tutor names per meeting that can join as host without login
  await db.exec("CREATE TABLE IF NOT EXISTS tentors (id TEXT PRIMARY KEY, meeting_id TEXT NOT NULL, name TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  try { await db.exec("ALTER TABLE tentors ADD COLUMN meeting_id TEXT NOT NULL DEFAULT ''"); } catch { /* column already exists */ }
  // Drop old global UNIQUE on name, replace with per-meeting unique
  try { await db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_tentors_meeting_name ON tentors(meeting_id, name)"); } catch { /* index exists */ }
  // Try dropping autoindex by common names SQLite/D1 may use
  try { await db.exec("DROP INDEX IF EXISTS sqlite_autoindex_tentors_1"); } catch { /* ignore */ }
  try { await db.exec("DROP INDEX IF EXISTS tentors_name_unique"); } catch { /* ignore */ }
  // Nuclear option: if old UNIQUE on name still blocks inserts, recreate the table
  try {
    // Must NOT match idx_tentors_meeting_name (the correct per-meeting unique).
    const hasNameUnique = await db.prepare(
      "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='tentors' AND sql LIKE '%UNIQUE%' AND sql LIKE '%name%' AND sql NOT LIKE '%meeting_id%' AND name != 'idx_tentors_meeting_name'"
    ).all<{name: string}>();
    if (hasNameUnique.results && hasNameUnique.results.length > 0) {
      const rows = await db.prepare("SELECT id, meeting_id, name, created_at FROM tentors").all<TentorRow>();
      await db.exec("DROP TABLE tentors");
      await db.exec("CREATE TABLE tentors (id TEXT PRIMARY KEY, meeting_id TEXT NOT NULL, name TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
      await db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_tentors_meeting_name ON tentors(meeting_id, name)");
      for (const r of rows.results || []) {
        await db.prepare("INSERT INTO tentors (id, meeting_id, name, created_at) VALUES (?, ?, ?, ?)").bind(r.id, r.meeting_id || '', r.name, r.created_at).run();
      }
    }
  } catch { /* ignore */ }

  // Recordings metadata table — stores R2 object key and expiration.
  // Tidak ada kolom provider_recording_id / download_url: rekaman sepenuhnya
  // client-side (file diunggah langsung ke R2 oleh host), tanpa Cloud Export.
  await db.exec("CREATE TABLE IF NOT EXISTS recordings (id TEXT PRIMARY KEY, meeting_id TEXT NOT NULL, storage_key TEXT NOT NULL, file_name TEXT NOT NULL, duration_seconds INTEGER, size_bytes INTEGER, resolution_width INTEGER, resolution_height INTEGER, status TEXT NOT NULL DEFAULT 'ready', expires_at DATETIME NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  await db.exec("CREATE INDEX IF NOT EXISTS idx_recordings_meeting_id ON recordings(meeting_id)");
  await db.exec("CREATE INDEX IF NOT EXISTS idx_recordings_expires_at ON recordings(expires_at)");

  // Migration: add download_count column if missing
  try {
    await db.exec("ALTER TABLE recordings ADD COLUMN download_count INTEGER DEFAULT 0");
  } catch { /* column already exists */ }

  // Migration: recording resolution (nullable — provider payload carries none)
  try {
    await db.exec("ALTER TABLE recordings ADD COLUMN resolution_width INTEGER");
  } catch { /* column already exists */ }
  try {
    await db.exec("ALTER TABLE recordings ADD COLUMN resolution_height INTEGER");
  } catch { /* column already exists */ }
  // Rekaman VPS (migration 0016)
  try {
    await db.exec("ALTER TABLE recordings ADD COLUMN source TEXT DEFAULT 'manual'");
  } catch { /* column already exists */ }
  try {
    await db.exec("ALTER TABLE recordings ADD COLUMN storage TEXT DEFAULT 'r2'");
  } catch { /* column already exists */ }
  try {
    await db.exec("ALTER TABLE recordings ADD COLUMN vps_file_path TEXT");
  } catch { /* column already exists */ }

  // Auto-backfill public_id & resolutions for legacy meetings lacking one
  try {
    await db.exec("UPDATE meetings SET public_id = 'meet-' || substr(id, 1, 6) WHERE public_id IS NULL OR public_id = ''");
    await db.exec("UPDATE meetings SET host_resolution = '360p' WHERE host_resolution IS NULL OR host_resolution = ''");
    await db.exec("UPDATE meetings SET member_resolution = '240p' WHERE member_resolution IS NULL OR member_resolution = ''");
  } catch { /* ignore */ }

  await ensureSuperAdmin(db, env);
  const adminRow = await db.prepare(
    "SELECT id FROM users WHERE role IN ('admin', 'superadmin') ORDER BY CASE WHEN role = 'superadmin' THEN 0 ELSE 1 END, created_at, id LIMIT 1"
  ).first<UserRow>();
  const adminUserId = adminRow?.id;

  // Seed default presets if table is empty
  const presetCheck = await db.prepare("SELECT id FROM presets LIMIT 1").first();
  if (!presetCheck && adminUserId) {
    await db.prepare(
      "INSERT OR IGNORE INTO presets (id, name, max_participants, duration_minutes, host_resolution, member_resolution, created_by) VALUES ('pst_std', 'Standard Classroom', 20, 60, '360p', '240p', ?), ('pst_webinar', 'Large Webinar', 100, 90, '720p', '240p', ?), ('pst_workshop', 'Interactive Workshop', 15, 120, '480p', '360p', ?)"
    ).bind(adminUserId, adminUserId, adminUserId).run();
  }
}

export function generateSalt(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hashPassword(password: string, salt: string): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: enc.encode(salt),
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );
  return Array.from(new Uint8Array(derivedBits), (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPassword(password: string, salt: string, expectedHash: string): Promise<boolean> {
  const computedHash = await hashPassword(password, salt);
  // Constant-time compare
  if (computedHash.length !== expectedHash.length) return false;
  let diff = 0;
  for (let i = 0; i < computedHash.length; i++) {
    diff |= computedHash.charCodeAt(i) ^ expectedHash.charCodeAt(i);
  }
  return diff === 0;
}

// Session signing and verification
async function getCryptoKey(secret: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  return crypto.subtle.importKey(
    'raw',
    enc.encode(secret || 'default-fallback-insecure-secret-learnly'),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify']
  );
}

function base64UrlEncode(str: string): string {
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlDecode(str: string): string {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  return atob(str);
}

export async function createSessionToken(payload: Omit<SessionPayload, 'exp'>, secret: string, maxAgeSec = DEFAULT_EXPIRATION_SECONDS): Promise<string> {
  const exp = Math.floor(Date.now() / 1000) + maxAgeSec;
  const fullPayload: SessionPayload = { ...payload, exp };
  const payloadStr = base64UrlEncode(JSON.stringify(fullPayload));

  const key = await getCryptoKey(secret);
  const enc = new TextEncoder();
  const signatureBuffer = await crypto.subtle.sign('HMAC', key, enc.encode(payloadStr));
  const signatureStr = Array.from(new Uint8Array(signatureBuffer), (b) => b.toString(16).padStart(2, '0')).join('');

  return `${payloadStr}.${signatureStr}`;
}

export async function verifySessionToken(token: string, secret: string): Promise<SessionPayload | null> {
  try {
    const [payloadStr, signatureStr] = token.split('.');
    if (!payloadStr || !signatureStr) return null;

    const key = await getCryptoKey(secret);
    const enc = new TextEncoder();
    const expectedSigBuf = await crypto.subtle.sign('HMAC', key, enc.encode(payloadStr));
    const expectedSigStr = Array.from(new Uint8Array(expectedSigBuf), (b) => b.toString(16).padStart(2, '0')).join('');

    if (expectedSigStr.length !== signatureStr.length) return null;
    let diff = 0;
    for (let i = 0; i < expectedSigStr.length; i++) {
      diff |= expectedSigStr.charCodeAt(i) ^ signatureStr.charCodeAt(i);
    }
    if (diff !== 0) return null;

    const decoded = JSON.parse(base64UrlDecode(payloadStr)) as SessionPayload;
    const now = Math.floor(Date.now() / 1000);
    if (decoded.exp && decoded.exp < now) {
      return null; // Expired
    }
    return decoded;
  } catch {
    return null;
  }
}

function toHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hmacHex(secret: string, data: string): Promise<string> {
  const key = await getCryptoKey(secret);
  const signature = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data));
  return toHex(signature);
}

export function timingSafeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

// Short-lived token handed to the client after a reset code is verified, so the
// code itself never has to be re-sent together with the new password.
export async function createResetToken(userId: string, secret: string, maxAgeSec = 600): Promise<string> {
  const exp = Math.floor(Date.now() / 1000) + maxAgeSec;
  const payloadStr = base64UrlEncode(JSON.stringify({ sub: userId, exp }));
  const signatureStr = await hmacHex(secret, payloadStr);
  return `${payloadStr}.${signatureStr}`;
}

export async function verifyResetToken(token: string, secret: string): Promise<string | null> {
  try {
    const [payloadStr, signatureStr] = token.split('.');
    if (!payloadStr || !signatureStr) return null;

    const expected = await hmacHex(secret, payloadStr);
    if (!timingSafeEqualHex(expected, signatureStr)) return null;

    const decoded = JSON.parse(base64UrlDecode(payloadStr)) as { sub?: string; exp?: number };
    if (!decoded.sub) return null;
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) return null;
    return decoded.sub;
  } catch {
    return null;
  }
}

export function parseCookies(cookieHeader: string | null): Record<string, string> {
  if (!cookieHeader) return {};
  const cookies: Record<string, string> = {};
  for (const part of cookieHeader.split(';')) {
    const [name, ...rest] = part.trim().split('=');
    if (name) {
      cookies[name] = decodeURIComponent(rest.join('='));
    }
  }
  return cookies;
}

export function createSessionCookie(token: string, maxAgeSec = DEFAULT_EXPIRATION_SECONDS, secure = true): string {
  const secureFlag = secure ? 'Secure;' : '';
  return `${SESSION_COOKIE_NAME}=${token}; HttpOnly; ${secureFlag} SameSite=Lax; Path=/; Max-Age=${maxAgeSec}`;
}

export function createClearSessionCookie(secure = true): string {
  const secureFlag = secure ? 'Secure;' : '';
  return `${SESSION_COOKIE_NAME}=; HttpOnly; ${secureFlag} SameSite=Lax; Path=/; Max-Age=0`;
}

export async function getSessionFromRequest(req: Request, env: Env): Promise<SessionPayload | null> {
  const cookieHeader = req.headers.get('cookie');
  const cookies = parseCookies(cookieHeader);
  const token = cookies[SESSION_COOKIE_NAME];
  if (!token) return null;

  try {
    const secret = getSessionSecret(env, req.url);
    return verifySessionToken(token, secret);
  } catch {
    return null;
  }
}
