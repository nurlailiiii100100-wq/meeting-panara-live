import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function AdminProtectedRoute() {
  const { user, status } = useAuth();

  if (status === 'loading') {
    return (
      <div className="min-h-screen w-full tetris-grid flex items-center justify-center text-slate-100">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-slate-600 border-t-emerald-500 rounded-full animate-spin mx-auto"></div>
          <p className="text-slate-400 text-sm">Verifying authentication...</p>
        </div>
      </div>
    );
  }

  if (status === 'unauthenticated' || !user || (user.role !== 'admin' && user.role !== 'superadmin')) {
    return <Navigate to="/admin/login" replace />;
  }

  return <Outlet />;
}
