import { useEffect, useRef, useState, type ClipboardEvent, type FormEvent, type KeyboardEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSiteLogo, ThemeToggle } from '../../../shared';
import {
  Lock,
  User as UserIcon,
  LogIn,
  Eye,
  EyeOff,
  Mail,
  KeyRound,
  ArrowLeft,
  CheckCircle2
} from 'lucide-react';

type View = 'login' | 'email' | 'code' | 'password' | 'done';

const EMPTY_CODE = ['', '', '', '', '', ''];

function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!domain) return email;
  return `${local.slice(0, 1)}•••@${domain}`;
}

async function postJson(path: string, payload: unknown): Promise<Record<string, unknown>> {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(
      typeof data?.message === 'string' && data.message
        ? data.message
        : typeof data?.error === 'string' && data.error
          ? data.error
          : 'Terjadi kesalahan. Coba lagi.'
    );
  }
  return data;
}

export default function AdminLogin() {
  const [view, setView] = useState<View>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [resetEmail, setResetEmail] = useState('');
  const [code, setCode] = useState<string[]>(EMPTY_CODE);
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [resendIn, setResendIn] = useState(0);

  const codeRefs = useRef<Array<HTMLInputElement | null>>([]);
  const { login } = useAuth();
  const navigate = useNavigate();
  const { logo } = useSiteLogo();

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setInterval(() => setResendIn((s) => (s <= 1 ? 0 : s - 1)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const resetWizard = () => {
    setView('login');
    setResetEmail('');
    setCode(EMPTY_CODE);
    setResetToken('');
    setNewPassword('');
    setConfirmPassword('');
    setError(null);
    setInfo(null);
    setResendIn(0);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError('Please enter username and password');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      const res = await login(username.trim(), password);
      if (res.success) {
        navigate('/admin');
      } else {
        setError(res.error || 'Invalid username or password');
      }
    } catch {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const requestCode = async (e?: FormEvent) => {
    e?.preventDefault();
    const email = resetEmail.trim();
    if (!email || !email.includes('@')) {
      setError('Masukkan email yang valid');
      return;
    }
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      await postJson('/api/auth/forgot', { email });
      setView('code');
      setCode(EMPTY_CODE);
      setResendIn(60);
      setInfo(null);
      setTimeout(() => codeRefs.current[0]?.focus(), 50);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan. Coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async (e: FormEvent) => {
    e.preventDefault();
    const value = code.join('');
    if (value.length !== 6) {
      setError('Masukkan 6 digit kode verifikasi');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const data = await postJson('/api/auth/forgot/verify', { email: resetEmail.trim(), code: value });
      setResetToken(String(data.reset_token || ''));
      setNewPassword('');
      setConfirmPassword('');
      setView('password');
    } catch (err) {
      setCode(EMPTY_CODE);
      codeRefs.current[0]?.focus();
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan. Coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const submitNewPassword = async (e: FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      setError('Password minimal 8 karakter');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Password tidak sama');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const data = await postJson('/api/auth/forgot/reset', {
        reset_token: resetToken,
        password: newPassword,
        confirm: confirmPassword
      });
      setInfo(String(data.message || 'Password berhasil diubah.'));
      setView('done');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan. Coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const handleCodeChange = (index: number, raw: string) => {
    const digit = raw.replace(/\D/g, '').slice(-1);
    const next = [...code];
    next[index] = digit;
    setCode(next);
    if (digit && index < 5) codeRefs.current[index + 1]?.focus();
  };

  const handleCodeKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      codeRefs.current[index - 1]?.focus();
    }
  };

  const handleCodePaste = (e: ClipboardEvent<HTMLInputElement>) => {
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!text) return;
    e.preventDefault();
    const next = EMPTY_CODE.map((_, i) => text[i] || '');
    setCode(next);
    codeRefs.current[Math.min(text.length, 6) - 1]?.focus();
  };

  const cardIcon = view === 'login' ? <Lock className="w-6 h-6" />
    : view === 'email' ? <Mail className="w-6 h-6" />
      : view === 'code' ? <KeyRound className="w-6 h-6" />
        : view === 'password' ? <Lock className="w-6 h-6" />
          : <CheckCircle2 className="w-6 h-6" />;

  const stepDot = (step: number, label: string, active: boolean, done: boolean) => (
    <span className={`text-xs ${active ? 'text-emerald-400 font-semibold' : done ? 'text-slate-300' : 'text-slate-500'}`}>
      {done ? '✓' : step} {label}
    </span>
  );

  return (
    <div className="min-h-screen w-full tetris-grid flex flex-col justify-between overflow-x-hidden">
      <header className="flex items-center px-4 sm:px-6 py-4 text-slate-100">
        <div className="flex items-center gap-2">
          <img src={logo || '/learnly.svg'} alt="Learnly" className="w-7 h-7" />
          <span className="font-bold text-2xl tracking-tight">learnly</span>
        </div>
        <div className="ml-auto">
          <ThemeToggle />
        </div>
      </header>

      <main className="flex flex-col items-center justify-center px-4 sm:px-6 py-8 sm:py-12 text-slate-100">
        <div className="w-full max-w-md bg-slate-900 border-2 border-slate-700 p-6 sm:p-8 shadow-xl">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-slate-800 border-2 border-slate-700 mb-3 text-emerald-400">
              {cardIcon}
            </div>

            {view === 'login' && (
              <>
                <h1 className="text-2xl font-bold tracking-tight text-slate-100">Admin Sign In</h1>
                <p className="text-sm text-slate-400 mt-1">
                  Enter your admin credentials to manage classrooms
                </p>
              </>
            )}

            {view !== 'login' && (
              <div className="flex items-center justify-center gap-2">
                {stepDot(1, 'Email', view === 'email', view !== 'email')}
                <span className="text-slate-600">─</span>
                {stepDot(2, 'Kode', view === 'code', view === 'password' || view === 'done')}
                <span className="text-slate-600">─</span>
                {stepDot(3, 'Password', view === 'password', view === 'done')}
              </div>
            )}
          </div>

          {view === 'login' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-slate-300 mb-1 font-medium">Username atau Email</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <UserIcon className="h-4 w-4" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="admin atau admin@domain.com"
                    required
                    autoFocus
                    className="w-full pl-10 pr-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-slate-300 mb-1 font-medium">Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="h-4 w-4" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full pl-10 pr-10 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-2 border-2 accent-btn font-medium px-4 py-3 disabled:opacity-50 transition-all cursor-pointer"
              >
                {loading ? (
                  <span>Signing in...</span>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>Sign In as Admin</span>
                  </>
                )}
              </button>

              <div className="text-center">
                <button
                  type="button"
                  onClick={() => { resetWizard(); setView('email'); setError(null); }}
                  className="text-sm text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  Lupa password?
                </button>
              </div>
            </form>
          )}

          {view === 'email' && (
            <form onSubmit={requestCode} className="space-y-4">
              <div className="text-center">
                <h1 className="text-2xl font-bold tracking-tight text-slate-100">Forgot Your Password?</h1>
                <p className="text-sm text-slate-400 mt-1">
                  Masukkan email akun admin kamu. Kami akan mengirim kode verifikasi.
                </p>
              </div>

              <div>
                <label className="block text-sm text-slate-300 mb-1 font-medium">Email</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Mail className="h-4 w-4" />
                  </div>
                  <input
                    type="email"
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="admin@domain.com"
                    required
                    autoFocus
                    className="w-full pl-10 pr-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-2 border-2 accent-btn font-medium px-4 py-3 disabled:opacity-50 transition-all cursor-pointer"
              >
                {loading ? 'Mengirim...' : 'Kirim Kode Verifikasi'}
              </button>

              <div className="text-center">
                <button
                  type="button"
                  onClick={resetWizard}
                  className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="h-3.5 w-3.5" /> Kembali ke Sign In
                </button>
              </div>
            </form>
          )}

          {view === 'code' && (
            <form onSubmit={verifyCode} className="space-y-4">
              <div className="text-center">
                <h1 className="text-2xl font-bold tracking-tight text-slate-100">Masukkan Kode Verifikasi</h1>
                <p className="text-sm text-slate-400 mt-1">
                  Kode 6 digit sudah dikirim ke <span className="text-slate-200">{maskEmail(resetEmail)}</span>
                </p>
              </div>

              <div className="flex justify-center gap-2" onPaste={handleCodePaste}>
                {code.map((digit, i) => (
                  <input
                    key={i}
                    ref={(el) => { codeRefs.current[i] = el; }}
                    value={digit}
                    onChange={(e) => handleCodeChange(i, e.target.value)}
                    onKeyDown={(e) => handleCodeKeyDown(i, e)}
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    maxLength={1}
                    aria-label={`Digit ${i + 1}`}
                    className="w-10 h-12 text-center text-lg font-semibold border-2 border-slate-700 bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                  />
                ))}
              </div>

              {error && (
                <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-2 border-2 accent-btn font-medium px-4 py-3 disabled:opacity-50 transition-all cursor-pointer"
              >
                {loading ? 'Memeriksa...' : 'Verifikasi'}
              </button>

              <div className="flex items-center justify-between text-sm">
                <button
                  type="button"
                  onClick={() => { setView('email'); setError(null); }}
                  className="inline-flex items-center gap-1 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="h-3.5 w-3.5" /> Ganti email
                </button>
                <button
                  type="button"
                  onClick={() => requestCode()}
                  disabled={resendIn > 0 || loading}
                  className="text-slate-400 hover:text-emerald-400 disabled:text-slate-600 disabled:cursor-not-allowed transition-colors cursor-pointer"
                >
                  {resendIn > 0 ? `Kirim ulang (${resendIn}s)` : 'Kirim ulang'}
                </button>
              </div>
            </form>
          )}

          {view === 'password' && (
            <form onSubmit={submitNewPassword} className="space-y-4">
              <div className="text-center">
                <h1 className="text-2xl font-bold tracking-tight text-slate-100">Buat Password Baru</h1>
                <p className="text-sm text-slate-400 mt-1">
                  Kode untuk <span className="text-slate-200">{maskEmail(resetEmail)}</span> sudah diverifikasi.
                </p>
              </div>

              <div>
                <label className="block text-sm text-slate-300 mb-1 font-medium">Password Baru</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="h-4 w-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Minimal 8 karakter"
                    required
                    autoFocus
                    className="w-full pl-10 pr-10 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-xs text-slate-500 mt-1">Minimal 8 karakter</p>
              </div>

              <div>
                <label className="block text-sm text-slate-300 mb-1 font-medium">Ulangi Password Baru</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="h-4 w-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Ulangi password baru"
                    required
                    className="w-full pl-10 pr-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-2 border-2 accent-btn font-medium px-4 py-3 disabled:opacity-50 transition-all cursor-pointer"
              >
                {loading ? 'Menyimpan...' : 'Simpan Password Baru'}
              </button>
            </form>
          )}

          {view === 'done' && (
            <div className="space-y-4 text-center">
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">Password Berhasil Diubah</h1>
              <p className="text-sm text-slate-400">
                {info || 'Silakan sign in dengan password barumu.'}
              </p>
              <button
                type="button"
                onClick={resetWizard}
                className="w-full inline-flex items-center justify-center gap-2 border-2 accent-btn font-medium px-4 py-3 transition-all cursor-pointer"
              >
                Ke Halaman Sign In
              </button>
            </div>
          )}
        </div>
      </main>

      <footer className="text-center py-6 text-xs text-slate-500">
        &copy; {new Date().getFullYear()} Learnly Meet. Protected Administrative Area.
      </footer>
    </div>
  );
}
