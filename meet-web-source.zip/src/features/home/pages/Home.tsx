import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn } from 'lucide-react';
import { getPersistentUserId, getActiveMeetingSession, setActiveMeetingSession, useSiteLogo, DEFAULT_SITE_TITLE, ThemeToggle } from '../../../shared';

function getAuthTokenFromResponse(data: unknown): string | undefined {
  const d = data as { auth_token?: string; token?: string };
  return d?.auth_token ?? d?.token;
}

export default function Home() {
  const [name, setName] = useState('');
  const [meetingCode, setMeetingCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Host join code — hanya muncul kalau nama terdaftar sebagai tentor dan
  // meeting mengaktifkan kode.
  const [showHostCodePopup, setShowHostCodePopup] = useState(false);
  const [hostCode, setHostCode] = useState('');
  const [hostCodeError, setHostCodeError] = useState<string | null>(null);
  const [hostCodeChecking, setHostCodeChecking] = useState(false);
  const navigate = useNavigate();
  const { logo, title } = useSiteLogo();

  useEffect(() => {
    const cached = localStorage.getItem('learnly:name');
    if (cached) setName(cached);

    // Check for active meeting session to restore
    const activeSession = getActiveMeetingSession();
    if (activeSession?.meetingId) {
      navigate(`/meeting/${activeSession.meetingId}`, { replace: true });
    }
  }, [navigate]);

  async function joinWithCode(asMember = false) {
    if (!meetingCode.trim()) return;
    if (!name.trim()) {
      setError('Nama wajib diisi sebelum masuk meeting.');
      return;
    }
    setError(null);
    setLoading(true);
    const codeToSend = asMember ? '' : hostCode.trim();
    try {
      // Pre-check: verify meeting schedule before requesting token
      const metaRes = await fetch(`/api/meetings/${meetingCode.trim()}`, { credentials: 'include' });
      if (metaRes.ok) {
        const meta = await metaRes.json();
        if (meta.meeting?.status === 'expired' || meta.meeting?.status === 'ended' || meta.meeting?.status === 'deleted') {
          throw new Error('Meeting ini sudah berakhir atau tidak tersedia.');
        }
        if (meta.meeting?.scheduled_at && !meta.meeting?.started_at) {
          const scheduledTime = new Date(meta.meeting.scheduled_at);
          const nowTs = Date.now();
          if (nowTs < scheduledTime.getTime()) {
            throw new Error(`Kelas ini dijadwalkan pada ${scheduledTime.toLocaleString()}. Silakan bergabung setelah jadwal dimulai.`);
          }
          if (nowTs > scheduledTime.getTime() + (meta.meeting.duration_minutes || 60) * 60_000) {
            throw new Error('Kelas ini sudah terlewat dari jadwal. Hubungi pengajar untuk membuka kembali.');
          }
        }
        // Nama terdaftar sebagai tentor + meeting pakai kode host → minta kode dulu
        // (kecuali user memilih masuk sebagai peserta biasa)
        const tentorNames: string[] = Array.isArray(meta.tentor_names) ? meta.tentor_names : [];
        const needsHostCode = meta.host_code_set === true
          && tentorNames.some((t) => String(t).trim().toLowerCase() === name.trim().toLowerCase());
        if (needsHostCode && !codeToSend && !asMember) {
          setShowHostCodePopup(true);
          setHostCodeError(null);
          setLoading(false);
          return;
        }
      }
      const userId = getPersistentUserId();
      const r = await fetch('/api/tokens', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          meetingId: meetingCode.trim(),
          userId,
          name: name.trim(),
          presetName: 'group_call_participant',
          hostCode: codeToSend || undefined,
        })
      });
      const tokenData = await r.json();
      if (!r.ok) {
        // Server sudah memutus (admin/tentor & reconnect tetap lolos); client
        // hanya menerjemahkan pesannya ke Indonesia.
        if (tokenData?.error === 'LATE_JOIN_CLOSED') {
          throw new Error('Kelas sudah berjalan lebih dari batas izin masuk. Hubungi pengajar jika Anda perlu bergabung.');
        }
        throw new Error(tokenData?.message || tokenData?.error || 'Failed to issue token');
      }
      const authToken = getAuthTokenFromResponse(tokenData);
      if (!authToken) throw new Error('Could not obtain auth token');
      const inputCode = meetingCode.trim();
      const targetId = tokenData.public_id || tokenData.meeting_id || inputCode;
      const displayName = name.trim();
      setActiveMeetingSession(targetId, userId, displayName);
      try {
        sessionStorage.setItem(`rtk:token:${targetId}`, authToken);
      } catch { void 0; }
      navigate(`/meeting/${targetId}`);
    } catch (err: unknown) {
      const msg = typeof err === 'object' && err && 'message' in err ? String((err as Error).message) : 'Unable to join with that code';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  // Validasi kode host SEBELUM minta token — kalau salah, user masih di popup
  // dan tidak sempat mendaftarkan diri ke provider sebagai peserta.
  async function submitHostCode() {
    if (!hostCode.trim() || !name.trim() || !meetingCode.trim() || hostCodeChecking) return;
    setHostCodeChecking(true);
    setHostCodeError(null);
    try {
      const r = await fetch(`/api/meetings/${meetingCode.trim()}/host-code`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), code: hostCode.trim() }),
      });
      const d = await r.json().catch(() => null);
      if (!r.ok || d?.valid === false) {
        setHostCodeError(
          d?.reason === 'locked'
            ? `Terlalu banyak percobaan kode host. Coba lagi dalam ${Math.ceil((d?.retry_after_seconds || 600) / 60)} menit.`
            : 'Kode host salah. Coba lagi.'
        );
        return;
      }
      setShowHostCodePopup(false);
      await joinWithCode();
    } catch {
      setHostCodeError('Gagal memeriksa kode host. Coba lagi.');
    } finally {
      setHostCodeChecking(false);
    }
  }

  return (
    <div className="min-h-screen w-full tetris-grid flex flex-col justify-between overflow-x-hidden">

      <header className="flex items-center px-4 sm:px-6 py-4 text-slate-100">
        <div className="flex items-center gap-2">
          <img src={logo || '/learnly.svg'} alt="Learnly" className="w-7 h-7" />
          <span className="font-bold text-2xl tracking-tight">{title || DEFAULT_SITE_TITLE}</span>
        </div>
        <div className="ml-auto">
          <ThemeToggle />
        </div>
      </header>

      <main className="flex flex-col items-center text-center px-4 sm:px-6 text-slate-100 flex-1 justify-center">
        <div className="w-full max-w-md text-left">
          <div className="border-2 border-slate-700 p-4 sm:p-6 shadow-sm bg-slate-900 text-slate-100">
            <h2 className="text-xl font-semibold text-slate-100 mb-4 flex items-center gap-2">
              <LogIn className="w-5 h-5 text-emerald-400" />
              Join Classroom
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-300">Meeting ID / Code</label>
                <input
                  value={meetingCode}
                  onChange={(e) => setMeetingCode(e.target.value)}
                  placeholder="e.g. frontend-01"
                  className="mt-1 w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-600"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-300">Your display name *</label>
                <input
                  value={name}
                  onChange={(e) => { setName(e.target.value); localStorage.setItem('learnly:name', e.target.value); }}
                  placeholder="e.g. Alex Johnson"
                  className="mt-1 w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-600"
                />
              </div>
              {error && <div className="text-red-400 text-sm">{error}</div>}
              <button
                onClick={() => joinWithCode()}
                disabled={!meetingCode.trim() || !name.trim() || loading}
                className="w-full border-2 accent-btn font-medium px-4 py-3 disabled:opacity-50 cursor-pointer transition-all"
              >
                {loading ? 'Joining Session...' : 'Join Classroom'}
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Host join code — hanya muncul untuk nama terdaftar di list tentor */}
      {showHostCodePopup && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-sm w-full text-center shadow-2xl rounded-lg">
            <h2 className="text-slate-100 font-semibold text-lg mb-1">Kode Host</h2>
            <p className="text-slate-400 text-xs mb-4">
              Nama <span className="text-slate-200 font-medium">{name.trim()}</span> terdaftar sebagai tentor.
              Masukkan kode host untuk masuk sebagai host.
            </p>
            <input
              value={hostCode}
              onChange={(e) => { setHostCode(e.target.value.replace(/\D/g, '').slice(0, 10)); setHostCodeError(null); }}
              onKeyDown={(e) => { if (e.key === 'Enter') submitHostCode(); }}
              inputMode="numeric"
              autoComplete="off"
              placeholder="Contoh: 123456"
              autoFocus
              className="w-full px-3 py-2 mb-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-600 text-sm text-center tracking-widest"
            />
            {hostCodeError && <div className="text-red-400 text-xs mb-2 text-left">{hostCodeError}</div>}
            <button
              onClick={submitHostCode}
              disabled={!hostCode.trim() || hostCodeChecking}
              className="w-full border-2 accent-btn font-medium px-4 py-2 text-sm disabled:opacity-50 cursor-pointer transition-all mb-2"
            >
              {hostCodeChecking ? 'Memeriksa...' : 'Masuk sebagai Host'}
            </button>
            <button
              onClick={() => { setShowHostCodePopup(false); setHostCode(''); setHostCodeError(null); joinWithCode(true); }}
              className="w-full text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
            >
              Masuk sebagai peserta biasa
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
