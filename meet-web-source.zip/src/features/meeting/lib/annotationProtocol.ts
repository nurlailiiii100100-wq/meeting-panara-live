/*
 * Screen Share Annotation realtime protocol.
 *
 * Independent from the Whiteboard WB_* protocol (see Whiteboard.tsx).
 * Transport: `meeting.participants.broadcastMessage` via annotBroadcast.ts
 * (ordered queue rate-limited under the SDK's 5 broadcasts/sec cap).
 *
 * Every message carries `userId` (persistent sender id, used for echo
 * filtering) and, except STATE_REQUEST, `sessionId` (used to ignore messages
 * from a previous/stale annotation session).
 *
 * Message flow:
 *  - Host broadcasts ANNOT_SESSION_START { userId, sessionId, sharerId }
 *    -> every client opens AnnotationStage bound to that sharer.
 *  - Host broadcasts ANNOT_SESSION_END { userId, sessionId }
 *    -> every client closes AnnotationStage. Screen share keeps running.
 *  - Late joiners / refresh: client broadcasts ANNOT_STATE_REQUEST { userId }.
 *    Host answers with ANNOT_SESSION_START (session info, handled by Meeting)
 *    and the host's open stage answers ANNOT_STATE_SYNC
 *    { userId, sessionId, sharerId, strokes } (annotation state).
 *  - Freehand (pen/highlighter): ANNOT_STROKE_START / ANNOT_STROKE_POINT
 *    (batched ~30fps, JSON string because the typed channel only carries
 *    primitives) / ANNOT_STROKE_END.
 *  - Shapes & text are sent complete on pointer release (local preview only
 *    while dragging): ANNOT_STROKE_START carrying the full geometry, then
 *    ANNOT_STROKE_END. No POINT batches.
 *  - ANNOT_CLEAR (host only) removes every annotation of the session.
 *  - ANNOT_DELETE { userId, sessionId, annotationId } removes one annotation
 *    by id (eraser). Any client with draw permission may delete any
 *    annotation it touches.
 *  - ANNOT_UNDO { userId, sessionId, annotationId } removes the sender's own
 *    last annotation on every client (never another user's).
 *  - ANNOT_REDO { userId, sessionId, annotation } re-adds a previously undone
 *    own annotation (full serialized annotation, applied by id).
 *
 * Backward compatibility note: receivers ignore unknown `kind` values instead
 * of crashing, and every mutation is id-keyed (never array-index based).
 */

export const ANNOT_SESSION_START = 'ANNOT_SESSION_START';
export const ANNOT_SESSION_END = 'ANNOT_SESSION_END';
export const ANNOT_STATE_REQUEST = 'ANNOT_STATE_REQUEST';
export const ANNOT_STATE_SYNC = 'ANNOT_STATE_SYNC';
export const ANNOT_STROKE_START = 'ANNOT_STROKE_START';
export const ANNOT_STROKE_POINT = 'ANNOT_STROKE_POINT';
export const ANNOT_STROKE_END = 'ANNOT_STROKE_END';
export const ANNOT_CLEAR = 'ANNOT_CLEAR';
export const ANNOT_UNDO = 'ANNOT_UNDO';
export const ANNOT_REDO = 'ANNOT_REDO';
export const ANNOT_DELETE = 'ANNOT_DELETE';

// BroadcastMessagePayload only allows primitive values, so structured data
// (point batches, full annotation lists) is serialized as a JSON string.
export type AnnotPayload = Record<string, string | number | boolean>;

export interface AnnotPoint {
  x: number; // normalized 0..1 relative to the actual video frame
  y: number; // normalized 0..1 relative to the actual video frame
}

export type AnnotMode = 'pen' | 'eraser';

// Annotation geometry kind. 'freehand' covers pen + highlighter strokes
// (distinguished by the `highlight` flag); shapes/text carry their own
// normalized geometry. All positions/sizes are normalized 0..1.
export type AnnotKind = 'freehand' | 'line' | 'arrow' | 'rect' | 'circle' | 'text';

// Toolbar tools. Draw tools map to kinds: pen/highlighter -> 'freehand',
// shapes/text map 1:1, eraser deletes on touch (creates nothing).
export type AnnotTool =
  | 'pen'
  | 'highlighter'
  | 'line'
  | 'arrow'
  | 'rect'
  | 'circle'
  | 'text'
  | 'eraser';

export type AnnotSizeLevel = 1 | 2 | 3;

export interface AnnotAnnotation {
  id: string;
  userId: string;
  kind: AnnotKind;
  mode: AnnotMode; // kept for protocol stability ('pen' for all created kinds)
  highlight: boolean; // true only for highlighter freehand strokes
  color: string;
  // Stroke width as a fraction of the video frame height — reproducible on
  // every client regardless of screen size (never raw screen pixels).
  width: number;
  size: AnnotSizeLevel;
  points: AnnotPoint[]; // freehand only
  sx: number; // line/arrow start x (normalized)
  sy: number; // line/arrow start y
  ex: number; // line/arrow end x
  ey: number; // line/arrow end y
  x: number; // rect/circle/text: normalized left
  y: number; // rect/circle/text: normalized top
  w: number; // rect/circle: normalized width (>= 0)
  h: number; // rect/circle: normalized height (>= 0)
  text: string; // text only
  // Text size as a fraction of the video frame height.
  fontSize: number;
  done: boolean;
}

export interface AnnotationSessionInfo {
  sessionId: string;
  sharerId: string;
  starterUserId: string; // persistent user id of the host that started the session
}

export function newAnnotationSessionId(): string {
  return crypto.randomUUID();
}

export function newAnnotationId(userId: string): string {
  return `${userId}:${Date.now()}:${Math.random().toString(36).slice(2, 7)}`;
}

// Palette: the 6 required colors first, existing colors preserved.
export const ANNOT_PALETTE = [
  '#111827', // black
  '#ef4444', // red
  '#fbbf24', // yellow
  '#4ade80', // green
  '#38bdf8', // blue
  '#f8fafc', // white
  '#f472b6', // pink
];
export const ANNOT_DEFAULT_COLOR = '#ef4444';

// Pen widths (fraction of frame height) per thickness level.
// Highlighter multiplies the pen width; font size is its own scale.
const PEN_WIDTHS: Record<AnnotSizeLevel, number> = { 1: 0.004, 2: 0.007, 3: 0.012 };
const HIGHLIGHT_MULT = 3.5;
const FONT_SIZES: Record<AnnotSizeLevel, number> = { 1: 0.032, 2: 0.045, 3: 0.06 };

export function normalizeSizeLevel(size: unknown): AnnotSizeLevel {
  return size === 1 || size === 2 || size === 3 ? size : 2;
}

export function penWidthForSize(size: AnnotSizeLevel, highlight: boolean): number {
  const base = PEN_WIDTHS[size] ?? PEN_WIDTHS[2];
  return highlight ? base * HIGHLIGHT_MULT : base;
}

export function fontSizeForSize(size: AnnotSizeLevel): number {
  return FONT_SIZES[size] ?? FONT_SIZES[2];
}

// Freehand points are flushed at ~30fps so we never send one message per
// pointer event.
export const ANNOT_FLUSH_MS = 33;
// Eraser hit threshold in screen pixels (evaluated after mapping to the
// actual frame, so behavior is identical on every screen size).
export const ANNOT_ERASER_THRESHOLD_PX = 14;
// Minimum drag (normalized units) for a shape to be kept on release.
export const ANNOT_MIN_SHAPE_SPAN = 0.005;

export function baseAnnotation(
  id: string,
  userId: string,
  kind: AnnotKind,
  color: string,
  size: AnnotSizeLevel
): AnnotAnnotation {
  return {
    id,
    userId,
    kind,
    mode: 'pen',
    highlight: false,
    color,
    width: penWidthForSize(size, false),
    size,
    points: [],
    sx: 0,
    sy: 0,
    ex: 0,
    ey: 0,
    x: 0,
    y: 0,
    w: 0,
    h: 0,
    text: '',
    fontSize: fontSizeForSize(size),
    done: false,
  };
}

// ---- Serialization (for STATE_SYNC / REDO payloads) ----

export function serializeAnnot(a: AnnotAnnotation): Record<string, unknown> {
  return {
    id: a.id,
    userId: a.userId,
    kind: a.kind,
    highlight: a.highlight,
    color: a.color,
    width: a.width,
    size: a.size,
    points: a.points,
    sx: a.sx,
    sy: a.sy,
    ex: a.ex,
    ey: a.ey,
    x: a.x,
    y: a.y,
    w: a.w,
    h: a.h,
    text: a.text,
    fontSize: a.fontSize,
  };
}

const KNOWN_KINDS: AnnotKind[] = ['freehand', 'line', 'arrow', 'rect', 'circle', 'text'];

// Returns null for unknown kinds / malformed payloads (receiver ignores).
export function parseAnnot(raw: unknown): AnnotAnnotation | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.id !== 'string' || !r.id) return null;
  if (!KNOWN_KINDS.includes(r.kind as AnnotKind)) return null;
  const num = (v: unknown, fallback: number) =>
    typeof v === 'number' && Number.isFinite(v) ? v : fallback;
  const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
  const size = normalizeSizeLevel(r.size);
  const points: AnnotPoint[] = Array.isArray(r.points)
    ? (r.points as Array<Record<string, unknown>>)
        .map((pt) => ({ x: num(pt.x, NaN), y: num(pt.y, NaN) }))
        .filter((pt) => Number.isFinite(pt.x) && Number.isFinite(pt.y))
        .map((pt) => ({ x: clamp01(pt.x), y: clamp01(pt.y) }))
    : [];
  return {
    id: r.id,
    userId: typeof r.userId === 'string' ? r.userId : '',
    kind: r.kind as AnnotKind,
    mode: 'pen',
    highlight: r.highlight === true,
    color: typeof r.color === 'string' ? r.color : '#f8fafc',
    width: num(r.width, penWidthForSize(size, r.highlight === true)),
    size,
    points,
    sx: clamp01(num(r.sx, 0)),
    sy: clamp01(num(r.sy, 0)),
    ex: clamp01(num(r.ex, 0)),
    ey: clamp01(num(r.ey, 0)),
    x: clamp01(num(r.x, 0)),
    y: clamp01(num(r.y, 0)),
    w: Math.max(0, num(r.w, 0)),
    h: Math.max(0, num(r.h, 0)),
    text: typeof r.text === 'string' ? r.text.slice(0, 500) : '',
    fontSize: num(r.fontSize, fontSizeForSize(size)),
    done: true,
  };
}

export function parseAnnotList(raw: unknown): AnnotAnnotation[] {
  if (!Array.isArray(raw)) return [];
  const out: AnnotAnnotation[] = [];
  for (const item of raw) {
    const a = parseAnnot(item);
    if (a) out.push(a);
  }
  return out;
}

export function parseJsonAnnotList(json: unknown): AnnotAnnotation[] {
  if (typeof json === 'string') {
    try {
      const parsed: unknown = JSON.parse(json);
      return parseAnnotList(parsed);
    } catch {
      return [];
    }
  }
  return parseAnnotList(json);
}

/*
 * Contain-fit frame math.
 *
 * The shared video is rendered with `object-fit: contain`, so the actual
 * video frame may be letterboxed/pillarboxed inside its container. All
 * annotation coordinates are normalized (0..1) against the ACTUAL frame,
 * never against raw container pixels — this keeps annotations aligned for
 * every participant regardless of screen size or aspect ratio.
 */
export interface VideoFrame {
  videoWidth: number;
  videoHeight: number;
  offsetX: number;
  offsetY: number;
}

export function videoFrameForContain(
  containerWidth: number,
  containerHeight: number,
  trackWidth: number,
  trackHeight: number
): VideoFrame | null {
  if (
    !Number.isFinite(containerWidth) || !Number.isFinite(containerHeight) ||
    !Number.isFinite(trackWidth) || !Number.isFinite(trackHeight) ||
    containerWidth <= 0 || containerHeight <= 0 ||
    trackWidth <= 0 || trackHeight <= 0
  ) {
    return null;
  }
  const scale = Math.min(containerWidth / trackWidth, containerHeight / trackHeight);
  const videoWidth = trackWidth * scale;
  const videoHeight = trackHeight * scale;
  return {
    videoWidth,
    videoHeight,
    offsetX: (containerWidth - videoWidth) / 2,
    offsetY: (containerHeight - videoHeight) / 2,
  };
}

// Container-relative pointer position -> normalized frame coordinate.
// Returns null when the pointer is on the letterbox bars (do not draw).
export function pointerToNormalized(
  pointerX: number,
  pointerY: number,
  frame: VideoFrame
): AnnotPoint | null {
  const nx = (pointerX - frame.offsetX) / frame.videoWidth;
  const ny = (pointerY - frame.offsetY) / frame.videoHeight;
  if (nx < 0 || nx > 1 || ny < 0 || ny > 1) return null;
  return { x: nx, y: ny };
}

// Normalized frame coordinate -> container-relative screen position.
export function normalizedToScreen(
  nx: number,
  ny: number,
  frame: VideoFrame
): { x: number; y: number } {
  return {
    x: frame.offsetX + nx * frame.videoWidth,
    y: frame.offsetY + ny * frame.videoHeight,
  };
}

// ---- Eraser hit-testing (all in screen pixels after frame mapping,
// so the feel is identical on every screen size) ----

function distPointSeg(
  px: number, py: number,
  ax: number, ay: number,
  bx: number, by: number
): number {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  let t = 0;
  if (lenSq > 0) {
    t = ((px - ax) * dx + (py - ay) * dy) / lenSq;
    t = Math.min(1, Math.max(0, t));
  }
  const cx = ax + t * dx;
  const cy = ay + t * dy;
  return Math.hypot(px - cx, py - cy);
}

// Approximate screen-space bounding box of a text annotation.
export function textBoxFor(
  a: Pick<AnnotAnnotation, 'x' | 'y' | 'text' | 'fontSize'>,
  frame: VideoFrame
): { left: number; top: number; width: number; height: number } {
  const origin = normalizedToScreen(a.x, a.y, frame);
  const fontPx = Math.max(1, a.fontSize * frame.videoHeight);
  return {
    left: origin.x,
    top: origin.y,
    width: Math.max(1, a.text.length * 0.6 * fontPx),
    height: Math.max(1, 1.25 * fontPx),
  };
}

// True when the normalized pointer touches the annotation (eraser V1:
// freehand distance + shape/text bounding areas).
export function hitAnnot(nx: number, ny: number, a: AnnotAnnotation, frame: VideoFrame): boolean {
  const t = ANNOT_ERASER_THRESHOLD_PX;
  const p = normalizedToScreen(nx, ny, frame);
  switch (a.kind) {
    case 'freehand': {
      if (a.points.length === 0) return false;
      if (a.points.length === 1) {
        const s = normalizedToScreen(a.points[0].x, a.points[0].y, frame);
        return Math.hypot(p.x - s.x, p.y - s.y) <= t;
      }
      for (let i = 1; i < a.points.length; i++) {
        const s0 = normalizedToScreen(a.points[i - 1].x, a.points[i - 1].y, frame);
        const s1 = normalizedToScreen(a.points[i].x, a.points[i].y, frame);
        if (distPointSeg(p.x, p.y, s0.x, s0.y, s1.x, s1.y) <= t) return true;
      }
      return false;
    }
    case 'line':
    case 'arrow': {
      const s0 = normalizedToScreen(a.sx, a.sy, frame);
      const s1 = normalizedToScreen(a.ex, a.ey, frame);
      return distPointSeg(p.x, p.y, s0.x, s0.y, s1.x, s1.y) <= t;
    }
    case 'rect':
    case 'circle': {
      const tl = normalizedToScreen(a.x, a.y, frame);
      const br = normalizedToScreen(a.x + a.w, a.y + a.h, frame);
      return (
        p.x >= tl.x - t && p.x <= br.x + t &&
        p.y >= tl.y - t && p.y <= br.y + t
      );
    }
    case 'text': {
      const box = textBoxFor(a, frame);
      return (
        p.x >= box.left - t && p.x <= box.left + box.width + t &&
        p.y >= box.top - t && p.y <= box.top + box.height + t
      );
    }
    default:
      return false;
  }
}
