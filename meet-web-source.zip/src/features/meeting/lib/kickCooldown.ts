/*
 * Kick cooldown plumbing shared by EVERY kick path.
 *
 * The app exposes two kick buttons:
 *   1. our "Manage Participants" drawer (Meeting.tsx), and
 *   2. the built-in RealtimeKit participants menu (inside <RtkMeeting>).
 * Path 2 calls `participant.kick()` on the SDK object directly and never
 * reaches our API, so the member was removed from the room without any
 * rejoin cooldown being recorded (and without any toast).
 *
 * `patchParticipantKick` wraps the SDK participant prototype's `kick()` so
 * both paths go through the backend first: remove + record cooldown, then
 * let the SDK do its realtime teardown.
 */

export type KickResult = {
  ok: boolean;
  message?: string;
  cooldownMinutes?: number;
  cooldownRecorded?: boolean;
};

export const KICK_RESULT_EVENT = 'meet:kick-result';

const PATCH_FLAG = '__kickCooldownPatched';
const RECENT_MS = 15_000;

type KickableParticipant = {
  id?: string;
  customParticipantId?: string;
  kick?: (...args: unknown[]) => unknown;
};

let runtimeMeetingId = '';
const recentlyRecorded = new Map<string, number>();

export function setKickMeetingId(meetingId: string): void {
  if (meetingId) runtimeMeetingId = meetingId;
}

export function emitKickResult(result: KickResult): void {
  window.dispatchEvent(new CustomEvent<KickResult>(KICK_RESULT_EVENT, { detail: result }));
}

function markRecorded(participantId: string): void {
  recentlyRecorded.set(participantId, Date.now());
  if (recentlyRecorded.size > 50) {
    const cutoff = Date.now() - RECENT_MS;
    for (const [key, at] of recentlyRecorded) {
      if (at < cutoff) recentlyRecorded.delete(key);
    }
  }
}

function wasRecentlyRecorded(participantId: string): boolean {
  const at = recentlyRecorded.get(participantId);
  if (at === undefined) return false;
  if (Date.now() - at > RECENT_MS) {
    recentlyRecorded.delete(participantId);
    return false;
  }
  return true;
}

type KickApiResponse = {
  message?: string;
  cooldown_recorded?: boolean;
  kick_cooldown_minutes?: number;
};

/** Remove the participant through the backend (records the cooldown) + toast. */
export async function kickViaBackend(
  participantId: string,
  customParticipantId?: string
): Promise<KickResult> {
  const emit = (result: KickResult): KickResult => {
    emitKickResult(result);
    return result;
  };

  const meetingId = runtimeMeetingId;
  if (!meetingId || !participantId) {
    return emit({ ok: false, message: 'Meeting belum siap, coba lagi sebentar.' });
  }

  const userParam = customParticipantId ? `?user=${encodeURIComponent(customParticipantId)}` : '';
  try {
    const res = await fetch(
      `/api/meetings/${encodeURIComponent(meetingId)}/participants/${encodeURIComponent(participantId)}${userParam}`,
      { method: 'DELETE', credentials: 'include' }
    );
    const data = (await res.json().catch(() => null)) as KickApiResponse | null;
    if (!res.ok) {
      return emit({ ok: false, message: data?.message || `Gagal mengeluarkan peserta (HTTP ${res.status})` });
    }
    markRecorded(participantId);
    return emit({
      ok: true,
      cooldownMinutes: typeof data?.kick_cooldown_minutes === 'number' ? data.kick_cooldown_minutes : 0,
      cooldownRecorded: data?.cooldown_recorded === true
    });
  } catch (e) {
    return emit({ ok: false, message: e instanceof Error ? e.message : 'Gagal mengeluarkan peserta' });
  }
}

/**
 * Wrap `kick()` on the SDK participant prototype so the built-in RealtimeKit
 * participants menu records the cooldown too. Idempotent (flagged on the
 * prototype) and safe to call on every poll tick.
 */
export function patchParticipantKick(meeting: unknown): void {
  const joined = (meeting as
    | { participants?: { joined?: { toArray?: () => KickableParticipant[] } } }
    | null
    | undefined)?.participants?.joined;

  let participants: KickableParticipant[] = [];
  try {
    participants = joined?.toArray?.() ?? [];
  } catch {
    return;
  }

  for (const participant of participants) {
    if (!participant || typeof participant.kick !== 'function') continue;
    const proto = Object.getPrototypeOf(participant) as Record<string, unknown> | null;
    if (!proto || typeof proto.kick !== 'function' || proto[PATCH_FLAG]) continue;

    const original = proto.kick as (this: KickableParticipant, ...args: unknown[]) => unknown;
    proto[PATCH_FLAG] = true;
    proto.kick = async function (this: KickableParticipant, ...args: unknown[]) {
      const participantId = typeof this.id === 'string' ? this.id : '';
      if (participantId && !wasRecentlyRecorded(participantId)) {
        await kickViaBackend(participantId, this.customParticipantId);
      }
      try {
        return await original.apply(this, args);
      } catch {
        /* backend removal already happened — SDK kick is best effort */
        return undefined;
      }
    };
  }
}
