/*
 * Ordered, rate-limited transport for ANNOT_* broadcasts.
 *
 * RTK's `meeting.participants.broadcastMessage` is rate limited client-side
 * to 5 invocations/second (SDK decorator `rateLimitConfig`, error code
 * "0013") and throws SYNCHRONOUSLY once the budget is used up. Annotation
 * used to fire one broadcast per 33ms flush (~30/s) straight into that
 * limit through a swallowing try/catch, so most ANNOT_STROKE_POINT batches
 * silently never left the sender: local view stayed intact, remote view
 * broke.
 *
 * Every annotation broadcast funnels through ONE FIFO queue that:
 *   - paces real invocations ANNOT_BROADCAST_MIN_INTERVAL_MS apart
 *     (250ms => max 4/s, under the SDK's 5/s budget, leaving headroom for
 *     the occasional session/permission message);
 *   - coalesces consecutive ANNOT_STROKE_POINT batches of the same stroke
 *     into a single queued message (fewer broadcasts, zero point loss);
 *   - keeps strict FIFO with a single in-flight message, so STROKE_START
 *     is always broadcast before POINT and STROKE_END always after, even
 *     across retries;
 *   - removes a message only after the SDK accepted it — synchronous rate
 *     limit throws and async rejections retry the SAME head message, so
 *     nothing is ever dropped.
 */

import type { Meeting } from '@cloudflare/realtimekit-react-ui';
import {
  ANNOT_STROKE_POINT,
  type AnnotPayload,
  type AnnotPoint,
} from './annotationProtocol';

// <= 4 broadcasts/sec: comfortably under the SDK's 5 invocations/sec cap.
export const ANNOT_BROADCAST_MIN_INTERVAL_MS = 250;

interface QueuedMessage {
  type: string;
  payload: AnnotPayload;
  // POINT batches keep raw points here and are serialized only when actually
  // broadcast, so later batches of the same stroke can still be appended
  // (coalesced) while the message sits in the queue.
  points: AnnotPoint[] | null;
}

const queue: QueuedMessage[] = [];
let meetingRef: Meeting | null = null;
let timer: number | null = null;
let inFlight: QueuedMessage | null = null;
let lastAttemptAt = 0;
let lastWarnAt = 0;

// Failures are never silent: the message stays queued and retries, this
// logs at most once every 5s so a struggling socket cannot spam the console.
function warnRetry(reason: string): void {
  const now = Date.now();
  if (now - lastWarnAt < 5000) return;
  lastWarnAt = now;
  console.warn(`[annotation] broadcast retry (${reason}), queued=${queue.length}`);
}

function schedule(delay: number): void {
  if (timer !== null) return;
  timer = window.setTimeout(pump, delay);
}

function kick(): void {
  if (timer === null && inFlight === null) schedule(0);
}

function pump(): void {
  timer = null;
  if (inFlight !== null) return; // settle callback will re-kick
  if (queue.length === 0) return;
  const wait = ANNOT_BROADCAST_MIN_INTERVAL_MS - (Date.now() - lastAttemptAt);
  if (wait > 0) {
    schedule(wait);
    return;
  }
  const msg = queue[0];
  const participants = meetingRef?.participants;
  if (typeof participants?.broadcastMessage !== 'function') {
    // Room not joined (yet) — keep the message queued, try again shortly.
    schedule(ANNOT_BROADCAST_MIN_INTERVAL_MS);
    return;
  }
  const payload: AnnotPayload = msg.points
    ? { ...msg.payload, points: JSON.stringify(msg.points) }
    : msg.payload;
  inFlight = msg;
  lastAttemptAt = Date.now(); // pace from the actual attempt (what the SDK counts)
  let sent: Promise<unknown>;
  try {
    sent = participants.broadcastMessage(msg.type, payload);
  } catch (err) {
    // Synchronous SDK rate limit ("0013") or similar — msg stays at head.
    inFlight = null;
    warnRetry(err instanceof Error ? err.message : 'rate limited');
    schedule(ANNOT_BROADCAST_MIN_INTERVAL_MS);
    return;
  }
  Promise.resolve(sent).then(
    () => {
      inFlight = null;
      if (queue[0] === msg) queue.shift();
      kick();
    },
    (err: unknown) => {
      // Async failure — retry the SAME head so START/POINT/END order holds.
      inFlight = null;
      warnRetry(err instanceof Error ? err.message : 'rejected');
      schedule(ANNOT_BROADCAST_MIN_INTERVAL_MS);
    }
  );
}

/**
 * Queue one annotation broadcast. Never throws, never drops: delivery is
 * retried until the SDK accepts the message.
 *
 * `points` is for ANNOT_STROKE_POINT batches only — consecutive queued
 * batches of the same stroke are coalesced into one broadcast. Returns
 * false only when the transport refused the message (the caller must then
 * keep its pending data; today the queue always accepts).
 */
export function enqueueAnnotBroadcast(
  meeting: Meeting | null | undefined,
  type: string,
  payload: AnnotPayload,
  points?: AnnotPoint[]
): boolean {
  if (meeting) meetingRef = meeting;
  const tail = queue.length > 0 ? queue[queue.length - 1] : null;
  if (
    points &&
    points.length > 0 &&
    tail !== null &&
    tail !== inFlight &&
    tail.type === ANNOT_STROKE_POINT &&
    tail.points !== null &&
    tail.payload.id === payload.id &&
    tail.payload.sessionId === payload.sessionId
  ) {
    tail.points.push(...points);
  } else {
    queue.push({ type, payload, points: points ? points.slice() : null });
  }
  kick();
  return true;
}
