// Screen share capability detection + kontrak bridge native (WebView wrapper).
//
// Tiga jalur eksekusi (sesuai feature detection yang diinginkan):
//   'web'         -> navigator.mediaDevices.getDisplayMedia tersedia (desktop).
//   'native'      -> wrapper native menyuntikkan window.MeetNativeScreenShare
//                    (Android MediaProjection / iOS ReplayKit di native layer).
//   'unsupported' -> browser HP/tablet biasa: API getDisplayMedia memang tidak
//                    ada (iOS/iPadOS semua versi, Chrome & Firefox Android
//                    versi sekarang). Bukan bug kode, tapi batasan platform.
//   'insecure'    -> halaman dibuka lewat HTTP: navigator.mediaDevices tidak
//                    ada sama sekali (secure context wajib untuk media API).
//
// Deteksi memakai keberadaan API, BUKAN user-agent, karena iPadOS melaporkan
// UA "Macintosh" dan Chrome Android versi lama pernah mengekspos API yang
// selalu gagal. UA hanya dipakai untuk menyesuaikan teks pesan.

export type ScreenShareMode = 'web' | 'native' | 'unsupported' | 'insecure';

export interface NativeScreenShareBridge {
  start: () => Promise<void>;
  stop: () => Promise<void>;
  isActive?: () => boolean;
}

declare global {
  interface Window {
    /**
     * Disuntikkan oleh wrapper native (Android/iOS) sebelum halaman meeting
     * dijalankan. Menangani MediaProjection/ReplayKit di sisi native lalu
     * menerbitkan hasilnya ke RealtimeKit lewat SDK native-nya.
     */
    MeetNativeScreenShare?: NativeScreenShareBridge;
  }
}

/** Event dikirim native -> web setelah status native screen share berubah. */
export const NATIVE_SHARE_STATE_EVENT = 'learnly:native-screenshare-state';

export interface ScreenShareSupport {
  mode: ScreenShareMode;
  /** Browser ini bisa memulai screen share lewat web API. */
  webSupported: boolean;
  /** Wrapper native siap menangani screen share. */
  nativeSupported: boolean;
  secureContext: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  isMobile: boolean;
}

export function getNativeScreenShareBridge(): NativeScreenShareBridge | null {
  if (typeof window === 'undefined') return null;
  const bridge = window.MeetNativeScreenShare;
  if (!bridge || typeof bridge.start !== 'function' || typeof bridge.stop !== 'function') {
    return null;
  }
  return bridge;
}

function hasWebScreenShare(): boolean {
  if (typeof navigator === 'undefined') return false;
  if (!navigator.mediaDevices) return false;
  return typeof navigator.mediaDevices.getDisplayMedia === 'function';
}

function detectPlatform(): Pick<ScreenShareSupport, 'isIOS' | 'isAndroid' | 'isMobile'> {
  if (typeof navigator === 'undefined') return { isIOS: false, isAndroid: false, isMobile: false };
  const ua = navigator.userAgent;
  const isAndroid = /Android/i.test(ua);
  // iPadOS >= 13 melaporkan UA desktop "Macintosh"; dibedakan via maxTouchPoints.
  const isIOS =
    /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isMobile = isIOS || isAndroid || /Mobi|Windows Phone/i.test(ua);
  return { isIOS, isAndroid, isMobile };
}

export function getScreenShareSupport(): ScreenShareSupport {
  const secureContext = typeof window === 'undefined' ? false : window.isSecureContext !== false;
  const webSupported = secureContext && hasWebScreenShare();
  const nativeSupported = getNativeScreenShareBridge() !== null;
  const platform = detectPlatform();

  let mode: ScreenShareMode;
  if (webSupported) mode = 'web';
  else if (nativeSupported) mode = 'native';
  else if (!secureContext) mode = 'insecure';
  else mode = 'unsupported';

  return { mode, webSupported, nativeSupported, secureContext, ...platform };
}

/**
 * Deteksi ringkas: browser ini punya API web screen share (getDisplayMedia)?
 * Satu-satunya sumber fitur deteksi — dipakai ShareScreenNotice lewat
 * utils/screenShareSupport agar logika tidak terpecah dua.
 */
export const isScreenShareSupported = (): boolean => hasWebScreenShare();

/**
 * Subscribe perubahan status native screen share.
 * Native wajib melempar:
 *   window.dispatchEvent(new CustomEvent('learnly:native-screenshare-state',
 *     { detail: { active: boolean } }))
 * Return fungsi unsubscribe.
 */
export function subscribeNativeShareState(listener: (active: boolean) => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const handler = (event: Event) => {
    const detail = (event as CustomEvent<{ active?: boolean }>).detail;
    listener(detail?.active === true);
  };
  window.addEventListener(NATIVE_SHARE_STATE_EVENT, handler);

  const bridge = getNativeScreenShareBridge();
  if (bridge?.isActive) {
    try {
      listener(bridge.isActive() === true);
    } catch {
      /* bridge tidak menyediakan state awal yang valid */
    }
  }

  return () => window.removeEventListener(NATIVE_SHARE_STATE_EVENT, handler);
}

/** Hentikan screen share native (dipakai saat user keluar dari meeting). */
export function stopNativeScreenShareIfActive(): void {
  const bridge = getNativeScreenShareBridge();
  if (!bridge) return;
  const active = bridge.isActive ? bridge.isActive() === true : true;
  if (!active) return;
  bridge.stop().catch(() => {
    /* native layer sudah berhenti sendiri */
  });
}
