import { AlertTriangle, X } from 'lucide-react';
import { isScreenShareSupported } from '../utils/screenShareSupport';

interface ShareScreenNoticeProps {
  show: boolean;
  mediaError: boolean;
  dismissed: boolean;
  onDismiss: () => void;
}

export function ShareScreenNotice({ show, mediaError, dismissed, onDismiss }: ShareScreenNoticeProps) {
  if (!show || dismissed || isScreenShareSupported()) return null;
  return (
    <div className={`absolute left-4 right-4 z-50 pointer-events-auto ${mediaError ? 'top-28' : 'top-16'}`}>
      <div className="bg-amber-950/95 border border-amber-700 px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 backdrop-blur-sm max-w-md mx-auto w-full">
        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
        <p className="text-amber-200 text-xs font-medium flex-1">
          Fitur Share Screen tidak didukung di browser HP/tablet — gunakan Chrome/Edge di laptop/PC untuk berbagi layar.
        </p>
        <button
          onClick={onDismiss}
          title="Tutup"
          className="text-amber-400 hover:text-amber-200 cursor-pointer shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
