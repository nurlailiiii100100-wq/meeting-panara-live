import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Pen, Highlighter, Minus, ArrowUpRight, Square, Circle as CircleIcon, Type,
  Eraser, Undo2, Redo2, Trash2, Palette, ChevronDown, X, Check,
} from 'lucide-react';
import type { Meeting } from '@cloudflare/realtimekit-react-ui';
import type { ScreenSharer } from '../hooks/useScreenShare';
import { Tooltip } from '../../../shared';
import { enqueueAnnotBroadcast } from '../lib/annotBroadcast';
import { isHostPeer } from '../utils/hostBadge';
import {
  ANNOT_CLEAR,
  ANNOT_DELETE,
  ANNOT_PALETTE,
  ANNOT_DEFAULT_COLOR,
  ANNOT_FLUSH_MS,
  ANNOT_MIN_SHAPE_SPAN,
  ANNOT_REDO,
  ANNOT_STATE_REQUEST,
  ANNOT_STATE_SYNC,
  ANNOT_STROKE_END,
  ANNOT_STROKE_POINT,
  ANNOT_STROKE_START,
  ANNOT_UNDO,
  type AnnotAnnotation,
  type AnnotPayload,
  type AnnotPoint,
  type AnnotSizeLevel,
  type AnnotTool,
  type AnnotationSessionInfo,
  type VideoFrame,
  baseAnnotation,
  fontSizeForSize,
  hitAnnot,
  newAnnotationId,
  normalizedToScreen,
  normalizeSizeLevel,
  parseAnnot,
  parseJsonAnnotList,
  penWidthForSize,
  pointerToNormalized,
  serializeAnnot,
  videoFrameForContain,
} from '../lib/annotationProtocol';

/*
 * Screen Share Annotation Stage — Zoom-style annotation over a live screen share.
 *
 * Fullscreen takeover overlay (same pattern as Whiteboard.tsx): <RtkMeeting>
 * keeps running underneath (audio/video/RTC/recording untouched), while this
 * stage shows ONE screen share view with a transparent annotation canvas
 * exactly on top of the actual video frame.
 *
 * Rendering choice: a plain <video> fed from the sharer's official
 * `screenShareTracks.video` track (the same attach pattern the SDK itself
 * uses) — this keeps `object-fit: contain` geometry uniform for self and
 * remote sharers so overlay coordinates always match.
 *
 * Coordinates are normalized 0..1 against the ACTUAL video frame computed
 * from contain-fit math (see annotationProtocol.ts), never raw pixels.
 *
 * Tools: pen, highlighter, line, arrow, rectangle, circle, text, eraser
 * (touch-to-delete), undo/redo (own annotations, id-broadcast so every
 * client converges), color, thickness, clear-all (host only).
 *
 * Independent from Whiteboard.tsx: separate protocol (ANNOT_*), separate
 * annotations, separate permission flag. Nothing is shared or moved.
 */

interface AnnotationStageProps {
  meeting: Meeting;
  session: AnnotationSessionInfo;
  sharer: ScreenSharer | null;
  sharerName: string;
  onStop: () => void; // host only: broadcast SESSION_END + close
  myUserId: string;
  isHost: boolean;
  canDraw: boolean;
  allowMemberAnnotation: boolean;
  onToggleAnnotation: (allowed: boolean) => void;
  onClose?: () => void;
}

interface FrameDims {
  cw: number;
  ch: number;
  tw: number;
  th: number;
}

interface TextDraft {
  nx: number;
  ny: number;
  value: string;
}

type MenuId = 'draw' | 'shapes' | 'color' | 'size' | null;

const DRAW_TOOLS: AnnotTool[] = ['pen', 'highlighter'];
const SHAPE_TOOLS: AnnotTool[] = ['line', 'arrow', 'rect', 'circle'];

const TOOL_META: Record<AnnotTool, { label: string }> = {
  pen: { label: 'Pen' },
  highlighter: { label: 'Highlighter' },
  line: { label: 'Line' },
  arrow: { label: 'Arrow' },
  rect: { label: 'Rectangle' },
  circle: { label: 'Circle' },
  text: { label: 'Text' },
  eraser: { label: 'Eraser' },
};

function ToolIcon({ tool, className }: { tool: AnnotTool; className: string }) {
  switch (tool) {
    case 'pen':
      return <Pen className={className} />;
    case 'highlighter':
      return <Highlighter className={className} />;
    case 'line':
      return <Minus className={className} />;
    case 'arrow':
      return <ArrowUpRight className={className} />;
    case 'rect':
      return <Square className={className} />;
    case 'circle':
      return <CircleIcon className={className} />;
    case 'text':
      return <Type className={className} />;
    case 'eraser':
      return <Eraser className={className} />;
  }
}

export default function AnnotationStage({
  meeting,
  session,
  sharer,
  sharerName,
  onStop,
  myUserId,
  isHost,
  canDraw,
  allowMemberAnnotation,
  onToggleAnnotation,
  onClose,
}: AnnotationStageProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const annotsRef = useRef<Map<string, AnnotAnnotation>>(new Map());
  const dirtyRef = useRef(true);
  const drawingIdRef = useRef<string | null>(null);
  const dragStartRef = useRef<{ tool: AnnotTool; start: AnnotPoint } | null>(null);
  const previewRef = useRef<AnnotAnnotation | null>(null);
  const pendingPointsRef = useRef<Array<{ id: string; x: number; y: number }>>([]);
  const flushTimerRef = useRef<number | null>(null);
  const syncedRef = useRef(false);
  const redoStackRef = useRef<AnnotAnnotation[]>([]);
  const sharerRef = useRef<ScreenSharer | null>(sharer);
  sharerRef.current = sharer;

  const [tool, setTool] = useState<AnnotTool>('pen');
  const [color, setColor] = useState(ANNOT_DEFAULT_COLOR);
  const [size, setSize] = useState<AnnotSizeLevel>(2);
  const [dims, setDims] = useState<FrameDims>({ cw: 0, ch: 0, tw: 0, th: 0 });
  const [trackAlive, setTrackAlive] = useState(true);
  const [textDraft, setTextDraft] = useState<TextDraft | null>(null);
  const [openMenu, setOpenMenu] = useState<MenuId>(null);
  // Bumped on every discrete annotation mutation so undo/redo disabled
  // states stay fresh (strokes themselves live in refs, never in state).
  const [, setHistTick] = useState(0);
  const bumpHist = useCallback(() => setHistTick((t) => t + 1), []);

  const sessionId = session.sessionId;
  const sharerId = session.sharerId;

  const frame: VideoFrame | null = videoFrameForContain(dims.cw, dims.ch, dims.tw, dims.th);
  const frameRef = useRef<VideoFrame | null>(null);
  frameRef.current = frame;

  const send = useCallback(
    (type: string, payload: AnnotPayload) => {
      // Routed through the shared ordered, rate-limited annotation transport
      // (RTK caps broadcastMessage at 5/s and throws "0013" when exceeded).
      enqueueAnnotBroadcast(meeting, type, payload);
    },
    [meeting]
  );

  const readTrack = useCallback((): MediaStreamTrack | null => {
    try {
      const t = (sharerRef.current as { screenShareTracks?: { video?: unknown } } | null)
        ?.screenShareTracks?.video;
      return t instanceof MediaStreamTrack ? t : null;
    } catch {
      return null;
    }
  }, []);

  // ---- Frame measurement: container size + track content size ----
  const refreshDims = useCallback(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const cw = wrap.clientWidth;
    const ch = wrap.clientHeight;
    let tw = 0;
    let th = 0;
    try {
      const s = readTrack()?.getSettings?.() as { width?: number; height?: number } | undefined;
      if (typeof s?.width === 'number' && typeof s?.height === 'number' && s.width > 0 && s.height > 0) {
        tw = s.width;
        th = s.height;
      }
    } catch {
      /* track not readable yet */
    }
    if (tw <= 0 || th <= 0) {
      const v = videoRef.current;
      if (v && v.videoWidth > 0 && v.videoHeight > 0) {
        tw = v.videoWidth;
        th = v.videoHeight;
      } else {
        tw = 16;
        th = 9;
      }
    }
    setDims((prev) => (prev.cw === cw && prev.ch === ch && prev.tw === tw && prev.th === th
      ? prev
      : { cw, ch, tw, th }));
    dirtyRef.current = true;
  }, [readTrack]);

  useEffect(() => {
    refreshDims();
    const wrap = wrapRef.current;
    if (!wrap || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => refreshDims());
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [refreshDims]);

  // Re-read track settings periodically while open: the sharer may resize
  // their window or switch tab mid-session (same track object, new size).
  useEffect(() => {
    const t = window.setInterval(refreshDims, 2000);
    return () => window.clearInterval(t);
  }, [refreshDims]);

  // ---- Canvas backing store (DPR-aware) ----
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, Math.round(dims.cw * dpr));
    canvas.height = Math.max(1, Math.round(dims.ch * dpr));
    canvas.style.width = `${dims.cw}px`;
    canvas.style.height = `${dims.ch}px`;
    dirtyRef.current = true;
  }, [dims.cw, dims.ch]);

  // ---- Attach the sharer's screen track to our own <video> ----
  useEffect(() => {
    const video = videoRef.current;
    const track = readTrack();
    if (!video) return;
    if (!track) {
      try {
        video.srcObject = null;
      } catch {
        /* ignore */
      }
      return;
    }
    try {
      video.srcObject = new MediaStream([track]);
      void video.play().catch(() => {
        /* autoplay blocked — user gesture on stage will resume */
      });
    } catch {
      /* ignore attach errors */
    }
    setTrackAlive(track.readyState !== 'ended');
    const onEnded = () => setTrackAlive(false);
    const onLoadedMetadata = () => refreshDims();
    try {
      track.addEventListener('ended', onEnded);
      video.addEventListener('loadedmetadata', onLoadedMetadata);
    } catch {
      /* ignore */
    }
    refreshDims();
    return () => {
      try {
        track.removeEventListener('ended', onEnded);
        video.removeEventListener('loadedmetadata', onLoadedMetadata);
      } catch {
        /* ignore */
      }
      try {
        if (video.srcObject instanceof MediaStream) {
          video.srcObject.getTracks().forEach((t) => {
            if (t !== track) {
              try {
                t.stop();
              } catch {
                /* ignore */
              }
            }
          });
          video.srcObject = null;
        }
      } catch {
        /* ignore */
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sharer, sharerId]);

  // ---- Annotation rendering ----
  const drawAnnot = useCallback(
    (ctx: CanvasRenderingContext2D, a: AnnotAnnotation, f: VideoFrame, preview: boolean) => {
      const linePx = Math.max(1, a.width * f.videoHeight);
      ctx.globalAlpha = preview ? 0.65 : a.highlight ? 0.35 : 1;
      ctx.strokeStyle = a.color;
      ctx.fillStyle = a.color;
      ctx.lineWidth = linePx;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      if (preview) {
        ctx.setLineDash([7, 5]);
      } else {
        ctx.setLineDash([]);
      }

      switch (a.kind) {
        case 'freehand': {
          if (a.points.length === 0) break;
          ctx.beginPath();
          const first = normalizedToScreen(a.points[0].x, a.points[0].y, f);
          ctx.moveTo(first.x, first.y);
          if (a.points.length === 1) ctx.lineTo(first.x + 0.01, first.y + 0.01);
          for (let i = 1; i < a.points.length; i++) {
            const pt = normalizedToScreen(a.points[i].x, a.points[i].y, f);
            ctx.lineTo(pt.x, pt.y);
          }
          ctx.stroke();
          break;
        }
        case 'line': {
          const s0 = normalizedToScreen(a.sx, a.sy, f);
          const s1 = normalizedToScreen(a.ex, a.ey, f);
          ctx.beginPath();
          ctx.moveTo(s0.x, s0.y);
          ctx.lineTo(s1.x, s1.y);
          ctx.stroke();
          break;
        }
        case 'arrow': {
          const s0 = normalizedToScreen(a.sx, a.sy, f);
          const s1 = normalizedToScreen(a.ex, a.ey, f);
          ctx.beginPath();
          ctx.moveTo(s0.x, s0.y);
          ctx.lineTo(s1.x, s1.y);
          ctx.stroke();
          const angle = Math.atan2(s1.y - s0.y, s1.x - s0.x);
          const headLen = Math.min(48, Math.max(12, linePx * 8));
          const headAngle = Math.PI / 7;
          ctx.beginPath();
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(
            s1.x - headLen * Math.cos(angle - headAngle),
            s1.y - headLen * Math.sin(angle - headAngle)
          );
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(
            s1.x - headLen * Math.cos(angle + headAngle),
            s1.y - headLen * Math.sin(angle + headAngle)
          );
          ctx.stroke();
          break;
        }
        case 'rect': {
          const tl = normalizedToScreen(a.x, a.y, f);
          ctx.strokeRect(tl.x, tl.y, a.w * f.videoWidth, a.h * f.videoHeight);
          break;
        }
        case 'circle': {
          const tl = normalizedToScreen(a.x, a.y, f);
          ctx.beginPath();
          ctx.ellipse(
            tl.x + (a.w * f.videoWidth) / 2,
            tl.y + (a.h * f.videoHeight) / 2,
            Math.max(0.5, (a.w * f.videoWidth) / 2),
            Math.max(0.5, (a.h * f.videoHeight) / 2),
            0, 0, Math.PI * 2
          );
          ctx.stroke();
          break;
        }
        case 'text': {
          if (!a.text) break;
          const origin = normalizedToScreen(a.x, a.y, f);
          const fontPx = Math.max(8, a.fontSize * f.videoHeight);
          ctx.font = `500 ${fontPx}px system-ui, -apple-system, sans-serif`;
          ctx.textBaseline = 'top';
          const pad = fontPx * 0.25;
          const tw = ctx.measureText(a.text).width;
          ctx.fillStyle = 'rgba(2, 6, 23, 0.7)';
          ctx.fillRect(origin.x - pad, origin.y - pad, tw + pad * 2, fontPx * 1.25 + pad * 2);
          ctx.fillStyle = a.color;
          ctx.fillText(a.text, origin.x, origin.y);
          break;
        }
      }
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    },
    []
  );

  // ---- Redraw loop (single rAF loop redraws only when dirty) ----
  useEffect(() => {
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const canvas = canvasRef.current;
      const f = frameRef.current;
      if (!canvas || !dirtyRef.current || !f) return;
      dirtyRef.current = false;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const dpr = window.devicePixelRatio || 1;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, dims.cw, dims.ch);

      for (const a of annotsRef.current.values()) {
        drawAnnot(ctx, a, f, false);
      }
      const preview = previewRef.current;
      if (preview) drawAnnot(ctx, preview, f, true);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [dims.cw, dims.ch, sessionId, drawAnnot]);

  // ---- Local mutation helpers (each discrete mutation bumps hist tick
  // so undo/redo disabled states stay fresh) ----
  const deleteLocal = useCallback(
    (id: string) => {
      if (annotsRef.current.delete(id)) {
        dirtyRef.current = true;
        bumpHist();
        return true;
      }
      return false;
    },
    [bumpHist]
  );

  // Resolve a sender's host status from live room state (never from the
  // payload) so only admins can delete annotations they don't own.
  const senderIsHost = useCallback(
    (senderUserId: string): boolean => {
      if (!senderUserId) return false;
      try {
        const peers = meeting?.participants?.joined?.toArray() ?? [];
        const sender = peers.find(
          (p) => p.customParticipantId === senderUserId || p.id === senderUserId
        );
        return isHostPeer(sender);
      } catch {
        return false;
      }
    },
    [meeting]
  );

  // ---- Realtime receive ----
  useEffect(() => {
    if (!meeting?.participants?.on || !meeting?.participants?.off) return;

    const onMessage = (event: { type: string; payload: Record<string, unknown> }) => {
      const p = event.payload || {};
      const from = typeof p.userId === 'string' ? p.userId : '';
      if (from && from === myUserId) return; // ignore echoes of our own messages

      switch (event.type) {
        case ANNOT_STROKE_START: {
          if (typeof p.id !== 'string') return;
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          const kind = p.kind === 'line' || p.kind === 'arrow' || p.kind === 'rect' ||
            p.kind === 'circle' || p.kind === 'text' ? p.kind : 'freehand';
          const size = normalizeSizeLevel(p.size);
          const highlight = p.highlight === true;
          const color = typeof p.color === 'string' ? p.color : '#f8fafc';
          const width = typeof p.width === 'number' && Number.isFinite(p.width)
            ? p.width
            : penWidthForSize(size, highlight);
          if (kind === 'freehand') {
            const x = Number(p.x);
            const y = Number(p.y);
            if (!Number.isFinite(x) || !Number.isFinite(y)) return;
            annotsRef.current.set(p.id, {
              ...baseAnnotation(p.id, from, kind, color, size),
              highlight,
              width,
              points: [{ x, y }],
              done: false,
            });
          } else if (kind === 'line' || kind === 'arrow') {
            annotsRef.current.set(p.id, {
              ...baseAnnotation(p.id, from, kind, color, size),
              width,
              sx: Number(p.sx) || 0,
              sy: Number(p.sy) || 0,
              ex: Number(p.ex) || 0,
              ey: Number(p.ey) || 0,
              done: false,
            });
          } else if (kind === 'rect' || kind === 'circle') {
            annotsRef.current.set(p.id, {
              ...baseAnnotation(p.id, from, kind, color, size),
              width,
              x: Number(p.x) || 0,
              y: Number(p.y) || 0,
              w: Math.max(0, Number(p.w) || 0),
              h: Math.max(0, Number(p.h) || 0),
              done: false,
            });
          } else {
            // text arrives complete on START
            annotsRef.current.set(p.id, {
              ...baseAnnotation(p.id, from, kind, color, size),
              width,
              x: Number(p.x) || 0,
              y: Number(p.y) || 0,
              text: typeof p.text === 'string' ? p.text.slice(0, 500) : '',
              fontSize: typeof p.fontSize === 'number' && Number.isFinite(p.fontSize)
                ? p.fontSize
                : fontSizeForSize(size),
              done: false,
            });
          }
          dirtyRef.current = true;
          bumpHist();
          break;
        }
        case ANNOT_STROKE_POINT: {
          if (typeof p.id !== 'string') return;
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          const stroke = annotsRef.current.get(p.id);
          // OWNERSHIP GUARD: only the stroke creator can append points
          if (!stroke || stroke.userId !== from || stroke.kind !== 'freehand') return;
          let list: Array<Record<string, unknown>> | null = null;
          if (typeof p.points === 'string') {
            try {
              const parsed: unknown = JSON.parse(p.points);
              if (Array.isArray(parsed)) list = parsed as Array<Record<string, unknown>>;
            } catch {
              list = null;
            }
          } else if (Array.isArray(p.points)) {
            list = p.points as Array<Record<string, unknown>>;
          }
          if (!list) return;
          for (const pt of list) {
            const x = Number(pt.x);
            const y = Number(pt.y);
            if (Number.isFinite(x) && Number.isFinite(y)) {
              stroke.points.push({ x, y });
            }
          }
          dirtyRef.current = true;
          break;
        }
        case ANNOT_STROKE_END: {
          if (typeof p.id !== 'string') return;
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          const stroke = annotsRef.current.get(p.id);
          // OWNERSHIP GUARD: only the stroke creator can complete the stroke
          if (!stroke || stroke.userId !== from) return;
          stroke.done = true;
          dirtyRef.current = true;
          break;
        }
        case ANNOT_CLEAR: {
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          // OWNERSHIP GUARD: clear only removes annotations created by the sender ('from')
          for (const [id, a] of annotsRef.current.entries()) {
            if (a.userId === from) {
              annotsRef.current.delete(id);
            }
          }
          redoStackRef.current = redoStackRef.current.filter((a) => a.userId !== from);
          dirtyRef.current = true;
          bumpHist();
          break;
        }
        case ANNOT_DELETE: {
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          if (typeof p.annotationId !== 'string') return;
          const target = annotsRef.current.get(p.annotationId as string);
          if (!target) return;
          // Members may only delete their own; the host may delete anyone's.
          if (target.userId !== from && !senderIsHost(from)) return;
          redoStackRef.current = redoStackRef.current.filter((a) => a.id !== p.annotationId);
          deleteLocal(p.annotationId as string);
          break;
        }
        case ANNOT_UNDO: {
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          if (typeof p.annotationId !== 'string') return;
          const target = annotsRef.current.get(p.annotationId as string);
          // OWNERSHIP GUARD: only the annotation creator can undo it
          if (!target || target.userId !== from) return;
          redoStackRef.current = redoStackRef.current.filter((a) => a.id !== p.annotationId);
          deleteLocal(p.annotationId as string);
          break;
        }
        case ANNOT_REDO: {
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          if (typeof p.annotation !== 'string') return;
          try {
            const parsed: unknown = JSON.parse(p.annotation as string);
            const a = parseAnnot(parsed);
            // OWNERSHIP GUARD: only the annotation creator can redo it
            if (a && a.userId === from && !annotsRef.current.has(a.id)) {
              annotsRef.current.set(a.id, { ...a, done: true });
              dirtyRef.current = true;
              bumpHist();
            }
          } catch {
            /* malformed redo payload — ignore */
          }
          break;
        }
        case ANNOT_STATE_REQUEST: {
          // Only the host answers so N participants don't flood N syncs.
          if (!isHost || !from) return;
          send(ANNOT_STATE_SYNC, {
            userId: myUserId,
            sessionId,
            sharerId,
            strokes: JSON.stringify(
              Array.from(annotsRef.current.values()).map(serializeAnnot)
            ),
          });
          break;
        }
        case ANNOT_STATE_SYNC: {
          if (typeof p.sessionId !== 'string' || p.sessionId !== sessionId) return; // stale session
          const list = parseJsonAnnotList(p.strokes);
          annotsRef.current.clear();
          for (const a of list) annotsRef.current.set(a.id, { ...a, done: true });
          redoStackRef.current = [];
          syncedRef.current = true;
          dirtyRef.current = true;
          bumpHist();
          break;
        }
      }
    };

    meeting.participants.on('broadcastedMessage', onMessage);
    return () => {
      meeting.participants.off('broadcastedMessage', onMessage);
    };
  }, [meeting, myUserId, isHost, send, sessionId, sharerId, deleteLocal, bumpHist, senderIsHost]);

  // ---- Ask for current state when opening (late joiner / refresh recovery) ----
  useEffect(() => {
    syncedRef.current = false;
    const ask = () => {
      if (!syncedRef.current) send(ANNOT_STATE_REQUEST, { userId: myUserId });
    };
    const t = window.setTimeout(ask, 600);
    const interval = window.setInterval(ask, 3000);
    return () => {
      window.clearTimeout(t);
      window.clearInterval(interval);
    };
  }, [send, myUserId, sessionId]);

  // ---- Flush queued freehand points at ~30fps (33ms) into the ordered
  // rate-limited transport (broadcasts themselves are paced in
  // annotBroadcast, so this cadence never exceeds the SDK's 5/s budget) ----
  const flushPoints = useCallback(() => {
    flushTimerRef.current = null;
    if (pendingPointsRef.current.length === 0) return;
    const batch = pendingPointsRef.current;
    // Hand the batch to the retrying transport FIRST; local pending points
    // are only cleared once the transport accepted them (never dropped).
    const enqueued = enqueueAnnotBroadcast(
      meeting,
      ANNOT_STROKE_POINT,
      { userId: myUserId, sessionId, id: batch[0].id },
      batch
    );
    if (enqueued) pendingPointsRef.current = [];
  }, [meeting, myUserId, sessionId]);

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (flushTimerRef.current !== null) {
        window.clearTimeout(flushTimerRef.current);
        flushTimerRef.current = null;
      }
    };
  }, []);

  // ---- Shared finalize for locally created annotations ----
  const commitLocal = useCallback(
    (a: AnnotAnnotation) => {
      a.done = true;
      annotsRef.current.set(a.id, a);
      redoStackRef.current = []; // new annotation clears redo history (editor norm)
      dirtyRef.current = true;
      bumpHist();
    },
    [bumpHist]
  );

  const broadcastFullShape = useCallback(
    (a: AnnotAnnotation) => {
      // Shapes/text are sent complete on release (local preview only before).
      const base = {
        userId: myUserId,
        sessionId,
        id: a.id,
        kind: a.kind,
        color: a.color,
        width: a.width,
        size: a.size,
      };
      if (a.kind === 'line' || a.kind === 'arrow') {
        send(ANNOT_STROKE_START, { ...base, sx: a.sx, sy: a.sy, ex: a.ex, ey: a.ey });
      } else if (a.kind === 'rect' || a.kind === 'circle') {
        send(ANNOT_STROKE_START, { ...base, x: a.x, y: a.y, w: a.w, h: a.h });
      } else if (a.kind === 'text') {
        send(ANNOT_STROKE_START, { ...base, x: a.x, y: a.y, text: a.text, fontSize: a.fontSize });
      }
      send(ANNOT_STROKE_END, { userId: myUserId, sessionId, id: a.id });
    },
    [send, myUserId, sessionId]
  );

  // ---- Pointer handlers (permission guarded in EVERY edit path) ----
  const toNormalized = (e: React.PointerEvent<HTMLCanvasElement>): AnnotPoint | null => {
    const f = frameRef.current;
    if (!f) return null;
    const rect = e.currentTarget.getBoundingClientRect();
    return pointerToNormalized(e.clientX - rect.left, e.clientY - rect.top, f);
  };

  const eraseAt = useCallback(
    (pt: AnnotPoint) => {
      const f = frameRef.current;
      if (!f) return;
      // Topmost first (insertion order reversed).
      const all = Array.from(annotsRef.current.values()).reverse();
      for (const a of all) {
        // OWNERSHIP GUARD: members erase only their own; the host may erase any.
        if (!isHost && a.userId !== myUserId) continue;
        let hit = false;
        try {
          hit = hitAnnot(pt.x, pt.y, a, f);
        } catch {
          hit = false;
        }
        if (hit) {
          redoStackRef.current = redoStackRef.current.filter((r) => r.id !== a.id);
          if (deleteLocal(a.id)) {
            send(ANNOT_DELETE, { userId: myUserId, sessionId, annotationId: a.id });
          }
          return;
        }
      }
    },
    [deleteLocal, send, myUserId, sessionId, isHost]
  );

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!canDraw) return; // permission enforced here, not just by hiding buttons
    if (textDraft) return; // finish/cancel the pending text first
    const pt = toNormalized(e);
    if (!pt) return; // pointer on the letterbox bars — do not draw

    if (tool === 'eraser') {
      e.currentTarget.setPointerCapture(e.pointerId);
      drawingIdRef.current = 'erase-drag';
      eraseAt(pt);
      return;
    }
    if (tool === 'text') {
      setTextDraft({ nx: pt.x, ny: pt.y, value: '' });
      return;
    }
    e.currentTarget.setPointerCapture(e.pointerId);

    if (tool === 'pen' || tool === 'highlighter') {
      const highlight = tool === 'highlighter';
      const id = newAnnotationId(myUserId);
      drawingIdRef.current = id;
      const a: AnnotAnnotation = {
        ...baseAnnotation(id, myUserId, 'freehand', color, size),
        highlight,
        width: penWidthForSize(size, highlight),
        points: [{ x: pt.x, y: pt.y }],
        done: false,
      };
      annotsRef.current.set(id, a);
      dirtyRef.current = true;
      send(ANNOT_STROKE_START, {
        userId: myUserId,
        sessionId,
        id,
        kind: 'freehand',
        highlight,
        color,
        width: a.width,
        size,
        x: pt.x,
        y: pt.y,
      });
      return;
    }

    // Shapes: begin local-only drag preview; broadcast happens on release.
    dragStartRef.current = { tool, start: pt };
    previewRef.current = {
      ...baseAnnotation('preview', myUserId, 'freehand', color, size),
      width: penWidthForSize(size, false),
      done: false,
    };
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!canDraw || textDraft) return;
    const pt = toNormalized(e);
    if (!pt) {
      // Leaving the frame cancels an in-progress shape preview.
      if (dragStartRef.current) {
        dragStartRef.current = null;
        previewRef.current = null;
        dirtyRef.current = true;
      }
      return;
    }

    if (tool === 'eraser') {
      if (drawingIdRef.current === 'erase-drag' && (e.buttons & 1) === 1) eraseAt(pt);
      return;
    }

    const freeId = drawingIdRef.current;
    if (freeId && freeId !== 'erase-drag') {
      const stroke = annotsRef.current.get(freeId);
      if (stroke && stroke.kind === 'freehand') {
        stroke.points.push({ x: pt.x, y: pt.y }); // Immediate local 0ms render
        dirtyRef.current = true;
      }
      pendingPointsRef.current.push({ id: freeId, x: pt.x, y: pt.y });
      if (flushTimerRef.current === null) {
        flushTimerRef.current = window.setTimeout(flushPoints, ANNOT_FLUSH_MS);
      }
      return;
    }

    const drag = dragStartRef.current;
    if (drag) {
      const { start } = drag;
      const prev = previewRef.current;
      if (!prev) return;
      if (drag.tool === 'line' || drag.tool === 'arrow') {
        const kind: AnnotAnnotation['kind'] = drag.tool;
        previewRef.current = {
          ...prev,
          kind,
          sx: start.x,
          sy: start.y,
          ex: pt.x,
          ey: pt.y,
        };
      } else if (drag.tool === 'rect' || drag.tool === 'circle') {
        const kind: AnnotAnnotation['kind'] = drag.tool;
        previewRef.current = {
          ...prev,
          kind,
          x: Math.min(start.x, pt.x),
          y: Math.min(start.y, pt.y),
          w: Math.abs(pt.x - start.x),
          h: Math.abs(pt.y - start.y),
        };
      }
      dirtyRef.current = true;
    }
  };

  const finishShapePreview = useCallback(() => {
    const drag = dragStartRef.current;
    const prev = previewRef.current;
    dragStartRef.current = null;
    previewRef.current = null;
    if (!drag || !prev) {
      dirtyRef.current = true;
      return;
    }
    const span = (v: number) => Math.abs(v) >= ANNOT_MIN_SHAPE_SPAN;
    let valid = false;
    if (drag.tool === 'line' || drag.tool === 'arrow') {
      valid = span(prev.ex - prev.sx) || span(prev.ey - prev.sy);
    } else {
      valid = span(prev.w) || span(prev.h);
    }
    if (!valid) {
      dirtyRef.current = true;
      return; // accidental click — discard
    }
    if (drag.tool !== 'line' && drag.tool !== 'arrow' && drag.tool !== 'rect' && drag.tool !== 'circle') {
      dirtyRef.current = true;
      return; // unreachable guard for the type checker
    }
    const id = newAnnotationId(myUserId);
    const a: AnnotAnnotation = { ...prev, id, userId: myUserId, kind: drag.tool, done: false };
    commitLocal(a);
    broadcastFullShape(a);
  }, [myUserId, commitLocal, broadcastFullShape]);

  const onPointerUp = () => {
    const freeId = drawingIdRef.current;
    drawingIdRef.current = null;
    if (freeId === 'erase-drag') return;
    if (flushTimerRef.current !== null) {
      window.clearTimeout(flushTimerRef.current);
      flushPoints();
    }
    if (freeId) {
      const stroke = annotsRef.current.get(freeId);
      if (stroke) stroke.done = true;
      redoStackRef.current = [];
      bumpHist();
      send(ANNOT_STROKE_END, { userId: myUserId, sessionId, id: freeId });
      return;
    }
    if (dragStartRef.current) finishShapePreview();
  };

  // ---- Text annotation ----
  const confirmTextDraft = useCallback(() => {
    if (!canDraw) {
      setTextDraft(null);
      return;
    }
    setTextDraft((draft) => {
      if (!draft) return draft;
      const value = draft.value.trim();
      if (!value) return null;
      const id = newAnnotationId(myUserId);
      const a: AnnotAnnotation = {
        ...baseAnnotation(id, myUserId, 'text', color, size),
        width: penWidthForSize(size, false),
        x: draft.nx,
        y: draft.ny,
        text: value.slice(0, 500),
        fontSize: fontSizeForSize(size),
      };
      commitLocal(a);
      broadcastFullShape(a);
      return null;
    });
  }, [canDraw, myUserId, color, size, commitLocal, broadcastFullShape]);

  // ---- Undo / redo (own annotations only; id-broadcast keeps all clients in sync) ----
  const handleUndo = useCallback(() => {
    if (!canDraw) return;
    const own = Array.from(annotsRef.current.values()).filter((a) => a.userId === myUserId);
    const last = own[own.length - 1];
    if (!last) return;
    annotsRef.current.delete(last.id);
    redoStackRef.current.push(last);
    dirtyRef.current = true;
    bumpHist();
    send(ANNOT_UNDO, { userId: myUserId, sessionId, annotationId: last.id });
  }, [canDraw, myUserId, sessionId, send, bumpHist]);

  const handleRedo = useCallback(() => {
    if (!canDraw) return;
    const next = redoStackRef.current.pop();
    if (!next) {
      bumpHist();
      return;
    }
    if (!annotsRef.current.has(next.id)) {
      annotsRef.current.set(next.id, { ...next, done: true });
      dirtyRef.current = true;
      send(ANNOT_REDO, {
        userId: myUserId,
        sessionId,
        annotation: JSON.stringify(serializeAnnot(next)),
      });
    }
    bumpHist();
  }, [canDraw, myUserId, sessionId, send, bumpHist]);

  const handleClear = () => {
    if (!canDraw) return;
    for (const [id, a] of annotsRef.current.entries()) {
      if (a.userId === myUserId) {
        annotsRef.current.delete(id);
      }
    }
    redoStackRef.current = redoStackRef.current.filter((a) => a.userId !== myUserId);
    previewRef.current = null;
    dragStartRef.current = null;
    dirtyRef.current = true;
    bumpHist();
    send(ANNOT_CLEAR, { userId: myUserId, sessionId });
  };

  const selectTool = (t: AnnotTool) => {
    if (textDraft) setTextDraft(null); // switching tools cancels pending text
    setTool(t);
    setOpenMenu(null);
  };

  // Undo/redo availability (computed on render; histTick keeps it fresh).
  let ownCount = 0;
  for (const a of annotsRef.current.values()) {
    if (a.userId === myUserId) ownCount++;
  }
  const canUndo = canDraw && ownCount > 0;
  const canRedo = canDraw && redoStackRef.current.length > 0;

  const showWaiting = !sharer || !trackAlive || !frame;
  const draftPos = textDraft && frame
    ? normalizedToScreen(textDraft.nx, textDraft.ny, frame)
    : null;

  const toolBtn = (active: boolean) =>
    `p-2 min-w-11 min-h-11 flex items-center justify-center rounded border cursor-pointer transition-colors ${
      active
        ? 'bg-emerald-900/80 border-emerald-600 text-emerald-200'
        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
    }`;
  const iconBtn =
    'p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer transition-colors disabled:opacity-40 disabled:cursor-not-allowed';
  const menuPanel =
    'absolute bottom-full mb-2 left-0 z-10 min-w-[140px] max-w-[calc(100vw-2rem)] rounded-lg border border-slate-700 bg-slate-800 shadow-xl p-1 space-y-0.5';
  const menuItem =
    'w-full flex items-center gap-2 px-2.5 py-2 rounded text-xs text-slate-200 hover:bg-slate-700 cursor-pointer whitespace-nowrap min-h-11';

  return (
    <div className="absolute inset-0 z-50 bg-slate-950/95 backdrop-blur-sm flex flex-col p-3 gap-2">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2 text-slate-200 text-xs font-semibold min-w-0">
          <span className="px-2 py-1 rounded bg-slate-800 border border-slate-700 inline-flex items-center gap-1.5">
            <Pen className="w-3 h-3" /> Annotation
          </span>
          <span className="truncate text-slate-400 font-normal">
            Screen Share • {sharerName}
          </span>
          {!canDraw && (
            <span className="text-amber-300/90 font-normal">View only</span>
          )}
          {isHost && (
            <label className="flex items-center gap-1.5 cursor-pointer select-none ml-2">
              <span className="text-[11px] text-slate-400 font-normal">Allow All</span>
              <div className="relative inline-flex items-center">
                <input
                  type="checkbox"
                  checked={allowMemberAnnotation}
                  onChange={(e) => onToggleAnnotation(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-7 h-4 bg-slate-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:inset-s-0.5 after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-600 cursor-pointer"></div>
              </div>
            </label>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {isHost ? (
            <Tooltip content="Stop annotation">
              <button
                onClick={onStop}
                aria-label="Stop annotation"
                className="px-3 py-2 min-h-11 rounded border bg-red-950/80 border-red-800 text-red-300 hover:bg-red-900 cursor-pointer text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <X className="w-4 h-4" />
                Stop
              </button>
            </Tooltip>
          ) : (
            <Tooltip content="Close annotation">
              <button
                onClick={onClose || onStop}
                aria-label="Close annotation"
                className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </Tooltip>
          )}
        </div>
      </div>

      {/* Screen share container: our own video + transparent canvas on top */}
      <div ref={wrapRef} className="flex-1 relative rounded-lg overflow-hidden border border-slate-700 bg-black min-h-0">
        <video
          ref={videoRef}
          className="absolute inset-0 h-full w-full object-contain pointer-events-none"
          autoPlay
          muted
          playsInline
        />
        <canvas
          ref={canvasRef}
          className={`absolute inset-0 ${
            canDraw && frame && !textDraft
              ? tool === 'text'
                ? 'cursor-text touch-none'
                : 'cursor-crosshair touch-none'
              : 'cursor-default'
          }`}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerLeave={onPointerUp}
        />
        {showWaiting && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <p className="text-slate-400 text-sm bg-slate-900/80 border border-slate-700 rounded px-4 py-2">
              Waiting for screen share…
            </p>
          </div>
        )}

        {/* Inline text editor (proper input, never window.prompt) */}
        {textDraft && draftPos && (
          <div
            className="absolute z-10 -translate-x-1 -translate-y-full"
            style={{ left: draftPos.x, top: draftPos.y }}
          >
            <div className="flex items-center gap-1 rounded-lg border border-emerald-600 bg-slate-900 shadow-xl p-1 max-w-[calc(100vw-1.5rem)]">
              <input
                autoFocus
                value={textDraft.value}
                onChange={(e) => setTextDraft({ ...textDraft, value: e.target.value })}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') confirmTextDraft();
                  if (e.key === 'Escape') setTextDraft(null);
                }}
                placeholder="Type annotation…"
                maxLength={200}
                className="w-full min-w-0 max-w-xs sm:w-56 px-2 py-1.5 text-sm bg-slate-800 border border-slate-700 rounded text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
              <Tooltip content="Confirm text">
                <button
                  onClick={confirmTextDraft}
                  aria-label="Confirm text"
                  className="p-1.5 min-w-11 min-h-11 flex items-center justify-center rounded bg-emerald-900/80 border border-emerald-600 text-emerald-200 hover:bg-emerald-800 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                </button>
              </Tooltip>
              <Tooltip content="Cancel text">
                <button
                  onClick={() => setTextDraft(null)}
                  aria-label="Cancel text"
                  className="p-1.5 min-w-11 min-h-11 flex items-center justify-center rounded bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </Tooltip>
            </div>
          </div>
        )}
      </div>

      {/* Compact grouped toolbar */}
      {canDraw && (
        <div className="flex flex-wrap items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/90 px-2 py-1.5">
          {/* Draw group: pen + highlighter */}
          <div className="relative">
            <Tooltip content="Draw tools">
              <button
                onClick={() => setOpenMenu(openMenu === 'draw' ? null : 'draw')}
                aria-label="Draw tools"
                className={`${toolBtn(tool === 'pen' || tool === 'highlighter')} inline-flex items-center gap-1`}
              >
                <ToolIcon tool={tool === 'highlighter' ? 'highlighter' : 'pen'} className="w-4 h-4" />
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>
            </Tooltip>
            {openMenu === 'draw' && (
              <div className={menuPanel}>
                {DRAW_TOOLS.map((t) => (
                  <button key={t} onClick={() => selectTool(t)} className={menuItem}>
                    <ToolIcon tool={t} className="w-4 h-4 text-emerald-300" />
                    {TOOL_META[t].label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Shapes group */}
          <div className="relative">
            <Tooltip content="Shapes">
              <button
                onClick={() => setOpenMenu(openMenu === 'shapes' ? null : 'shapes')}
                aria-label="Shapes"
                className={`${toolBtn(SHAPE_TOOLS.includes(tool))} inline-flex items-center gap-1`}
              >
                <ToolIcon tool={SHAPE_TOOLS.includes(tool) ? tool : 'line'} className="w-4 h-4" />
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>
            </Tooltip>
            {openMenu === 'shapes' && (
              <div className={menuPanel}>
                {SHAPE_TOOLS.map((t) => (
                  <button key={t} onClick={() => selectTool(t)} className={menuItem}>
                    <ToolIcon tool={t} className="w-4 h-4 text-emerald-300" />
                    {TOOL_META[t].label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Text */}
          <Tooltip content="Text">
            <button
              onClick={() => selectTool('text')}
              aria-label="Text"
              className={toolBtn(tool === 'text')}
            >
              <ToolIcon tool="text" className="w-4 h-4" />
            </button>
          </Tooltip>

          <div className="w-px h-6 bg-slate-700 mx-0.5" />

          {/* Style group: color */}
          <div className="relative">
            <Tooltip content="Color">
              <button
                onClick={() => setOpenMenu(openMenu === 'color' ? null : 'color')}
                aria-label="Color"
                className={`${iconBtn} inline-flex items-center gap-1.5`}
              >
                <Palette className="w-4 h-4" />
                <span className="w-4 h-4 rounded-full border border-slate-500" style={{ backgroundColor: color }} />
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>
            </Tooltip>
            {openMenu === 'color' && (
              <div className={menuPanel}>
                <div className="grid grid-cols-4 gap-1.5 p-1.5">
                  {ANNOT_PALETTE.map((c) => (
                    <button
                      key={c}
                      onClick={() => {
                        setColor(c);
                        setOpenMenu(null);
                      }}
                      aria-label={`Color ${c}`}
                      title={c}
                      className={`w-8 h-8 min-w-11 min-h-11 flex items-center justify-center rounded-full cursor-pointer border-2 transition-transform ${color === c ? 'border-white scale-110' : 'border-slate-600 hover:scale-105'}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Style group: thickness */}
          <div className="relative">
            <Tooltip content="Thickness">
              <button
                onClick={() => setOpenMenu(openMenu === 'size' ? null : 'size')}
                aria-label="Thickness"
                className={`${iconBtn} inline-flex items-center gap-1.5`}
              >
                <span
                  className="w-5 rounded-full bg-slate-200"
                  style={{ height: size === 1 ? 2 : size === 2 ? 4 : 7 }}
                />
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>
            </Tooltip>
            {openMenu === 'size' && (
              <div className={menuPanel}>
                {([1, 2, 3] as AnnotSizeLevel[]).map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      setSize(s);
                      setOpenMenu(null);
                    }}
                    className={`${menuItem} gap-3`}
                  >
                    <span
                      className={`w-8 rounded-full ${size === s ? 'bg-emerald-300' : 'bg-slate-300'}`}
                      style={{ height: s === 1 ? 2 : s === 2 ? 4 : 7 }}
                    />
                    {s === 1 ? 'Thin' : s === 2 ? 'Medium' : 'Thick'}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="w-px h-6 bg-slate-700 mx-0.5" />

          {/* Edit group */}
          <Tooltip content="Undo">
            <button
              onClick={handleUndo}
              disabled={!canUndo}
              aria-label="Undo"
              className={iconBtn}
            >
              <Undo2 className="w-4 h-4" />
            </button>
          </Tooltip>
          <Tooltip content="Redo">
            <button
              onClick={handleRedo}
              disabled={!canRedo}
              aria-label="Redo"
              className={iconBtn}
            >
              <Redo2 className="w-4 h-4" />
            </button>
          </Tooltip>
          <Tooltip content="Eraser">
            <button
              onClick={() => selectTool('eraser')}
              aria-label="Eraser"
              className={toolBtn(tool === 'eraser')}
            >
              <Eraser className="w-4 h-4" />
            </button>
          </Tooltip>
          <Tooltip content="Clear my annotations">
            <button
              onClick={handleClear}
              aria-label="Clear my annotations"
              className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </Tooltip>
        </div>
      )}
    </div>
  );
}
