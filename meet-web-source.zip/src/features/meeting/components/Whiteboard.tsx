import { useCallback, useEffect, useRef, useState } from 'react';
import { Pen, Eraser, Trash2, X, Loader2, Undo2, Redo2, Users } from 'lucide-react';
import type { Meeting } from '@cloudflare/realtimekit-react-ui';
import { Tooltip } from '../../../shared';

/*
 * Shared Whiteboard — synced in realtime over RealtimeKit data messaging
 * (`meeting.participants.broadcastMessage`), which uses the provider's
 * socket/DataChannel — NOT polling and NOT local-only React state.
 *
 * Message protocol (all payloads carry `userId` so senders can ignore echoes
 * and clients enforce ownership at the realtime message layer):
 *  - WB_STROKE_START { userId, id, mode, color, width, x, y }  (normalized 0..1 coords)
 *  - WB_STROKE_POINT { userId, id, points }                   (~25ms batched points)
 *  - WB_STROKE_END   { userId, id }
 *  - WB_DELETE       { userId, id }                            (delete own stroke)
 *  - WB_UNDO         { userId, id }                            (undo own stroke)
 *  - WB_REDO         { userId, stroke }                        (redo own stroke)
 *  - WB_CLEAR        { userId }                                (clear own strokes)
 *  - WB_REQUEST_SYNC { userId }                                (sent by late joiners)
 *  - WB_SYNC         { userId, strokes: [] }                   (host replies with current state)
 */

interface StrokePoint {
  x: number;
  y: number;
}

interface Stroke {
  id: string;
  userId: string;
  mode: 'pen' | 'eraser';
  color: string;
  width: number;
  points: StrokePoint[];
  done: boolean;
}

type WBMessagePayload = Record<string, string | number | boolean>;

const WB_STROKE_START = 'WB_STROKE_START';
const WB_STROKE_POINT = 'WB_STROKE_POINT';
const WB_STROKE_END = 'WB_STROKE_END';
const WB_DELETE = 'WB_DELETE';
const WB_UNDO = 'WB_UNDO';
const WB_REDO = 'WB_REDO';
const WB_CLEAR = 'WB_CLEAR';
const WB_REQUEST_SYNC = 'WB_REQUEST_SYNC';
const WB_SYNC = 'WB_SYNC';

const PALETTE = ['#f8fafc', '#fbbf24', '#ef4444', '#4ade80', '#38bdf8', '#f472b6'];
const PEN_WIDTH = 3;

function distPointSeg(
  px: number, py: number,
  ax: number, ay: number,
  bx: number, by: number
): number {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  let t = 0;
  if (lenSq > 0) {
    t = ((px - ax) * dx + (py - ay) * dy) / lenSq;
    t = Math.min(1, Math.max(0, t));
  }
  const cx = ax + t * dx;
  const cy = ay + t * dy;
  return Math.hypot(px - cx, py - cy);
}

function hitStroke(nx: number, ny: number, stroke: Stroke, w: number, h: number): boolean {
  if (stroke.points.length === 0) return false;
  const px = nx * w;
  const py = ny * h;
  const threshold = Math.max(14, stroke.width * 2.5);
  if (stroke.points.length === 1) {
    const sx = stroke.points[0].x * w;
    const sy = stroke.points[0].y * h;
    return Math.hypot(px - sx, py - sy) <= threshold;
  }
  for (let i = 1; i < stroke.points.length; i++) {
    const s0x = stroke.points[i - 1].x * w;
    const s0y = stroke.points[i - 1].y * h;
    const s1x = stroke.points[i].x * w;
    const s1y = stroke.points[i].y * h;
    if (distPointSeg(px, py, s0x, s0y, s1x, s1y) <= threshold) return true;
  }
  return false;
}

interface WhiteboardProps {
  meeting: Meeting | null | undefined;
  open: boolean;
  onClose: () => void;
  myUserId: string;
  isHost: boolean;
  canDraw: boolean;
  allowMemberWhiteboard?: boolean;
  onToggleWhiteboard?: (allowed: boolean) => void;
}

export default function Whiteboard({
  meeting,
  open,
  onClose,
  myUserId,
  isHost,
  canDraw,
  allowMemberWhiteboard = false,
  onToggleWhiteboard,
}: WhiteboardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const strokesRef = useRef<Map<string, Stroke>>(new Map());
  const redoStackRef = useRef<Stroke[]>([]);
  const dirtyRef = useRef(true);
  const drawingIdRef = useRef<string | null>(null);
  const pendingPointsRef = useRef<Array<{ id: string; x: number; y: number }>>([]);
  const flushTimerRef = useRef<number | null>(null);

  const [mode, setMode] = useState<'pen' | 'eraser'>('pen');
  const [color, setColor] = useState(PALETTE[1]);
  const [peerCount, setPeerCount] = useState(0);
  const [, setHistTick] = useState(0);
  const bumpHist = useCallback(() => setHistTick((t) => t + 1), []);

  const send = useCallback(
    (type: string, payload: WBMessagePayload) => {
      try {
        void meeting?.participants?.broadcastMessage?.(type, payload);
      } catch {
        /* socket not ready — transient, next events will converge */
      }
    },
    [meeting]
  );

  // ---- Redraw loop (single rAF loop redraws only when dirty) ----
  useEffect(() => {
    if (!open) return;
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const canvas = canvasRef.current;
      if (!canvas || !dirtyRef.current) return;
      dirtyRef.current = false;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.width / dpr;
      const h = canvas.height / dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      for (const stroke of strokesRef.current.values()) {
        if (stroke.points.length === 0) continue;
        ctx.strokeStyle = stroke.color;
        ctx.lineWidth = stroke.width;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        const first = stroke.points[0];
        ctx.moveTo(first.x * w, first.y * h);
        if (stroke.points.length === 1) {
          ctx.lineTo(first.x * w + 0.01, first.y * h + 0.01);
        } else {
          for (let i = 1; i < stroke.points.length; i++) {
            ctx.lineTo(stroke.points[i].x * w, stroke.points[i].y * h);
          }
        }
        ctx.stroke();
      }
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [open]);

  // ---- Canvas sizing (unified 16:9 contain-fit canvas: identical across all devices) ----
  useEffect(() => {
    if (!open) return;
    const resize = () => {
      const canvas = canvasRef.current;
      const wrap = wrapRef.current;
      if (!canvas || !wrap) return;
      const cw = wrap.clientWidth;
      const ch = wrap.clientHeight;
      if (cw <= 0 || ch <= 0) return;
      const scale = Math.min(cw / 16, ch / 9);
      const w = Math.max(160, Math.floor(scale * 16));
      const h = Math.max(90, Math.floor(scale * 9));
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      dirtyRef.current = true;
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [open]);

  // ---- Realtime receive with strict sender ownership enforcement ----
  useEffect(() => {
    if (!open || !meeting?.participants?.on || !meeting?.participants?.off) return;

    const upsertLocal = (s: Omit<Stroke, 'done'>) => {
      const existing = strokesRef.current.get(s.id);
      if (existing) {
        existing.points = s.points;
      } else {
        strokesRef.current.set(s.id, { ...s, done: true });
      }
      dirtyRef.current = true;
      bumpHist();
    };

    const onMessage = (event: { type: string; payload: Record<string, unknown> }) => {
      const p = event.payload || {};
      const from = typeof p.userId === 'string' ? p.userId : '';
      if (from && from === myUserId) return; // ignore echoes of our own messages

      switch (event.type) {
        case WB_STROKE_START: {
          if (typeof p.id !== 'string') return;
          strokesRef.current.set(p.id, {
            id: p.id,
            userId: from,
            mode: 'pen',
            color: typeof p.color === 'string' ? p.color : '#f8fafc',
            width: typeof p.width === 'number' ? p.width : PEN_WIDTH,
            points: [{ x: Number(p.x) || 0, y: Number(p.y) || 0 }],
            done: false,
          });
          dirtyRef.current = true;
          bumpHist();
          break;
        }
        case WB_STROKE_POINT: {
          if (typeof p.id !== 'string') return;
          const stroke = strokesRef.current.get(p.id);
          // OWNERSHIP GUARD: only the stroke creator can append points
          if (!stroke || stroke.userId !== from) return;
          let list: Array<Record<string, unknown>> | null = null;
          if (typeof p.points === 'string') {
            try {
              const parsed: unknown = JSON.parse(p.points);
              if (Array.isArray(parsed)) list = parsed as Array<Record<string, unknown>>;
            } catch {
              list = null;
            }
          } else if (Array.isArray(p.points)) {
            list = p.points as Array<Record<string, unknown>>;
          }
          if (list) {
            for (const pt of list) {
              const x = Number(pt.x);
              const y = Number(pt.y);
              if (Number.isFinite(x) && Number.isFinite(y)) {
                stroke.points.push({ x, y });
              }
            }
          } else if (Number.isFinite(Number(p.x)) && Number.isFinite(Number(p.y))) {
            stroke.points.push({ x: Number(p.x), y: Number(p.y) });
          }
          dirtyRef.current = true;
          break;
        }
        case WB_STROKE_END: {
          if (typeof p.id !== 'string') return;
          const stroke = strokesRef.current.get(p.id);
          // OWNERSHIP GUARD: only the stroke creator can complete the stroke
          if (!stroke || stroke.userId !== from) return;
          stroke.done = true;
          dirtyRef.current = true;
          break;
        }
        case WB_DELETE:
        case WB_UNDO: {
          if (typeof p.id !== 'string') return;
          const stroke = strokesRef.current.get(p.id);
          // OWNERSHIP GUARD: only the stroke creator can delete/undo their stroke
          if (!stroke || stroke.userId !== from) return;
          redoStackRef.current = redoStackRef.current.filter((r) => r.id !== p.id);
          strokesRef.current.delete(p.id);
          dirtyRef.current = true;
          bumpHist();
          break;
        }
        case WB_REDO: {
          if (typeof p.stroke !== 'string') return;
          try {
            const parsed = JSON.parse(p.stroke) as Stroke;
            // OWNERSHIP GUARD: only the stroke creator can redo their stroke
            if (parsed && typeof parsed.id === 'string' && parsed.userId === from && !strokesRef.current.has(parsed.id)) {
              strokesRef.current.set(parsed.id, { ...parsed, done: true });
              dirtyRef.current = true;
              bumpHist();
            }
          } catch {
            /* ignore malformed payload */
          }
          break;
        }
        case WB_CLEAR: {
          // OWNERSHIP GUARD: clear only removes strokes owned by the sender ('from')
          for (const [id, s] of strokesRef.current.entries()) {
            if (s.userId === from) {
              strokesRef.current.delete(id);
            }
          }
          redoStackRef.current = redoStackRef.current.filter((s) => s.userId !== from);
          dirtyRef.current = true;
          bumpHist();
          break;
        }
        case WB_REQUEST_SYNC: {
          // Only the host answers so N participants don't flood N syncs.
          if (!isHost || !from) return;
          send(WB_SYNC, {
            userId: myUserId,
            strokes: JSON.stringify(
              Array.from(strokesRef.current.values()).map((s) => ({
                id: s.id,
                userId: s.userId,
                mode: s.mode,
                color: s.color,
                width: s.width,
                points: s.points,
              }))
            ),
          });
          break;
        }
        case WB_SYNC: {
          let list: Array<Record<string, unknown>> = [];
          if (typeof p.strokes === 'string') {
            try {
              const parsed: unknown = JSON.parse(p.strokes);
              if (Array.isArray(parsed)) list = parsed as Array<Record<string, unknown>>;
            } catch {
              /* ignore */
            }
          } else if (Array.isArray(p.strokes)) {
            list = p.strokes as Array<Record<string, unknown>>;
          }
          for (const raw of list) {
            if (typeof raw.id !== 'string') continue;
            upsertLocal({
              id: raw.id,
              userId: typeof raw.userId === 'string' ? raw.userId : '',
              mode: 'pen',
              color: typeof raw.color === 'string' ? raw.color : '#f8fafc',
              width: typeof raw.width === 'number' ? raw.width : PEN_WIDTH,
              points: Array.isArray(raw.points)
                ? (raw.points as Array<Record<string, unknown>>).map((pt) => ({
                    x: Number(pt.x) || 0,
                    y: Number(pt.y) || 0,
                  }))
                : [],
            });
          }
          dirtyRef.current = true;
          bumpHist();
          break;
        }
      }
    };

    meeting.participants.on('broadcastedMessage', onMessage);
    return () => {
      meeting.participants.off('broadcastedMessage', onMessage);
    };
  }, [open, meeting, myUserId, isHost, send, bumpHist]);

  // ---- Ask for current state when opening (late joiner recovery) ----
  useEffect(() => {
    if (!open) return;
    const t = window.setTimeout(() => send(WB_REQUEST_SYNC, { userId: myUserId }), 600);
    return () => window.clearTimeout(t);
  }, [open, send, myUserId]);

  // ---- Peer count (lightweight presence indicator) ----
  // Uses the joined participants map's join/left events (actual SDK events).
  useEffect(() => {
    if (!open || !meeting?.participants?.joined?.on || !meeting?.participants?.joined?.off) return;
    const joinedMap = meeting.participants.joined;
    const update = () => setPeerCount(joinedMap.size);
    update();
    joinedMap.on('participantJoined', update);
    joinedMap.on('participantLeft', update);
    return () => {
      joinedMap.off('participantJoined', update);
      joinedMap.off('participantLeft', update);
    };
  }, [open, meeting]);

  // ---- Flush queued local points to network at ~40fps (25ms) ----
  const flushPoints = useCallback(() => {
    flushTimerRef.current = null;
    if (pendingPointsRef.current.length === 0) return;
    const batch = pendingPointsRef.current;
    pendingPointsRef.current = [];
    send(WB_STROKE_POINT, { userId: myUserId, id: batch[0].id, points: JSON.stringify(batch) });
  }, [send, myUserId]);

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (flushTimerRef.current !== null) {
        window.clearTimeout(flushTimerRef.current);
        flushTimerRef.current = null;
      }
    };
  }, []);

  // ---- Pointer handlers & ownership-safe actions ----
  const norm = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    return {
      x: Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)),
      y: Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height)),
    };
  };

  const eraseAt = useCallback((nx: number, ny: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.width / dpr;
    const h = canvas.height / dpr;
    const all = Array.from(strokesRef.current.values()).reverse();
    for (const s of all) {
      if (s.userId !== myUserId) continue; // OWNERSHIP GUARD: only erase own strokes
      if (hitStroke(nx, ny, s, w, h)) {
        strokesRef.current.delete(s.id);
        redoStackRef.current = redoStackRef.current.filter((r) => r.id !== s.id);
        dirtyRef.current = true;
        bumpHist();
        send(WB_DELETE, { userId: myUserId, id: s.id });
        return;
      }
    }
  }, [myUserId, send, bumpHist]);

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!canDraw) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const { x, y } = norm(e);

    if (mode === 'eraser') {
      drawingIdRef.current = 'erase-drag';
      eraseAt(x, y);
      return;
    }

    const id = `${myUserId}:${Date.now()}:${Math.random().toString(36).slice(2, 7)}`;
    drawingIdRef.current = id;
    strokesRef.current.set(id, {
      id,
      userId: myUserId,
      mode: 'pen',
      color,
      width: PEN_WIDTH,
      points: [{ x, y }],
      done: false,
    });
    redoStackRef.current = [];
    dirtyRef.current = true;
    bumpHist();
    send(WB_STROKE_START, { userId: myUserId, id, mode: 'pen', color, width: PEN_WIDTH, x, y });
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!canDraw || !drawingIdRef.current) return;
    const { x, y } = norm(e);

    if (mode === 'eraser') {
      if (drawingIdRef.current === 'erase-drag' && (e.buttons & 1) === 1) eraseAt(x, y);
      return;
    }

    const id = drawingIdRef.current;
    const stroke = strokesRef.current.get(id);
    if (stroke) {
      stroke.points.push({ x, y }); // Immediate local 0ms render
      dirtyRef.current = true;
    }
    pendingPointsRef.current.push({ id, x, y });
    if (flushTimerRef.current === null) {
      flushTimerRef.current = window.setTimeout(flushPoints, 25);
    }
  };

  const onPointerUp = () => {
    const id = drawingIdRef.current;
    drawingIdRef.current = null;
    if (id === 'erase-drag') return;
    if (flushTimerRef.current !== null) {
      window.clearTimeout(flushTimerRef.current);
      flushPoints();
    }
    if (!id) return;
    const stroke = strokesRef.current.get(id);
    if (stroke) stroke.done = true;
    send(WB_STROKE_END, { userId: myUserId, id });
  };

  const handleUndo = useCallback(() => {
    if (!canDraw) return;
    const own = Array.from(strokesRef.current.values()).filter((s) => s.userId === myUserId);
    const last = own[own.length - 1];
    if (!last) return;
    strokesRef.current.delete(last.id);
    redoStackRef.current.push(last);
    dirtyRef.current = true;
    bumpHist();
    send(WB_UNDO, { userId: myUserId, id: last.id });
  }, [canDraw, myUserId, send, bumpHist]);

  const handleRedo = useCallback(() => {
    if (!canDraw) return;
    const next = redoStackRef.current.pop();
    if (!next) {
      bumpHist();
      return;
    }
    if (!strokesRef.current.has(next.id)) {
      strokesRef.current.set(next.id, { ...next, done: true });
      dirtyRef.current = true;
      send(WB_REDO, {
        userId: myUserId,
        stroke: JSON.stringify(next),
      });
    }
    bumpHist();
  }, [canDraw, myUserId, send, bumpHist]);

  const handleClear = () => {
    if (!canDraw) return;
    for (const [id, s] of strokesRef.current.entries()) {
      if (s.userId === myUserId) {
        strokesRef.current.delete(id);
      }
    }
    redoStackRef.current = redoStackRef.current.filter((s) => s.userId !== myUserId);
    dirtyRef.current = true;
    bumpHist();
    send(WB_CLEAR, { userId: myUserId });
  };

  let ownCount = 0;
  for (const s of strokesRef.current.values()) {
    if (s.userId === myUserId) ownCount++;
  }
  const canUndo = canDraw && ownCount > 0;
  const canRedo = canDraw && redoStackRef.current.length > 0;

  if (!open) return null;

  return (
    <div className="absolute inset-0 z-50 bg-slate-950/95 backdrop-blur-sm flex flex-col p-3 gap-2">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-slate-200 text-xs font-semibold flex-wrap">
          <span className="px-2 py-1 rounded bg-slate-800 border border-slate-700 inline-flex items-center gap-1.5">
            <Pen className="w-3 h-3" /> Whiteboard
          </span>
          <span className="px-2 py-1 rounded bg-slate-800/60 border border-slate-800 inline-flex items-center gap-1 text-slate-400">
            <Users className="w-3 h-3" /> {peerCount + 1}
          </span>
          {!canDraw && (
            <span className="text-amber-300/90 font-normal hidden sm:inline">View only — host has not enabled member drawing</span>
          )}
          {isHost && onToggleWhiteboard && (
            <label className="flex items-center gap-1.5 cursor-pointer select-none ml-2">
              <span className="text-[11px] text-slate-400 font-normal">Allow All</span>
              <div className="relative inline-flex items-center">
                <input
                  type="checkbox"
                  checked={allowMemberWhiteboard}
                  onChange={(e) => onToggleWhiteboard(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-7 h-4 bg-slate-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:inset-s-0.5 after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-600 cursor-pointer"></div>
              </div>
            </label>
          )}
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {canDraw && (
            <>
              <Tooltip content="Pen">
                <button
                  onClick={() => setMode('pen')}
                  aria-label="Pen"
                  className={`p-2 min-w-11 min-h-11 flex items-center justify-center rounded border cursor-pointer ${mode === 'pen' ? 'bg-emerald-900/80 border-emerald-600 text-emerald-200' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'}`}
                >
                  <Pen className="w-4 h-4" />
                </button>
              </Tooltip>
              <Tooltip content="Eraser">
                <button
                  onClick={() => setMode('eraser')}
                  aria-label="Eraser"
                  className={`p-2 min-w-11 min-h-11 flex items-center justify-center rounded border cursor-pointer ${mode === 'eraser' ? 'bg-emerald-900/80 border-emerald-600 text-emerald-200' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'}`}
                >
                  <Eraser className="w-4 h-4" />
                </button>
              </Tooltip>
              {mode === 'pen' && (
                <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 border border-slate-700">
                  {PALETTE.map((c) => (
                    <Tooltip key={c} content={`Color ${c}`}>
                      <button
                        onClick={() => setColor(c)}
                        aria-label={`Color ${c}`}
                        className={`w-5 h-5 min-w-11 min-h-11 flex items-center justify-center rounded-full cursor-pointer border ${color === c ? 'border-white scale-110' : 'border-slate-600'}`}
                        style={{ backgroundColor: c }}
                      />
                    </Tooltip>
                  ))}
                </div>
              )}
              <div className="w-px h-6 bg-slate-700 mx-0.5" />
              <Tooltip content="Undo">
                <button
                  onClick={handleUndo}
                  disabled={!canUndo}
                  aria-label="Undo"
                  className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Undo2 className="w-4 h-4" />
                </button>
              </Tooltip>
              <Tooltip content="Redo">
                <button
                  onClick={handleRedo}
                  disabled={!canRedo}
                  aria-label="Redo"
                  className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Redo2 className="w-4 h-4" />
                </button>
              </Tooltip>
              <Tooltip content="Clear my drawings">
                <button
                  onClick={handleClear}
                  aria-label="Clear my drawings"
                  className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </Tooltip>
            </>
          )}
          <Tooltip content="Close whiteboard">
            <button
              onClick={onClose}
              aria-label="Close whiteboard"
              className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded border bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </Tooltip>
        </div>
      </div>

      {/* Canvas */}
      <div ref={wrapRef} className="flex-1 relative rounded-lg overflow-hidden border border-slate-700 bg-slate-950 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          className={`rounded border border-slate-800 bg-slate-900 shadow-2xl ${canDraw ? 'cursor-crosshair touch-none' : 'cursor-default'}`}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerLeave={onPointerUp}
        />
        {peerCount === 0 && (
          <div className="absolute bottom-2 right-2 text-[10px] text-slate-500 flex items-center gap-1">
            <Loader2 className="w-3 h-3 animate-spin" /> waiting for other participants…
          </div>
        )}
      </div>
    </div>
  );
}
