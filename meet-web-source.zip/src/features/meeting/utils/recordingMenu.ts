import { defaultIconPack, type Addon, type UIConfig } from '@cloudflare/realtimekit-react-ui';

// Kontrol rekaman (Pause/Resume/Stop) yang disisipkan ke menu More (⋮) milik
// RTK. RTK hanya me-render tag generik di slot `more-elements`, jadi kita pakai
// custom element — pola yang sama dengan meet-host-badge. Elemen ini murni
// tampilan + tombol; semua aksi dikirim keluar lewat CustomEvent di window
// (lihat RECORDING_EVENTS), supaya logika tetap di React (useClientRecorder).
//
// Tiap tombol dirender memakai `rtk-controlbar-button` bawaan RTK (variant
// horizontal + ikon SVG dari defaultIconPack), sehingga barisnya benar-benar
// seragam dengan item More lainnya — bukan tombol/emoji buatan sendiri.

const RECORDING_TAG = 'meet-recording-controls';
const RTK_BUTTON = 'rtk-controlbar-button';

type RtkButton = HTMLElement & {
  variant: string;
  label: string;
  icon: string;
  iconPack: typeof defaultIconPack;
};

export const RECORDING_EVENTS = {
  start: 'meet-recording:start',
  pause: 'meet-recording:pause',
  resume: 'meet-recording:resume',
  stop: 'meet-recording:stop',
} as const;

// Status yang dikirim Meeting.tsx ke elemen ini tiap kali state rekaman berubah.
// Durasi rekaman TIDAK dikirim — timernya sudah tampil di navbar, jadi menu More
// hanya butuh status, visibilitas, dan hak operator.
export interface RecordingMenuState {
  /**
   * Hanya host/admin yang boleh melihat kontrol rekaman, dan hanya bila mereka
   * boleh bertindak: `visible` sudah dihitung Meeting.tsx (aktif bila sedang
   * menjadi operator rekaman ATAU belum ada yang merekam).
   */
  visible: boolean;
  /**
   * true bila klien INILAH operator rekaman (yang menekan Start). Sesuai aturan
   * "satu rekaman per sesi": host/admin lain tidak boleh pause/stop rekaman
   * yang bukan milik mereka, jadi tombol Pause/Stop hanya dirender untuk
   * operator. Bukan operator yang melihat rekaman aktif tidak melihat apa pun.
   */
  isOperator: boolean;
  state: 'IDLE' | 'STARTING' | 'RECORDING' | 'PAUSED' | 'STOPPING' | 'UPLOADING' | 'ERROR';
}

// ---------------------------------------------------------------------------
// Module-level store + registry instance.
//
// Elemen ini dirender RTK di dalam SHADOW DOM, sehingga Meeting.tsx tidak bisa
// menjangkaunya dengan document.querySelector (tidak menembus shadow root) —
// itu sebabnya pola "push state lewat query" gagal dan elemen tidak pernah
// tampil. Sebagai gantinya state disimpan di sini; setiap elemen yang terpasang
// (connectedCallback) mendaftarkan diri dan membaca state terakhir dari store,
// sehingga tidak peduli di shadow root mana ia berada, ia tetap sinkron.
// ---------------------------------------------------------------------------
let sharedState: RecordingMenuState = { visible: false, isOperator: false, state: 'IDLE' };
const instances = new Set<MeetRecordingControls>();

/** Dipanggil Meeting.tsx tiap state rekaman berubah — update semua instance. */
export function setRecordingMenuState(next: RecordingMenuState): void {
  sharedState = next;
  for (const el of instances) el.applyState(next);
}

class MeetRecordingControls extends HTMLElement {
  private current: RecordingMenuState = { visible: false, isOperator: false, state: 'IDLE' };

  // Dipanggil dari module store (setRecordingMenuState) tiap state berubah.
  // Label tombol seluruhnya statis (tanpa durasi) — timer rekaman sudah tampil
  // di navbar, jadi elemen ini cukup di-render ulang saat `visible`/`state`
  // berubah.
  applyState(next: RecordingMenuState): void {
    const prev = this.current;
    this.current = next;
    if (prev.visible !== next.visible || prev.state !== next.state || prev.isOperator !== next.isOperator) {
      this.render();
    }
  }

  connectedCallback() {
    // Daftarkan diri ke registry & tarik state terakhir — elemen ini berada di
    // shadow DOM RTK, jadi satu-satunya cara tetap sinkron adalah lewat store.
    instances.add(this);
    this.applyState(sharedState);
  }

  disconnectedCallback() {
    instances.delete(this);
  }

  private emit(name: string) {
    window.dispatchEvent(new CustomEvent(name));
  }

  // `rtk-controlbar-button` adalah komponen Stencil milik RTK. Kalau belum
  // terdaftar saat kita render (jarang — menu More baru ada setelah RTK
  // bootstrap), tunggu pendaftarannya dulu lalu render ulang. Ini mencegah set
  // properti jatuh ke own-property yang men-shadow accessor Stencil.
  private ready(): boolean {
    if (typeof customElements === 'undefined') return false;
    if (customElements.get(RTK_BUTTON)) return true;
    customElements.whenDefined(RTK_BUTTON).then(() => {
      if (this.isConnected) this.render();
    });
    return false;
  }

  // Satu baris menu, dibuat dari komponen bawaan RTK agar tampilannya identik
  // dengan item More lainnya (font, ikon SVG, hover, tinggi baris). `variant`
  // di-reflect Stencil ke atribut sehingga CSS :host([variant='horizontal'])
  // (width 100% + ikon & label rata kiri) ikut aktif.
  private row(opts: { icon: string; label: string; onClick: () => void }): RtkButton {
    const btn = document.createElement(RTK_BUTTON) as RtkButton;
    btn.variant = 'horizontal';
    btn.icon = opts.icon;
    btn.label = opts.label;
    btn.iconPack = defaultIconPack;
    btn.addEventListener('click', opts.onClick);
    return btn;
  }

  private render(): void {
    const { visible, isOperator, state } = this.current;

    // Non-host/admin, atau saat proses start/stop/upload berjalan — sembunyikan
    // total karena kontrolnya tidak berguna pada fase itu.
    const transitional =
      state === 'STOPPING' || state === 'UPLOADING' || state === 'STARTING';
    if (!visible || transitional) {
      this.replaceChildren();
      this.style.display = 'none';
      return;
    }

    // Rekaman sedang berjalan TETAPI klien ini bukan operatornya (host/admin
    // lain yang menekan Start): jangan tawarkan Pause/Stop — bukan hak mereka.
    // Start juga tidak muncul karena Meeting.tsx sudah menyetel `visible=false`.
    const recordingElsewhere =
      (state === 'RECORDING' || state === 'PAUSED') && !isOperator;
    if (recordingElsewhere) {
      this.replaceChildren();
      this.style.display = 'none';
      return;
    }

    // Tunggu komponen tombol RTK siap dulu sebelum merangkai (jarang terjadi,
    // render ulang dipicu otomatis oleh `ready()` saat komponen sudah terdaftar).
    if (!this.ready()) {
      this.replaceChildren();
      this.style.display = 'none';
      return;
    }

    // Flex column supaya tiap baris tombol menumpuk penuh lebar — sama seperti
    // item More lainnya.
    this.style.display = 'flex';
    this.style.flexDirection = 'column';
    this.replaceChildren();

    // Idle / error: cukup tombol Mulai. Klik langsung mulai rekam tanpa dialog —
    // resolusi mengikuti settingan admin (screenshare_resolution).
    if (state === 'IDLE' || state === 'ERROR') {
      this.appendChild(
        this.row({
          icon: defaultIconPack.recording,
          label: 'Start Recording',
          onClick: () => this.emit(RECORDING_EVENTS.start),
        })
      );
      return;
    }

    // RECORDING / PAUSED: tombol Pause/Resume lalu Stop. Durasi rekaman tidak
    // ditampilkan di sini karena sudah tampil di navbar.
    const paused = state === 'PAUSED';
    this.appendChild(
      this.row({
        icon: paused ? defaultIconPack.play : defaultIconPack.pause,
        label: paused ? 'Resume Recording' : 'Pause Recording',
        onClick: () => this.emit(paused ? RECORDING_EVENTS.resume : RECORDING_EVENTS.pause),
      })
    );
    this.appendChild(
      this.row({
        icon: defaultIconPack.stop_recording,
        label: 'Stop Recording',
        onClick: () => this.emit(RECORDING_EVENTS.stop),
      })
    );
  }
}

function ensureRecordingElement(): void {
  if (typeof customElements === 'undefined') return;
  if (!customElements.get(RECORDING_TAG)) {
    customElements.define(RECORDING_TAG, MeetRecordingControls);
  }
}

function isRecordingEntry(entry: unknown): boolean {
  return typeof entry === 'string'
    ? entry === RECORDING_TAG
    : Array.isArray(entry) && entry[0] === RECORDING_TAG;
}

function pushEntry(list: unknown[], entry: unknown): unknown[] {
  return [...list.filter(child => !isRecordingEntry(child)), entry];
}

/**
 * Menyisipkan <meet-recording-controls> ke menu More RTK. Item masuk lewat
 * `add` pada konfigurasi root untuk state `activeMoreMenu` (dan varian ukuran
 * sm/md yang dipakai layar sempit) — slot `more-elements` dirender RTK sebagai
 * daftar item horizontal di dalam menu More.
 */
export const recordingMenuAddon: Addon = {
  register(config: UIConfig) {
    ensureRecordingElement();
    const root = config.root ?? (config.root = {});
    const entry = [RECORDING_TAG, { slot: 'more-elements' }] as [string, { slot: string }];

    for (const key of ['rtk-more-toggle.activeMoreMenu', 'rtk-more-toggle.activeMoreMenu.sm', 'rtk-more-toggle.activeMoreMenu.md']) {
      const current = root[key] as unknown;
      if (Array.isArray(current)) {
        root[key] = pushEntry(current, entry) as (typeof current);
      } else if (current && typeof current === 'object') {
        const obj = current as { add?: unknown[] };
        obj.add = pushEntry(Array.isArray(obj.add) ? obj.add : [], entry);
      } else {
        root[key] = [entry];
      }
    }
    return config;
  },
  unregister() {
    // Elemen dibiarkan terdaftar agar aman dipakai ulang saat config dibangun ulang.
  },
};
