import type { Addon, UIConfig } from '@cloudflare/realtimekit-react-ui';

const HOST_PRESET = 'group_call_host';
const BADGE_TAG = 'meet-host-badge';

type BadgePeer = {
  presetName?: string;
  isHost?: boolean;
} | null | undefined;

export function isHostPeer(peer: BadgePeer): boolean {
  if (!peer) return false;
  return peer.presetName === HOST_PRESET || peer.isHost === true;
}

class MeetHostBadge extends HTMLElement {
  private peer: BadgePeer = null;
  private shown: boolean | null = null;

  get participant(): BadgePeer {
    return this.peer;
  }

  set participant(value: BadgePeer) {
    this.peer = value;
    this.sync();
  }

  connectedCallback() {
    this.sync();
  }

  private sync() {
    const host = isHostPeer(this.peer);
    if (host === this.shown) return;
    this.shown = host;
    if (host) {
      this.textContent = 'HOST';
      this.style.cssText =
        'display:inline-flex;align-items:center;margin-left:6px;padding:0 5px;' +
        'border-radius:9999px;background:#10b981;color:#ffffff;font-size:9px;' +
        'font-weight:700;letter-spacing:0.04em;line-height:1.6;white-space:nowrap;' +
        'pointer-events:none;user-select:none;';
    } else {
      this.textContent = '';
      this.style.cssText = 'display:none;';
    }
  }
}

function ensureHostBadgeElement(): void {
  if (typeof customElements === 'undefined') return;
  if (!customElements.get(BADGE_TAG)) {
    customElements.define(BADGE_TAG, MeetHostBadge);
  }
}

const isBadgeEntry = (entry: unknown): boolean =>
  typeof entry === 'string'
    ? entry === BADGE_TAG
    : Array.isArray(entry) && entry[0] === BADGE_TAG;

export const hostBadgeAddon: Addon = {
  register(config: UIConfig) {
    ensureHostBadgeElement();
    const root = config.root ?? (config.root = {});
    const entry = root['rtk-name-tag'];
    const badge = [BADGE_TAG, { slot: 'end' }] as [string, { slot: string }];

    if (Array.isArray(entry)) {
      root['rtk-name-tag'] = [...entry.filter(child => !isBadgeEntry(child)), badge];
    } else if (entry && typeof entry === 'object') {
      const children = (entry.children ?? []).filter(child => !isBadgeEntry(child));
      root['rtk-name-tag'] = { ...entry, children: [...children, badge] };
    } else {
      root['rtk-name-tag'] = [badge];
    }
    return config;
  },
  unregister() {
    // Badge hanya pembeda visual; definisi element dibiarkan agar aman di-reuse.
  },
};

type RowElement = Element & { participant?: BadgePeer };

function injectRowBadge(row: Element): void {
  const shadow = row.shadowRoot;
  if (!shadow) return;
  const left = shadow.querySelector('.left');
  if (!left) return;
  let badge = left.querySelector(':scope > meet-host-badge');
  if (!badge) {
    badge = document.createElement(BADGE_TAG);
    left.appendChild(badge);
  }
  (badge as MeetHostBadge).participant = (row as RowElement).participant ?? null;
}

function walkShadowTree(root: ParentNode, visit: (el: Element) => void): void {
  for (const el of Array.from(root.querySelectorAll('*'))) {
    visit(el);
    if (el.shadowRoot) walkShadowTree(el.shadowRoot, visit);
  }
}

function syncSidebarBadges(): void {
  walkShadowTree(document, el => {
    if (el.tagName === 'RTK-PARTICIPANT') injectRowBadge(el);
  });
}

export function startHostBadgeSync(): () => void {
  ensureHostBadgeElement();
  if (typeof window === 'undefined') return () => {};
  syncSidebarBadges();
  const timer = window.setInterval(syncSidebarBadges, 500);
  return () => window.clearInterval(timer);
}
