// Browser HP/tablet tidak mengekspos navigator.mediaDevices.getDisplayMedia
// (Safari iOS/iPadOS & semua browser iOS = WebKit; Chrome/Firefox Android),
// sehingga tombol Share Screen bawaan RealtimeKit (rtk-screen-share-toggle)
// disembunyikan oleh SDK. Deteksi dipakai ShareScreenNotice untuk banner info.
//
// Implementasi ada di satu tempat saja (lib/screenShareSupport) — file ini
// hanya re-export agar path import lama tetap berfungsi.
export { isScreenShareSupported } from '../lib/screenShareSupport';
