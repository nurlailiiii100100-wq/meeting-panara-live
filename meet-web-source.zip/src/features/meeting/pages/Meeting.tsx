import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { RtkMeeting, registerAddons, type Meeting, type UIConfig } from '@cloudflare/realtimekit-react-ui';
import { useRealtimeKitClient } from '@cloudflare/realtimekit-react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../../auth/context/AuthContext';
import { Clock, Users, UserX, X, AlertTriangle, PenTool, Circle, User as UserIcon, Share2, Edit2, Check, Copy, UserPen, Link2, Pen, KeyRound, Monitor } from 'lucide-react';
import { getPersistentUserId, getActiveMeetingSession, setActiveMeetingSession, clearActiveMeetingSession } from '../../../shared';
import { hostBadgeAddon, isHostPeer, startHostBadgeSync } from '../utils/hostBadge';
import { recordingMenuAddon, RECORDING_EVENTS, setRecordingMenuState } from '../utils/recordingMenu';
import type { RecordingMenuState } from '../utils/recordingMenu';
import Whiteboard from '../components/Whiteboard';
import AnnotationStage from '../components/AnnotationStage';
import { ShareScreenNotice } from '../components/ShareScreenNotice';
import { useScreenShare } from '../hooks/useScreenShare';
import { useScreenShareConnection } from '../hooks/useScreenShareConnection';
import { useClientRecorder } from '../hooks/useClientRecorder';
import {
  getScreenShareSupport,
  getNativeScreenShareBridge,
  stopNativeScreenShareIfActive,
  subscribeNativeShareState,
  type ScreenShareSupport,
} from '../lib/screenShareSupport';
import { enqueueAnnotBroadcast } from '../lib/annotBroadcast';
import {
  KICK_RESULT_EVENT,
  kickViaBackend,
  patchParticipantKick,
  setKickMeetingId,
  type KickResult,
} from '../lib/kickCooldown';
import {
  ANNOT_SESSION_END,
  ANNOT_SESSION_START,
  ANNOT_STATE_REQUEST,
  type AnnotationSessionInfo,
  newAnnotationSessionId,
} from '../lib/annotationProtocol';
import { useToast, ConfirmDialog, Tooltip } from '../../../shared';

// Menyembunyikan kontrol rekaman bawaan RealtimeKit (Cloud Export) — rekaman
// sekarang dijalankan client-side lewat useClientRecorder.
function stripRecordingUi(config: UIConfig, tags: string[]): void {
  const root = config.root;
  if (!root) return;
  const isTagged = (child: unknown): boolean =>
    (typeof child === 'string' && tags.includes(child)) ||
    (Array.isArray(child) && typeof child[0] === 'string' && tags.includes(child[0]));
  for (const [key, entry] of Object.entries(root)) {
    if (Array.isArray(entry)) {
      root[key] = entry.filter(child => !isTagged(child));
    } else if (entry && typeof entry === 'object') {
      if (Array.isArray(entry.children)) entry.children = entry.children.filter(child => !isTagged(child));
      if (Array.isArray(entry.add)) entry.add = entry.add.filter(child => !isTagged(child));
      if (Array.isArray(entry.prepend)) entry.prepend = entry.prepend.filter(child => !isTagged(child));
      if (entry.addBefore) {
        for (const [before, list] of Object.entries(entry.addBefore)) {
          if (Array.isArray(list)) entry.addBefore[before] = list.filter(child => !isTagged(child));
        }
      }
    }
  }
}

// Ambil nama tag dari entri config (string, atau tuple [tag, props]).
function cfgTag(entry: unknown): string | null {
  if (typeof entry === 'string') return entry;
  if (Array.isArray(entry) && typeof entry[0] === 'string') return entry[0];
  return null;
}

// Ambil props.id dari entri tuple — dipakai untuk mengenali tombol Effects
// (rtk-controlbar-button) milik addon video-background tanpa ikut menangkap
// tombol controlbar lain.
function cfgId(entry: unknown): string | null {
  if (Array.isArray(entry) && entry[1] && typeof entry[1] === 'object') {
    const id = (entry[1] as Record<string, unknown>).id;
    return typeof id === 'string' ? id : null;
  }
  return null;
}

// Pindahkan satu item controlbar (mis. Settings / Effects / Plugins) ke menu
// More. Item dihapus dari zona controlbar (left/center/right/mobile), lalu
// ditambahkan ke tiap More menu (desktop + md + sm) sebagai item horizontal —
// tanpa duplikat, karena di mobile (md/sm) sebagian item mungkin sudah ada di
// More (allSideElements) dan tombol Effects sudah ditambahkan addon video-bg.
function moveControlbarItemToMore(config: UIConfig, match: (entry: unknown) => boolean): void {
  const root = config.root;
  if (!root) return;

  // Cari entri asli agar propertinya (label/icon/onClick) ikut terbawa.
  let found: unknown = null;
  for (const [key, entry] of Object.entries(root)) {
    if (!key.startsWith('div#controlbar-') || !Array.isArray(entry)) continue;
    const hit = (entry as unknown[]).find(match);
    if (hit !== undefined) { found = hit; break; }
  }

  // Hapus dari semua zona controlbar.
  for (const [key, entry] of Object.entries(root)) {
    if (!key.startsWith('div#controlbar-') || !Array.isArray(entry)) continue;
    root[key] = (entry as unknown[]).filter(e => !match(e)) as typeof entry;
  }

  if (found === null) return;

  // Tambahkan ke tiap More menu bila belum ada (mobile mungkin sudah memuatnya).
  for (const key of [
    'rtk-more-toggle.activeMoreMenu',
    'rtk-more-toggle.activeMoreMenu.md',
    'rtk-more-toggle.activeMoreMenu.sm',
  ]) {
    const list = root[key];
    if (!Array.isArray(list)) continue;
    if ((list as unknown[]).some(match)) continue;
    const item: unknown = Array.isArray(found)
      ? [found[0], { ...((found[1] as Record<string, unknown>) ?? {}), variant: 'horizontal', slot: 'more-elements' }]
      : [found, { variant: 'horizontal', slot: 'more-elements' }];
    // Disisipkan di ATAS (prepend) — bukan di akhir — supaya Settings/Plugins/
    // Effects menempel di puncak menu More dan kontrol rekaman (yang disisipkan
    // addon lebih dulu) tetap berada di posisi paling bawah.
    root[key] = [item, ...(list as unknown[])] as typeof list;
  }
}

type LeaveRoomState = 'disconnected' | 'connected-meeting' | 'left-breakout' | 'left-meeting' | string;

// Screenshare constraints passed into RTK at init time.
// Must be a class instance (not a plain object): the SDK's lodash merge
// only keeps a live reference for non-plain objects, so mutating width/height
// before enableScreenShare() is reflected in getDisplayMedia constraints.
class ScreenshareConstraints {
  width = { max: 1280 };
  height = { max: 720 };
  frameRate = { ideal: 5, max: 5 };
  displaySurface: 'window' | 'monitor' | 'browser' = 'monitor';
}
const screenshareConstraints = new ScreenshareConstraints();

const MAX_SUBSCRIBED_STREAMS = 24;
const SHARE_HEAL_INTERVAL_MS = 15000;
const SHARE_WATCH_TICK_MS = 5000;

// socket.preset.StreamPermissionType — nilai updatePermissions(media.video.canProduce)
const STREAM_ALLOWED = 1;
const STREAM_NOT_ALLOWED = 2;
// Pesan broadcast host → peserta yang kameranya dibuka/dikunci oleh batas kamera
const CAMERA_CAP_MESSAGE = 'CAMERA_CAP';
const CAMERA_CAP_TICK_MS = 1500;

interface LiveParticipant {
  id: string;
  name?: string;
  custom_participant_id?: string;
  userId?: string;
}

// admin & superadmin sama-sama dianggap staf/host di meeting
const isStaffRole = (role?: string | null) => role === 'admin' || role === 'superadmin';

// --- Kunci rekaman (recording lock) -----------------------------------------
// Aturan: SATU perekaman per sesi meeting, dan hanya orang yang menekan Start
// (operator) yang boleh pause/stop. Kuncinya disimpan di server (kolom
// recording_* pada tabel meetings) dan ikut dikirim lewat polling meeting,
// sehingga SEMUA host/admin melihat keadaan yang sama.
//
// Operator diidentifikasi lewat id persistent browser (getPersistentUserId),
// sama seperti fitur kick — jadi operator tetap dikenali setelah reload.
const RECORDING_LOCK_HEARTBEAT_MS = 15_000;

interface RecordingLockState {
  active: boolean;
  operatorId: string | null;
  source: string | null;
}

export default function Meeting() {
  const [meeting, initMeeting] = useRealtimeKitClient();
  const [customConfig, setCustomConfig] = useState<UIConfig | undefined>(undefined);
  const navigate = useNavigate();
  const { id } = useParams();
  const { user, status } = useAuth();
  const homePath = isStaffRole(user?.role) ? '/admin' : '/';
  const { addToast } = useToast();
  const [kickConfirmId, setKickConfirmId] = useState<string | null>(null);
  const [kickConfirmCustomId, setKickConfirmCustomId] = useState<string | undefined>(undefined);
  const [kickConfirmName, setKickConfirmName] = useState('');
  const didInitRef = useRef<string | null>(null);
  const hasJoinedRef = useRef(false);
  const consecutiveMissingCountRef = useRef(0);
  const lastShareHealRef = useRef(0);

  // Ruang meeting selalu dark — paksa lepas class light, kembalikan preferensi
  // pengguna setelah keluar dari meeting.
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('light');
    return () => {
      try {
        if (localStorage.getItem('learnly:theme') === 'light') {
          root.classList.add('light');
        }
      } catch {
        /* storage tidak tersedia */
      }
    };
  }, []);

  // Host Tools & Participant Management State
  const [showHostTools, setShowHostTools] = useState(false);
  const [participantsList, setParticipantsList] = useState<LiveParticipant[]>([]);
  const [kickLoadingId, setKickLoadingId] = useState<string | null>(null);
  // RealtimeKit provider failure while listing participants (null = OK).
  const [participantsError, setParticipantsError] = useState<string | null>(null);

  // Name gate — members must fill in a display name before entering
  const [showNameGate, setShowNameGate] = useState(false);
  const [gateName, setGateName] = useState('');
  // Host join code — hanya untuk nama terdaftar di list tentor saat meeting
  // mengaktifkan kode host.
  const [showHostCodeGate, setShowHostCodeGate] = useState(false);
  const [gateHostCode, setGateHostCode] = useState('');
  const [gateHostCodeError, setGateHostCodeError] = useState<string | null>(null);
  const [gateHostCodeLoading, setGateHostCodeLoading] = useState(false);

  // Share-link & participant-rename state
  const [meetingPublicId, setMeetingPublicId] = useState('');
  const [showShareModal, setShowShareModal] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [renameMember, setRenameMember] = useState<{ participantId: string; custom_participant_id: string; name: string } | null>(null);
  const [memberRenameName, setMemberRenameName] = useState('');
  const [memberRenameLoading, setMemberRenameLoading] = useState(false);
  const [memberRenameError, setMemberRenameError] = useState<string | null>(null);

  // Self-rename state (for member, guest, or admin)
  const [showSelfRenameModal, setShowSelfRenameModal] = useState(false);
  const [selfRenameName, setSelfRenameName] = useState('');
  const [selfRenameLoading, setSelfRenameLoading] = useState(false);
  const [selfRenameError, setSelfRenameError] = useState<string | null>(null);

  // Counter to force RtkMeeting re-render when participant names change
  const [renameVersion, setRenameVersion] = useState(0);

  // Track locally renamed participants so polling doesn't overwrite them
  const localNameOverridesRef = useRef<Map<string, string>>(new Map());

  // Auto-record state (from meeting record)
  const [autoRecord, setAutoRecord] = useState(false);
  const [scheduledAt, setScheduledAt] = useState<string | null>(null);
  const didAutoRecordRef = useRef(false);
  // Menandai penghentian rekaman saat meeting expired sudah ditangani sekali.
  const expiryStopHandledRef = useRef(false);

  // Duration & Expiration State
  const [expiresAt, setExpiresAt] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<string | null>(null);
  const [isNearExpired, setIsNearExpired] = useState(false);

  // Recording State — client-side MediaRecorder (tanpa RealtimeKit Cloud Export)
  const {
    recordingState,
    durationSeconds,
    uploadProgress,
    errorMessage: recordingError,
    start: startClientRecording,
    stop: stopClientRecording,
    pause: pauseClientRecording,
    resume: resumeClientRecording,
    clearError: clearRecordingError,
  } = useClientRecorder(meeting);
  // Resolusi rekaman tidak lagi dipilih manual lewat dialog — otomatis mengikuti
  // settingan admin (screenshare_resolution) yang sudah diterapkan ke shareRes.
  const recordingElapsed = useMemo(() => {
    const totalSec = Math.max(0, Math.floor(durationSeconds));
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, [durationSeconds]);

  // Immutable meeting id (uuid) captured from the first detail response.
  // Route param `:id` may be a public_id that an admin renames mid-meeting;
  // polling and in-room API calls must keep using the internal id.
  const runtimeIdRef = useRef<string | null>(null);

  // Berkas token unggah rekaman client-side (diterbitkan untuk host saat join).
  const readUploadToken = useCallback(() => {
    if (!id) return null;
    try {
      return sessionStorage.getItem(`rtk:uploadtoken:${id}`);
    } catch {
      return null;
    }
  }, [id]);

  // Whiteboard & permission policy state
  const [showWhiteboard, setShowWhiteboard] = useState(false);
  const [allowMemberWhiteboard, setAllowMemberWhiteboard] = useState(false);
  const [allowMemberAnnotation, setAllowMemberAnnotation] = useState(false);
  // Batas kamera peserta (non-host) yang boleh menyala serentak; 0 = tanpa batas
  const [maxActiveCameras, setMaxActiveCameras] = useState(0);
  const [tokenRole, setTokenRole] = useState<'admin' | 'member' | null>(null);

  // Screen share annotation session state (Zoom-like annotation).
  const [annotationSession, setAnnotationSession] = useState<AnnotationSessionInfo | null>(null);
  const annotationRequestedRef = useRef(false);

  // Transient media error banner (permission denied, etc.)
  const [mediaError, setMediaError] = useState<string | null>(null);
  const mediaErrorTimerRef = useRef<number | null>(null);
  const showMediaError = useCallback((msg: string) => {
    setMediaError(msg);
    if (mediaErrorTimerRef.current !== null) window.clearTimeout(mediaErrorTimerRef.current);
    mediaErrorTimerRef.current = window.setTimeout(() => setMediaError(null), 4000);
  }, []);

  // Resolusi screen share — diatur admin (Excel / form Add Meeting), bukan dipilih di room
  const [shareRes, setShareRes] = useState<'480p' | '720p'>('720p');
  const [shareNoticeDismissed, setShareNoticeDismissed] = useState(false);

  // Gerbang koneksi screen share (issue #82): share hanya boleh dimulai saat
  // koneksi RTK sehat, dan otomatis dihentikan secara lokal saat koneksi hilang.
  const shareConnection = useScreenShareConnection(meeting);

  // Screen share capability: 'web' (desktop getDisplayMedia) atau 'native'
  // (WebView wrapper dengan MediaProjection/ReplayKit). Mobile web tanpa API
  // dibanner otomatis oleh ShareScreenNotice (bukan state terpisah).
  const [shareSupport, setShareSupport] = useState<ScreenShareSupport>(() => getScreenShareSupport());
  const [nativeShareActive, setNativeShareActive] = useState(false);
  const nativeShareActiveRef = useRef(false);

  // Hitung ulang setelah meeting object siap (bridge native bisa disuntik
  // terlambat oleh wrapper Android/iOS).
  useEffect(() => {
    setShareSupport(getScreenShareSupport());
  }, [meeting]);

  // Sinkronkan status native screen share + hentikan capture saat leave.
  useEffect(() => {
    const unsubscribe = subscribeNativeShareState((active) => {
      nativeShareActiveRef.current = active;
      setNativeShareActive(active);
    });
    return () => {
      unsubscribe();
      if (nativeShareActiveRef.current) stopNativeScreenShareIfActive();
    };
  }, []);

  const isHost = isStaffRole(user?.role) || tokenRole === 'admin' || meeting?.self?.presetName === 'group_call_host';
  const isAdmin = isHost;

  // Listen for media permission errors (e.g. browser permission denied)
  useEffect(() => {
    if (!meeting?.self?.on || !meeting?.self?.off) return;

    const onMediaPermissionError = (payload: { kind?: string; message?: string }) => {
      // User membatalkan picker share/izin — bukan error, jangan tampilkan.
      if (payload?.message === 'CANCELED') return;
      if (payload?.kind === 'audio') showMediaError('Microphone permission was denied. Please allow microphone access in your browser settings.');
      if (payload?.kind === 'video') showMediaError('Camera permission was denied. Please allow camera access in your browser settings.');
      if (payload?.kind === 'screenshare') {
        // DENIED (user membatalkan/menolak picker) sudah ditandai SDK lewat
        // ikon merah + warning pada tombol share-nya — jangan dobelkan toast.
        if (payload?.message === 'SYSTEM_DENIED' || payload?.message === 'COULD_NOT_START') {
          showMediaError('Screen sharing tidak dapat dimulai. Periksa izin akses layar di pengaturan browser.');
        }
      }
    };

    meeting.self.on('mediaPermissionError', onMediaPermissionError);
    return () => {
      meeting.self.off('mediaPermissionError', onMediaPermissionError);
    };
  }, [meeting, showMediaError]);

  // Host: terapkan batas kamera peserta serentak (max_active_cameras; 0 = tanpa batas).
  // Blokir izin produksi video lewat provider sehingga tombol kamera peserta benar-benar
  // mati (SDK men-stop track sendiri saat izin berubah), lalu buka lagi begitu ada slot
  // kosong — antrean diurutkan sesuai urutan join di room.
  useEffect(() => {
    const cap = Math.max(0, Math.floor(Number(maxActiveCameras) || 0));
    if (!isHost || cap <= 0) return;
    if (!meeting?.self?.roomJoined || !meeting?.participants?.joined) return;

    type PresetPatch = Parameters<typeof meeting.participants.updatePermissions>[1];
    const blocked = new Set<string>();
    let running = false;
    let stopped = false;
    let warned = false;

    const patchPermission = (participantIds: string[], canProduce: number) =>
      meeting.participants.updatePermissions(
        participantIds,
        { media: { video: { canProduce } } } as unknown as PresetPatch
      );

    const announce = (participantIds: string[], isBlocked: boolean) => {
      if (!participantIds.length) return;
      void meeting.participants
        .broadcastMessage(
          CAMERA_CAP_MESSAGE,
          // BroadcastMessagePayload hanya menerima primitive — id digabung pakai koma
          { ids: participantIds.join(','), blocked: isBlocked, limit: cap },
          { participantIds }
        )
        .catch(() => { /* peer keluar / rate limit broadcast */ });
    };

    const run = async () => {
      if (running || stopped) return;
      running = true;
      try {
        const members = [...meeting.participants.joined.values()].filter((p) => !isHostPeer(p));
        const present = new Set(members.map((p) => p.id));
        for (const pid of [...blocked]) if (!present.has(pid)) blocked.delete(pid);

        const active = members.filter((p) => p.videoEnabled && !blocked.has(p.id));
        if (active.length > cap) {
          const ids = active.slice(cap).map((p) => p.id);
          await patchPermission(ids, STREAM_NOT_ALLOWED);
          ids.forEach((pid) => blocked.add(pid));
          announce(ids, true);
        } else {
          const reopen = members.filter((p) => blocked.has(p.id)).slice(0, cap - active.length);
          if (reopen.length) {
            const ids = reopen.map((p) => p.id);
            await patchPermission(ids, STREAM_ALLOWED);
            ids.forEach((pid) => blocked.delete(pid));
            announce(ids, false);
          }
        }
        warned = false;
      } catch (err) {
        if (!warned) {
          warned = true;
          console.warn('Pembatasan kamera ditolak provider:', err);
          addToast('Provider menolak batas kamera — cek preset host (can change participant permissions).', 'error');
        }
      } finally {
        running = false;
      }
    };

    void run();
    const timer = window.setInterval(() => { void run(); }, CAMERA_CAP_TICK_MS);

    return () => {
      stopped = true;
      window.clearInterval(timer);
      const ids = [...blocked];
      blocked.clear();
      // Lepas semua blokade saat host pindah/refresh supaya tidak ada kamera terkunci permanen
      if (ids.length) void patchPermission(ids, STREAM_ALLOWED).catch(() => { /* best effort */ });
    };
  }, [isHost, maxActiveCameras, meeting, addToast]);

  // Intercept built-in Share Screen button: set resolusi dari setting admin
  // lalu langsung mulai — tanpa dialog pilihan di room.
  // Capture phase + preventDefault supaya constraints keburu diset sebelum SDK mulai.
  // Stop-sharing clicks (already sharing) are left alone.
  // Use composedPath() — closest() does not pierce nested shadow DOM
  // (rtk-screen-share-toggle > rtk-tooltip > rtk-controlbar-button > button).
  const startShareAuto = useCallback(async () => {
    if (!meeting) return;
    // Issue #82: tolak bila koneksi RTK belum sehat (offline / belum join
    // room / sedang reconnect). navigator.onLine tidak dijadikan bukti cukup.
    if (!shareConnection.canStartShare) {
      showMediaError(
        shareConnection.blockedReason ??
          'Koneksi internet terputus. Hubungkan kembali jaringan sebelum membagikan layar.',
      );
      return;
    }
    if (shareRes === '480p') {
      screenshareConstraints.width.max = 854;
      screenshareConstraints.height.max = 480;
    } else {
      screenshareConstraints.width.max = 1280;
      screenshareConstraints.height.max = 720;
    }
    try {
      await meeting.self.enableScreenShare();
    } catch {
      showMediaError('Screen sharing could not be started.');
    }
  }, [meeting, shareRes, showMediaError, shareConnection.canStartShare, shareConnection.blockedReason]);

  useEffect(() => {
    const onClick = (e: Event) => {
      const path = e.composedPath();
      const isShareToggle = path.some(
        (n) => n instanceof HTMLElement && n.localName === 'rtk-screen-share-toggle'
      );
      if (!isShareToggle) return;
      // Stop-sharing (saat sudah berbagi) dibiarkan — member tidak akan berbagi,
      // tapi guard ini tetap aman bila tombol ditekan saat share aktif.
      if (meeting?.self?.screenShareEnabled) return;
      e.preventDefault();
      e.stopPropagation();
      // Share Screen khusus host — tombol seharusnya sudah lenyap lewat config;
      // gate ini menutup jalur bypass (mis. konfigurasi kit berubah).
      if (!isHost) {
        addToast('Hanya host yang dapat berbagi layar.', 'error');
        return;
      }
      // Issue #82: jangan mulai share sebelum koneksi RTK benar-benar pulih.
      if (!shareConnection.canStartShare) {
        showMediaError(
          shareConnection.blockedReason ??
            'Koneksi internet terputus. Hubungkan kembali jaringan sebelum membagikan layar.',
        );
        return;
      }
      void startShareAuto();
    };
    document.addEventListener('click', onClick, true);
    return () => document.removeEventListener('click', onClick, true);
  }, [meeting, startShareAuto, isHost, addToast, showMediaError, shareConnection.canStartShare, shareConnection.blockedReason]);

  // Tombol Share Screen cadangan — HANYA untuk wrapper native (WebView:
  // MediaProjection/ReplayKit via bridge). Desktop memakai tombol RTK bawaan;
  // mobile web tanpa API dibanner otomatis oleh ShareScreenNotice, tanpa tombol.
  const handleShareFallbackClick = useCallback(async () => {
    if (!isHost) return;
    const bridge = getNativeScreenShareBridge();
    if (!bridge) return;
    // Issue #82: jangan mulai share native saat koneksi RTK belum sehat.
    // (Stop dibiarkan — selalu boleh agar sesi bisa dibersihkan.)
    if (!nativeShareActiveRef.current && !shareConnection.canStartShare) {
      showMediaError(
        shareConnection.blockedReason ??
          'Koneksi internet terputus. Hubungkan kembali jaringan sebelum membagikan layar.',
      );
      return;
    }
    try {
      if (nativeShareActiveRef.current) await bridge.stop();
      else await bridge.start();
    } catch {
      showMediaError('Screen sharing tidak dapat dimulai.');
    }
  }, [showMediaError, isHost, shareConnection.canStartShare, shareConnection.blockedReason]);

  // Laporkan kegagalan rekaman client-side (MediaRecorder/canvas tidak
  // didukung, upload gagal, dst.) lewat banner media error yang sudah ada.
  useEffect(() => {
    if (recordingError) showMediaError(recordingError);
  }, [recordingError, showMediaError]);

  // Kunci rekaman (satu perekaman per sesi). Diambil dari payload polling
  // meeting — semua host/admin melihat keadaan yang sama dalam ±3 detik.
  const [recordingLock, setRecordingLock] = useState<RecordingLockState>({
    active: false,
    operatorId: null,
    source: null,
  });
  const [recordingFailureAlert, setRecordingFailureAlert] = useState<{
    isOpen: boolean;
    reason: string;
  }>({ isOpen: false, reason: '' });
  const wasAutoRecordingRef = useRef(false);
  // Supaya pemberitahuan "sedang direkam" hanya muncul sekali per sesi rekaman.
  const recordingLockNotifiedRef = useRef(false);
  const myRecordingId = useMemo(() => getPersistentUserId(), []);

  // Klaim kunci rekaman SEBELUM merekam. 409 dari server berarti sudah ada
  // host/admin lain yang merekam → rekaman tidak boleh dimulai (aturan "satu
  // rekaman per sesi"). Kegagalan jaringan juga menggagalkan start, karena
  // tanpa kunci aturannya tidak bisa dijaga.
  const claimRecordingLock = useCallback(async (source: 'manual' | 'auto' = 'manual'): Promise<boolean> => {
    if (!id) return false;
    try {
      const res = await fetch(`/api/meetings/${encodeURIComponent(runtimeIdRef.current || id)}/recording-claim`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ operator_id: getPersistentUserId(), source }),
      });
      if (res.status === 409) {
        showMediaError('Meeting ini sedang direkam oleh host lain. Tunggu sampai rekaman selesai.');
        return false;
      }
      if (!res.ok) {
        showMediaError('Gagal mengunci rekaman. Coba lagi.');
        return false;
      }
      setRecordingLock({ active: true, operatorId: getPersistentUserId(), source });
      return true;
    } catch {
      showMediaError('Gagal mengunci rekaman. Periksa koneksi lalu coba lagi.');
      return false;
    }
  }, [id, showMediaError]);

  // Lepas kunci rekaman (best-effort) setelah berhenti, supaya host lain boleh
  // memulai rekaman berikutnya. Kalau panggilan ini gagal, kunci tetap bersih
  // sendiri lewat kadaluarsa heartbeat (lihat worker).
  const releaseRecordingLock = useCallback(async () => {
    if (!id) return;
    try {
      await fetch(`/api/meetings/${encodeURIComponent(runtimeIdRef.current || id)}/recording-release`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ operator_id: getPersistentUserId() }),
      });
    } catch {
      /* biarkan — heartbeat yang kadaluarsa akan membersihkan kunci */
    }
  }, [id]);

  // Stop Recording — Admin/Host only
  const handleStopRecording = useCallback(async () => {
    try {
      await stopClientRecording();
    } catch (err) {
      console.error('Failed to stop recording:', err);
      showMediaError('Gagal menghentikan recording.');
    } finally {
      void releaseRecordingLock();
    }
  }, [stopClientRecording, showMediaError, releaseRecordingLock]);

  // Start Recording — langsung mulai rekaman client-side. Tidak ada dialog
  // share-screen: tampilan meeting (kamera peserta + screenshare bila ada)
  // dirender ke canvas. Resolusi mengikuti settingan admin tanpa dialog.
  const confirmStartRecording = useCallback(async () => {
    if (!id) return;
    clearRecordingError();
    // Kunci dulu — kalau host/admin lain sudah merekam, rekaman batal di sini.
    if (!(await claimRecordingLock('manual'))) return;
    try {
      await startClientRecording({
        meetingId: runtimeIdRef.current || id,
        resolution: shareRes,
        uploadToken: readUploadToken(),
      });
    } catch {
      showMediaError('Gagal memulai rekaman.');
      // Start gagal setelah kunci terambil → lepas supaya tidak mengunci meeting.
      void releaseRecordingLock();
    }
  }, [id, shareRes, readUploadToken, startClientRecording, clearRecordingError, showMediaError, claimRecordingLock, releaseRecordingLock]);

  const canRecord = isAdmin || meeting?.self?.permissions?.canRecord;
  const isRecordingPaused = recordingState === 'PAUSED';
  const isRecordingActive = recordingState === 'RECORDING' || recordingState === 'STARTING' || isRecordingPaused;
  const isRecordingStopping = recordingState === 'STOPPING';
  const isRecordingUploading = recordingState === 'UPLOADING';
  // true bila klien INILAH operator rekaman (yang menekan Start). Hanya
  // operator yang boleh pause/stop, dan selama ada operator lain, host/admin
  // ini tidak boleh memulai rekaman kedua.
  const amRecordingOperator = recordingLock.active && recordingLock.operatorId === myRecordingId;
  // Mulai rekaman hanya bila: boleh rekam, tidak sedang proses, DAN belum ada
  // yang merekam (atau kunci sedang dipegang sendiri — mis. setelah reload).
  const canStartRecording =
    Boolean(canRecord) &&
    (recordingState === 'IDLE' || recordingState === 'ERROR') &&
    (!recordingLock.active || amRecordingOperator);

  // Pause / Resume Recording — Admin/Host only
  const handlePauseRecording = useCallback(() => {
    pauseClientRecording();
  }, [pauseClientRecording]);
  const handleResumeRecording = useCallback(() => {
    resumeClientRecording();
  }, [resumeClientRecording]);

  // Sinkronkan state rekaman ke <meet-recording-controls> di menu More, dan
  // dengarkan aksi (start/pause/resume/stop) yang dikirim elemen itu. Elemen
  // dirender RTK di dalam SHADOW DOM, jadi tidak bisa dijangkau querySelector —
  // state dikirim lewat module store (setRecordingMenuState) yang dibaca semua
  // instance elemen. Kontrol hanya ditampilkan untuk host/admin yang merekam.
  // Durasi tidak dikirim ke menu — timernya sudah tampil di navbar, jadi menu
  // cukup tahu `visible` + `state` (ini juga bikin menu tak ikut re-render tiap
  // detik).
  const recordingMenuState = useMemo<RecordingMenuState>(
    () => ({
      // Sembunyikan kalau rekaman sedang dipegang host/admin lain — host ini
      // tidak boleh memulai rekaman kedua, dan tidak berhak menyentuh rekaman
      // milik orang lain (lihat recordingMenu.ts).
      visible: Boolean(canRecord) && (amRecordingOperator || canStartRecording),
      isOperator: amRecordingOperator,
      state: recordingState,
    }),
    [canRecord, amRecordingOperator, canStartRecording, recordingState]
  );

  useEffect(() => {
    setRecordingMenuState(recordingMenuState);
  }, [recordingMenuState]);

  useEffect(() => {
    const onStart = () => void confirmStartRecording();
    const onPause = () => handlePauseRecording();
    const onResume = () => handleResumeRecording();
    const onStop = () => void handleStopRecording();
    window.addEventListener(RECORDING_EVENTS.start, onStart);
    window.addEventListener(RECORDING_EVENTS.pause, onPause);
    window.addEventListener(RECORDING_EVENTS.resume, onResume);
    window.addEventListener(RECORDING_EVENTS.stop, onStop);
    return () => {
      window.removeEventListener(RECORDING_EVENTS.start, onStart);
      window.removeEventListener(RECORDING_EVENTS.pause, onPause);
      window.removeEventListener(RECORDING_EVENTS.resume, onResume);
      window.removeEventListener(RECORDING_EVENTS.stop, onStop);
    };
  }, [confirmStartRecording, handlePauseRecording, handleResumeRecording, handleStopRecording]);

  // Submit name gate — persist + reload so the join flow resumes with a name
  const handleGateSubmit = useCallback(() => {
    const trimmed = gateName.trim();
    if (!trimmed || !id) return;
    localStorage.setItem('learnly:name', trimmed);
    setActiveMeetingSession(id, getPersistentUserId(), trimmed);
    setShowNameGate(false);
    window.location.reload();
  }, [gateName, id]);

  // Submit host code — validasi dulu ke server, simpan ke sessionStorage,
  // lalu reload supaya auto-join mengirim kodenya saat minta token.
  const handleHostCodeSubmit = useCallback(async () => {
    const code = gateHostCode.trim();
    if (!code || !id || gateHostCodeLoading) return;
    setGateHostCodeLoading(true);
    setGateHostCodeError(null);
    try {
      const session = getActiveMeetingSession();
      const cachedName = localStorage.getItem('learnly:name') || '';
      const displayName = user?.name || user?.username || session?.participantName || cachedName;
      const r = await fetch(`/api/meetings/${id}/host-code`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name: displayName, code }),
      });
      const d = await r.json().catch(() => null);
      if (!r.ok || d?.valid === false) {
        setGateHostCodeError(
          d?.reason === 'locked'
            ? `Terlalu banyak percobaan kode host. Coba lagi dalam ${Math.ceil((d?.retry_after_seconds || 600) / 60)} menit.`
            : 'Kode host salah. Coba lagi.'
        );
        return;
      }
      sessionStorage.setItem(`rtk:hostcode:${id}`, code);
      sessionStorage.removeItem(`rtk:hostmember:${id}`);
      setShowHostCodeGate(false);
      window.location.reload();
    } catch {
      setGateHostCodeError('Gagal memeriksa kode host. Coba lagi.');
    } finally {
      setGateHostCodeLoading(false);
    }
  }, [gateHostCode, gateHostCodeLoading, id, user]);

  // Safely stop recording (used before leaving / at expiry) — best-effort.
  // Menunggu rekaman client-side berhenti + terunggah, supaya data tidak
  // hilang saat halaman berpindah.
  const stopRecordingSafely = useCallback(async () => {
    try {
      await stopClientRecording();
    } catch {
      /* ignore */
    } finally {
      // Lepas kunci supaya host lain bisa merekam lagi setelah meeting berpindah
      // halaman / berakhir.
      void releaseRecordingLock();
    }
  }, [stopClientRecording, releaseRecordingLock]);

  // Auto-record: start when scheduled time has passed, stop at expiry
  const maybeAutoRecord = useCallback(async () => {
    if (!canRecord || !hasJoinedRef.current || !autoRecord) return;

    // Untuk HP/Tablet (mobile): jangan rekam client-side di browser
    // (alur mobile ditangani terpisah via bot VPS)
    if (shareSupport.isMobile) {
      return;
    }

    // Jika sedang direkam oleh operator lain atau bot (kunci rekaman aktif), browser PC yield
    if (recordingLock.active) {
      return;
    }

    const now = Date.now();

    if (expiresAt && now >= new Date(expiresAt).getTime()) {
      if (isRecordingActive || isRecordingStopping) {
        try { await stopRecordingSafely(); } catch { /* ignore */ }
      }
      return;
    }

    if (scheduledAt && now < new Date(scheduledAt).getTime()) return;

    if (canStartRecording && !didAutoRecordRef.current) {
      didAutoRecordRef.current = true;
      clearRecordingError();
      try {
        // Klaim kunci dulu — kalau host/admin lain sudah merekam, jangan dobel.
        if (!(await claimRecordingLock('auto'))) {
          didAutoRecordRef.current = false;
          return;
        }
        await startClientRecording({
          meetingId: runtimeIdRef.current || id || '',
          resolution: shareRes,
          uploadToken: readUploadToken(),
        });
      } catch (err) {
        console.error('Auto-record start failed:', err);
        didAutoRecordRef.current = false;
        void releaseRecordingLock();
      }
    }
  }, [canRecord, autoRecord, shareSupport.isMobile, recordingLock.active, scheduledAt, expiresAt, isRecordingActive, isRecordingStopping, stopRecordingSafely, canStartRecording, clearRecordingError, startClientRecording, shareRes, readUploadToken, id, claimRecordingLock, releaseRecordingLock]);

  // Evaluate auto-record immediately and re-check periodically (covers time windows)
  useEffect(() => {
    if (!autoRecord) return;
    maybeAutoRecord();
    const t = window.setInterval(maybeAutoRecord, 15000);
    return () => window.clearInterval(t);
  }, [maybeAutoRecord, autoRecord]);

  // Denyut (heartbeat) kunci rekaman: operator mengabari server tiap 15 detik
  // selama merekam, supaya kunci tidak dianggap kadaluarsa. Bila server menjawab
  // 409, kunci sudah diambil alih host lain (mis. tab kita sempat crash lalu
  // bangkit dan melewati batas kadaluarsa) → hentikan rekaman lokal supaya tidak
  // ada dua rekaman sekaligus.
  // Server yang tak terjangkau TIDAK menghentikan rekaman: file tetap direkam &
  // diunggah, hanya kuncinya yang tidak segar.
  useEffect(() => {
    if (!isRecordingActive || !amRecordingOperator || !id) return;
    const beat = async () => {
      try {
        const res = await fetch(
          `/api/meetings/${encodeURIComponent(runtimeIdRef.current || id)}/recording-heartbeat`,
          {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ operator_id: getPersistentUserId() }),
          }
        );
        if (res.status === 409) {
          showMediaError('Rekaman diambil alih oleh host lain.');
          await stopRecordingSafely();
        }
      } catch {
        /* server tak terjangkau — rekaman lokal tetap berjalan */
      }
    };
    const timer = window.setInterval(() => void beat(), RECORDING_LOCK_HEARTBEAT_MS);
    return () => window.clearInterval(timer);
  }, [isRecordingActive, amRecordingOperator, id, showMediaError, stopRecordingSafely]);

  // Beri tahu host/admin lain bahwa meeting sedang direkam (sekali per sesi
  // rekaman) — supaya mereka mengerti kenapa tombol rekamnya tidak muncul.
  useEffect(() => {
    if (!recordingLock.active || amRecordingOperator) {
      recordingLockNotifiedRef.current = false;
      return;
    }
    if (recordingLockNotifiedRef.current) return;
    recordingLockNotifiedRef.current = true;
    addToast(
      recordingLock.source === 'auto'
        ? 'Meeting ini sedang direkam otomatis oleh sistem.'
        : 'Meeting ini sedang direkam oleh host lain.',
      'info'
    );
  }, [recordingLock.active, recordingLock.source, amRecordingOperator, addToast]);

  // Expiry banner state
  const [expiryMessage, setExpiryMessage] = useState<string | null>(null);

  // Resolution Policy State
  const [resolutionPolicy, setResolutionPolicy] = useState<{ host: string; member: string } | null>(null);

  useEffect(() => {
    const searchParams = new URL(window.location.href).searchParams;
    let authToken: string | null = searchParams.get('authToken');

    if (!authToken && id) {
      try {
        authToken = sessionStorage.getItem(`rtk:token:${id}`);
      } catch {
        /* ignore storage access error */
      }
    }

    if (!authToken && id) {
      if (status === 'loading') return;

      // Auto-join / Reconnect on direct link or reload
      let isSubscribed = true;
      (async () => {
        try {
          const cachedName = localStorage.getItem('learnly:name') || '';
          const session = getActiveMeetingSession();
          const displayName = user?.name || user?.username || session?.participantName || cachedName;

          // Members must enter a display name before joining
          if (!isStaffRole(user?.role) && !displayName.trim()) {
            setGateName(cachedName || '');
            setShowNameGate(true);
            return;
          }

          const userId = getPersistentUserId();

          // Host code gate: nama terdaftar sebagai tentor + meeting memakai
          // kode host → minta kode dulu sebelum minta token (sekali validasi
          // di sessionStorage, dipakai lagi untuk reconnect).
          let hostCodeForJoin = '';
          if (!isStaffRole(user?.role)) {
            hostCodeForJoin = sessionStorage.getItem(`rtk:hostcode:${id}`) || '';
            const joinedAsMember = sessionStorage.getItem(`rtk:hostmember:${id}`) === '1';
            if (!hostCodeForJoin && !joinedAsMember) {
              const metaRes = await fetch(`/api/meetings/${id}`, { credentials: 'include' });
              if (metaRes.ok) {
                const meta = await metaRes.json();
                const tentorNames: string[] = Array.isArray(meta.tentor_names) ? meta.tentor_names : [];
                const needsHostCode = meta.host_code_set === true
                  && tentorNames.some((t) => String(t).trim().toLowerCase() === displayName.trim().toLowerCase());
                if (needsHostCode) {
                  setGateHostCode('');
                  setGateHostCodeError(null);
                  setShowHostCodeGate(true);
                  return;
                }
              }
            }
          }

          const r = await fetch('/api/tokens', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              meetingId: id,
              userId,
              name: displayName,
              presetName: isStaffRole(user?.role) ? 'group_call_host' : 'group_call_participant',
              hostCode: hostCodeForJoin || undefined
            })
          });
          const data = await r.json();
          if (!isSubscribed) return;

          if (!r.ok) {
            clearActiveMeetingSession(id);
            setExpiryMessage(data.message || data.error || "Unable to join meeting session.");
            setTimeout(() => navigate(homePath), 3000);
            return;
          }

          const token = data.auth_token;
          if (!token) {
            clearActiveMeetingSession(id);
            setExpiryMessage("Could not retrieve meeting token.");
            setTimeout(() => navigate(homePath), 3000);
            return;
          }

          // Meeting policy snapshot for member capabilities (whiteboard etc.)
          if (typeof data.allow_member_whiteboard === 'boolean') {
            setAllowMemberWhiteboard(data.allow_member_whiteboard);
          }
          if (typeof data.allow_member_annotation === 'boolean') {
            setAllowMemberAnnotation(data.allow_member_annotation);
          }
          if (data.user_role === 'admin' || data.user_role === 'member') {
            setTokenRole(data.user_role);
          }

          // Batas kamera serentak (0 = tanpa batas)
          if (typeof data.max_active_cameras === 'number') {
            setMaxActiveCameras(Math.max(0, Math.floor(data.max_active_cameras)));
          }

          // Auto-record policy snapshot
          if (typeof data.auto_record === 'boolean') {
            setAutoRecord(data.auto_record);
          }
          if (data.scheduled_at) {
            setScheduledAt(data.scheduled_at);
          }

          setActiveMeetingSession(id, userId, displayName);
          try {
            sessionStorage.setItem(`rtk:token:${id}`, token);
            // Token unggah rekaman client-side (hanya diterbitkan untuk host)
            if (typeof data.upload_token === 'string' && data.upload_token) {
              sessionStorage.setItem(`rtk:uploadtoken:${id}`, data.upload_token);
            }
          } catch {
            /* ignore */
          }

          const dynamicKey = `${id}:${token}`;
          if (didInitRef.current !== dynamicKey) {
            didInitRef.current = dynamicKey;
            initMeeting({
              authToken: token,
              defaults: {
                audio: true,
                video: true,
                mediaConfiguration: { screenshare: screenshareConstraints },
              },
              modules: { devTools: { logs: true, logLevel: import.meta.env.DEV ? 'debug' : 'info' } },
            });
          }
        } catch {
          if (isSubscribed) {
            clearActiveMeetingSession(id);
            setExpiryMessage("Network error connecting to meeting.");
            setTimeout(() => navigate(homePath), 3000);
          }
        }
      })();

      return () => {
        isSubscribed = false;
      };
    }

    if (authToken && id) {
      const cachedName = localStorage.getItem('learnly:name') || '';
      const session = getActiveMeetingSession();
      const displayName = user?.name || user?.username || session?.participantName || cachedName;

      // Members must enter a display name before joining
      if (!isStaffRole(user?.role) && !displayName.trim()) {
        setGateName(cachedName || '');
        setShowNameGate(true);
        return;
      }

      setActiveMeetingSession(id, getPersistentUserId(), displayName);
      const initKey = `${id}:${authToken}`;
      if (didInitRef.current === initKey) return;
      didInitRef.current = initKey;
      initMeeting({
        authToken,
        defaults: {
          audio: true,
          video: true,
          mediaConfiguration: { screenshare: screenshareConstraints },
        },
        modules: { devTools: { logs: true, logLevel: import.meta.env.DEV ? 'debug' : 'info' } },
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, initMeeting, navigate, status, homePath]);

  // Track when user actually joins RTK room
  useEffect(() => {
    if (meeting?.self?.roomJoined) {
      hasJoinedRef.current = true;
      try {
        if (meeting.participants.maxActiveParticipantsCount < MAX_SUBSCRIBED_STREAMS) {
          meeting.participants.setMaxActiveParticipantsCount(MAX_SUBSCRIBED_STREAMS);
        }
      } catch (err) {
        console.warn('Unable to raise subscription limit:', err);
      }
    }
  }, [meeting, meeting?.self?.roomJoined]);

  useEffect(() => {
    if (!meeting || !meeting.self?.roomJoined) return;

    const timer = window.setInterval(() => {
      try {
        const selfId = meeting.self.id;
        const stuckShare = meeting.participants.joined
          .toArray()
          .some((p) => p.id !== selfId && p.screenShareEnabled && !p.screenShareTracks?.video);
        if (!stuckShare) return;

        const now = Date.now();
        if (now - lastShareHealRef.current < SHARE_HEAL_INTERVAL_MS) return;
        lastShareHealRef.current = now;

        meeting.participants.setMaxActiveParticipantsCount(meeting.participants.maxActiveParticipantsCount);
      } catch (err) {
        console.warn('Screen share recovery failed:', err);
      }
    }, SHARE_WATCH_TICK_MS);

    return () => window.clearInterval(timer);
  }, [meeting, meeting?.self?.roomJoined]);

  // Fetch meeting detail & expiration info
  useEffect(() => {
    if (!id) return;

    const checkMeetingStatus = async () => {
      try {
        const targetId = runtimeIdRef.current || id;
        setKickMeetingId(targetId);
        const res = await fetch(`/api/meetings/${targetId}`, { credentials: 'include' });
        if (res.ok) {
          const data = await res.json();
          if (data.meeting) {
            if (typeof data.meeting.id === 'string' && data.meeting.id) {
              runtimeIdRef.current = data.meeting.id;
            }
            // Class code (for the share link)
            if (typeof data.meeting.public_id === 'string') {
              setMeetingPublicId(data.meeting.public_id);
            }
            // Auto-record policy from meeting record (fallback if token missed it)
            if (data.meeting.auto_record === true || data.meeting.auto_record === 1) {
              setAutoRecord(true);
            }

            // Kunci rekaman (satu perekaman per sesi) — dikirim worker pada
            // payload polling yang sama. Pakai functional update supaya polling
            // tiap 3 detik tidak memicu re-render bila keadaannya tetap sama.
            const lock = data.recording_lock ?? {};
            const nextLock: RecordingLockState = {
              active: Boolean(lock.active),
              operatorId: typeof lock.operator_id === 'string' ? lock.operator_id : null,
              source: typeof lock.source === 'string' ? lock.source : null,
            };

            // Deteksi kegagalan rekaman otomatis VPS (crash / stale lock setelah 90 detik)
            // Hanya aktif jika yang merekam adalah bot VPS ('vps-recorder')
            if (nextLock.active && nextLock.operatorId === 'vps-recorder') {
              wasAutoRecordingRef.current = true;
            } else if (!nextLock.active && wasAutoRecordingRef.current) {
              wasAutoRecordingRef.current = false;
              if (data.meeting.status === 'active' || !data.meeting.status || data.meeting.status === 'scheduled') {
                setRecordingFailureAlert({
                  isOpen: true,
                  reason: 'Koneksi perekam VPS terputus atau rekaman otomatis berhenti mendadak.',
                });
              }
            }

            setRecordingLock((prev) =>
              prev.active === nextLock.active &&
              prev.operatorId === nextLock.operatorId &&
              prev.source === nextLock.source
                ? prev
                : nextLock
            );
            if (data.meeting.scheduled_at) {
              setScheduledAt(data.meeting.scheduled_at);
            }

            if (data.meeting.status === 'expired' || data.meeting.status === 'ended' || data.meeting.status === 'deleted') {
              didAutoRecordRef.current = false;
              // Tunggu rekaman client-side berhenti & terunggah sebelum keluar.
              if (!expiryStopHandledRef.current) {
                expiryStopHandledRef.current = true;
                await stopRecordingSafely();
                clearActiveMeetingSession(id);
                try { await meeting?.leave?.(); } catch { /* ignore */ }
                setExpiryMessage("This meeting has expired or been terminated.");
                setTimeout(() => navigate(homePath), 3000);
              }
              return;
            }
            // Schedule enforcement: only before the first start (non-admins)
            if (data.meeting.scheduled_at && !data.meeting.started_at && !isStaffRole(user?.role)) {
              const scheduledTime = new Date(data.meeting.scheduled_at);
              if (new Date() < scheduledTime) {
                clearActiveMeetingSession(id);
                try { await meeting?.leave?.(); } catch { /* ignore */ }
                setExpiryMessage(`Meeting ini dijadwalkan pada ${scheduledTime.toLocaleString()}. Menunggu jadwal dimulai...`);
                setTimeout(() => navigate(homePath), 3000);
                return;
              }
            }
            if (data.meeting.expires_at) {
              setExpiresAt(data.meeting.expires_at);
            }
            // Store resolution policy from meeting record
            if (data.meeting.host_resolution || data.meeting.member_resolution) {
              setResolutionPolicy({
                host: data.meeting.host_resolution || '360p',
                member: data.meeting.member_resolution || '240p'
              });
            }
            // Resolusi screen share dari setting admin (Excel / form Add Meeting)
            if (data.meeting.screenshare_resolution === '480p' || data.meeting.screenshare_resolution === '720p') {
              setShareRes(data.meeting.screenshare_resolution);
            }
            // Whiteboard permission policy (fallback if token response missed it)
            if (typeof data.meeting.allow_member_whiteboard === 'boolean' || data.meeting.allow_member_whiteboard === 1 || data.meeting.allow_member_whiteboard === 0) {
              setAllowMemberWhiteboard(data.meeting.allow_member_whiteboard === 1 || data.meeting.allow_member_whiteboard === true);
            }
            // Annotation permission policy (fallback if token response missed it)
            if (typeof data.meeting.allow_member_annotation === 'boolean' || data.meeting.allow_member_annotation === 1 || data.meeting.allow_member_annotation === 0) {
              setAllowMemberAnnotation(data.meeting.allow_member_annotation === 1 || data.meeting.allow_member_annotation === true);
            }
            // Batas kamera serentak (fallback if token response missed it)
            if (typeof data.meeting.max_active_cameras === 'number') {
              setMaxActiveCameras(Math.max(0, Math.floor(Number(data.meeting.max_active_cameras))));
            }
          }

          if (Array.isArray(data.participants)) {
            // BUG 11: a RealtimeKit provider failure previously looked like an
            // empty room. Surface an explicit warning — never pretend nobody
            // is in the meeting.
            if (data.participants_error) {
              setParticipantsError(String(data.participants_error));
            } else {
              setParticipantsError(null);
            }
            // Merge local name overrides so polling doesn't revert renames
            const overrides = localNameOverridesRef.current;
            if (overrides.size > 0) {
              for (const p of data.participants) {
                const override = overrides.get(p.id);
                if (override) p.name = override;
              }
            }
            setParticipantsList(data.participants);

            // Active presence / Kick detection (ONLY for Members, Host is immune):
            // Skip until user has actually joined RTK room — prevents false kick on page load / new meeting
            if (!isStaffRole(user?.role) && hasJoinedRef.current && data.participants.length > 0) {
              const persistentUserId = getPersistentUserId();
              const isStillPresent = data.participants.some((p: LiveParticipant) => {
                return (
                  (p.custom_participant_id && p.custom_participant_id === persistentUserId) ||
                  (p.id && p.id === persistentUserId)
                );
              });

              if (isStillPresent) {
                consecutiveMissingCountRef.current = 0;
              } else {
                consecutiveMissingCountRef.current += 1;
                // Require 2 consecutive misses to prevent race condition right after reload
                if (consecutiveMissingCountRef.current >= 2) {
                  clearActiveMeetingSession(id);
                  try { await meeting?.leave?.(); } catch { /* ignore */ }
                  setExpiryMessage('Anda telah dikeluarkan dari meeting oleh host.');
                  setTimeout(() => navigate(homePath), 2000);
                  return;
                }
              }
            }
          }
        }
      } catch {
        /* ignore network error */
      }
    };

    checkMeetingStatus();
    const timer = setInterval(checkMeetingStatus, 3000); // Check every 3s for fast kick & duration response

    return () => clearInterval(timer);
  }, [id, homePath, navigate, user?.role, meeting, stopRecordingSafely]);

  // Countdown timer calculation
  // Sumber kebenaran: expires_at dari backend (bukan hitungan lokal). Tick 1
  // detik hanya untuk tampilan; keputusan berakhir selalu dihitung ulang dari
  // expires_at, dan diperiksa ulang saat tab kembali aktif / koneksi pulih
  // (throttling timer di background tab tidak boleh menjaga meeting tetap hidup).
  useEffect(() => {
    if (!expiresAt) return;

    const updateCountdown = () => {
      const remainingMs = new Date(expiresAt).getTime() - Date.now();
      if (remainingMs <= 0) {
        setTimeLeft('00:00');
        setExpiryMessage("Meeting duration limit reached. The session has ended.");
        // Rekaman client-side dihentikan + diunggah dulu, baru pindah halaman
        // (dijalankan sekali agar tidak ada navigasi berulang tiap detik).
        if (!expiryStopHandledRef.current) {
          expiryStopHandledRef.current = true;
          didAutoRecordRef.current = false;
          void (async () => {
            // Hentikan screen share yang masih aktif sebelum meninggalkan room.
            try {
              if (meeting?.self?.screenShareEnabled) await meeting.self.disableScreenShare();
            } catch { /* ignore */ }
            if (nativeShareActiveRef.current) stopNativeScreenShareIfActive();
            await stopRecordingSafely();
            clearActiveMeetingSession(id || '');
            // Keluar dari room RTK — navigasi saja tidak memutus sesi.
            try { await meeting?.leave?.(); } catch { /* ignore */ }
            setTimeout(() => navigate(homePath), 3000);
          })();
        }
        return;
      }

      const totalSec = Math.floor(remainingMs / 1000);
      const mins = Math.floor(totalSec / 60);
      const secs = totalSec % 60;
      setTimeLeft(`${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`);
      setIsNearExpired(mins < 5); // Warning under 5 min
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    // Pemeriksaan ulang saat tab kembali terlihat atau koneksi pulih.
    const recheck = () => { if (!document.hidden) updateCountdown(); };
    document.addEventListener('visibilitychange', recheck);
    window.addEventListener('online', recheck);
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', recheck);
      window.removeEventListener('online', recheck);
    };
  }, [expiresAt, homePath, navigate, stopRecordingSafely, meeting, id]);

  // Load Video Background Addon (best-effort, fails gracefully)
  useEffect(() => {
    const buildConfig = (addons: Parameters<typeof registerAddons>[0]) => {
      const cfg = registerAddons(addons, meeting as Meeting);
      // Rekaman RealtimeKit (Cloud Export, berbayar) dimatikan untuk SEMUA
      // peran — rekaman dijalankan client-side lewat useClientRecorder.
      stripRecordingUi(cfg, ['rtk-recording-toggle', 'rtk-recording-indicator']);
      // Share Screen khusus host: tombol kit (control bar desktop & menu More)
      // disembunyikan untuk member. Gate tambahan ada di intercept klik.
      if (!isHost) stripRecordingUi(cfg, ['rtk-screen-share-toggle']);
      // Rapikan navbar: Settings, Effects (video background), dan Plugins
      // dipindahkan dari controlbar ke menu More agar navbar bawah bersih.
      // Tiap item di-prepend (disisipkan di atas), jadi dipanggil dari bawah ke
      // atas agar urutan akhir di puncak menu: Settings -> Plugins -> Effects.
      // (Di mobile/md/sm sebagian sudah ada di More — helper menjaga tanpa duplikat.)
      moveControlbarItemToMore(cfg, e => cfgTag(e) === 'rtk-controlbar-button' && cfgId(e) === 'effects');
      moveControlbarItemToMore(cfg, e => cfgTag(e) === 'rtk-plugins-toggle');
      moveControlbarItemToMore(cfg, e => cfgTag(e) === 'rtk-settings-toggle');
      return cfg;
    };

    async function addEffectsToggleControlBar() {
      try {
        const { default: RealtimeKitVideoBackground } = await import('@cloudflare/realtimekit-ui-addons/video-background');

        const videoBackground = await RealtimeKitVideoBackground.init({
          modes: ['blur', 'virtual', 'random'],
          blurStrength: 30,
          meeting,
          segmentationConfig: { pipeline: 'webgl2' },
          images: [
            'https://assets.dyte.io/backgrounds/bg_0.jpg',
            'https://assets.dyte.io/backgrounds/bg_1.jpg',
            'https://assets.dyte.io/backgrounds/bg_2.jpg',
          ],
          randomCount: 5,
        });

        const newConfig = buildConfig([videoBackground, hostBadgeAddon, ...(isHost ? [recordingMenuAddon] : [])]);
        setCustomConfig(newConfig);
      } catch (err) {
        console.warn('Video background addon not loaded:', err);
        setCustomConfig(buildConfig([hostBadgeAddon, ...(isHost ? [recordingMenuAddon] : [])]));
      }
    }

    if (meeting) {
      setCustomConfig(buildConfig([hostBadgeAddon, ...(isHost ? [recordingMenuAddon] : [])]));
      addEffectsToggleControlBar();
    }
  }, [meeting, isHost]);

  useEffect(() => {
    if (!meeting) return;
    return startHostBadgeSync();
  }, [meeting]);

  // Apply Resolution Policy — set ideal video constraints based on meeting config
  useEffect(() => {
    if (!meeting || !resolutionPolicy) return;

    const maxAllowedRes = isAdmin ? resolutionPolicy.host : resolutionPolicy.member;

    // Map resolution string to pixel height
    const resolutionToHeight: Record<string, number> = {
      '140p': 140,
      '240p': 240,
      '360p': 360,
      '480p': 480,
      '720p': 720,
      '1080p': 1080
    };

    const maxHeight = resolutionToHeight[maxAllowedRes] ?? 240;

    // Apply ideal video constraints using RealtimeKit SDK
    try {
      meeting.self?.updateVideoConstraints({
        width: { ideal: Math.round(maxHeight * (16 / 9)) },
        height: { ideal: maxHeight }
      });
    } catch {
      // SDK method not available or failed — resolution enforcement is best-effort
    }
  }, [meeting, resolutionPolicy, isAdmin]);

  // Redirect to Home when local user leaves the room
  useEffect(() => {
    if (!meeting?.self?.on || !meeting?.self?.off) return;

    const handler = async ({ state }: { state: LeaveRoomState }) => {
      if (state === 'disconnected' || state === 'connected-meeting') return;
      // Jalur kedaluwarsa (countdown / status server) sudah memegang alur keluar
      // — banner "waktu habis" + navigasi tertunda. Jangan dobelkan navigasi.
      if (expiryStopHandledRef.current) return;
      didAutoRecordRef.current = false;
      // Rekaman client-side dihentikan + diunggah dulu, baru tinggalkan halaman.
      await stopRecordingSafely();
      clearActiveMeetingSession(id);
      if (state === 'kicked') {
        setExpiryMessage('Anda telah dikeluarkan dari meeting oleh host.');
        setTimeout(() => navigate(homePath), 2000);
        return;
      }
      navigate(homePath);
    };

    meeting.self.on('roomLeft', handler);
    return () => {
      meeting.self.off('roomLeft', handler);
    };
  }, [meeting, navigate, homePath, stopRecordingSafely, id]);

  // Safety net: listen for 'kicked' event on participants map
  useEffect(() => {
    if (!meeting?.participants?.joined?.on || !meeting?.participants?.joined?.off) return;

    const onKicked = (payload: { id: string }) => {
      if (payload.id === meeting.self?.id) {
        setExpiryMessage('Anda telah dikeluarkan dari meeting oleh host.');
        setTimeout(() => navigate(homePath), 2000);
      }
    };

    meeting.participants.joined.on('kicked', onKicked);
    return () => {
      meeting.participants.joined.off('kicked', onKicked);
    };
  }, [meeting, navigate, homePath]);

  // Participant kick action
  const handleKickParticipant = async (participantId: string, customParticipantId?: string, name?: string) => {
    if (!id) return;
    setKickConfirmId(participantId);
    setKickConfirmCustomId(customParticipantId);
    setKickConfirmName(name || 'this participant');
  };

  // Every kick path (our drawer AND the built-in RealtimeKit participants
  // menu) must reach the backend, otherwise no cooldown is recorded.
  useEffect(() => {
    if (!meeting) return;
    setKickMeetingId(runtimeIdRef.current || id || '');
    patchParticipantKick(meeting);
    const timer = window.setInterval(() => patchParticipantKick(meeting), 3000);
    return () => window.clearInterval(timer);
  }, [meeting, id]);

  // Single reporter for kick results: confirmKick and the patched SDK kick
  // both emit KICK_RESULT_EVENT so the admin always sees the outcome.
  useEffect(() => {
    const onKickResult = (event: Event) => {
      const detail = (event as CustomEvent<KickResult>).detail;
      if (!detail) return;
      if (!detail.ok) {
        addToast(detail.message || 'Gagal mengeluarkan peserta.', 'error');
        return;
      }
      const minutes = detail.cooldownMinutes ?? 0;
      if (minutes > 0 && !detail.cooldownRecorded) {
        addToast('Peserta dikeluarkan, tetapi jeda (cooldown) tidak tercatat.', 'error');
      } else if (minutes > 0) {
        addToast(`Peserta dikeluarkan. Jeda join ulang ${minutes} menit aktif.`, 'success');
      } else {
        addToast('Peserta dikeluarkan.', 'success');
      }
    };
    window.addEventListener(KICK_RESULT_EVENT, onKickResult);
    return () => window.removeEventListener(KICK_RESULT_EVENT, onKickResult);
  }, [addToast]);

  const confirmKick = async () => {
    if (!kickConfirmId || !id) return;
    const participantId = kickConfirmId;
    const customParticipantId = kickConfirmCustomId;
    setKickConfirmId(null);
    setKickConfirmCustomId(undefined);
    setKickConfirmName('');

    setKickLoadingId(participantId);
    try {
      // Resolve the member's persistent id (used by the rejoin-cooldown gate).
      // Sources: participants list payload, then the live SDK participant.
      const allParticipants = meeting?.participants?.joined?.toArray() ?? [];
      const lookupId = customParticipantId || participantId;
      const sdkParticipant = allParticipants.find(
        (p) => p.customParticipantId === lookupId || p.id === lookupId
      );
      const userCustomId =
        (customParticipantId && customParticipantId.trim()) ||
        (sdkParticipant?.customParticipantId ? sdkParticipant.customParticipantId : '');

      // 1. Backend FIRST: removes the participant from the provider session AND
      //    records the rejoin cooldown. Outcome is announced through
      //    KICK_RESULT_EVENT (toast) by kickViaBackend itself.
      const result = await kickViaBackend(participantId, userCustomId);

      // 2. Realtime teardown via the SDK. The kick is patched, so it skips the
      //    backend call that just ran and only does the WebRTC removal.
      let sdkKicked = false;
      if (sdkParticipant && typeof sdkParticipant.kick === 'function') {
        try {
          await sdkParticipant.kick();
          sdkKicked = true;
        } catch {
          /* already removed by the backend */
        }
      }

      // 3. Update the list only if something actually removed the participant.
      if (result.ok || sdkKicked) {
        setParticipantsList(prev => prev.filter(p => p.id !== participantId));
      }
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Error kicking participant', 'error');
    } finally {
      setKickLoadingId(null);
    }
  };

  const myUserId = useMemo(() => getPersistentUserId(), []);

  // Screen share detection (official RealtimeKit SDK events)
  const screenShare = useScreenShare(meeting);

  const sendAnnotMessage = useCallback(
    (type: string, payload: Record<string, string | number | boolean>) => {
      // Same ordered, rate-limited transport as AnnotationStage so annotation
      // session messages share (and stay within) RTK's 5 broadcasts/sec.
      enqueueAnnotBroadcast(meeting, type, payload);
    },
    [meeting]
  );

  // Host/participant starts an annotation session bound to the active screen sharer
  const handleStartAnnotation = useCallback(() => {
    if (annotationSession || screenShare.sharers.length === 0) return;
    const selfSharer = screenShare.sharers.find((s) => s.id === meeting?.self?.id);
    const target = selfSharer ?? screenShare.sharers[0];
    if (!target) return;
    const info: AnnotationSessionInfo = {
      sessionId: newAnnotationSessionId(),
      sharerId: target.id,
      starterUserId: myUserId,
    };
    setAnnotationSession(info);
    sendAnnotMessage(ANNOT_SESSION_START, {
      userId: myUserId,
      sessionId: info.sessionId,
      sharerId: info.sharerId,
    });
  }, [annotationSession, screenShare.sharers, meeting?.self?.id, myUserId, sendAnnotMessage]);

  const handleStopAnnotation = useCallback(() => {
    if (!annotationSession) return;
    const sid = annotationSession.sessionId;
    setAnnotationSession(null);
    sendAnnotMessage(ANNOT_SESSION_END, {
      userId: myUserId,
      sessionId: sid,
    });
  }, [annotationSession, myUserId, sendAnnotMessage]);

  const handleToggleAnnotation = useCallback(
    async (allowed: boolean) => {
      setAllowMemberAnnotation(allowed);
      sendAnnotMessage('ANNOT_PERMISSION_UPDATE', { userId: myUserId, allowMemberAnnotation: allowed });
      if (id) {
        try {
          await fetch(`/api/meetings/${runtimeIdRef.current || id}/annotation`, {
            method: 'PATCH',
            headers: { 'content-type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ allow_member_annotation: allowed }),
          });
        } catch {
          /* best-effort */
        }
      }
    },
    [id, myUserId, sendAnnotMessage]
  );

  const handleToggleWhiteboard = useCallback(
    async (allowed: boolean) => {
      setAllowMemberWhiteboard(allowed);
      sendAnnotMessage('WB_PERMISSION_UPDATE', { userId: myUserId, allowMemberWhiteboard: allowed });
      if (id) {
        try {
          await fetch(`/api/meetings/${runtimeIdRef.current || id}`, {
            method: 'PATCH',
            headers: { 'content-type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ allow_member_whiteboard: allowed }),
          });
        } catch {
          /* best-effort */
        }
      }
    },
    [id, myUserId, sendAnnotMessage]
  );

  // Discover pre-existing annotation session right after joining
  useEffect(() => {
    if (!meeting?.self?.roomJoined) return;
    if (annotationRequestedRef.current) return;
    annotationRequestedRef.current = true;
    const t = window.setTimeout(() => {
      sendAnnotMessage(ANNOT_STATE_REQUEST, { userId: myUserId });
    }, 800);
    return () => window.clearTimeout(t);
  }, [meeting?.self?.roomJoined, myUserId, sendAnnotMessage]);

  // Auto-close annotation stage if screen sharing completely stops
  useEffect(() => {
    if (!annotationSession) return;
    const stillSharing = screenShare.sharers.some((s) => s.id === annotationSession.sharerId);
    if (!stillSharing && screenShare.sharers.length === 0) {
      setAnnotationSession(null);
    }
  }, [annotationSession, screenShare.sharers]);

  // Resolve bound sharer object + display name for AnnotationStage
  const annotationSharer = useMemo(() => {
    if (!annotationSession) return null;
    return screenShare.sharers.find((s) => s.id === annotationSession.sharerId) ?? null;
  }, [annotationSession, screenShare.sharers]);

  const annotationSharerName = useMemo(() => {
    if (!annotationSession) return '';
    if (annotationSharer && annotationSharer.id === meeting?.self?.id) {
      return user?.name || user?.username || 'You';
    }
    const fromList = participantsList.find(
      (p) => p.id === annotationSession.sharerId || p.custom_participant_id === annotationSession.sharerId
    );
    return fromList?.name || 'Screen share';
  }, [annotationSession, annotationSharer, participantsList, meeting, user]);

  // Participant rename sync & Annotation / Whiteboard session messaging
  useEffect(() => {
    if (!meeting?.participants?.on || !meeting?.participants?.off) return;
    const onMessage = (event: { type?: string; payload?: Record<string, unknown> }) => {
      if (event?.type === 'MEMBER_RENAME') {
        const p = event.payload ?? {};
        const pid = typeof p.participantId === 'string' ? p.participantId : null;
        const newName = typeof p.name === 'string' ? p.name : null;
        if (pid && newName) {
          try {
            const sdkParticipant = meeting.participants.joined.get(pid);
            if (sdkParticipant) {
              sdkParticipant.name = newName;
            }
          } catch { /* ignore */ }
          localNameOverridesRef.current.set(pid, newName);
          setParticipantsList(prev => prev.map(m => (m.id === pid ? { ...m, name: newName } : m)));
          setRenameVersion(v => v + 1);
        }
      } else if (event?.type === ANNOT_SESSION_START) {
        const p = event.payload ?? {};
        const from = typeof p.userId === 'string' ? p.userId : '';
        if (from === myUserId) return;
        if (typeof p.sessionId === 'string' && typeof p.sharerId === 'string') {
          setAnnotationSession({
            sessionId: p.sessionId,
            sharerId: p.sharerId,
            starterUserId: from,
          });
        }
      } else if (event?.type === ANNOT_SESSION_END) {
        const p = event.payload ?? {};
        const from = typeof p.userId === 'string' ? p.userId : '';
        if (from === myUserId) return;
        setAnnotationSession((curr) => {
          if (!curr || curr.sessionId === p.sessionId) return null;
          return curr;
        });
      } else if (event?.type === ANNOT_STATE_REQUEST) {
        if (isHost && annotationSession) {
          sendAnnotMessage(ANNOT_SESSION_START, {
            userId: myUserId,
            sessionId: annotationSession.sessionId,
            sharerId: annotationSession.sharerId,
          });
        }
      } else if (event?.type === 'ANNOT_PERMISSION_UPDATE') {
        const p = event.payload ?? {};
        if (typeof p.allowMemberAnnotation === 'boolean') {
          setAllowMemberAnnotation(p.allowMemberAnnotation);
        }
      } else if (event?.type === 'WB_PERMISSION_UPDATE') {
        const p = event.payload ?? {};
        if (typeof p.allowMemberWhiteboard === 'boolean') {
          setAllowMemberWhiteboard(p.allowMemberWhiteboard);
        }
      } else if (event?.type === CAMERA_CAP_MESSAGE) {
        const p = event.payload ?? {};
        const ids = typeof p.ids === 'string' ? p.ids.split(',') : [];
        const selfId = meeting?.self?.id;
        if (selfId && ids.includes(selfId)) {
          const limit = Number(p.limit) || 0;
          showMediaError(
            p.blocked === true
              ? `Kamera Anda dibatasi host: maks ${limit} kamera boleh menyala serentak.`
              : 'Slot kamera sudah kosong — kamera Anda boleh dinyalakan kembali.'
          );
        }
      }
    };
    meeting.participants.on('broadcastedMessage', onMessage);
    return () => {
      meeting.participants.off('broadcastedMessage', onMessage);
    };
  }, [meeting, myUserId, isHost, annotationSession, sendAnnotMessage, showMediaError]);

  const meetingCode = meetingPublicId || id || '';
  const meetingLink = meetingCode ? `${window.location.origin}/meeting/${meetingCode}` : '';

  const handleCopyText = useCallback(async (key: string, text: string) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); } catch { /* ignore */ }
      document.body.removeChild(ta);
    }
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey(prev => (prev === key ? null : prev)), 2000);
  }, []);

  const handleRenameMember = useCallback(async () => {
    if (!id || !renameMember) return;
    const trimmed = memberRenameName.trim();
    if (!trimmed) return;
    setMemberRenameLoading(true);
    setMemberRenameError(null);
    try {
      const res = await fetch(`/api/meetings/${runtimeIdRef.current || id}/participants/${encodeURIComponent(renameMember.participantId)}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ name: trimmed, customParticipantId: renameMember.custom_participant_id })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || data.error || 'Gagal mengubah nama peserta.');
      setParticipantsList(prev => prev.map(m => (m.id === renameMember.participantId ? { ...m, name: trimmed } : m)));
      setRenameMember(null);
      try {
        void meeting?.participants?.broadcastMessage?.('MEMBER_RENAME', {
          participantId: renameMember.participantId,
          name: trimmed
        });
      } catch { /* socket not ready — local state already updated */ }
      // Force RtkMeeting re-render so rtk-name-tag picks up the new name
      setRenameVersion(v => v + 1);
      addToast(`Nama peserta diubah menjadi "${trimmed}"`, 'success');
    } catch (err) {
      setMemberRenameError(err instanceof Error ? err.message : 'Gagal mengubah nama peserta.');
    } finally {
      setMemberRenameLoading(false);
    }
  }, [id, renameMember, memberRenameName, meeting, addToast]);

  // Self-rename handler (members, guests, or admin renaming themselves inside meeting)
  const handleSelfRename = useCallback(async () => {
    const trimmed = selfRenameName.trim();
    if (!trimmed) {
      setSelfRenameError('Nama tidak boleh kosong.');
      return;
    }
    setSelfRenameLoading(true);
    setSelfRenameError(null);
    try {
      // 1. Update RTK SDK Self directly (realtime local & peer update)
      if (meeting?.self && typeof meeting.self.setName === 'function') {
        try {
          meeting.self.setName(trimmed);
        } catch (err) {
          console.warn('meeting.self.setName error:', err);
        }
      }

      // 3. Persist locally for session restore & reload
      localStorage.setItem('learnly:name', trimmed);
      if (id) {
        setActiveMeetingSession(id, myUserId, trimmed);
      }

      const selfSdkId = meeting?.self?.id;

      // 4. Broadcast to other participants in the room
      if (selfSdkId) {
        try {
          void meeting?.participants?.broadcastMessage?.('MEMBER_RENAME', {
            participantId: selfSdkId,
            name: trimmed
          });
        } catch { /* ignore */ }
      }

      // 5. Update local participant list & save override for polling
      if (selfSdkId) {
        localNameOverridesRef.current.set(selfSdkId, trimmed);
        setParticipantsList(prev => prev.map(m => (m.id === selfSdkId || m.custom_participant_id === myUserId ? { ...m, name: trimmed } : m)));
      }

      // 6. Persist override in DB so new joiners / page reloads see the renamed name
      if (id) {
        void fetch(`/api/meetings/${runtimeIdRef.current || id}/participants/${encodeURIComponent(selfSdkId || myUserId)}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ name: trimmed, customParticipantId: myUserId })
        }).catch(() => { /* non-blocking — local rename already applied */ });
      }

      // Force RtkMeeting re-render so rtk-name-tag picks up the new name
      setRenameVersion(v => v + 1);

      setShowSelfRenameModal(false);
      addToast(`Nama Anda berhasil diubah menjadi "${trimmed}"`, 'success');
    } catch (err) {
      setSelfRenameError(err instanceof Error ? err.message : 'Gagal mengubah nama.');
    } finally {
      setSelfRenameLoading(false);
    }
  }, [selfRenameName, meeting, id, myUserId, addToast]);

  return (
    <div id="realtimekit-integration-wrapper" className="w-screen h-screen relative bg-slate-950">
      {/* Top Overlay Badge: Duration, Whiteboard & Host Recording Controls */}
      <div className="absolute top-3 left-4 right-4 z-40 flex flex-wrap items-center gap-2 pointer-events-auto">
        {timeLeft && (
          <div className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-md border ${isNearExpired ? 'bg-red-950/90 text-red-300 border-red-700 animate-pulse' : 'bg-slate-900/90 text-slate-200 border-slate-700'}`}>
            <Clock className="w-3.5 h-3.5" />
            <span>Time Left: {timeLeft}</span>
            {isNearExpired && <AlertTriangle className="w-3.5 h-3.5 text-red-400" />}
          </div>
        )}

        {/* Shared Whiteboard button */}
        <Tooltip content="Open Whiteboard">
          <button
            onClick={() => setShowWhiteboard(true)}
            aria-label="Open Whiteboard"
            className="px-3 py-1.5 rounded-md text-xs font-semibold bg-slate-900/90 text-slate-200 border border-slate-700 hover:bg-slate-800 shadow-md flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <PenTool className="w-3.5 h-3.5" />
          </button>
        </Tooltip>

        {/* Share Screen cadangan — hanya host; hanya saat wrapper native (WebView)
            menyuntikkan bridge MediaProjection/ReplayKit; desktop/mobile web
            memakai jalur lain. */}
        {shareSupport.mode === 'native' && isHost && (
          <Tooltip content={nativeShareActive ? 'Stop Screen Share' : (!shareConnection.canStartShare ? (shareConnection.blockedReason ?? 'Koneksi terputus') : 'Share Screen (perangkat ini)')}>
            <button
              onClick={handleShareFallbackClick}
              // Issue #82: nonaktifkan tombol saat ingin memulai share tapi
              // koneksi RTK belum sehat. Stop selalu diizinkan agar sesi bisa
              // dibersihkan.
              disabled={!nativeShareActive && !shareConnection.canStartShare}
              aria-label={nativeShareActive ? 'Stop Screen Share' : 'Share Screen'}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold shadow-md flex items-center gap-1.5 transition-colors cursor-pointer border ${
                nativeShareActive
                  ? 'bg-red-900/90 text-red-200 border-red-600'
                  : !shareConnection.canStartShare
                    ? 'bg-slate-800/60 text-slate-500 border-slate-700 cursor-not-allowed'
                    : 'bg-slate-900/90 text-slate-200 border-slate-700 hover:bg-slate-800'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>{nativeShareActive ? 'Stop Share' : 'Share'}</span>
            </button>
          </Tooltip>
        )}

        {/* Screen Share Annotation button — active when anyone is sharing screen */}
        {screenShare.active && (
          <Tooltip content={annotationSession ? 'Annotating…' : 'Annotate Screen Share'}>
            <button
              onClick={handleStartAnnotation}
              aria-label={annotationSession ? 'Annotating…' : 'Annotate Screen Share'}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold shadow-md flex items-center gap-1.5 transition-colors cursor-pointer border ${
                annotationSession
                  ? 'bg-emerald-900/90 text-emerald-200 border-emerald-600'
                  : 'bg-slate-900/90 text-slate-200 border-slate-700 hover:bg-slate-800'
              }`}
            >
              <Pen className="w-3.5 h-3.5" />
            </button>
          </Tooltip>
        )}

        {/* Self Rename button — for member, guest, and admin inside meeting */}
        <Tooltip content="Rename Yourself">
          <button
            onClick={() => {
              const selfId = meeting?.self?.id;
              const fromList = participantsList.find(p => p.id === selfId || p.custom_participant_id === myUserId);
              const overrideName = selfId ? localNameOverridesRef.current.get(selfId) : null;
              const currentName = overrideName || fromList?.name || localStorage.getItem('learnly:name') || user?.name || '';
              setSelfRenameName(currentName);
              setSelfRenameError(null);
              setShowSelfRenameModal(true);
            }}
            aria-label="Rename Yourself"
            className="px-3 py-1.5 rounded-md text-xs font-semibold bg-slate-900/90 text-slate-200 border border-slate-700 hover:bg-slate-800 shadow-md flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <UserPen className="w-3.5 h-3.5 text-emerald-400" />
          </button>
        </Tooltip>

        {/* Admin: share meeting link + class code */}
        {isAdmin && (
          <Tooltip content="Share Meeting Link">
            <button
              onClick={() => setShowShareModal(true)}
              aria-label="Share Meeting Link"
              className="px-3 py-1.5 rounded-md text-xs font-semibold bg-slate-900/90 text-slate-200 border border-slate-700 hover:bg-slate-800 shadow-md flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
          </Tooltip>
        )}

        {/* Recording Indicator — only for host/admin who can start recording */}
        {isAdmin && isRecordingActive && !isRecordingPaused && (
          <div className="px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-md border bg-red-950/90 text-red-300 border-red-700 animate-pulse">
            <Circle className="w-3 h-3 fill-red-500 text-red-500" />
            <span>REC {recordingElapsed}</span>
          </div>
        )}

        {/* Paused indicator — timer berhenti, tandanya tidak berkedip */}
        {isAdmin && isRecordingPaused && (
          <div className="px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-md border bg-amber-950/90 text-amber-300 border-amber-700">
            <Circle className="w-3 h-3 fill-amber-500 text-amber-500" />
            <span>PAUSED {recordingElapsed}</span>
          </div>
        )}

        {isAdmin && isRecordingStopping && (
          <div className="px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-md border bg-amber-950/90 text-amber-300 border-amber-700">
            <Circle className="w-3 h-3 fill-amber-500 text-amber-500" />
            <span>Stopping recording...</span>
          </div>
        )}

        {isAdmin && isRecordingUploading && (
          <div className="px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-md border bg-slate-900/90 text-emerald-300 border-emerald-700">
            <Circle className="w-3 h-3 fill-emerald-500 text-emerald-500" />
            <span>Uploading... {Math.max(uploadProgress, 1)}%</span>
          </div>
        )}


      </div>

      {/* Host Controls Drawer */}
      {isAdmin && showHostTools && (
        <div className="absolute top-24 sm:top-12 left-4 z-50 w-80 max-w-[calc(100vw-2rem)] bg-slate-900/95 border-2 border-slate-700 p-4 shadow-2xl backdrop-blur-md rounded-lg text-slate-100">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h4 className="text-sm font-bold flex items-center gap-1.5 text-emerald-400">
              <Users className="w-4 h-4" />
              Manage Participants
            </h4>
            <button
              onClick={() => setShowHostTools(false)}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3 space-y-2 max-h-72 overflow-y-auto pr-1">
            {participantsError && (
              <div className="mb-2 flex items-start gap-1.5 rounded border border-amber-800 bg-amber-950/70 px-2 py-1.5 text-[10px] text-amber-300">
                <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0" />
                <span>Participant list unreliable: {participantsError}</span>
              </div>
            )}
            {participantsList.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No other participants detected.</p>
            ) : (
              participantsList.filter((p) => p.custom_participant_id !== meeting?.self?.customParticipantId).map((p) => {
                const rowPeer = meeting?.participants?.joined?.get(p.id);
                const rowIsHost = isHostPeer(rowPeer);
                return (
                <div key={p.id} className="p-2 bg-slate-800/80 border border-slate-700/80 rounded text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="truncate mr-2">
                      <p className="flex min-w-0 items-center gap-1.5 font-medium text-slate-200">
                        <span className="truncate">{p.name || 'Participant'}</span>
                        {rowIsHost && (
                          <span className="inline-flex shrink-0 items-center rounded-full bg-emerald-500 px-[5px] text-[9px] font-bold leading-[1.6] tracking-[0.04em] text-white pointer-events-none select-none">
                            HOST
                          </span>
                        )}
                      </p>
                      <p className="text-[10px] text-slate-400 font-mono truncate">ID: {p.id.slice(0, 8)}...</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => { setRenameMember({ participantId: p.id, custom_participant_id: p.custom_participant_id || '', name: p.name || '' }); setMemberRenameName(p.name || ''); setMemberRenameError(null); }}
                        title="Ubah nama peserta"
                        className="p-1.5 border border-slate-600 hover:bg-slate-700 text-slate-400 hover:text-slate-100 rounded cursor-pointer transition-colors"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleKickParticipant(p.id, p.custom_participant_id, p.name || 'Participant')}
                        disabled={kickLoadingId === p.id}
                        title="Kick participant out of meeting"
                        className="px-2 py-1 bg-red-950/80 hover:bg-red-900 border border-red-800 text-red-300 rounded font-medium inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <UserX className="w-3 h-3" />
                        {kickLoadingId === p.id ? 'Kicking...' : 'Remove'}
                      </button>
                    </div>
                  </div>
                </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Shared Whiteboard overlay (realtime synced via RealtimeKit messaging) */}
      <Whiteboard
        meeting={meeting ?? null}
        open={showWhiteboard}
        onClose={() => setShowWhiteboard(false)}
        myUserId={myUserId}
        isHost={isHost}
        canDraw={isHost || allowMemberWhiteboard}
        allowMemberWhiteboard={allowMemberWhiteboard}
        onToggleWhiteboard={handleToggleWhiteboard}
      />

      {/* Screen Share Annotation stage (Zoom-like realtime annotation over live screen share) */}
      {meeting && annotationSession && (
        <AnnotationStage
          key={annotationSession.sessionId}
          meeting={meeting}
          session={annotationSession}
          sharer={annotationSharer}
          sharerName={annotationSharerName}
          onStop={handleStopAnnotation}
          onClose={() => setAnnotationSession(null)}
          myUserId={myUserId}
          isHost={isHost}
          canDraw={isHost || allowMemberAnnotation}
          allowMemberAnnotation={allowMemberAnnotation}
          onToggleAnnotation={handleToggleAnnotation}
        />
      )}

      {meeting ? (
        <RtkMeeting meeting={meeting} config={customConfig} key={renameVersion} />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-slate-950">
          <div className="text-center space-y-3">
            <div className="w-8 h-8 border-4 border-slate-600 border-t-emerald-500 rounded-full animate-spin mx-auto"></div>
            <p className="text-slate-400 text-sm">Connecting to meeting...</p>
          </div>
        </div>
      )}

      {/* Host join code — hanya untuk nama terdaftar sebagai tentor */}
      {showHostCodeGate && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-sm w-full text-center shadow-2xl rounded-lg">
            <KeyRound className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
            <h2 className="text-slate-100 font-semibold text-lg mb-1">Kode Host</h2>
            <p className="text-slate-400 text-xs mb-4">Nama Anda terdaftar sebagai tentor. Masukkan kode host untuk masuk sebagai host.</p>
            <input
              value={gateHostCode}
              onChange={(e) => { setGateHostCode(e.target.value.replace(/\D/g, '').slice(0, 10)); setGateHostCodeError(null); }}
              onKeyDown={(e) => { if (e.key === 'Enter') handleHostCodeSubmit(); }}
              inputMode="numeric"
              autoComplete="off"
              placeholder="Contoh: 123456"
              autoFocus
              className="w-full px-3 py-2 mb-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-600 text-sm text-center tracking-widest"
            />
            {gateHostCodeError && <div className="text-red-400 text-xs mb-2 text-left">{gateHostCodeError}</div>}
            <button
              onClick={handleHostCodeSubmit}
              disabled={!gateHostCode.trim() || gateHostCodeLoading}
              className="w-full accent-btn border-2 font-medium px-4 py-2 text-sm disabled:opacity-50 cursor-pointer transition-all mb-2"
            >
              {gateHostCodeLoading ? 'Memeriksa...' : 'Masuk sebagai Host'}
            </button>
            <button
              onClick={() => { sessionStorage.removeItem(`rtk:hostcode:${id}`); sessionStorage.setItem(`rtk:hostmember:${id}`, '1'); setShowHostCodeGate(false); window.location.reload(); }}
              className="w-full text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
            >
              Masuk sebagai peserta biasa
            </button>
          </div>
        </div>
      )}

      {/* Name Gate — members must fill in a display name before entering */}
      {showNameGate && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-sm w-full text-center shadow-2xl rounded-lg">
            <UserIcon className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
            <h2 className="text-slate-100 font-semibold text-lg mb-1">Masukkan Nama Anda</h2>
            <p className="text-slate-400 text-xs mb-4">Nama wajib diisi sebelum masuk meeting.</p>
            <input
              value={gateName}
              onChange={(e) => setGateName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && gateName.trim()) handleGateSubmit(); }}
              placeholder="Nama Anda"
              autoFocus
              className="w-full px-3 py-2 mb-4 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-600 text-sm"
            />
            <button
              onClick={handleGateSubmit}
              disabled={!gateName.trim()}
              className="w-full accent-btn border-2 font-medium px-4 py-2 text-sm disabled:opacity-50 cursor-pointer transition-all"
            >
              Masuk Meeting
            </button>
          </div>
        </div>
      )}

      {/* Uploading overlay — rekaman sedang dikirim ke cloud */}
      {isRecordingUploading && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-sm w-full text-center shadow-2xl rounded-lg">
            <div className="w-8 h-8 border-4 border-slate-600 border-t-emerald-500 rounded-full animate-spin mx-auto mb-3"></div>
            <p className="text-slate-100 font-semibold text-sm mb-1">Mengunggah rekaman...</p>
            <p className="text-slate-400 text-xs mb-3">{Math.max(uploadProgress, 1)}%</p>
            <div className="h-2 w-full bg-slate-800 rounded overflow-hidden">
              <div
                className="h-full bg-emerald-500 transition-all"
                style={{ width: `${Math.max(uploadProgress, 1)}%` }}
              ></div>
            </div>
          </div>
        </div>
      )}

      {/* Media permission error banner */}
      {mediaError && (
        <div className="absolute top-16 left-4 right-4 z-50 pointer-events-none">
          <div className="bg-red-950/95 border border-red-700 px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 backdrop-blur-sm max-w-md mx-auto w-full">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <p className="text-red-200 text-xs font-medium">{mediaError}</p>
          </div>
        </div>
      )}

      {/* Info: screen share tidak didukung browser HP/tablet (RTK menyembunyikan
          tombolnya) — hanya relevan untuk host, karena member tidak punya akses
          Share Screen. */}
      <ShareScreenNotice
        show={!!meeting && isHost}
        mediaError={!!mediaError}
        dismissed={shareNoticeDismissed}
        onDismiss={() => setShareNoticeDismissed(true)}
      />

      {/* Expiry Banner */}
      {expiryMessage && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-black/60 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-red-700 p-6 max-w-sm w-full text-center shadow-2xl rounded-lg">
            <AlertTriangle className="w-8 h-8 text-red-400 mx-auto mb-3" />
            <p className="text-red-300 font-semibold text-sm">{expiryMessage}</p>
            <p className="text-slate-400 text-xs mt-2">Returning to home in a few seconds...</p>
          </div>
        </div>
      )}

      {/* Self Rename Modal — available for members, guests, and admin */}
      {showSelfRenameModal && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-sm w-full shadow-2xl rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-slate-100 font-semibold text-lg flex items-center gap-2">
                <UserPen className="w-4 h-4 text-emerald-400" />
                Ubah Nama Anda
              </h2>
              <button
                onClick={() => setShowSelfRenameModal(false)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-400 text-xs mb-3">
              Masukkan nama baru yang akan tampil kepada seluruh peserta di dalam meeting.
            </p>
            <input
              value={selfRenameName}
              onChange={(e) => setSelfRenameName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && selfRenameName.trim() && !selfRenameLoading) handleSelfRename(); }}
              placeholder="Nama Anda"
              maxLength={80}
              autoFocus
              className="w-full px-3 py-2 mb-3 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-600 text-sm rounded"
            />
            {selfRenameError && <p className="text-xs text-red-300 mb-3">{selfRenameError}</p>}
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowSelfRenameModal(false)}
                className="px-3 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm rounded cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleSelfRename}
                disabled={selfRenameLoading || !selfRenameName.trim()}
                className="px-3 py-2 accent-btn border-2 font-medium text-sm rounded disabled:opacity-50 cursor-pointer"
              >
                {selfRenameLoading ? 'Menyimpan...' : 'Simpan'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rename Member Modal — admin only */}
      {isAdmin && renameMember && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-sm w-full shadow-2xl rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-slate-100 font-semibold text-lg flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-emerald-400" />
                Ubah Nama Peserta
              </h2>
              <button
                onClick={() => setRenameMember(null)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-400 text-xs mb-3">
              Mengubah nama <code className="text-emerald-300 font-mono">{renameMember.name || 'peserta'}</code> akan berlaku untuk semua peserta.
            </p>
            <input
              value={memberRenameName}
              onChange={(e) => setMemberRenameName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && memberRenameName.trim() && !memberRenameLoading) handleRenameMember(); }}
              placeholder="Nama baru peserta"
              maxLength={80}
              autoFocus
              className="w-full px-3 py-2 mb-3 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-600 text-sm rounded"
            />
            {memberRenameError && <p className="text-xs text-red-300 mb-3">{memberRenameError}</p>}
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setRenameMember(null)}
                className="px-3 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm rounded cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleRenameMember}
                disabled={memberRenameLoading || !memberRenameName.trim()}
                className="px-3 py-2 accent-btn border-2 font-medium text-sm rounded disabled:opacity-50 cursor-pointer"
              >
                {memberRenameLoading ? 'Menyimpan...' : 'Simpan'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Meeting Modal — admin only: link + class code, one-click copy */}
      {isAdmin && showShareModal && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-slate-700 p-6 max-w-md w-full shadow-2xl rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-slate-100 font-semibold text-lg flex items-center gap-2">
                <Share2 className="w-4 h-4 text-emerald-400" />
                Bagikan Meeting
              </h2>
              <button
                onClick={() => setShowShareModal(false)}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-400 text-xs mb-4">
              Bagikan link meeting dan kode kelas berikut. Klik tombol Salin untuk menyalin.
            </p>

            <label className="block text-xs font-semibold text-slate-300 mb-1">Link Meeting</label>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex-1 flex items-center gap-2 min-w-0 px-3 py-2 border-2 border-slate-700 bg-slate-800 rounded">
                <Link2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="text-slate-100 text-xs font-mono truncate">{meetingLink || 'Link tidak tersedia'}</span>
              </div>
              <button
                onClick={() => handleCopyText('link', meetingLink)}
                disabled={!meetingLink}
                className="px-3 py-2 accent-btn border-2 font-medium text-xs inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer shrink-0 rounded"
              >
                {copiedKey === 'link' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'link' ? 'Tersalin' : 'Salin'}
              </button>
            </div>

            <label className="block text-xs font-semibold text-slate-300 mb-1">Kode Kelas</label>
            <div className="flex items-center gap-2 mb-5">
              <div className="flex-1 px-3 py-2 border-2 border-slate-700 bg-slate-800 rounded min-w-0">
                <span className="text-emerald-300 text-sm font-mono tracking-wider truncate block">{meetingCode || 'Kode tidak tersedia'}</span>
              </div>
              <button
                onClick={() => handleCopyText('code', meetingCode)}
                disabled={!meetingCode}
                className="px-3 py-2 accent-btn border-2 font-medium text-xs inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer shrink-0 rounded"
              >
                {copiedKey === 'code' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'code' ? 'Tersalin' : 'Salin'}
              </button>
            </div>

            <button
              onClick={() => handleCopyText('all', `Link Meeting: ${meetingLink}\nKode Kelas: ${meetingCode}`)}
              disabled={!meetingLink && !meetingCode}
              className="w-full py-2 accent-btn border-2 font-medium text-sm inline-flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer rounded"
            >
              {copiedKey === 'all' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copiedKey === 'all' ? 'Tersalin!' : 'Salin Semua'}
            </button>
          </div>
        </div>
      )}

      {/* Kick Confirm Dialog */}
      <ConfirmDialog
        open={!!kickConfirmId}
        onClose={() => { setKickConfirmId(null); setKickConfirmCustomId(undefined); setKickConfirmName(''); }}
        onConfirm={confirmKick}
        title="Remove Participant?"
        message={`Are you sure you want to remove "${kickConfirmName}" from this meeting?`}
        confirmLabel="Remove"
        cancelLabel="Cancel"
        variant="danger"
      />

      {/* Auto Recording Failure / Disconnect Modal Alert */}
      {recordingFailureAlert.isOpen && (
        <div className="absolute inset-0 z-60 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-auto p-3 sm:p-4">
          <div className="bg-slate-900 border-2 border-amber-600/50 p-6 max-w-md w-full shadow-2xl rounded-lg">
            <div className="flex items-start gap-3 mb-4">
              <div className="p-2 rounded-full bg-amber-500/20 text-amber-400 shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-slate-100 font-semibold text-base">
                  Rekaman Otomatis Berhenti
                </h2>
                <p className="text-slate-300 text-xs mt-1">
                  {recordingFailureAlert.reason}
                </p>
              </div>
              <button
                onClick={() => setRecordingFailureAlert({ isOpen: false, reason: '' })}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="bg-slate-800/80 rounded p-3 text-xs text-slate-400 mb-4 border border-slate-700/50">
              <p>
                Bagian rekaman yang sudah berlangsung tersimpan di VPS. Anda dapat mengambil alih dan merekam sisa meeting secara manual.
              </p>
            </div>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setRecordingFailureAlert({ isOpen: false, reason: '' })}
                className="px-3 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded cursor-pointer transition-colors"
              >
                Tutup
              </button>
              {canRecord && (
                <button
                  onClick={() => {
                    setRecordingFailureAlert({ isOpen: false, reason: '' });
                    void confirmStartRecording();
                  }}
                  className="px-3 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-medium rounded inline-flex items-center gap-1.5 cursor-pointer transition-colors shadow-lg shadow-red-950/30"
                >
                  <Circle className="w-3 h-3 fill-white" />
                  Rekam Manual
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
