import { useCallback, useEffect, useRef, useState } from 'react';
import type { Meeting } from '@cloudflare/realtimekit-react-ui';
import {
  deletePendingRecording,
  patchPendingRecording,
  savePendingRecording,
} from '../../../shared/utils/pendingUploads';
import { fileExtensionFor, uploadRecordingBlob } from '../../../shared/utils/recordingUpload';

// Rekaman berjalan sepenuhnya di sisi client TANPA getDisplayMedia/dialog
// share-screen. Tampilan meeting (kamera peserta + layar yang dibagikan bila
// ada) dirender ulang ke <canvas> lewat track milik RealtimeKit, audio room
// (mikrofon semua peserta + audio screenshare) di-mix lewat AudioContext, lalu
// keduanya di-encode MediaRecorder dan diunggah lewat pipeline tahan-gagal
// (shared/utils/recordingUpload.ts: file kecil satu request, file besar
// chunked + R2 multipart, retry per tahap).
// Keuntungannya: host cukup klik "Start Recording" — tidak perlu memilih
// layar, dan rekaman tetap ada walau tidak seorang pun share screen.
// Tidak ada RealtimeKit Cloud Export sama sekali (biaya $0).
//
// Anti-hilang: sebelum unggahan dimulai, file ditulis ke IndexedDB dan hanya
// dihapus setelah server mengonfirmasi sukses. Tab tertutup / jaringan putus /
// unggahan gagal TIDAK menghapus rekaman — selalu ada cadangan yang bisa
// dikirim ulang dari dashboard admin (menu Rekaman). Selama unggahan berjalan,
// browser juga memperingatkan sebelum tab ditutup.

export type ClientRecordingState =
  | 'IDLE'
  | 'STARTING'
  | 'RECORDING'
  | 'PAUSED'
  | 'STOPPING'
  | 'UPLOADING'
  | 'ERROR';
export type RecordingResolution = '720p' | '480p';

export interface StartRecordingOptions {
  /** id meeting (uuid atau public_id) — divalidasi backend saat unggah. */
  meetingId: string;
  resolution: RecordingResolution;
  /** Token unggah host dari response /api/tokens (hanya host yang punya). */
  uploadToken?: string | null;
}

interface ResolutionPreset {
  width: number;
  height: number;
  videoBitsPerSecond: number;
}

const RESOLUTION_PRESETS: Record<RecordingResolution, ResolutionPreset> = {
  '720p': { width: 1280, height: 720, videoBitsPerSecond: 2_000_000 },
  '480p': { width: 854, height: 480, videoBitsPerSecond: 800_000 },
};

// Buffer chunk tiap 2 detik — mencegah lonjakan RAM untuk rekaman panjang.
const CHUNK_INTERVAL_MS = 2000;
// Pindel (audio + komposisi video) tiap 2 detik — peserta baru, kamera
// dinyalakan/dimatikan, dan screenshare mulai/berhenti ikut terekam otomatis.
const SCAN_MS = 2000;
const MIME_CANDIDATES = [
  'video/mp4;codecs=avc1,mp4a.40.2',
  'video/mp4;codecs=avc1',
  'video/mp4',
  'video/webm;codecs=vp9,opus',
  'video/webm;codecs=vp8,opus',
  'video/webm',
];
// Frame rate canvas hasil rekaman + ritme menggambar.
const CANVAS_FPS = 25;
const DRAW_INTERVAL_MS = 1000 / CANVAS_FPS;
// AudioContext.resume() bisa menggantung tanpa gesture user (mis. auto-record
// dari timer) — dibatasi race ini, kalau tetap tidak running rekaman jalan
// video-only (track audio dari context mati justru membuat file 0 byte).
const RESUME_TIMEOUT_MS = 1200;
// Batas tile yang digambar — peserta di luar batas dihitung sebagai overlay.
const MAX_TILES = 24;

const CANVAS_BG = '#0d1117';
const TILE_BG = '#161b22';
const TILE_TEXT = '#ffffff';
const TILE_MUTED_TEXT = '#8b949e';

// Struktur minimal participant RealtimeKit yang kita pakai (dibaca lewat
// getter resmi SDK: videoTrack / audioTrack / screenShareTracks).
interface RtkParticipantLike {
  id?: string;
  name?: string;
  videoTrack?: unknown;
  audioTrack?: unknown;
  screenShareEnabled?: boolean;
  screenShareTracks?: { video?: unknown; audio?: unknown };
}

interface CompositionTile {
  label: string;
  /** null = peserta tanpa kamera (placeholder nama). */
  element: HTMLVideoElement | null;
  /** true untuk layar yang dibagikan — digambar besar sebagai konten utama. */
  main: boolean;
}

function asLiveTrack(value: unknown): MediaStreamTrack | null {
  if (!(value instanceof MediaStreamTrack)) return null;
  if (value.readyState !== 'live' || value.muted) return null;
  return value;
}

// Self dulu (posisi stabil), lalu peserta lain sesuai urutan joined.
function collectParticipants(meeting: Meeting | null | undefined): RtkParticipantLike[] {
  const out: RtkParticipantLike[] = [];
  const seen = new Set<string>();
  const push = (candidate: unknown) => {
    const p = candidate as RtkParticipantLike | null | undefined;
    const id = typeof p?.id === 'string' ? p.id : null;
    if (!p || !id || seen.has(id)) return;
    seen.add(id);
    out.push(p);
  };
  try {
    const m = meeting as unknown as {
      self?: unknown;
      participants?: { joined?: { toArray?: () => unknown[]; values?: () => Iterable<unknown> } };
    } | null | undefined;
    push(m?.self);
    const joined = m?.participants?.joined;
    const list = joined?.toArray?.() ?? (joined?.values ? Array.from(joined.values()) : []);
    for (const peer of list) push(peer);
  } catch {
    /* SDK belum siap — tidak ada track untuk dikumpulkan */
  }
  return out;
}

// Audio yang masuk rekaman: mikrofon semua peserta + audio screenshare (bila
// ada yang membagikan layar dengan "share tab audio").
function collectRoomAudioTracks(meeting: Meeting | null | undefined): MediaStreamTrack[] {
  if (typeof MediaStreamTrack === 'undefined') return [];
  const tracks: MediaStreamTrack[] = [];
  const seen = new Set<string>();
  const add = (candidate: MediaStreamTrack | null) => {
    if (!candidate || seen.has(candidate.id)) return;
    seen.add(candidate.id);
    tracks.push(candidate);
  };
  for (const p of collectParticipants(meeting)) {
    add(asLiveTrack(p.audioTrack));
    if (p.screenShareEnabled) add(asLiveTrack(p.screenShareTracks?.audio));
  }
  return tracks;
}

// SELALU sambungkan minimal satu sumber senyap ke mixer. Penting: Chrome
// tidak menghasilkan frame audio (bahkan silence) untuk MediaStreamAudioDestin
// ationNode yang TIDAK punya input tersambung — MediaRecorder yang menerima
// track seperti itu menghasilkan file 0 byte, dan rekaman berakhir dengan
// error "tidak berisi data apa pun". Dengan sumber senyap, mixer tetap hidup;
// mikrofon peserta yang menyala belakangan tetap tercampur masuk oleh scan
// berkala (uji Chrome 155: dest kosong = 0 byte, dest + input gain 0 = data).
function connectSilentSource(context: AudioContext, destination: MediaStreamAudioDestinationNode): void {
  try {
    const osc = context.createOscillator();
    const gain = context.createGain();
    gain.gain.value = 0;
    osc.connect(gain).connect(destination);
    osc.start();
    return;
  } catch {
    /* fallback ke constant source di bawah */
  }
  try {
    const constant = context.createConstantSource();
    constant.offset.value = 0;
    constant.connect(destination);
    constant.start();
  } catch {
    /* kedua opsi gagal — rekaman tetap jalan tanpa audio */
  }
}

function pickMimeType(): string | undefined {
  if (typeof MediaRecorder === 'undefined') return undefined;
  return MIME_CANDIDATES.find((candidate) => {
    try {
      return MediaRecorder.isTypeSupported(candidate);
    } catch {
      return false;
    }
  });
}

// Emergency fallback: rekaman disimpan ke storage lokal browser agar tidak
// hilang ketika upload cloud gagal (offline / server down / tab ditutup).
function downloadLocally(blob: Blob): void {
  try {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `recording-${new Date().toISOString().replace(/[:.]/g, '-')}.${fileExtensionFor(blob)}`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  } catch {
    /* browser menolak download — data tetap di memori */
  }
}

// ---------------------------------------------------------------------------
// Kompositor canvas — menggambar tampilan meeting menjadi satu video.
// ---------------------------------------------------------------------------

function initialsOf(label: string): string {
  const parts = label.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): void {
  const radius = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(x, y, w, h, radius);
    return;
  }
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

// Gambar video dengan rasio asli (letterbox), pas di dalam kotak.
function drawContain(
  ctx: CanvasRenderingContext2D,
  el: HTMLVideoElement,
  x: number,
  y: number,
  w: number,
  h: number
): void {
  const vw = el.videoWidth;
  const vh = el.videoHeight;
  if (!vw || !vh) return;
  const scale = Math.min(w / vw, h / vh);
  const dw = vw * scale;
  const dh = vh * scale;
  try {
    ctx.drawImage(el, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  } catch {
    /* frame belum siap — biarkan latar tile */
  }
}

function drawTile(
  ctx: CanvasRenderingContext2D,
  tile: CompositionTile,
  x: number,
  y: number,
  w: number,
  h: number,
  fontPx: number
): void {
  if (w <= 0 || h <= 0) return;
  ctx.save();
  roundRectPath(ctx, x, y, w, h, Math.max(4, fontPx * 0.6));
  ctx.fillStyle = TILE_BG;
  ctx.fill();
  ctx.clip();

  const el = tile.element;
  if (el && el.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && el.videoWidth > 0) {
    drawContain(ctx, el, x, y, w, h);
  } else {
    // Placeholder untuk peserta yang kameranya mati: inisial di tengah.
    const radius = Math.min(w, h) * 0.18;
    const cx = x + w / 2;
    const cy = y + h / 2;
    ctx.fillStyle = '#21262d';
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = TILE_MUTED_TEXT;
    ctx.font = `600 ${Math.round(radius)}px system-ui, -apple-system, "Segoe UI", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(initialsOf(tile.label), cx, cy);
    ctx.textAlign = 'start';
  }

  // Nama peserta di bilah bawah tile.
  const barH = fontPx * 1.9;
  ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
  ctx.fillRect(x, y + h - barH, w, barH);
  ctx.fillStyle = TILE_TEXT;
  ctx.font = `600 ${fontPx}px system-ui, -apple-system, "Segoe UI", sans-serif`;
  ctx.textBaseline = 'middle';
  ctx.fillText(tile.label, x + fontPx * 0.6, y + h - barH / 2, Math.max(0, w - fontPx * 1.2));
  ctx.restore();
}

function drawGrid(
  ctx: CanvasRenderingContext2D,
  tiles: CompositionTile[],
  x: number,
  y: number,
  w: number,
  h: number,
  fontPx: number
): void {
  const n = tiles.length;
  if (n === 0) return;
  const cols = Math.ceil(Math.sqrt(n));
  const rows = Math.ceil(n / cols);
  const gap = Math.max(2, Math.round(fontPx * 0.5));
  const cellW = (w - gap * (cols - 1)) / cols;
  const cellH = (h - gap * (rows - 1)) / rows;
  tiles.forEach((tile, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    drawTile(
      ctx,
      tile,
      x + col * (cellW + gap),
      y + row * (cellH + gap),
      cellW,
      cellH,
      fontPx
    );
  });
}

export function useClientRecorder(meeting: Meeting | null | undefined) {
  const [recordingState, setRecordingState] = useState<ClientRecordingState>('IDLE');
  const [durationSeconds, setDurationSeconds] = useState(0);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const stateRef = useRef<ClientRecordingState>('IDLE');
  const meetingRef = useRef<Meeting | null | undefined>(meeting);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const blobTypeRef = useRef('video/mp4');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const canvasStreamRef = useRef<MediaStream | null>(null);
  // Elemen <video> tersembunyi per track (track → sumber gambar canvas).
  const videoElsRef = useRef<Map<string, { el: HTMLVideoElement; track: MediaStreamTrack; onEnded: () => void }>>(new Map());
  const videoHostRef = useRef<HTMLDivElement | null>(null);
  const tilesRef = useRef<CompositionTile[]>([]);
  const overflowRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const lastDrawRef = useRef(0);
  const hiddenDrawTimerRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioDestRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const audioSourcesRef = useRef<Map<string, MediaStreamAudioSourceNode>>(new Map());
  const durationTimerRef = useRef<number | null>(null);
  const scanTimerRef = useRef<number | null>(null);
  const startedAtRef = useRef(0);
  // Akumulasi durasi yang sudah berjalan sebelum pause terakhir — supaya waktu
  // pause tidak ikut terhitung dan timer bisa dilanjutkan dari titik yang benar.
  const accumulatedMsRef = useRef(0);
  const cancelRef = useRef(false);
  // Menandai MediaRecorder benar-benar sudah start — dipakai finalize() untuk
  // membedakan "rekaman kosong" (error nyata) vs "rekaman tak pernah jalan".
  const recorderStartedRef = useRef(false);
  // Mencegah finalize() berjalan dua kali (onstop + pemanggilan manual dari
  // stop()) — panggilan kedua melihat chunks yang sudah dikosongkan → 0 byte.
  const finalizingRef = useRef(false);
  const emergencySavedRef = useRef(false);
  const finishWaitersRef = useRef<Set<() => void>>(new Set());
  // Nomor sesi rekaman — finalize() hanya boleh mengubah state kalau sesinya
  // masih yang terbaru (melindungi rekaman baru dari ditimpa proses lama).
  const sessionRef = useRef(0);
  // Penunggu "sesi lama selesai dulu" untuk start() yang dipanggil saat masih
  // STOPPING/UPLOADING — rekaman baru tidak boleh menimpa unggahan berjalan.
  const idleWaitersRef = useRef<Set<() => void>>(new Set());
  const stopRef = useRef<() => Promise<void>>(async () => {});
  const tickRef = useRef<() => void>(() => {});
  const metaRef = useRef<{ meetingId: string; uploadToken: string | null; resolution: RecordingResolution }>({
    meetingId: '',
    uploadToken: null,
    resolution: '720p',
  });

  useEffect(() => {
    meetingRef.current = meeting;
  }, [meeting]);

  const applyState = useCallback((next: ClientRecordingState) => {
    stateRef.current = next;
    setRecordingState(next);
    // Rekaman berikutnya yang menunggu (start saat masih STOPPING/UPLOADING)
    // boleh lanjut begitu sesi lama benar-benar selesai.
    if ((next === 'IDLE' || next === 'ERROR') && idleWaitersRef.current.size > 0) {
      const waiters = Array.from(idleWaitersRef.current);
      idleWaitersRef.current.clear();
      for (const resolve of waiters) resolve();
    }
  }, []);

  const resolveWaiters = useCallback(() => {
    if (finishWaitersRef.current.size === 0) return;
    const waiters = Array.from(finishWaitersRef.current);
    finishWaitersRef.current.clear();
    for (const resolve of waiters) resolve();
  }, []);

  const connectAudioTrack = useCallback((track: MediaStreamTrack | null | undefined) => {
    if (!track || track.kind !== 'audio' || track.readyState !== 'live') return;
    if (audioSourcesRef.current.has(track.id)) return;
    const context = audioContextRef.current;
    const destination = audioDestRef.current;
    if (!context || !destination) return;
    try {
      const source = context.createMediaStreamSource(new MediaStream([track]));
      source.connect(destination);
      audioSourcesRef.current.set(track.id, source);
    } catch {
      /* track tidak bisa dipakai sebagai sumber audio — abaikan */
    }
  }, []);

  // Referensi terbaru supaya callback lama (listener track 'ended') selalu
  // memanggil implementasi komposisi yang paling baru.
  const syncCompositionRef = useRef<() => void>(() => {});

  // Ambil (atau buat) elemen <video> tersembunyi untuk sebuah track kamera /
  // screenshare. Elemen dipasang di container offscreen supaya browser tetap
  // mendecode frame-nya walaupun tidak terlihat pengguna.
  const elementForTrack = useCallback((track: MediaStreamTrack): HTMLVideoElement => {
    const cached = videoElsRef.current.get(track.id);
    if (cached) return cached.el;

    const el = document.createElement('video');
    el.muted = true;
    el.autoplay = true;
    el.playsInline = true;
    el.setAttribute('aria-hidden', 'true');
    try {
      el.srcObject = new MediaStream([track]);
    } catch {
      /* srcObject tidak didukung — tile jadi placeholder */
    }
    const onEnded = () => {
      // Kamera dimatikan / peserta keluar → lepas elemen & susun ulang layout.
      const entry = videoElsRef.current.get(track.id);
      if (entry) {
        try { entry.el.pause(); } catch { /* sudah berhenti */ }
        try { entry.el.srcObject = null; } catch { /* ignore */ }
        entry.el.remove();
        videoElsRef.current.delete(track.id);
      }
      void syncCompositionRef.current();
    };
    track.addEventListener('ended', onEnded);
    videoHostRef.current?.appendChild(el);
    void el.play().catch(() => { /* autoplay ditahan — frame tampil setelah play() berhasil */ });
    videoElsRef.current.set(track.id, { el, track, onEnded });
    return el;
  }, []);

  // Pindel ruangan → daftar tile terbaru (layar yang dibagikan sebagai konten
  // utama, kamera peserta sebagai grid, peserta tanpa kamera sebagai
  // placeholder). Elemen video yang tidak lagi dibutuhkan dibuang.
  const syncComposition = useCallback(() => {
    const participants = collectParticipants(meetingRef.current);
    const wanted = new Set<string>();
    const cameras: CompositionTile[] = [];
    let main: CompositionTile | null = null;

    for (const p of participants) {
      const label = (typeof p.name === 'string' && p.name.trim()) || 'Peserta';

      if (p.screenShareEnabled) {
        const shareTrack = asLiveTrack(p.screenShareTracks?.video);
        if (shareTrack) {
          wanted.add(shareTrack.id);
          const tile: CompositionTile = {
            label: `${label} — berbagi layar`,
            element: elementForTrack(shareTrack),
            main: true,
          };
          // Layar pertama jadi konten utama; share berikutnya diperlakukan
          // seperti tile biasa agar tidak ada yang hilang dari rekaman.
          if (!main) main = tile;
          else cameras.push(tile);
          continue;
        }
      }

      const camTrack = asLiveTrack(p.videoTrack);
      if (camTrack) {
        wanted.add(camTrack.id);
        cameras.push({ label, element: elementForTrack(camTrack), main: false });
      } else {
        cameras.push({ label, element: null, main: false });
      }
    }

    // Batasi jumlah tile agar komposisi tetap terbaca (sisa ditampilkan
    // sebagai overlay "+N lainnya").
    const budget = Math.max(1, MAX_TILES - (main ? 1 : 0));
    overflowRef.current = Math.max(0, cameras.length - budget);
    tilesRef.current = (main ? [main, ...cameras.slice(0, budget)] : cameras.slice(0, budget));

    // Buang elemen video yang sudah tidak dipakai (track berhenti/diganti).
    for (const [trackId, entry] of Array.from(videoElsRef.current.entries())) {
      if (wanted.has(trackId)) continue;
      try { entry.track.removeEventListener('ended', entry.onEnded); } catch { /* ignore */ }
      try { entry.el.pause(); } catch { /* ignore */ }
      try { entry.el.srcObject = null; } catch { /* ignore */ }
      entry.el.remove();
      videoElsRef.current.delete(trackId);
    }
  }, [elementForTrack]);

  syncCompositionRef.current = syncComposition;

  const drawFrame = useCallback(() => {
    const ctx = ctxRef.current;
    const canvas = canvasRef.current;
    if (!ctx || !canvas) return;
    const width = canvas.width;
    const height = canvas.height;
    const fontPx = Math.max(11, Math.round(height * 0.026));
    const pad = Math.max(2, Math.round(width * 0.006));

    ctx.fillStyle = CANVAS_BG;
    ctx.fillRect(0, 0, width, height);

    const tiles = tilesRef.current;
    if (tiles.length === 0) {
      ctx.fillStyle = TILE_MUTED_TEXT;
      ctx.font = `500 ${Math.round(fontPx * 1.6)}px system-ui, -apple-system, "Segoe UI", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('Menunggu kamera peserta…', width / 2, height / 2);
      ctx.textAlign = 'start';
      return;
    }

    const first = tiles[0];
    if (first.main) {
      // Konten utama = layar yang dibagikan; kamera peserta jadi strip bawah.
      const rest = tiles.slice(1);
      const stripH = rest.length > 0 ? Math.round(height * 0.24) : 0;
      drawTile(ctx, first, pad, pad, width - pad * 2, height - stripH - pad * (stripH > 0 ? 2 : 1), fontPx);
      if (stripH > 0) {
        drawGrid(ctx, rest, pad, height - stripH, width - pad * 2, stripH - pad, fontPx);
      }
    } else {
      drawGrid(ctx, tiles, pad, pad, width - pad * 2, height - pad * 2, fontPx);
    }

    if (overflowRef.current > 0) {
      const label = `+${overflowRef.current} peserta lainnya`;
      ctx.font = `600 ${fontPx}px system-ui, -apple-system, "Segoe UI", sans-serif`;
      const textW = Math.min(width / 2, ctx.measureText(label).width + fontPx * 1.6);
      const barH = fontPx * 1.9;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
      ctx.fillRect(width - textW - pad, height - barH - pad, textW, barH);
      ctx.fillStyle = TILE_TEXT;
      ctx.textBaseline = 'middle';
      ctx.fillText(label, width - textW - pad + fontPx * 0.8, height - barH / 2 - pad);
    }
  }, []);

  const tick = useCallback(() => {
    rafRef.current = window.requestAnimationFrame(tick);
    const now = Date.now();
    if (now - lastDrawRef.current < DRAW_INTERVAL_MS) return;
    lastDrawRef.current = now;
    drawFrame();
  }, [drawFrame]);

  tickRef.current = tick;

  const cleanupMedia = useCallback(() => {
    if (durationTimerRef.current !== null) {
      window.clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }
    if (scanTimerRef.current !== null) {
      window.clearInterval(scanTimerRef.current);
      scanTimerRef.current = null;
    }
    if (hiddenDrawTimerRef.current !== null) {
      window.clearInterval(hiddenDrawTimerRef.current);
      hiddenDrawTimerRef.current = null;
    }
    if (rafRef.current !== null) {
      window.cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    for (const source of audioSourcesRef.current.values()) {
      try {
        source.disconnect();
      } catch {
        /* sudah terputus */
      }
    }
    audioSourcesRef.current.clear();
    audioDestRef.current = null;
    const context = audioContextRef.current;
    audioContextRef.current = null;
    if (context) {
      try {
        void context.close();
      } catch {
        /* context sudah tertutup */
      }
    }
    // Lepas semua elemen video & host offscreen-nya.
    for (const entry of videoElsRef.current.values()) {
      try { entry.track.removeEventListener('ended', entry.onEnded); } catch { /* ignore */ }
      try { entry.el.pause(); } catch { /* ignore */ }
      try { entry.el.srcObject = null; } catch { /* ignore */ }
      entry.el.remove();
    }
    videoElsRef.current.clear();
    const host = videoHostRef.current;
    videoHostRef.current = null;
    host?.remove();
    tilesRef.current = [];
    overflowRef.current = 0;
    ctxRef.current = null;
    canvasRef.current = null;
    const canvasStream = canvasStreamRef.current;
    canvasStreamRef.current = null;
    if (canvasStream) {
      for (const track of canvasStream.getTracks()) {
        try {
          track.stop();
        } catch {
          /* track sudah berhenti */
        }
      }
    }
    const recorder = recorderRef.current;
    recorderRef.current = null;
    if (recorder) {
      recorder.ondataavailable = null;
      recorder.onerror = null;
      recorder.onstop = null;
    }
  }, []);

  const finalize = useCallback(async () => {
    if (finalizingRef.current) return;
    finalizingRef.current = true;
    const session = sessionRef.current;
    try {
      const chunks = chunksRef.current;
      chunksRef.current = [];
      const blob = new Blob(chunks, { type: blobTypeRef.current || 'video/mp4' });
      // Durasi file = akumulasi waktu rekam aktif; waktu pause tidak dihitung.
      // Kalau berhenti saat masih PAUSED, jangan tambahkan sisa `startedAtRef`.
      const lastSegmentMs =
        stateRef.current === 'PAUSED' ? 0 : Math.max(0, Date.now() - startedAtRef.current);
      const elapsedMs = Math.max(1000, accumulatedMsRef.current + lastSegmentMs);
      const duration = Math.max(1, Math.round(elapsedMs / 1000));
      cleanupMedia();

      // Tab ditutup / halaman berpindah: data sudah disimpan lokal, lewati unggah.
      if (emergencySavedRef.current) {
        emergencySavedRef.current = false;
        applyState('IDLE');
        setDurationSeconds(0);
        resolveWaiters();
        return;
      }

      if (blob.size === 0) {
        // Rekaman tidak pernah mencapai MediaRecorder (mis. stop saat fase
        // STARTING) → tidak ada yang perlu diunggah, kembali diam-diam tanpa
        // menakut-nakuti user. Kalau recorder sempat jalan tapi benar-benar 0
        // byte, laporkan lengkap dengan durasi untuk memudahkan diagnosa.
        console.warn('[recording] hasil kosong', {
          chunks: chunks.length,
          durationSeconds: duration,
          recorderStarted: recorderStartedRef.current,
        });
        if (recorderStartedRef.current) {
          applyState('ERROR');
          setErrorMessage(`Rekaman tidak menghasilkan data (0 byte, ${duration} detik).`);
        } else {
          applyState('IDLE');
          setDurationSeconds(0);
        }
        resolveWaiters();
        return;
      }

      const meta = metaRef.current;
      const preset = RESOLUTION_PRESETS[meta.resolution] || RESOLUTION_PRESETS['720p'];
      const fileName = `recording-${new Date().toISOString().replace(/[:.]/g, '-')}.${fileExtensionFor(blob)}`;

      applyState('UPLOADING');
      setUploadProgress(0);

      // Anti-hilang: tulis dulu ke IndexedDB, hapus hanya setelah server
      // mengonfirmasi sukses. Kalau tab ditutup / jaringan putus di tengah
      // unggahan, file tetap tersimpan dan bisa dikirim ulang dari dashboard
      // admin (menu Rekaman).
      const pendingId = crypto.randomUUID();
      let pendingSaved = false;
      if (meta.meetingId) {
        try {
          await savePendingRecording({
            id: pendingId,
            createdAt: Date.now(),
            meetingId: meta.meetingId,
            uploadToken: meta.uploadToken,
            durationSeconds: duration,
            resolutionWidth: preset.width,
            resolutionHeight: preset.height,
            fileName,
            mimeType: blob.type || 'video/mp4',
            blob,
            attempts: 0,
            lastError: null,
          });
          pendingSaved = true;
        } catch {
          /* IndexedDB penuh/nonaktif — jatuh ke unduhan lokal bila unggah gagal */
        }
      }

      const uploaded = meta.meetingId
        ? await uploadRecordingBlob(
            blob,
            {
              meetingId: meta.meetingId,
              uploadToken: meta.uploadToken,
              durationSeconds: duration,
              resolutionWidth: preset.width,
              resolutionHeight: preset.height,
              fileName,
            },
            setUploadProgress
          )
        : false;

      if (uploaded) {
        if (pendingSaved) {
          try {
            await deletePendingRecording(pendingId);
          } catch {
            /* abaikan */
          }
        }
        // Sesi rekaman baru sudah berjalan — jangan menimpa state-nya.
        if (sessionRef.current !== session) return;
        setUploadProgress(100);
        setDurationSeconds(0);
        applyState('IDLE');
      } else {
        if (sessionRef.current !== session) return;
        setUploadProgress(0);
        applyState('ERROR');
        if (pendingSaved) {
          void patchPendingRecording(pendingId, { attempts: 1, lastError: 'Unggahan gagal' }).catch(
            () => {}
          );
          setErrorMessage(
            'Unggahan rekaman gagal — file disimpan di perangkat dan bisa dikirim ulang dari dashboard (menu Rekaman).'
          );
        } else {
          // Cadangan terakhir: file tetap diunduh lokal supaya tidak hilang.
          downloadLocally(blob);
          setErrorMessage('Unggahan rekaman gagal — file disimpan lokal di perangkat ini.');
        }
      }
      resolveWaiters();
    } finally {
      finalizingRef.current = false;
    }
  }, [applyState, cleanupMedia, resolveWaiters]);

  const stop = useCallback((): Promise<void> => {
    const current = stateRef.current;
    if (current !== 'RECORDING' && current !== 'STARTING' && current !== 'PAUSED') return Promise.resolve();

    // Masih fase STARTING dan MediaRecorder belum ada → belum ada yang bisa
    // dihentikan. JANGAN langsung finalize (chunks masih kosong → dulu bikin
    // error "tidak berisi data"). Cukup pasang bendera batal; start() yang
    // akan menutup semuanya dengan bersih dan me-resolve waiter ini.
    if (current === 'STARTING' && !recorderRef.current) {
      cancelRef.current = true;
      applyState('STOPPING');
      return new Promise<void>((resolve) => {
        finishWaitersRef.current.add(resolve);
        window.setTimeout(() => {
          if (finishWaitersRef.current.delete(resolve)) resolve();
        }, 15000);
      });
    }

    applyState('STOPPING');

    return new Promise<void>((resolve) => {
      finishWaitersRef.current.add(resolve);
      // Pengaman: jangan pernah menahan caller (navigasi) lebih dari 15 detik.
      window.setTimeout(() => {
        if (finishWaitersRef.current.delete(resolve)) resolve();
      }, 15000);

      const recorder = recorderRef.current;
      if (recorder && recorder.state !== 'inactive') {
        try {
          recorder.stop();
          return;
        } catch {
          /* jatuh ke finalize di bawah */
        }
      }
      // Recorder sudah tidak aktif. onstop kemungkinan besar sudah (atau sedang)
      // memanggil finalize yang mengosongkan chunks — memanggil dua kali membuat
      // panggilan kedua melihat 0 byte dan memunculkan error palsu. Finalize
      // manual hanya kalau datanya masih ada atau memang belum pernah jalan.
      if (chunksRef.current.length > 0 || !finalizingRef.current) void finalize();
    });
  }, [applyState, finalize]);

  stopRef.current = stop;

  // Pause beneran: hentikan encoding (MediaRecorder.pause) supaya bagian yang
  // di-pause tidak ikut masuk file, dan bekukan timer.
  const pause = useCallback(() => {
    if (stateRef.current !== 'RECORDING') return;
    const recorder = recorderRef.current;
    if (!recorder || recorder.state !== 'recording') return;
    try {
      recorder.pause();
    } catch {
      return;
    }
    // Catat mulai pause & akumulasikan durasi yang sudah berjalan sejauh ini.
    accumulatedMsRef.current += Date.now() - startedAtRef.current;
    setDurationSeconds(Math.max(0, Math.floor(accumulatedMsRef.current / 1000)));
    applyState('PAUSED');
  }, [applyState]);

  const resume = useCallback(() => {
    if (stateRef.current !== 'PAUSED') return;
    const recorder = recorderRef.current;
    if (!recorder || recorder.state !== 'paused') return;
    try {
      recorder.resume();
    } catch {
      return;
    }
    // Lanjutkan penghitungan dari titik pause (durasi pause sudah tidak dihitung).
    startedAtRef.current = Date.now();
    applyState('RECORDING');
  }, [applyState]);

  const start = useCallback(
    async (options: StartRecordingOptions): Promise<void> => {
      // Rekaman sebelumnya masih STOPPING/UPLOADING? Tunggu sampai benar-benar
      // selesai — memulai rekaman baru di tengah unggahan akan menimpa state
      // dan membuat rekaman berikutnya hilang tanpa sempat terkumpul.
      if (stateRef.current === 'STOPPING' || stateRef.current === 'UPLOADING') {
        await new Promise<void>((resolve) => {
          const done = () => {
            idleWaitersRef.current.delete(done);
            resolve();
          };
          idleWaitersRef.current.add(done);
          window.setTimeout(done, 180_000);
        });
      }
      const current = stateRef.current;
      if (current !== 'IDLE' && current !== 'ERROR') {
        throw new Error('Rekaman sedang berlangsung.');
      }
      sessionRef.current += 1;
      // Rekaman tidak butuh getDisplayMedia/dialog share-screen: cukup
      // MediaRecorder + canvas.captureStream (semua browser modern punya ini).
      if (
        typeof navigator === 'undefined' ||
        typeof MediaRecorder === 'undefined' ||
        typeof HTMLCanvasElement === 'undefined' ||
        typeof HTMLCanvasElement.prototype.captureStream !== 'function'
      ) {
        applyState('ERROR');
        setErrorMessage('Browser ini tidak mendukung perekaman meeting.');
        throw new Error('MediaRecorder/canvas.captureStream not supported');
      }

      cancelRef.current = false;
      emergencySavedRef.current = false;
      recorderStartedRef.current = false;
      setErrorMessage(null);
      setUploadProgress(0);
      setDurationSeconds(0);
      metaRef.current = {
        meetingId: options.meetingId,
        uploadToken: options.uploadToken ?? null,
        resolution: options.resolution === '480p' ? '480p' : '720p',
      };
      applyState('STARTING');

      const preset = RESOLUTION_PRESETS[metaRef.current.resolution];

      // Canvas = "layar" rekaman: berisi tampilan meeting (grid kamera +
      // screenshare bila ada). Tidak perlu izin khusus karena semua track
      // sudah dipegang RealtimeKit.
      const canvas = document.createElement('canvas');
      canvas.width = preset.width;
      canvas.height = preset.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        applyState('ERROR');
        setErrorMessage('Canvas 2D tidak tersedia di browser ini.');
        resolveWaiters();
        throw new Error('Canvas 2D unavailable');
      }
      canvasRef.current = canvas;
      ctxRef.current = ctx;
      ctx.fillStyle = CANVAS_BG;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Container offscreen untuk elemen <video> sumber gambar.
      const host = document.createElement('div');
      host.setAttribute('aria-hidden', 'true');
      host.style.cssText =
        'position:fixed;left:-10000px;top:0;width:1px;height:1px;overflow:hidden;pointer-events:none;opacity:0;';
      document.body.appendChild(host);
      videoHostRef.current = host;

      // Mixing audio: mikrofon semua peserta + audio screenshare (kalau ada).
      // Dua pengaman hasil uji Chrome 155:
      //  1. destination SELALU diberi minimal satu sumber senyap — destination
      //     tanpa input membuat MediaRecorder menghasilkan file 0 byte;
      //  2. resume() dibatasi race — tanpa gesture user (auto-record) promise-nya
      //     bisa menggantung selamanya. Kalau context tetap tidak 'running',
      //     track-nya TIDAK dimasukkan ke rekaman (video-only lebih baik daripada
      //     file 0 byte).
      let audioReady = false;
      try {
        const context = new AudioContext();
        audioContextRef.current = context;
        const destination = context.createMediaStreamDestination();
        audioDestRef.current = destination;
        connectSilentSource(context, destination);
        if (context.state !== 'running') {
          try {
            await Promise.race([
              context.resume(),
              new Promise<void>((resolve) => window.setTimeout(resolve, RESUME_TIMEOUT_MS)),
            ]);
          } catch {
            /* biarkan — ditilik di bawah lewat context.state */
          }
        }
        audioReady = context.state === 'running';
        if (audioReady) {
          collectRoomAudioTracks(meetingRef.current).forEach(connectAudioTrack);
        }
      } catch {
        audioReady = false;
      }
      if (!audioReady) {
        // Context tidak jalan → tutup, rekam video-only (lihat catatan di atas).
        const context = audioContextRef.current;
        audioContextRef.current = null;
        audioDestRef.current = null;
        if (context) {
          try { void context.close(); } catch { /* ignore */ }
        }
      }

      // Rekaman dihentikan selama masih fase STARTING (mis. host klik stop
      // bersamaan) → batal sebelum MediaRecorder sempat dibuat.
      if (cancelRef.current) {
        cancelRef.current = false;
        cleanupMedia();
        applyState('IDLE');
        setDurationSeconds(0);
        resolveWaiters();
        return;
      }

      // Sinkronkan peserta baru / kamera & screenshare yang berubah selama
      // rekaman berjalan (audio room + komposisi video).
      syncComposition();
      drawFrame();
      lastDrawRef.current = Date.now();
      tickRef.current();
      scanTimerRef.current = window.setInterval(() => {
        collectRoomAudioTracks(meetingRef.current).forEach(connectAudioTrack);
        syncCompositionRef.current();
      }, SCAN_MS);
      // Saat tab disembunyikan, requestAnimationFrame berhenti — jaga frame
      // tetap hidup lewat interval supaya rekaman tidak membeku di satu gambar.
      hiddenDrawTimerRef.current = window.setInterval(() => {
        if (document.hidden) drawFrame();
      }, 500);

      let canvasStream: MediaStream;
      try {
        canvasStream = canvas.captureStream(CANVAS_FPS);
      } catch (err) {
        cleanupMedia();
        applyState('ERROR');
        setErrorMessage('Gagal menangkap tampilan meeting untuk direkam.');
        resolveWaiters();
        throw err;
      }
      canvasStreamRef.current = canvasStream;
      const videoTrack = canvasStream.getVideoTracks()[0];
      if (!videoTrack) {
        cleanupMedia();
        applyState('ERROR');
        setErrorMessage('Tidak ada video hasil tangkapan tampilan meeting.');
        resolveWaiters();
        throw new Error('No canvas video track');
      }

      const combined = new MediaStream();
      combined.addTrack(videoTrack);
      const mixedAudio = audioDestRef.current?.stream.getAudioTracks()[0];
      if (mixedAudio) combined.addTrack(mixedAudio);

      const mimeType = pickMimeType();
      let recorder: MediaRecorder;
      try {
        recorder = new MediaRecorder(combined, {
          ...(mimeType ? { mimeType } : {}),
          videoBitsPerSecond: preset.videoBitsPerSecond,
          audioBitsPerSecond: 128_000,
        });
      } catch (err) {
        cleanupMedia();
        applyState('ERROR');
        setErrorMessage('MediaRecorder tidak dapat dijalankan di browser ini.');
        resolveWaiters();
        throw err;
      }

      recorderRef.current = recorder;
      chunksRef.current = [];
      blobTypeRef.current = recorder.mimeType || mimeType || 'video/mp4';

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) chunksRef.current.push(event.data);
      };
      recorder.onerror = () => {
        const partial = new Blob(chunksRef.current, { type: blobTypeRef.current });
        if (partial.size > 0) downloadLocally(partial);
        chunksRef.current = [];
        applyState('ERROR');
        setErrorMessage('Perekaman mengalami error — file disimpan lokal.');
        cleanupMedia();
        resolveWaiters();
      };
      recorder.onstop = () => {
        void finalize();
      };

      startedAtRef.current = Date.now();
      accumulatedMsRef.current = 0;
      durationTimerRef.current = window.setInterval(() => {
        // Waktu pause tidak dihitung: kalau sedang pause, bekukan di angka terakhir.
        const elapsedMs =
          stateRef.current === 'PAUSED'
            ? accumulatedMsRef.current
            : accumulatedMsRef.current + (Date.now() - startedAtRef.current);
        setDurationSeconds(Math.max(0, Math.floor(elapsedMs / 1000)));
      }, 1000);

      try {
        recorder.start(CHUNK_INTERVAL_MS);
      } catch (err) {
        cleanupMedia();
        applyState('ERROR');
        setErrorMessage('Gagal memulai rekaman.');
        resolveWaiters();
        throw err;
      }
      recorderStartedRef.current = true;
      // (Stop selama STARTING sudah ditangani guard cancelRef di atas — tidak
      // ada await lagi setelah guard, jadi state langsung RECORDING berikut.)
      applyState('RECORDING');
    },
    [applyState, cleanupMedia, connectAudioTrack, drawFrame, finalize, resolveWaiters, syncComposition]
  );

  const clearError = useCallback(() => {
    setErrorMessage(null);
    if (stateRef.current === 'ERROR') applyState('IDLE');
  }, [applyState]);

  // Penutupan tab / leave room: hentikan rekaman dan selamatkan datanya.
  const emergencySave = useCallback(() => {
    const current = stateRef.current;
    if (current !== 'RECORDING' && current !== 'STARTING' && current !== 'PAUSED') return;
    if (emergencySavedRef.current) return;
    emergencySavedRef.current = true;
    try {
      recorderRef.current?.requestData?.();
    } catch {
      /* recorder sudah tidak aktif */
    }
    try {
      const snapshot = new Blob(chunksRef.current, { type: blobTypeRef.current });
      if (snapshot.size > 0) downloadLocally(snapshot);
    } catch {
      /* tidak ada chunk untuk diselamatkan */
    }
    try {
      const recorder = recorderRef.current;
      if (recorder && recorder.state !== 'inactive') recorder.stop();
    } catch {
      /* ignore */
    }
    cleanupMedia();
    chunksRef.current = [];
    setDurationSeconds(0);
    applyState('IDLE');
    resolveWaiters();
  }, [applyState, cleanupMedia, resolveWaiters]);

  useEffect(() => {
    const handler = () => emergencySave();
    window.addEventListener('beforeunload', handler);
    window.addEventListener('pagehide', handler);
    return () => {
      window.removeEventListener('beforeunload', handler);
      window.removeEventListener('pagehide', handler);
    };
  }, [emergencySave]);

  // Selama unggahan berjalan, browser memperingatkan sebelum tab ditutup/
  // di-reload. File sudah tersimpan di IndexedDB, tapi unggahan akan terputus
  // dan perlu dikirim ulang dari dashboard.
  useEffect(() => {
    if (recordingState !== 'UPLOADING') return;
    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [recordingState]);

  useEffect(() => () => emergencySave(), [emergencySave]);

  return {
    recordingState,
    durationSeconds,
    uploadProgress,
    errorMessage,
    start,
    stop,
    pause,
    resume,
    clearError,
  };
}
