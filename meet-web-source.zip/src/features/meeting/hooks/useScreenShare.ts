import { useCallback, useEffect, useState } from 'react';
import type { Meeting } from '@cloudflare/realtimekit-react-ui';
import type { RTKParticipant, RTKSelf } from '@cloudflare/realtimekit-react';

// A participant (or self) that is currently sharing its screen.
// Uses official RealtimeKit core getters only (`screenShareEnabled`,
// `screenShareTracks`) — never touches the SDK's internal DOM.
export type ScreenSharer = RTKParticipant | RTKSelf;

export interface ScreenShareState {
  // Everyone currently sharing, with self first when self is sharing.
  sharers: ScreenSharer[];
  // Primary sharer (self preferred, otherwise the first found).
  sharer: ScreenSharer | null;
  active: boolean;
  // Raw video track of the primary sharer (for overlay alignment).
  videoTrack: MediaStreamTrack | null;
}

function collectSharers(meeting: Meeting | null | undefined): ScreenSharer[] {
  const out: ScreenSharer[] = [];
  const seen = new Set<string>();
  const push = (p: unknown) => {
    const c = p as { id?: unknown; screenShareEnabled?: unknown } | null | undefined;
    if (c && typeof c.id === 'string' && c.screenShareEnabled === true && !seen.has(c.id)) {
      seen.add(c.id);
      out.push(p as ScreenSharer);
    }
  };
  try {
    const m = meeting as unknown as {
      self?: unknown;
      participants?: { joined?: { toArray?: () => unknown[] } };
    } | null | undefined;
    // Self first so the local user is preferred when they share.
    push(m?.self);
    const arr = m?.participants?.joined?.toArray?.() ?? [];
    for (const p of arr) push(p);
  } catch {
    /* SDK not ready — treat as no active share */
  }
  return out;
}

// Detects who is screen sharing via official RealtimeKit APIs and keeps the
// result in sync through the official `screenShareUpdate` events (both the
// per-participant event on self and the re-emitted event on the joined map).
export function useScreenShare(meeting: Meeting | null | undefined): ScreenShareState {
  const [sharers, setSharers] = useState<ScreenSharer[]>([]);

  const rescan = useCallback(() => {
    setSharers((prev) => {
      const next = collectSharers(meeting);
      if (next.length === prev.length && next.every((p, i) => p.id === prev[i]?.id)) {
        return prev;
      }
      return next;
    });
  }, [meeting]);

  useEffect(() => {
    rescan();
    if (!meeting) return;
    const onUpdate = () => rescan();
    const m = meeting as unknown as {
      self?: { on?: (e: string, h: () => void) => void; off?: (e: string, h: () => void) => void };
      participants?: {
        joined?: { on?: (e: string, h: () => void) => void; off?: (e: string, h: () => void) => void };
      };
    };
    try {
      m.participants?.joined?.on?.('screenShareUpdate', onUpdate);
    } catch {
      /* event API unavailable — rescan on meeting change still applies */
    }
    try {
      m.self?.on?.('screenShareUpdate', onUpdate);
    } catch {
      /* ignore */
    }
    return () => {
      try {
        m.participants?.joined?.off?.('screenShareUpdate', onUpdate);
      } catch {
        /* ignore */
      }
      try {
        m.self?.off?.('screenShareUpdate', onUpdate);
      } catch {
        /* ignore */
      }
    };
  }, [meeting, rescan]);

  const sharer = sharers.length > 0 ? sharers[0] : null;
  let videoTrack: MediaStreamTrack | null = null;
  try {
    const t = (sharer as { screenShareTracks?: { video?: unknown } } | null)?.screenShareTracks?.video;
    videoTrack = t instanceof MediaStreamTrack ? t : null;
  } catch {
    videoTrack = null;
  }

  return { sharers, sharer, active: sharers.length > 0, videoTrack };
}
