import { useEffect, useRef, useState } from 'react';
import type { Meeting } from '@cloudflare/realtimekit-react-ui';

/**
 * Sumber status koneksi yang otoritatif untuk keputusan screen share.
 *
 * RTK menyediakan `meta.socketState` (getter) dan event `socketConnectionUpdate`
 * pada `Meta`. Keduanya diverifikasi dari tipe SDK
 * (`@cloudflare/realtimekit`: MetaEvents['socketConnectionUpdate'] dan
 * Meta.socketState), bukan ditebak.
 *
 * `navigator.onLine` HANYA dipakai sebagai indikator tambahan — true tidak
 * berarti koneksi RTK sudah pulih (lihat issue #82).
 */
export type ConnectionState =
  | 'connected'
  | 'disconnected'
  | 'reconnecting'
  | 'failed';

export interface ScreenShareConnection {
  /**
   * true hanya bila koneksi RTK sehat: socket `connected` DAN self sudah
   * join room. Ini gerbang wajib sebelum memulai screen share.
   */
  canStartShare: boolean;
  /**
   * true bila koneksi sedang terputus / belum pulih (dipakai untuk
   * menonaktifkan tombol Share dan menampilkan alasan).
   */
  connectionDegraded: boolean;
  /** Alasan dalam Bahasa Indonesia mengapa share belum bisa dimulai. */
  blockedReason: string | null;
  /**
   * Nomor generasi koneksi. Meningkat setiap koneksi berpindah dari sehat ke
   * tidak sehat. Dipakai sebagai penanda sesi agar operasi lama tidak
   * mengubah state sesi baru (race condition).
   */
  generation: number;
}

/** Bacalah socketState + roomJoined dari objek meeting secara defensif. */
function readConnection(meeting: Meeting | null | undefined): {
  state: ConnectionState;
  roomJoined: boolean;
} {
  const fallback: ConnectionState = 'connected';
  if (!meeting) return { state: fallback, roomJoined: false };
  let state: ConnectionState = fallback;
  try {
    const raw = (meeting as unknown as {
      meta?: { socketState?: { state?: string } };
    })?.meta?.socketState?.state;
    // Nilai di luar daftar yang dikenal dianggap connected agar tidak
    // memblokir share pada versi SDK yang menambah state baru.
    if (
      raw === 'disconnected' ||
      raw === 'reconnecting' ||
      raw === 'failed' ||
      raw === 'connected'
    ) {
      state = raw;
    }
  } catch {
    /* meta belum siap — biarkan default connected */
  }
  let roomJoined = false;
  try {
    roomJoined = (meeting as unknown as { self?: { roomJoined?: boolean } })?.self
      ?.roomJoined === true;
  } catch {
    roomJoined = false;
  }
  return { state, roomJoined };
}

const DEGRADED_MESSAGE =
  'Koneksi internet terputus. Hubungkan kembali jaringan sebelum membagikan layar.';

/**
 * Melacak kesehatan koneksi RTK untuk keputusan screen share, serta menghentikan
 * screen share yang sedang berjalan secara lokal saat koneksi hilang.
 *
 * Perilaku (issue #82):
 * - `canStartShare` hanya true saat socket `connected` DAN `roomJoined`.
 * - Saat koneksi hilang dan share aktif, memanggil `disableScreenShare()`
 *   best-effort (cleanup lokal tidak menunggu respons server).
 * - `generation` naik tiap transisi sehat → tidak sehat, sebagai penanda sesi.
 */
export function useScreenShareConnection(
  meeting: Meeting | null | undefined,
): ScreenShareConnection {
  const [state, setState] = useState<ConnectionState>(() =>
    readConnection(meeting).state,
  );
  const [roomJoined, setRoomJoined] = useState<boolean>(() =>
    readConnection(meeting).roomJoined,
  );
  const [generation, setGeneration] = useState(0);

  // Ref berisi meeting terbaru agar handler event lama tetap membaca objek
  // yang up-to-date tanpa perlu subscribe ulang.
  const meetingRef = useRef(meeting);
  meetingRef.current = meeting;
  const prevStateRef = useRef<ConnectionState>(state);

  // Subscribe ke event koneksi resmi RTK pada `meta`.
  useEffect(() => {
    if (!meeting) return;
    const meta = (
      meeting as unknown as {
        meta?: {
          on?: (e: string, h: (s: { state?: string }) => void) => void;
          off?: (e: string, h: (s: { state?: string }) => void) => void;
        };
      }
    )?.meta;
    if (!meta?.on) return;

    const onUpdate = (s: { state?: string }) => {
      const raw = s?.state;
      const next: ConnectionState =
        raw === 'disconnected' || raw === 'reconnecting' || raw === 'failed'
          ? raw
          : 'connected';
      setState(next);
    };
    meta.on('socketConnectionUpdate', onUpdate);
    // Sinkronkan dengan nilai awal dari getter saat mulai subscribe.
    setState(readConnection(meeting).state);
    return () => {
      try {
        meta.off?.('socketConnectionUpdate', onUpdate);
      } catch {
        /* ignore */
      }
    };
  }, [meeting]);

  // Sinkronkan roomJoined dari self saat meeting berubah / roomJoined berubah.
  const roomJoinedRaw = (
    meeting as unknown as { self?: { roomJoined?: boolean } }
  )?.self?.roomJoined;
  useEffect(() => {
    setRoomJoined(readConnection(meeting).roomJoined);
  }, [meeting, roomJoinedRaw]);

  // Naikkan generation saat koneksi berpindah dari sehat ke tidak sehat.
  useEffect(() => {
    const prev = prevStateRef.current;
    const nowHealthy = state === 'connected';
    const wasHealthy = prev === 'connected';
    if (wasHealthy && !nowHealthy) {
      setGeneration((g) => g + 1);
    }
    prevStateRef.current = state;
  }, [state]);

  const connected = state === 'connected';
  const canStartShare = connected && roomJoined;
  const connectionDegraded = !canStartShare;

  // Saat koneksi hilang dan share sedang aktif, hentikan secara lokal.
  // Cleanup ini tidak menunggu respons server (koneksi memang sedang putus).
  useEffect(() => {
    if (canStartShare) return;
    const self = meetingRef.current?.self;
    if (!self) return;
    try {
      if (self.screenShareEnabled) {
        void self.disableScreenShare().catch(() => {
          /* best-effort: koneksi memang sedang terputus */
        });
      }
    } catch {
      /* self tidak siap */
    }
  }, [canStartShare]);

  return {
    canStartShare,
    connectionDegraded,
    blockedReason: canStartShare ? null : DEGRADED_MESSAGE,
    generation,
  };
}
