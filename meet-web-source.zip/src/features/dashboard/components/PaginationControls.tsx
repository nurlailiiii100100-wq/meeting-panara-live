interface PaginationControlsProps {
  total: number;
  perPage: number;
  onPerPage: (n: number) => void;
  page: number;
  onPage: (n: number) => void;
  options?: number[];
}

export function PaginationControls({ total, perPage, onPerPage, page, onPage, options = [6, 10, 20, 50] }: PaginationControlsProps) {
  const totalPages = Math.max(1, Math.ceil(total / perPage));
  const safePage = Math.min(page, totalPages);
  if (total === 0) return null;
  const startItem = (safePage - 1) * perPage + 1;
  const endItem = Math.min(safePage * perPage, total);

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-4 pt-4 border-t border-slate-800">
      <div className="flex items-center gap-2 text-xs text-slate-400">
        <span>Tampilkan</span>
        <select
          value={perPage}
          onChange={(e) => {
            onPerPage(Number(e.target.value));
            onPage(1);
          }}
          className="px-2 py-1 bg-slate-800 border border-slate-700 text-slate-200 rounded cursor-pointer text-xs focus:outline-none focus:ring-1 focus:ring-emerald-600"
        >
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
        <span>dari {total} item ({startItem}–{endItem})</span>
      </div>
      {totalPages > 1 && (
        <div className="flex items-center gap-1">
          <button
            onClick={() => onPage(Math.max(1, safePage - 1))}
            disabled={safePage <= 1}
            className="px-2.5 py-1 text-xs border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            Prev
          </button>
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            let p: number;
            if (totalPages <= 5) p = i + 1;
            else if (safePage <= 3) p = i + 1;
            else if (safePage >= totalPages - 2) p = totalPages - 4 + i;
            else p = safePage - 2 + i;
            return (
              <button
                key={p}
                onClick={() => onPage(p)}
                className={`px-2.5 py-1 text-xs border rounded cursor-pointer transition-colors ${safePage === p ? 'border-emerald-600 bg-emerald-950 text-emerald-300 font-semibold' : 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
              >
                {p}
              </button>
            );
          })}
          <button
            onClick={() => onPage(Math.min(totalPages, safePage + 1))}
            disabled={safePage >= totalPages}
            className="px-2.5 py-1 text-xs border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
