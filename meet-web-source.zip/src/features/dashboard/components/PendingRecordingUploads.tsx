import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, Download, RefreshCw, Trash2, UploadCloud } from 'lucide-react';
import {
  deletePendingRecording,
  listPendingRecordings,
  type PendingRecording,
} from '../../../shared/utils/pendingUploads';
import { uploadRecordingBlob } from '../../../shared/utils/recordingUpload';
import { formatDuration, formatFileSize } from '../utils/recordingHelpers';

// Rekaman yang belum terkonfirmasi tersimpan di server (unggahan gagal /
// tab tertutup di tengah unggahan). Salinannya aman di IndexedDB browser ini —
// banner ini menawarkan kirim ulang, unduh, atau hapus per file.

interface PendingRecordingUploadsProps {
  /** Dipanggil setelah satu rekaman berhasil dikirim (untuk refresh daftar). */
  onUploaded?: () => void;
}

function downloadPending(record: PendingRecording): void {
  try {
    const url = URL.createObjectURL(record.blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = record.fileName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  } catch {
    /* browser menolak download — file tetap tersimpan */
  }
}

export function PendingRecordingUploads({ onUploaded }: PendingRecordingUploadsProps) {
  const [items, setItems] = useState<PendingRecording[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      setItems(await listPendingRecordings());
    } catch {
      setItems([]);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const handleRetry = useCallback(
    async (record: PendingRecording) => {
      setBusyId(record.id);
      setMessage(null);
      const ok = await uploadRecordingBlob(record.blob, {
        meetingId: record.meetingId,
        uploadToken: record.uploadToken,
        durationSeconds: record.durationSeconds,
        resolutionWidth: record.resolutionWidth,
        resolutionHeight: record.resolutionHeight,
        fileName: record.fileName,
      });
      if (ok) {
        try {
          await deletePendingRecording(record.id);
        } catch {
          /* abaikan */
        }
        setMessage(`Rekaman "${record.fileName}" berhasil dikirim ke server.`);
        onUploaded?.();
      } else {
        setMessage(`Rekaman "${record.fileName}" masih gagal dikirim. Coba lagi nanti atau unduh filenya.`);
      }
      setBusyId(null);
      void reload();
    },
    [onUploaded, reload]
  );

  const handleRemove = useCallback(
    async (record: PendingRecording) => {
      if (!window.confirm(`Hapus rekaman "${record.fileName}" yang belum terkirim?`)) return;
      try {
        await deletePendingRecording(record.id);
      } catch {
        /* abaikan */
      }
      void reload();
    },
    [reload]
  );

  if (items.length === 0) return null;

  return (
    <div className="mb-4 rounded border border-amber-700/70 bg-amber-950/40 p-3 sm:p-4">
      <div className="flex items-start gap-2 sm:gap-3">
        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" aria-hidden="true" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-amber-200">
            {items.length} rekaman belum terkirim ke server
          </p>
          <p className="text-xs text-amber-300/80 mt-0.5">
            File tetap aman di perangkat ini. Kirim ulang agar muncul di daftar rekaman, atau unduh
            kalau perlu.
          </p>

          <ul className="mt-3 space-y-2">
            {items.map((record) => (
              <li
                key={record.id}
                className="flex flex-wrap items-center gap-2 sm:gap-3 rounded border border-amber-800/70 bg-slate-900/60 px-3 py-2"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-slate-200 truncate">{record.fileName}</p>
                  <p className="text-[11px] text-slate-400">
                    {new Date(record.createdAt).toLocaleString('id-ID')} ·{' '}
                    {formatFileSize(record.blob.size)} · {formatDuration(record.durationSeconds)} ·
                    meeting {record.meetingId.slice(0, 8)}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => void handleRetry(record)}
                    disabled={busyId !== null}
                    className="inline-flex items-center gap-1 rounded border border-emerald-700 bg-emerald-900/60 px-2 py-1 text-[11px] font-medium text-emerald-200 hover:bg-emerald-900 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {busyId === record.id ? (
                      <RefreshCw className="w-3 h-3 animate-spin" aria-hidden="true" />
                    ) : (
                      <UploadCloud className="w-3 h-3" aria-hidden="true" />
                    )}
                    {busyId === record.id ? 'Mengirim...' : 'Kirim ulang'}
                  </button>
                  <button
                    onClick={() => downloadPending(record)}
                    title="Unduh file"
                    className="inline-flex items-center gap-1 rounded border border-slate-700 bg-slate-800/80 px-2 py-1 text-[11px] text-slate-300 hover:text-slate-100 cursor-pointer"
                  >
                    <Download className="w-3 h-3" aria-hidden="true" />
                    Unduh
                  </button>
                  <button
                    onClick={() => void handleRemove(record)}
                    title="Hapus dari daftar"
                    className="inline-flex items-center gap-1 rounded border border-slate-700 bg-slate-800/80 px-2 py-1 text-[11px] text-slate-400 hover:text-red-300 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" aria-hidden="true" />
                    Hapus
                  </button>
                </div>
              </li>
            ))}
          </ul>

          {message && <p className="mt-2 text-xs text-emerald-300">{message}</p>}
        </div>
      </div>
    </div>
  );
}
