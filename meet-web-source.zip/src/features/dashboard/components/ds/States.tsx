import { AlertCircle, Inbox, Loader2 } from 'lucide-react';
import type { ReactNode } from 'react';
import { cx } from './util';

interface SkeletonProps {
  className?: string;
  /** Varian cepat: baris teks, kotak kartu. */
  variant?: 'text' | 'block';
}

/** Placeholder loading berbentuk meniru konten (bukan spinner layar penuh). */
export function Skeleton({ className, variant = 'text' }: SkeletonProps) {
  return (
    <div
      aria-hidden="true"
      className={cx(
        'ds-skeleton bg-slate-800 rounded-[var(--ds-r-control)]',
        variant === 'text' ? 'h-4 w-full' : 'h-20 w-full',
        className,
      )}
    />
  );
}

/** Spinner kecil untuk inline/loading tombol. */
export function Spinner({ className }: { className?: string }) {
  return (
    <Loader2 className={cx('w-5 h-5 animate-spin text-[var(--ds-accent-text)]', className)} aria-hidden="true" />
  );
}

interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  description?: ReactNode;
  /** CTA tunggal agar pengguna tahu langkah berikutnya. */
  action?: ReactNode;
  className?: string;
}

/** Kondisi kosong: ikon + penjelasan + satu aksi. */
export function EmptyState({ icon, title, description, action, className }: EmptyStateProps) {
  return (
    <div className={cx('flex flex-col items-center text-center px-4 py-10 sm:py-12 gap-2', className)}>
      <span className="text-[var(--ds-text-faint)] mb-1">
        {icon ?? <Inbox className="w-8 h-8" aria-hidden="true" />}
      </span>
      <p className="text-sm sm:text-base font-semibold text-[var(--ds-text)]">{title}</p>
      {description && (
        <p className="text-sm text-[var(--ds-text-faint)] max-w-sm leading-relaxed">{description}</p>
      )}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

interface ErrorStateProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  retryLabel?: string;
  className?: string;
}

/** Kondisi gagal: pesan jelas + penyebab singkat + tombol coba lagi. */
export function ErrorState({
  title = 'Terjadi kesalahan',
  message,
  onRetry,
  retryLabel = 'Coba lagi',
  className,
}: ErrorStateProps) {
  return (
    <div
      role="alert"
      className={cx(
        'flex flex-col items-center text-center gap-2 px-4 py-8 rounded-[var(--ds-r-card)]',
        'border border-red-800 bg-red-950/40',
        className,
      )}
    >
      <AlertCircle className="w-6 h-6 text-red-400" aria-hidden="true" />
      <p className="text-sm font-semibold text-red-300">{title}</p>
      <p className="text-xs text-red-400/90 max-w-md break-words leading-relaxed">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="ds-focus ds-transition mt-2 min-h-9 px-3 text-xs font-medium rounded-[var(--ds-r-control)] border border-red-700 bg-red-950 hover:bg-red-900 text-red-300 cursor-pointer"
        >
          {retryLabel}
        </button>
      )}
    </div>
  );
}
