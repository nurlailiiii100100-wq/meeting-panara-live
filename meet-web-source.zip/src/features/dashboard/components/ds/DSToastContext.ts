import { createContext, useContext } from 'react';
import type { DSToastType } from './toastTypes';

export interface DSToastContextValue {
  toast: (message: string, type?: DSToastType, durationMs?: number) => void;
}

export const DSToastContext = createContext<DSToastContextValue | null>(null);

/** Ambil aksi toast dashboard. Wajib berada di dalam DSToastProvider. */
export function useDSToast(): DSToastContextValue {
  const ctx = useContext(DSToastContext);
  if (!ctx) throw new Error('useDSToast harus dipakai di dalam DSToastProvider');
  return ctx;
}
