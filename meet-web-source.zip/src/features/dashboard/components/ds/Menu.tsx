import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import type { ReactNode, Ref } from 'react';
import { cx } from './util';

export interface DropdownMenuItem {
  id: string;
  label: string;
  icon?: React.ElementType;
  /** Aksi destruktif — tampil terpisah di bawah dengan gaya danger. */
  danger?: boolean;
  disabled?: boolean;
  onSelect: () => void;
}

interface DropdownMenuProps {
  /** Elemen pemicu; terima ref + handler dari menu. */
  trigger: (props: {
    ref: Ref<HTMLButtonElement>;
    onClick: () => void;
    'aria-haspopup': 'menu';
    'aria-expanded': boolean;
    'aria-controls'?: string;
  }) => ReactNode;
  items: DropdownMenuItem[];
  /** Label aksesibilitas untuk menu (role=menu). */
  label: string;
  /** Konten non-interaktif di atas daftar item (mis. identitas akun). */
  header?: ReactNode;
  /** Perataan terhadap pemicu. */
  align?: 'start' | 'end';
  className?: string;
}

/**
 * Menu titik-tiga berbasis portal (tidak terpotong container overflow-x),
 * tutup saat Esc / klik di luar / scroll, z-index 70 (maks ds: 90).
 */
export function DropdownMenu({ trigger, items, label, header, align = 'end', className }: DropdownMenuProps) {
  const menuId = useId();
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  const close = useCallback(() => {
    setOpen(false);
    setPos(null);
  }, []);

  const openMenu = useCallback(() => {
    setOpen(true);
    triggerRef.current?.focus();
  }, []);

  /* Posisi fixed diukur dari pemicu; dibalik bila keluar viewport. */
  useLayoutEffect(() => {
    if (!open) return;
    const anchor = triggerRef.current?.getBoundingClientRect();
    const menu = menuRef.current?.getBoundingClientRect();
    if (!anchor || !menu) return;
    const margin = 8;
    let top = anchor.bottom + 4;
    if (top + menu.height > window.innerHeight - margin) {
      top = Math.max(margin, anchor.top - menu.height - 4);
    }
    let left = align === 'end' ? anchor.right - menu.width : anchor.left;
    left = Math.min(Math.max(margin, left), Math.max(margin, window.innerWidth - menu.width - margin));
    setPos({ top, left });
  }, [open, align, items.length]);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (menuRef.current?.contains(t) || triggerRef.current?.contains(t)) return;
      close();
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        close();
        triggerRef.current?.focus();
      }
    };
    const onScrollOrResize = () => close();
    document.addEventListener('pointerdown', onPointerDown, true);
    document.addEventListener('keydown', onKeyDown);
    window.addEventListener('scroll', onScrollOrResize, true);
    window.addEventListener('resize', onScrollOrResize);
    return () => {
      document.removeEventListener('pointerdown', onPointerDown, true);
      document.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('scroll', onScrollOrResize, true);
      window.removeEventListener('resize', onScrollOrResize);
    };
  }, [open, close]);

  const active = items.filter(i => !i.danger);
  const danger = items.filter(i => i.danger);

  const renderItem = (item: DropdownMenuItem) => (
    <button
      key={item.id}
      type="button"
      role="menuitem"
      disabled={item.disabled}
      onClick={() => {
        item.onSelect();
        close();
      }}
      className={cx(
        'ds-focus ds-transition w-full flex items-center gap-2 px-3 py-2.5 text-sm text-left rounded-[var(--ds-r-control)]',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        item.danger
          ? 'text-red-400 hover:bg-red-950/60'
          : 'text-[var(--ds-text-muted)] hover:bg-[var(--ds-bg-hover)] hover:text-[var(--ds-text)]',
      )}
    >
      {item.icon && <item.icon className="w-4 h-4 shrink-0" aria-hidden="true" />}
      <span className="truncate">{item.label}</span>
    </button>
  );

  return (
    <>
      {trigger({
        ref: triggerRef,
        onClick: () => (open ? close() : openMenu()),
        'aria-haspopup': 'menu',
        'aria-expanded': open,
        'aria-controls': open ? menuId : undefined,
      })}
      {open &&
        createPortal(
          <div
            ref={menuRef}
            id={menuId}
            role="menu"
            aria-label={label}
            className={cx(
              'ds-z-dropdown ds-anim-dropdown fixed min-w-44 max-w-64 max-h-[min(70dvh,20rem)] overflow-y-auto rounded-[var(--ds-r-card)]',
              'bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-lg p-1',
              pos ? 'visible' : 'invisible',
              className,
            )}
            style={pos ? { top: pos.top, left: pos.left } : { top: -9999, left: -9999 }}
          >
            {header && (
              <div className="px-3 py-2.5 mb-1 border-b border-[var(--ds-border)]">{header}</div>
            )}
            {active.map(renderItem)}
            {danger.length > 0 && active.length > 0 && (
              <div className="my-1 border-t border-[var(--ds-border)]" role="separator" />
            )}
            {danger.map(renderItem)}
          </div>,
          document.body,
        )}
    </>
  );
}
