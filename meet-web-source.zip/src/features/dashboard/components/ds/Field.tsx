import { useId } from 'react';
import type {
  InputHTMLAttributes,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
  ReactNode,
} from 'react';
import { cx, FOCUS_VISIBLE } from './util';

/* Dasar visual input/select/textarea. 16px di mobile agar iOS tidak
   auto-zoom; 14px mulai tablet (sm). Border slate-500 lolos 3:1 di kedua tema. */
const CONTROL_CLASS =
  'ds-focus w-full rounded-[var(--ds-r-control)] border bg-[var(--ds-bg-raised)] px-3 py-2.5 text-base sm:text-sm ' +
  'text-[var(--ds-text)] placeholder:text-[var(--ds-text-faint)] border-[var(--ds-border-control)] ' +
  'focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed ' +
  'transition-colors';

const ERROR_CLASS = 'border-red-700 focus:border-red-700 focus:ring-red-600';

interface FieldShellProps {
  id: string;
  label: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  required?: boolean;
  /** Sembunyikan label secara visual (tetap terbaca pembaca layar). */
  hideLabel?: boolean;
  children: ReactNode;
}

function FieldShell({ id, label, hint, error, required, hideLabel, children }: FieldShellProps) {
  return (
    <div className="flex flex-col gap-1.5">
      <label
        htmlFor={id}
        className={cx('text-sm font-medium text-[var(--ds-text-muted)]', hideLabel && 'sr-only')}
      >
        {label}
        {required && (
          <span className="text-red-400 ml-0.5" aria-hidden="true">
            *
          </span>
        )}
      </label>
      {children}
      {error ? (
        <p id={`${id}-error`} className="text-xs text-red-400">
          {error}
        </p>
      ) : hint ? (
        <p id={`${id}-hint`} className="text-xs text-[var(--ds-text-faint)]">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

function describedBy(id: string, hint?: ReactNode, error?: ReactNode): string | undefined {
  const ids = [error ? `${id}-error` : null, !error && hint ? `${id}-hint` : null].filter(Boolean);
  return ids.length ? ids.join(' ') : undefined;
}

interface InputFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'id'> {
  label: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  hideLabel?: boolean;
  id?: string;
}

/** Input bertekstur label + hint/error + aria lengkap. */
export function Input({ label, hint, error, required, hideLabel, className, id, ...rest }: InputFieldProps) {
  const autoId = useId();
  const inputId = id ?? autoId;
  return (
    <FieldShell id={inputId} label={label} hint={hint} error={error} required={required} hideLabel={hideLabel}>
      <input
        id={inputId}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(inputId, hint, error)}
        className={cx(CONTROL_CLASS, error ? ERROR_CLASS : undefined, FOCUS_VISIBLE, className)}
        {...rest}
      />
    </FieldShell>
  );
}

interface TextareaFieldProps extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'id'> {
  label: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  id?: string;
}

export function Textarea({ label, hint, error, required, className, id, ...rest }: TextareaFieldProps) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  return (
    <FieldShell id={fieldId} label={label} hint={hint} error={error} required={required}>
      <textarea
        id={fieldId}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(fieldId, hint, error)}
        className={cx(CONTROL_CLASS, 'min-h-24 resize-y', error ? ERROR_CLASS : undefined, FOCUS_VISIBLE, className)}
        {...rest}
      />
    </FieldShell>
  );
}

interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface SelectFieldProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'id' | 'children'> {
  label: ReactNode;
  options: SelectOption[];
  hint?: ReactNode;
  error?: ReactNode;
  hideLabel?: boolean;
  id?: string;
}

export function Select({
  label,
  options,
  hint,
  error,
  required,
  hideLabel,
  className,
  id,
  ...rest
}: SelectFieldProps) {
  const autoId = useId();
  const selectId = id ?? autoId;
  return (
    <FieldShell id={selectId} label={label} hint={hint} error={error} required={required} hideLabel={hideLabel}>
      <select
        id={selectId}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(selectId, hint, error)}
        className={cx(CONTROL_CLASS, 'appearance-none pr-8 cursor-pointer', error ? ERROR_CLASS : undefined, FOCUS_VISIBLE, className)}
        {...rest}
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value} disabled={opt.disabled}>
            {opt.label}
          </option>
        ))}
      </select>
    </FieldShell>
  );
}

interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'id'> {
  label: ReactNode;
  id?: string;
}

/** Checkbox dengan label terklik (target sentuh ikut label). */
export function Checkbox({ label, className, id, ...rest }: CheckboxProps) {
  const autoId = useId();
  const inputId = id ?? autoId;
  return (
    <div className="flex items-center gap-2">
      <input
        id={inputId}
        type="checkbox"
        className={cx(
          'ds-focus size-4 shrink-0 rounded border-[var(--ds-border-control)] accent-emerald-600 cursor-pointer',
          className,
        )}
        {...rest}
      />
      <label htmlFor={inputId} className="text-sm text-[var(--ds-text-muted)] cursor-pointer select-none">
        {label}
      </label>
    </div>
  );
}
