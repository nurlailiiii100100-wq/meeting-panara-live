/** Gabungkan string conditional className (ringkas, tanpa dependency). */
export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/** Focus ring standar design system (kombinasikan dengan `ds-focus`). */
export const FOCUS_VISIBLE =
  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600';

/** Kelas dasar semua kontrol interaktif ds. */
export const CONTROL_BASE =
  'ds-focus ds-transition inline-flex items-center justify-center gap-2 rounded-[var(--ds-r-control)] font-medium cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed';
