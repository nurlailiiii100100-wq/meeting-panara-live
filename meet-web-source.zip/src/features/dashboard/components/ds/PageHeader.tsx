import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { cx } from './util';

export interface Crumb {
  label: string;
  /** Rute tujuan; crumb terakhir biasanya tanpa href. */
  href?: string;
  onClick?: () => void;
}

interface PageHeaderProps {
  title: string;
  /** Deskripsi singkat di bawah judul (opsional). */
  description?: ReactNode;
  /** Breadcrumb — kosongkan bila tidak perlu. */
  breadcrumb?: Crumb[];
  /** Aksi utama di kanan; di mobile turun jadi lebar penuh. */
  actions?: ReactNode;
  /** Badge/StatusPill di samping judul. */
  badge?: ReactNode;
  className?: string;
}

function CrumbLink({ crumb, isLast }: { crumb: Crumb; isLast: boolean }) {
  const cls = 'text-xs sm:text-sm hover:text-[var(--ds-text)] transition-colors';
  if (isLast) {
    return (
      <span aria-current="page" className="text-xs sm:text-sm text-[var(--ds-text)] font-medium">
        {crumb.label}
      </span>
    );
  }
  if (crumb.href) {
    return (
      <Link to={crumb.href} className={cls}>
        {crumb.label}
      </Link>
    );
  }
  return (
    <button type="button" onClick={crumb.onClick} className={cx('ds-focus rounded', cls)}>
      {crumb.label}
    </button>
  );
}

/** Header standar tiap halaman: breadcrumb + judul + deskripsi + aksi utama. */
export function PageHeader({ title, description, breadcrumb, actions, badge, className }: PageHeaderProps) {
  return (
    <div className={cx('flex flex-col gap-3 sm:gap-4', className)}>
      {breadcrumb && breadcrumb.length > 0 && (
        <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1 text-[var(--ds-text-faint)]">
          {breadcrumb.map((crumb, i) => (
            <span key={`${crumb.label}-${i}`} className="flex items-center gap-1">
              {i > 0 && <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />}
              <CrumbLink crumb={crumb} isLast={i === breadcrumb.length - 1} />
            </span>
          ))}
        </nav>
      )}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-lg sm:text-xl font-bold text-[var(--ds-text)] tracking-tight">{title}</h1>
            {badge}
          </div>
          {description && (
            <p className="mt-1 text-sm text-[var(--ds-text-faint)] leading-relaxed">{description}</p>
          )}
        </div>
        {actions && (
          /* Mobile: tombol aksi utama lebar penuh agar mudah dijangkau jempol. */
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center shrink-0 [&>*]:w-full sm:[&>*]:w-auto">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
