import type { ReactNode } from 'react';
import { cx } from './util';

interface CardProps {
  /** Judul kartu (opsional). */
  title?: ReactNode;
  /** Ikon di kiri judul. */
  icon?: ReactNode;
  /** Aksi kanan pada header (tombol, link "Lihat semua", dll). */
  actions?: ReactNode;
  className?: string;
  children: ReactNode;
}

/** Kartu permukaan standar: latar solid agar teks terbaca di atas animasi background. */
export function Card({ title, icon, actions, className, children }: CardProps) {
  return (
    <section
      className={cx(
        'rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-sm',
        className,
      )}
    >
      {(title || actions) && (
        <header className="flex items-center justify-between gap-3 px-4 sm:px-5 py-3.5 border-b border-[var(--ds-border)]">
          <h2 className="text-sm sm:text-base font-semibold text-[var(--ds-text)] flex items-center gap-2 min-w-0">
            {icon}
            <span className="truncate">{title}</span>
          </h2>
          {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
        </header>
      )}
      <div className="p-4 sm:p-5">{children}</div>
    </section>
  );
}

interface StatCardProps {
  label: ReactNode;
  value: ReactNode;
  /** Perubahan vs periode sebelumnya, mis. "+12%" / "-3 kelas". */
  delta?: { text: string; direction: 'up' | 'down' | 'flat'; tone?: 'good' | 'bad' | 'neutral' };
  icon?: ReactNode;
  /** Slot sparkline/visual kecil di kanan bawah. */
  visual?: ReactNode;
  /** Label tambahan di bawah nilai (mis. "vs minggu lalu"). */
  hint?: ReactNode;
  className?: string;
}

const DELTA_TONE: Record<'good' | 'bad' | 'neutral', string> = {
  good: 'text-emerald-400',
  bad: 'text-red-400',
  neutral: 'text-[var(--ds-text-faint)]',
};

/** KPI card: angka besar + delta + slot visual. Angka memakai tabular-nums. */
export function StatCard({ label, value, delta, icon, visual, hint, className }: StatCardProps) {
  const tone = delta?.tone ?? 'neutral';
  return (
    <article
      className={cx(
        'rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-sm p-4 sm:p-5 flex flex-col gap-2',
        className,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs sm:text-sm text-[var(--ds-text-faint)] font-medium">{label}</p>
        {icon && <span className="text-[var(--ds-accent-text)] shrink-0">{icon}</span>}
      </div>
      <p className="text-2xl sm:text-3xl font-semibold text-[var(--ds-text)] tabular-nums leading-tight">
        {value}
      </p>
      {(delta || hint) && (
        <div className="flex items-center gap-2 text-xs">
          {delta && (
            <span className={cx('inline-flex items-center gap-1 font-medium tabular-nums', DELTA_TONE[tone])}>
              {delta.direction === 'up' && <span aria-hidden="true">↑</span>}
              {delta.direction === 'down' && <span aria-hidden="true">↓</span>}
              {delta.text}
            </span>
          )}
          {hint && <span className="text-[var(--ds-text-faint)]">{hint}</span>}
        </div>
      )}
      {visual && <div className="mt-auto pt-1">{visual}</div>}
    </article>
  );
}
