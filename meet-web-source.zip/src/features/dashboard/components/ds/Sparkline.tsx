import { cx } from './util';

interface SparklineProps {
  /** Deret angka (mis. jumlah kelas per hari). */
  values: number[];
  width?: number;
  height?: number;
  className?: string;
}

/**
 * Sparkline SVG murni (tanpa library chart). Dekoratif — angka utama sudah
 * ditampilkan di StatCard, jadi disembunyikan dari pembaca layar.
 */
export function Sparkline({ values, width = 96, height = 28, className }: SparklineProps) {
  if (values.length < 2) return null;

  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const stepX = width / (values.length - 1);
  const pad = 2;

  const points = values.map((v, i) => {
    const x = i * stepX;
    const y = height - pad - ((v - min) / span) * (height - pad * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const areaPoints = `${points.join(' ')} ${width},${height} 0,${height}`;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      width={width}
      height={height}
      preserveAspectRatio="none"
      aria-hidden="true"
      focusable="false"
      className={cx('overflow-visible', className)}
    >
      <polygon points={areaPoints} className="fill-emerald-500/15" />
      <polyline
        points={points.join(' ')}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-emerald-400"
      />
    </svg>
  );
}
