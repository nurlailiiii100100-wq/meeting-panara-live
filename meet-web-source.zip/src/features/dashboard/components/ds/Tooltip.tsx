import { cloneElement, useCallback, useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import type { ReactElement, ReactNode } from 'react';
import { cx } from './util';

type Side = 'top' | 'bottom' | 'left' | 'right';

interface TooltipProps {
  content: ReactNode;
  side?: Side;
  /** Nilai bila konten kosong. */
  disabled?: boolean;
  children: ReactElement;
}

const HIDE_DELAY = 100;

/**
 * Tooltip dashboard: hover + keyboard focus, portal (tidak terpotong overflow),
 * z-index 90. Komponen Tooltip lama tetap dipakai Meeting dan tidak diubah.
 */
export function Tooltip({ content, side = 'top', disabled, children }: TooltipProps) {
  const id = useId();
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const anchorRef = useRef<HTMLElement | null>(null);
  const bubbleRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = useCallback(() => {
    if (disabled) return;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setOpen(true), 40);
  }, [disabled]);

  const hide = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      setOpen(false);
      setPos(null);
    }, HIDE_DELAY);
  }, []);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const anchor = anchorRef.current?.getBoundingClientRect();
    const bubble = bubbleRef.current?.getBoundingClientRect();
    if (!anchor || !bubble) return;
    const gap = 8;
    let top: number;
    let left: number;
    if (side === 'left' || side === 'right') {
      top = anchor.top + anchor.height / 2 - bubble.height / 2;
      left = side === 'left' ? anchor.left - bubble.width - gap : anchor.right + gap;
      // Balik bila keluar viewport
      if (top < gap) top = gap;
      if (top + bubble.height > window.innerHeight - gap) {
        top = Math.max(gap, window.innerHeight - bubble.height - gap);
      }
      if (left < gap) left = anchor.right + gap;
      if (left + bubble.width > window.innerWidth - gap) {
        left = Math.max(gap, anchor.left - bubble.width - gap);
      }
    } else {
      top = side === 'top' ? anchor.top - bubble.height - gap : anchor.bottom + gap;
      if (top < gap) top = anchor.bottom + gap;
      if (top + bubble.height > window.innerHeight - gap) {
        top = Math.max(gap, anchor.top - bubble.height - gap);
      }
      left = Math.min(
        Math.max(gap, anchor.left + anchor.width / 2 - bubble.width / 2),
        Math.max(gap, window.innerWidth - bubble.width - gap),
      );
    }
    setPos({ top, left });
    const onScroll = () => setOpen(false);
    window.addEventListener('scroll', onScroll, true);
    return () => window.removeEventListener('scroll', onScroll, true);
  }, [open, side]);

  if (disabled || !content) return children;

  const child = cloneElement(children, {
    ref: (node: HTMLElement | null) => {
      anchorRef.current = node;
      const r = (children as unknown as { ref?: unknown }).ref;
      if (typeof r === 'function') r(node);
      else if (r && typeof r === 'object') (r as { current: HTMLElement | null }).current = node;
    },
    onPointerEnter: show,
    onPointerLeave: hide,
    onFocus: show,
    onBlur: hide,
    'aria-describedby': open ? id : undefined,
  } as Partial<unknown>);

  return (
    <>
      {child}
      {open &&
        createPortal(
          <div
            ref={bubbleRef}
            id={id}
            role="tooltip"
            className={cx(
              'ds-z-tooltip fixed px-2 py-1 rounded text-xs font-medium leading-snug pointer-events-none',
              'bg-slate-800 text-slate-100 border border-slate-700 shadow-md max-w-56',
              pos ? 'visible' : 'invisible',
            )}
            style={pos ? { top: pos.top, left: pos.left } : { top: -9999, left: -9999 }}
          >
            {content}
          </div>,
          document.body,
        )}
    </>
  );
}
