import { AlertTriangle, Trash2 } from 'lucide-react';
import { Modal } from './Modal';
import { Button } from './Button';

interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  /**
   * Pesan wajib menyebut OBJEK dan DAMPAKNYA, contoh:
   * "Hapus pengguna Budi? Data riwayatnya tetap tersimpan, tetapi ia tidak
   * bisa login lagi."
   */
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'warning';
  loading?: boolean;
}

/** Konfirmasi aksi berbahaya — objek + dampak disebut eksplisit. */
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = 'Ya, lanjutkan',
  cancelLabel = 'Batal',
  variant = 'danger',
  loading = false,
}: ConfirmDialogProps) {
  const Icon = variant === 'danger' ? Trash2 : AlertTriangle;
  const iconColor = variant === 'danger' ? 'text-red-400' : 'text-amber-400';

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      icon={<Icon className={`w-5 h-5 ${iconColor}`} aria-hidden="true" />}
      maxWidth="max-w-md"
      busy={loading}
      showClose={false}
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={loading}>
            {cancelLabel}
          </Button>
          <Button
            variant={variant === 'danger' ? 'danger' : 'primary'}
            onClick={onConfirm}
            loading={loading}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <p className="text-sm text-[var(--ds-text-muted)] leading-relaxed">{message}</p>
    </Modal>
  );
}
