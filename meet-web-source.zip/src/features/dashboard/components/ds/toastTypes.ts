export type DSToastType = 'success' | 'error' | 'warning' | 'info';
