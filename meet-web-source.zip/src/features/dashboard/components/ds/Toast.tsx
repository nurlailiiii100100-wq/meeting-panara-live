import { useCallback, useMemo, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle, Info, X } from 'lucide-react';
import type { ReactNode } from 'react';
import { DSToastContext } from './DSToastContext';
import type { DSToastType } from './toastTypes';
import { cx } from './util';

interface DSToastItem {
  id: number;
  message: string;
  type: DSToastType;
}

const TYPE_ICON: Record<DSToastType, ReactNode> = {
  success: <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" aria-hidden="true" />,
  error: <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" aria-hidden="true" />,
  warning: <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" aria-hidden="true" />,
  info: <Info className="w-4 h-4 text-sky-400 shrink-0" aria-hidden="true" />,
};

const TYPE_BORDER: Record<DSToastType, string> = {
  success: 'border-emerald-700',
  error: 'border-red-700',
  warning: 'border-amber-700',
  info: 'border-sky-700',
};

/**
 * Provider toast khusus dashboard (z-index 90; toast global lama dipakai
 * Meeting dan tidak diubah). Pasang di dalam app shell — bukan di App root.
 */
export function DSToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<DSToastItem[]>([]);
  const counter = useRef(0);

  const remove = useCallback((id: number) => {
    setItems(prev => prev.filter(t => t.id !== id));
  }, []);

  const toast = useCallback(
    (message: string, type: DSToastType = 'info', durationMs = 4000) => {
      const id = ++counter.current;
      setItems(prev => [...prev, { id, message, type }]);
      if (durationMs > 0) {
        window.setTimeout(() => remove(id), durationMs);
      }
    },
    [remove],
  );

  const value = useMemo(() => ({ toast }), [toast]);

  return (
    <DSToastContext.Provider value={value}>
      {children}
      <div className="ds-z-tooltip fixed top-4 left-4 right-4 sm:left-auto sm:w-80 max-w-sm flex flex-col gap-2 pointer-events-none">
        {items.map(item => (
          <div
            key={item.id}
            role={item.type === 'error' ? 'alert' : 'status'}
            aria-live={item.type === 'error' ? 'assertive' : 'polite'}
            className={cx(
              'ds-anim-toast pointer-events-auto flex items-start gap-2 rounded-[var(--ds-r-card)]',
              'bg-[var(--ds-bg-card)] border px-3 py-2.5 shadow-lg',
              TYPE_BORDER[item.type],
            )}
          >
            {TYPE_ICON[item.type]}
            <p className="flex-1 text-xs sm:text-sm text-[var(--ds-text-muted)] leading-relaxed">{item.message}</p>
            <button
              type="button"
              onClick={() => remove(item.id)}
              aria-label="Tutup notifikasi"
              className="ds-focus p-0.5 -m-0.5 rounded text-[var(--ds-text-faint)] hover:text-[var(--ds-text)] cursor-pointer shrink-0"
            >
              <X className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>
        ))}
      </div>
    </DSToastContext.Provider>
  );
}
