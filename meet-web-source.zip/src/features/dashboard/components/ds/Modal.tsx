import { useCallback, useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import type { ReactNode } from 'react';
import { cx } from './util';

const FOCUSABLE =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  icon?: ReactNode;
  children: ReactNode;
  /** Tombol footer (Simpan/Batal, dsb). */
  footer?: ReactNode;
  maxWidth?: string;
  /** Sembunyikan tombol silang (untuk dialog aksi). */
  showClose?: boolean;
  /** Nonaktifkan tutup via Esc/overlay (saat proses berjalan). */
  busy?: boolean;
  /** Layar penuh di mobile (untuk form panjang) — desktop tetap dialog. */
  fullscreenMobile?: boolean;
}

/**
 * Modal dashboard: focus trap penuh, Esc, kunci scroll sementara lewat
 * class <html>, portal ke body, z-index 80. Tanpa backdrop-filter luas.
 * Header & footer tidak ikut scroll — hanya isi yang bergulir, sehingga
 * footer Simpan/Batal selalu menempel di bawah.
 */
export function Modal({
  open,
  onClose,
  title,
  icon,
  children,
  footer,
  maxWidth = 'max-w-lg',
  showClose = true,
  busy = false,
  fullscreenMobile = false,
}: ModalProps) {
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const restoreRef = useRef<HTMLElement | null>(null);

  const close = useCallback(() => {
    if (!busy) onClose();
  }, [busy, onClose]);

  /* Kunci scroll + simpan elemen fokus awal. */
  useEffect(() => {
    if (!open) return;
    restoreRef.current = document.activeElement as HTMLElement | null;
    document.documentElement.classList.add('ds-scroll-locked');
    const t = setTimeout(() => {
      const first = dialogRef.current?.querySelector<HTMLElement>(FOCUSABLE);
      (first ?? dialogRef.current)?.focus();
    }, 0);
    return () => {
      clearTimeout(t);
      document.documentElement.classList.remove('ds-scroll-locked');
      restoreRef.current?.focus();
    };
  }, [open]);

  /* Esc + focus trap (Tab berputar di dalam dialog). */
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        close();
        return;
      }
      if (e.key !== 'Tab') return;
      const nodes = dialogRef.current?.querySelectorAll<HTMLElement>(FOCUSABLE);
      if (!nodes || nodes.length === 0) return;
      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      const active = document.activeElement;
      if (e.shiftKey && (active === first || active === dialogRef.current)) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKeyDown, true);
    return () => document.removeEventListener('keydown', onKeyDown, true);
  }, [open, close]);

  if (!open) return null;

  return createPortal(
    <div
      className={cx(
        'ds-z-modal fixed inset-0 flex items-center justify-center bg-slate-950/70',
        fullscreenMobile ? 'p-0 sm:p-4' : 'p-3 sm:p-4',
      )}
      onPointerDown={e => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cx(
          'ds-anim-modal ds-focus w-full outline-none flex flex-col overflow-hidden',
          'rounded-[var(--ds-r-modal)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-2xl',
          fullscreenMobile
            ? 'h-dvh max-h-dvh rounded-none border-0 sm:h-auto sm:max-h-[calc(100dvh-2rem)] sm:rounded-[var(--ds-r-modal)] sm:border'
            : 'max-h-[calc(100dvh-2rem)]',
          maxWidth,
        )}
      >
        <header className="shrink-0 flex items-center justify-between gap-3 px-4 sm:px-6 pt-4 sm:pt-5 pb-3.5 border-b border-[var(--ds-border)]">
          <h2 id={titleId} className="text-base sm:text-lg font-bold text-[var(--ds-text)] flex items-center gap-2 min-w-0">
            {icon}
            <span className="truncate">{title}</span>
          </h2>
          {showClose && (
            <button
              type="button"
              onClick={close}
              disabled={busy}
              aria-label="Tutup"
              className="ds-focus ds-transition p-2 -m-1 rounded-[var(--ds-r-control)] text-[var(--ds-text-faint)] hover:text-[var(--ds-text)] hover:bg-[var(--ds-bg-hover)] cursor-pointer disabled:opacity-50"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          )}
        </header>
        <div className="flex-1 min-h-0 overflow-y-auto px-4 sm:px-6 py-4">{children}</div>
        {footer && (
          /* Mobile: Batal di atas, aksi utama di bawah (mudah dijangkau jempol);
             footer tidak ikut scroll — menempel di bawah dialog. */
          <footer className="shrink-0 flex flex-col gap-2 sm:flex-row sm:justify-end px-4 sm:px-6 py-4 border-t border-[var(--ds-border)] bg-[var(--ds-bg-card)]">
            {footer}
          </footer>
        )}
      </div>
    </div>,
    document.body,
  );
}
