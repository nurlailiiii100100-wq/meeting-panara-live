import type { ButtonHTMLAttributes, ReactNode, RefAttributes } from 'react';
import { Loader2 } from 'lucide-react';
import { cx, CONTROL_BASE } from './util';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg' | 'icon';

interface ButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'>,
    RefAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Tampilkan spinner & cegah klik ganda tanpa mengubah tipe. */
  loading?: boolean;
  /** Ikon di kiri label (dipertahankan saat loading). */
  icon?: ReactNode;
  children?: ReactNode;
}

const VARIANT_CLASS: Record<ButtonVariant, string> = {
  primary:
    'bg-[var(--ds-accent)] hover:bg-[var(--ds-accent-hover)] active:bg-[var(--ds-accent-hover)] text-white border border-transparent',
  secondary:
    'bg-[var(--ds-bg-raised)] hover:bg-slate-700 text-slate-200 border border-[var(--ds-border-control)]',
  ghost:
    'bg-transparent hover:bg-[var(--ds-bg-hover)] text-slate-300 hover:text-slate-100 border border-transparent',
  danger:
    'bg-[var(--ds-danger)] hover:bg-[var(--ds-danger-hover)] text-white border border-transparent',
};

const SIZE_CLASS: Record<ButtonSize, string> = {
  // sm tetap 44px di layar sentuh (target sentuh), 36px mulai tablet.
  sm: 'min-h-11 sm:min-h-9 px-3 text-sm',
  md: 'min-h-11 sm:min-h-10 px-4 text-sm',
  lg: 'min-h-12 px-5 text-base',
  // Target sentuh 44px di layar sentuh, 40px di desktop.
  icon: 'min-h-11 min-w-11 sm:min-h-10 sm:min-w-10 p-0',
};

/**
 * Tombol standar dashboard.
 * - primary = emerald-700/800 (warna aksen yang sudah dipakai dashboard)
 * - loading: spinner + aria-busy + disabled otomatis (anti klik ganda)
 */
export function Button({
  variant = 'secondary',
  size = 'md',
  loading = false,
  icon,
  className,
  children,
  disabled,
  type = 'button',
  ...rest
}: ButtonProps) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cx(CONTROL_BASE, VARIANT_CLASS[variant], SIZE_CLASS[size], className)}
      {...rest}
    >
      {loading ? (
        <Loader2 className="w-4 h-4 shrink-0 animate-spin" aria-hidden="true" />
      ) : (
        icon
      )}
      {children}
    </button>
  );
}
