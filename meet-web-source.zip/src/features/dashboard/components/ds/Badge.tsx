import type { ReactNode } from 'react';
import { cx } from './util';

export type BadgeTone = 'success' | 'danger' | 'warning' | 'info' | 'accent' | 'neutral';

interface BadgeProps {
  tone?: BadgeTone;
  /** Ikon di kiri teks — status tidak boleh hanya mengandalkan warna. */
  icon?: ReactNode;
  className?: string;
  children: ReactNode;
}

/* Pasangan bg/border/text dari family warna yang sudah dipakai dashboard;
   950/700/300 adalah shade yang sudah di-remap html.light. */
const TONE_CLASS: Record<BadgeTone, string> = {
  success: 'bg-emerald-950 border-emerald-700 text-emerald-300',
  danger: 'bg-red-950 border-red-700 text-red-300',
  warning: 'bg-amber-950 border-amber-700 text-amber-300',
  info: 'bg-sky-950 border-sky-700 text-sky-300',
  accent: 'bg-violet-950 border-violet-700 text-violet-300',
  neutral: 'bg-slate-800 border-slate-700 text-slate-300',
};

/** Pill status: ikon + teks + warna (bukan warna saja). */
export function Badge({ tone = 'neutral', icon, className, children }: BadgeProps) {
  return (
    <span
      className={cx(
        'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium whitespace-nowrap',
        TONE_CLASS[tone],
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}
