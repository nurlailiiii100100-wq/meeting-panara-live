import { useState, useEffect, useCallback, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Plus, Edit2, Power, RefreshCw, ShieldCheck, AlertCircle } from 'lucide-react';
import { useToast, Modal, ConfirmDialog } from '../../../shared';

interface AdminAccount {
  id: string;
  username: string;
  name: string | null;
  email: string | null;
  role: 'admin' | 'superadmin';
  active: number;
  created_at: string;
}

type FormMode = 'create' | 'edit';

const inputCls =
  'w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-500';

export function ManageAdmins() {
  const navigate = useNavigate();
  const { addToast } = useToast();

  const [admins, setAdmins] = useState<AdminAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formMode, setFormMode] = useState<FormMode | null>(null);
  const [target, setTarget] = useState<AdminAccount | null>(null);
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [toggleTarget, setToggleTarget] = useState<AdminAccount | null>(null);

  const fetchAdmins = useCallback(async () => {
    try {
      const res = await fetch('/api/admins', { credentials: 'include' });
      if (res.status === 401) { navigate('/admin/login'); return; }
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        addToast(data?.message || 'Gagal memuat daftar admin', 'error');
        return;
      }
      const data = await res.json() as { admins?: AdminAccount[] };
      setAdmins(data.admins || []);
    } catch {
      addToast('Gagal memuat daftar admin', 'error');
    } finally {
      setLoading(false);
    }
  }, [navigate, addToast]);

  useEffect(() => { fetchAdmins(); }, [fetchAdmins]);

  const openCreate = () => {
    setFormMode('create');
    setTarget(null);
    setUsername('');
    setName('');
    setEmail('');
    setPassword('');
    setConfirm('');
    setFormError(null);
  };

  const openEdit = (a: AdminAccount) => {
    setFormMode('edit');
    setTarget(a);
    setUsername(a.username);
    setName(a.name || '');
    setEmail(a.email || '');
    setFormError(null);
  };

  const closeForm = () => { setFormMode(null); setTarget(null); setFormError(null); };

  const submitForm = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setFormError(null);

    if (!username.trim()) { setFormError('Username wajib diisi.'); return; }
    if (email.trim() && !email.includes('@')) { setFormError('Email tidak valid.'); return; }
    if (formMode === 'create' && password.length < 8) { setFormError('Password minimal 8 karakter.'); return; }
    if (formMode === 'create' && password !== confirm) { setFormError('Password tidak sama.'); return; }

    setSaving(true);
    try {
      let res: Response;
      if (formMode === 'create') {
        res = await fetch('/api/admins', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ username: username.trim(), name: name.trim(), email: email.trim(), password })
        });
      } else if (formMode === 'edit' && target) {
        res = await fetch(`/api/admins/${encodeURIComponent(target.id)}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ username: username.trim(), name: name.trim(), email: email.trim() })
        });
      } else {
        return;
      }

      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setFormError(data?.message || data?.error || 'Gagal menyimpan');
        return;
      }
      addToast(
        formMode === 'create' ? 'Admin berhasil ditambahkan' : 'Admin berhasil diperbarui',
        'success'
      );
      closeForm();
      fetchAdmins();
    } catch {
      setFormError('Gagal terhubung ke server');
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async () => {
    if (!toggleTarget) return;
    try {
      const res = await fetch(`/api/admins/${encodeURIComponent(toggleTarget.id)}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ active: !(toggleTarget.active === 1) })
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        addToast(data?.message || 'Gagal mengubah status admin', 'error');
        return;
      }
      addToast(toggleTarget.active === 1 ? 'Admin dinonaktifkan' : 'Admin diaktifkan', 'success');
      fetchAdmins();
    } catch {
      addToast('Gagal terhubung ke server', 'error');
    } finally {
      setToggleTarget(null);
    }
  };

  const inputGroup = (label: string, node: React.ReactNode) => (
    <div className="mb-4">
      <label className="block text-sm text-slate-300 mb-1">{label}</label>
      {node}
    </div>
  );

  return (
    <div className="bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
          <Users className="w-5 h-5 text-emerald-400" />
          Kelola Admin
        </h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setLoading(true); fetchAdmins(); }}
            className="px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-200 text-sm hover:bg-slate-700 cursor-pointer flex items-center gap-1.5"
            title="Muat ulang"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={openCreate}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold cursor-pointer flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Tambah Admin
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-10 text-center text-slate-400 text-sm">Memuat daftar admin...</div>
      ) : admins.length === 0 ? (
        <div className="py-10 text-center text-slate-400 text-sm">Belum ada akun admin.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-700 text-xs uppercase tracking-wide text-slate-400">
                <th className="py-3 px-2">Username</th>
                <th className="py-3 px-2">Nama</th>
                <th className="py-3 px-2">Email</th>
                <th className="py-3 px-2">Status</th>
                <th className="py-3 px-2 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {admins.map((a) => {
                const isActive = a.active === 1;
                return (
                  <tr key={a.id} className="border-b border-slate-800 hover:bg-slate-800/40">
                    <td className="py-3 px-2 text-sm text-slate-100">
                      <span className="flex items-center gap-1.5">
                        {a.username}
                        {a.role === 'superadmin' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300">
                            <ShieldCheck className="w-3 h-3" />
                            Superadmin
                          </span>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-2 text-sm text-slate-300">{a.name || '—'}</td>
                    <td className="py-3 px-2 text-sm text-slate-300">{a.email || '—'}</td>
                    <td className="py-3 px-2 text-sm">
                      <span className={`px-2 py-0.5 text-xs font-semibold rounded border ${isActive
                        ? 'bg-emerald-950 border-emerald-700 text-emerald-300'
                        : 'bg-slate-800 border-slate-600 text-slate-400'}`}>
                        {isActive ? 'Aktif' : 'Nonaktif'}
                      </span>
                    </td>
                    <td className="py-3 px-2 text-sm text-right whitespace-nowrap">
                      {a.role === 'superadmin' ? (
                        <span className="text-xs text-slate-500">Akun utama</span>
                      ) : (
                        <span className="inline-flex gap-1.5">
                          <button
                            onClick={() => openEdit(a)}
                            className="px-2 py-1 border-2 border-slate-700 bg-slate-800 text-slate-200 text-xs hover:bg-slate-700 cursor-pointer inline-flex items-center gap-1"
                          >
                            <Edit2 className="w-3 h-3" /> Edit
                          </button>
                          <button
                            onClick={() => setToggleTarget(a)}
                            className={`px-2 py-1 border-2 text-xs cursor-pointer inline-flex items-center gap-1 ${isActive
                              ? 'border-rose-800 bg-rose-950 text-rose-300 hover:bg-rose-900'
                              : 'border-emerald-800 bg-emerald-950 text-emerald-300 hover:bg-emerald-900'}`}
                          >
                            <Power className="w-3 h-3" /> {isActive ? 'Nonaktifkan' : 'Aktifkan'}
                          </button>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal tambah / edit */}
      <Modal
        open={formMode === 'create' || formMode === 'edit'}
        onClose={closeForm}
        title={formMode === 'create' ? 'Tambah Admin' : 'Edit Admin'}
        icon={<Users className="w-5 h-5 text-emerald-400" />}
      >
        <form onSubmit={submitForm} className="pt-4">
          {inputGroup('Username', (
            <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className={inputCls} autoFocus />
          ))}
          {inputGroup('Nama', (
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} className={inputCls} placeholder="Nama lengkap (opsional)" />
          ))}
          {inputGroup('Email', (
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={inputCls} placeholder="email@contoh.com (opsional)" />
          ))}
          {formMode === 'create' && (
            <>
              {inputGroup('Password', (
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className={inputCls} placeholder="Minimal 8 karakter" />
              ))}
              {inputGroup('Ulangi Password', (
                <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className={inputCls} />
              ))}
            </>
          )}
          {formError && (
            <p className="text-sm text-rose-400 mb-3 flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0" /> {formError}
            </p>
          )}
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button type="button" onClick={closeForm} className="px-4 py-2 border-2 border-slate-700 bg-slate-800 text-slate-200 text-sm hover:bg-slate-700 cursor-pointer">
              Batal
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold cursor-pointer disabled:opacity-50">
              {saving ? 'Menyimpan...' : formMode === 'create' ? 'Tambah' : 'Simpan'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={toggleTarget !== null}
        onClose={() => setToggleTarget(null)}
        onConfirm={toggleActive}
        title={toggleTarget?.active === 1 ? 'Nonaktifkan Admin' : 'Aktifkan Admin'}
        message={toggleTarget?.active === 1
          ? `Akun "${toggleTarget?.username}" tidak akan bisa login selama nonaktif. Data meeting/preset tetap aman. Lanjutkan?`
          : `Aktifkan kembali akun "${toggleTarget?.username}"?`}
        confirmLabel={toggleTarget?.active === 1 ? 'Nonaktifkan' : 'Aktifkan'}
        variant={toggleTarget?.active === 1 ? 'danger' : 'warning'}
      />
    </div>
  );
}
