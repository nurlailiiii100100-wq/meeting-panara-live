import { useState, useEffect } from 'react';
import { Check, Play, Download } from 'lucide-react';
import type { RecordingItem, MeetingItem } from '../types/dashboard.types';
import {
  formatDuration,
  formatFileSize,
  formatResolution,
  getRecordingCountdown,
  getRecordingStatusBadge,
  getRecordingDisplayName,
} from '../utils/recordingHelpers';

export function RecordingCard({
  recording,
  meetings,
  onPlay,
}: {
  recording: RecordingItem;
  meetings: MeetingItem[];
  onPlay: (rec: RecordingItem) => void;
}) {
  const [countdown, setCountdown] = useState(getRecordingCountdown(recording.expires_at));

  useEffect(() => {
    if (recording.status !== 'ready') return;
    const timer = setInterval(() => {
      setCountdown(getRecordingCountdown(recording.expires_at));
    }, 60000);
    return () => clearInterval(timer);
  }, [recording.expires_at, recording.status]);

  const meetingName = meetings.find(m => m.id === recording.meeting_id)?.name || 'Unknown Meeting';
  const displayName = getRecordingDisplayName(recording, meetingName);
  const isReady = recording.status === 'ready';
  const isExpired = countdown.expired || recording.status === 'expired';
  const resolution = formatResolution(recording.resolution_width, recording.resolution_height);

  return (
    <div className="p-4 bg-slate-800/80 border border-slate-700 rounded-lg hover:border-slate-600 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm text-slate-100 truncate">{displayName}</h3>
          <p className="text-xs text-slate-400 truncate">Meeting: {meetingName}</p>
        </div>
        <div className="flex items-center gap-1.5">
          {(recording.download_count ?? 0) > 0 ? (
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-400" title={`${recording.download_count}x downloaded`}>
              <Check className="w-3 h-3 text-emerald-400" />
            </span>
          ) : (
            <span className="text-slate-500" title="Belum didownload">
              <Check className="w-4 h-4" />
            </span>
          )}
          {recording.source === 'auto' && (
            <span className="px-1.5 py-0.5 text-[10px] font-medium rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30" title="Direkam otomatis oleh VPS recorder">
              Otomatis
            </span>
          )}
          {getRecordingStatusBadge(recording.status)}
        </div>
      </div>

      <div className="space-y-1 text-xs text-slate-400 mb-3">
        {recording.duration_seconds != null && (
          <p>Duration: <span className="text-slate-200">{formatDuration(recording.duration_seconds)}</span></p>
        )}
        {recording.size_bytes != null && (
          <p>Size: <span className="text-slate-200">{formatFileSize(recording.size_bytes)}</span></p>
        )}
        {resolution && (
          <p>Resolution: <span className="text-slate-200">{resolution}</span></p>
        )}
        {recording.status === 'ready' && !isExpired && (
          <p className={countdown.urgent ? 'text-amber-400' : ''}>
            Video akan dihapus dalam: <span className="text-slate-200 font-medium">{countdown.text}</span>
          </p>
        )}
        {isExpired && <p className="text-red-400">Recording expired</p>}
        {recording.status === 'processing' && <p className="text-amber-400">Video sedang diproses...</p>}
        {recording.status === 'failed' && <p className="text-red-400">Recording gagal diproses</p>}
      </div>

      <div className="flex items-center gap-2 pt-2 border-t border-slate-700/50">
        {isReady && !isExpired && (
          <>
            <button
              onClick={() => onPlay(recording)}
              className="flex-1 py-1.5 text-xs border border-emerald-700 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 rounded font-medium inline-flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <Play className="w-3 h-3" />
              Play
            </button>
            <a
              href={`/api/recordings/${recording.id}/download`}
              className="flex-1 py-1.5 text-xs border border-slate-600 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium inline-flex items-center justify-center gap-1 transition-colors"
              download={displayName}
            >
              <Download className="w-3 h-3" />
              Download
            </a>
          </>
        )}
        {recording.status === 'processing' && (
          <div className="flex-1 py-1.5 text-xs text-center text-amber-400 italic">Menunggu proses...</div>
        )}
        {(recording.status === 'failed' || isExpired) && (
          <div className="flex-1 py-1.5 text-xs text-center text-slate-500 italic">Tidak tersedia</div>
        )}
      </div>
    </div>
  );
}
