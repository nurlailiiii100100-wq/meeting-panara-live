import type { CategoryItem } from '../types/dashboard.types';

export const VALID_RESOLUTIONS = ['140p', '240p', '360p', '480p', '720p', '1080p'];
// Resolusi screen share: cuma 2 pilihan (sama dengan opsi di form Add Meeting)
export const VALID_SHARE_RESOLUTIONS = ['480p', '720p'];

// --- Bulk import dari file Excel ---

export type BulkMeetingRow = {
  name: string;
  publicId: string;
  scheduleMode: 'alltime' | 'scheduled';
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  // Override per baris dari file Excel (undefined = ikut Preset/Kategori global)
  maxParticipants?: number;
  durationMinutes?: number;
  hostResolution?: string;
  memberResolution?: string;
  screenshareResolution?: string;
  categoryId?: string;
  maxActiveCameras?: number;
  autoRecord?: boolean;
  kickCooldownMinutes?: number;
  lateJoinMinutes?: number;
  hostJoinCode?: string;
  tentors?: string[];
  retentionHours?: number;
  scheduleWarning?: boolean; // jadwal tidak terbaca → dipaksa All Time
};

export const cellText = (v: unknown): string => (v == null ? '' : String(v).trim());

export const cellNumber = (v: unknown, min: number, max: number): number | undefined => {
  const text = cellText(v);
  if (!text) return undefined; // sel kosong = ikut preset/default, bukan 0
  const n = Number(text.replace(',', '.'));
  return Number.isFinite(n) && n >= min && n <= max ? Math.floor(n) : undefined;
};

export const cellResolution = (v: unknown): string | undefined => {
  const s = cellText(v).toLowerCase();
  return VALID_RESOLUTIONS.find(r => r === s);
};

export const cellShareResolution = (v: unknown): string | undefined => {
  const s = cellText(v).toLowerCase();
  return VALID_SHARE_RESOLUTIONS.find(r => r === s);
};

// Sel Ya/Tidak (juga menerima 1/0, true/false, yes/no) → undefined kalau kosong/tidak terbaca
export const cellBool = (v: unknown): boolean | undefined => {
  const s = cellText(v).toLowerCase();
  if (!s) return undefined;
  if (['1', 'true', 'ya', 'yes', 'y', 'on', 'aktif'].includes(s)) return true;
  if (['0', 'false', 'tidak', 'no', 'n', 'off', 'mati'].includes(s)) return false;
  return undefined;
};

// "Budi, Sari" → ['Budi', 'Sari'] (duplikat dibuang, beda besar-kecil huruf dianggap sama)
export const cellTentors = (v: unknown): string[] | undefined => {
  const seen = new Set<string>();
  const names: string[] = [];
  for (const raw of cellText(v).split(/[,;]+/)) {
    const name = raw.trim();
    if (!name) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    names.push(name);
  }
  return names.length ? names : undefined;
};

// Kode host harus 4-10 digit angka; selain itu dianggap kosong (server bikin kode acak)
export const cellHostCode = (v: unknown): string | undefined => {
  const s = cellText(v).replace(/[\s-]/g, '');
  return /^\d{4,10}$/.test(s) ? s : undefined;
};

// Sel "Jam": teks "08:00"/"08.00", sel time Excel (dibaca sebagai Date),
// atau pecahan serial 0..1 (Excel menyimpan jam sebagai angka) → "HH:MM"
export const cellTime = (v: unknown): string | undefined => {
  if (v instanceof Date) {
    if (isNaN(v.getTime())) return undefined;
    return `${String(v.getHours()).padStart(2, '0')}:${String(v.getMinutes()).padStart(2, '0')}`;
  }
  const s = cellText(v);
  if (!s) return undefined;
  const m = s.match(/^(\d{1,2})[:.](\d{2})(?:[:.]\d{2})?$/);
  if (m) {
    const h = Number(m[1]);
    const mi = Number(m[2]);
    if (h > 23 || mi > 59) return undefined;
    return `${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}`;
  }
  const n = Number(s.replace(',', '.'));
  if (Number.isFinite(n) && n > 0 && n < 1) {
    const total = Math.round(n * 1440) % 1440;
    return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
  }
  return undefined;
};

// Parse sel "Jadwal" → {date,time} (lokal) | 'none' (All Time) | null (tidak terbaca)
export const parseScheduleCell = (v: unknown): { date: string; time: string } | 'none' | null => {
  const pad = (n: number) => String(n).padStart(2, '0');
  if (v instanceof Date) {
    if (isNaN(v.getTime())) return null;
    return {
      date: `${v.getFullYear()}-${pad(v.getMonth() + 1)}-${pad(v.getDate())}`,
      time: `${pad(v.getHours())}:${pad(v.getMinutes())}`,
    };
  }
  const s = cellText(v);
  if (!s || /instant|unscheduled|all\s*time|tanpa jadwal/i.test(s)) return 'none';
  // "25/9/2026 08.00.00" (export id-ID) | "25-09-2026 08:00" | "2026-09-25T08:00" (ISO)
  let m = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?:[,\s]+(\d{1,2})[.:](\d{2}))?/);
  let d: number, mo: number, y: number, h: string | undefined, mi: string | undefined;
  if (m) {
    d = Number(m[1]); mo = Number(m[2]); y = Number(m[3]); h = m[4]; mi = m[5];
  } else {
    m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2}))?/);
    if (!m) return null;
    y = Number(m[1]); mo = Number(m[2]); d = Number(m[3]); h = m[4]; mi = m[5];
  }
  if (mo > 12 && d <= 12) [d, mo] = [mo, d]; // format MM/DD
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return { date: `${y}-${pad(mo)}-${pad(d)}`, time: h ? `${h.padStart(2, '0')}:${mi}` : '00:00' };
};

// Ringkasan chip "Dari Excel: ..." di tiap baris modal bulk import
export const describeBulkOverrides = (m: BulkMeetingRow, categories: CategoryItem[]): string =>
  [
    m.maxParticipants ? `${m.maxParticipants} peserta` : '',
    m.durationMinutes ? `${m.durationMinutes} menit` : '',
    m.hostResolution ? `host ${m.hostResolution}` : '',
    m.memberResolution ? `member ${m.memberResolution}` : '',
    m.screenshareResolution ? `share ${m.screenshareResolution}` : '',
    m.categoryId ? `kategori ${categories.find(c => c.id === m.categoryId)?.name ?? '?'}` : '',
    m.maxActiveCameras !== undefined ? `maks ${m.maxActiveCameras} kamera` : '',
    m.autoRecord !== undefined ? `rekam ${m.autoRecord ? 'otomatis' : 'manual'}` : '',
    m.kickCooldownMinutes !== undefined ? `kick cooldown ${m.kickCooldownMinutes} m` : '',
    m.lateJoinMinutes !== undefined ? `late join ${m.lateJoinMinutes} m` : '',
    m.hostJoinCode ? `kode host ${m.hostJoinCode}` : '',
    m.tentors?.length ? `tentor ${m.tentors.join(', ')}` : '',
    m.retentionHours ? `retensi ${m.retentionHours} jam` : '',
    m.scheduleWarning ? 'jadwal tidak terbaca → All Time' : '',
  ].filter(Boolean).join(' · ');

// Ubah isi sheet (baris pertama = judul kolom) jadi daftar meeting siap import.
// Lempar Error('FORMAT') kalau kolom Nama tidak ada.
export function parseBulkSheetData(
  data: unknown[][],
  categories: CategoryItem[]
): { rows: BulkMeetingRow[]; notes: string[] } {
  const notes: string[] = [];
  const header = data[0].map(c => cellText(c).toLowerCase().replace(/[^a-z0-9]/g, ''));
  const col = (...aliases: string[]) => {
    for (const a of aliases) {
      const i = header.indexOf(a);
      if (i >= 0) return i;
    }
    return -1;
  };
  const iName = col('nama', 'name');
  if (iName < 0) throw new Error('FORMAT');
  const iPublic = col('publicid', 'kode', 'meetingid');
  const iCategory = col('kategori', 'category');
  const iDate = col('tanggal', 'date', 'scheduleddate');
  const iTime = col('jam', 'time', 'waktujam');
  // Format lama: satu kolom "Jadwal" gabungan tanggal+jam (fallback bila kolom Tanggal tidak ada)
  const iSchedule = col('jadwal', 'schedule', 'tanggaljadwal');
  const iCap = col('kapasitas', 'maxparticipants', 'maxpeserta');
  const iDur = col('durasimenit', 'durasi', 'duration');
  const iHostRes = col('hostres', 'hostresolution');
  const iMemberRes = col('memberres', 'memberresolution');
  const iShareRes = col('screenshareres', 'shareres', 'ssres', 'resolusishare');
  const iMaxCam = col('maxactivecameras', 'bataskamera', 'kameramaks', 'maxcameras');
  const iAutoRec = col('autorecord', 'rekamotomatis', 'rekam');
  const iKick = col('kickcooldownmenit', 'kickcooldown', 'cooldown');
  const iLate = col('latejoincutoffmenit', 'latejoinmenit', 'latejoin');
  const iHostCode = col('kodehost', 'hostcode');
  const iTentor = col('tentor', 'tentors', 'pengajar');
  const iRetention = col('retentionjam', 'retentionhours', 'retensi');

  const rows: BulkMeetingRow[] = [];
  for (let r = 1; r < data.length; r++) {
    const cells = data[r] || [];
    const at = (i: number) => (i >= 0 ? cells[i] : null);
    const name = cellText(at(iName));
    if (!name) continue;
    const row: BulkMeetingRow = { name, publicId: cellText(at(iPublic)), scheduleMode: 'alltime', date: '', time: '' };

    // Format baru: kolom Tanggal + Jam terpisah (sama seperti form dashboard).
    // Format lama: satu kolom Jadwal gabungan.
    let sched: { date: string; time: string } | 'none' | null;
    if (iDate >= 0) {
      const rawJam = iTime >= 0 ? cellText(at(iTime)) : '';
      const t = iTime >= 0 ? cellTime(at(iTime)) : undefined;
      const d = parseScheduleCell(at(iDate));
      if (d === null) {
        sched = null;
      } else if (d === 'none') {
        if (rawJam) notes.push(`baris ${r}: jam diisi tanpa tanggal → All Time`);
        sched = 'none';
      } else {
        if (rawJam && !t) notes.push(`baris ${r}: jam "${rawJam}" tidak dibaca → 00:00`);
        sched = { date: d.date, time: t ?? (iTime >= 0 ? '00:00' : d.time) };
      }
    } else {
      sched = iSchedule >= 0 ? parseScheduleCell(at(iSchedule)) : 'none';
    }
    if (sched === null) {
      row.scheduleWarning = true;
      notes.push(`baris ${r}: jadwal tidak terbaca → All Time`);
    } else if (sched !== 'none') {
      row.scheduleMode = 'scheduled';
      row.date = sched.date;
      row.time = sched.time;
    }

    const cap = cellText(at(iCap));
    const capNum = cellNumber(cap, 1, 500);
    if (capNum !== undefined) row.maxParticipants = capNum;
    else if (cap) notes.push(`baris ${r}: kapasitas "${cap}" di luar 1–500 → pakai preset`);

    const dur = cellText(at(iDur));
    const durNum = cellNumber(dur, 1, 1440);
    if (durNum !== undefined) row.durationMinutes = durNum;
    else if (dur) notes.push(`baris ${r}: durasi "${dur}" di luar 1–1440 → pakai preset`);

    const hostRes = cellText(at(iHostRes));
    const hostResVal = cellResolution(hostRes);
    if (hostResVal) row.hostResolution = hostResVal;
    else if (hostRes) notes.push(`baris ${r}: host res "${hostRes}" tidak valid → pakai preset`);

    const memberRes = cellText(at(iMemberRes));
    const memberResVal = cellResolution(memberRes);
    if (memberResVal) row.memberResolution = memberResVal;
    else if (memberRes) notes.push(`baris ${r}: member res "${memberRes}" tidak valid → pakai preset`);

    const shareRes = cellText(at(iShareRes));
    const shareResVal = cellShareResolution(shareRes);
    if (shareResVal) row.screenshareResolution = shareResVal;
    else if (shareRes) notes.push(`baris ${r}: screenshare res "${shareRes}" tidak valid (480p/720p) → 720p`);

    const maxCam = cellText(at(iMaxCam));
    const maxCamNum = cellNumber(maxCam, 0, 500);
    if (maxCamNum !== undefined) row.maxActiveCameras = maxCamNum;
    else if (maxCam) notes.push(`baris ${r}: maks kamera "${maxCam}" di luar 0–500 → tanpa batas`);

    const autoRecRaw = cellText(at(iAutoRec));
    const autoRec = cellBool(at(iAutoRec));
    if (autoRec !== undefined) row.autoRecord = autoRec;
    else if (autoRecRaw) notes.push(`baris ${r}: auto record "${autoRecRaw}" tidak dibaca → tidak`);

    const kick = cellText(at(iKick));
    const kickNum = cellNumber(kick, 0, 1440);
    if (kickNum !== undefined) row.kickCooldownMinutes = kickNum;
    else if (kick) notes.push(`baris ${r}: kick cooldown "${kick}" di luar 0–1440 → preset`);

    const late = cellText(at(iLate));
    const lateNum = cellNumber(late, 0, 1440);
    if (lateNum !== undefined) row.lateJoinMinutes = lateNum;
    else if (late) notes.push(`baris ${r}: late join "${late}" di luar 0–1440 → preset`);

    const hostCodeRaw = cellText(at(iHostCode));
    const hostCode = cellHostCode(at(iHostCode));
    if (hostCode) row.hostJoinCode = hostCode;
    else if (hostCodeRaw) notes.push(`baris ${r}: kode host "${hostCodeRaw}" harus 4-10 digit → kode acak`);

    const tentors = cellTentors(at(iTentor));
    if (tentors) row.tentors = tentors;

    const retention = cellText(at(iRetention));
    const retentionNum = cellNumber(retention, 1, 720);
    if (retentionNum !== undefined) row.retentionHours = retentionNum;
    else if (retention) notes.push(`baris ${r}: retention "${retention}" di luar 1–720 jam → default`);

    const catName = cellText(at(iCategory));
    if (catName) {
      const cat = categories.find(c => c.name.toLowerCase() === catName.toLowerCase());
      if (cat) row.categoryId = cat.id;
      else notes.push(`baris ${r}: kategori "${catName}" tidak ada → kategori global`);
    }

    rows.push(row);
  }

  return { rows, notes };
}
