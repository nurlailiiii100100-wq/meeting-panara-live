import { unzipSync, zipSync } from 'fflate';

// 0-based → huruf kolom Excel: 0→A, 25→Z, 26→AA
export const columnLetter = (index: number): string => {
  let n = index;
  let s = '';
  do {
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26) - 1;
  } while (n >= 0);
  return s;
};

// Elemen yang dalam skema OOXML wajib berada SESUDAH <dataValidations>.
// Penyisipan harus sebelum yang paling awal di antaranya, kalau tidak Excel
// akan menampilkan "file needs to be repaired".
const TAGS_AFTER = [
  '<hyperlinks', '<printOptions', '<pageMargins', '<pageSetup', '<headerFooter',
  '<rowBreaks', '<colBreaks', '<drawing', '<legacyDrawing', '<tableParts', '<extLst'
];

export type ListValidationSpec = {
  columnIndex: number;
  // Pilih salah satu: `values` = inline list ("a,b,c", maks 255 karakter),
  // `formula` = referensi sel (mis. sheet daftar kategori) — tanpa batas 255.
  values?: string[];
  formula?: string;
  // stop (default Excel) = nilai di luar list diblokir; warning = hanya peringatan.
  errorStyle?: 'stop' | 'warning' | 'information';
};

// Isi <formula1> adalah teks XML — nama kategori boleh berisi & atau < (mis. "Matematika & Fisika")
const escapeXml = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// Sheet tersembunyi berisi daftar nama kategori (baris 1 = header, data mulai baris 2)
export const LIST_SHEET_NAME = 'Daftar Kategori';

/**
 * Referensi sel untuk dropdown Kategori mengarah ke sheet `LIST_SHEET_NAME`,
 * bukan inline list — jadi bebas batas 255 karakter, nama ber-koma pun aman.
 */
export const categoryListFormula = (count: number): string =>
  `'${LIST_SHEET_NAME}'!$A$2:$A$${count + 1}`;

// Feature write-excel-file: sembunyikan sheet daftar (workbook.xml → state="hidden").
export const hideListSheetFeature = {
  files: {
    transform: {
      'xl/workbook.xml': {
        transformElementAttributes: (
          tagName: string,
          attributes: Record<string, string | number>
        ): Record<string, string | number> =>
          tagName === 'sheet' && attributes.name === LIST_SHEET_NAME
            ? { ...attributes, state: 'hidden' }
            : attributes,
      },
    },
  },
};

/**
 * Sisipkan dropdown (data validation type=list) untuk beberapa kolom ke file xlsx.
 * Berlaku untuk baris 2..1000 (baris 1 = header), tanpa mengubah isi sel lain.
 * Idempoten: kalau sudah ada dataValidation, file dikembalikan apa adanya.
 */
export function addListValidations(
  xlsx: Uint8Array,
  specs: ListValidationSpec[]
): Uint8Array {
  if (!specs.length) return xlsx;
  const files = unzipSync(xlsx);
  // Urutkan numerik (sheet1, sheet2, … sheet10) — validasi selalu masuk ke sheet pertama
  const sheetName = Object.keys(files)
    .filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n))
    .sort((a, b) => Number(a.match(/\d+/)![0]) - Number(b.match(/\d+/)![0]))[0];
  if (!sheetName) return xlsx;

  const xml = new TextDecoder().decode(files[sheetName]);
  if (xml.includes('<dataValidation')) return xlsx;
  const close = xml.indexOf('</worksheet>');
  if (close < 0) return xlsx;

  const validations = specs
    .map((s) => {
      const col = columnLetter(s.columnIndex);
      const style = s.errorStyle ? ` errorStyle="${s.errorStyle}"` : '';
      const list = s.formula
        ? escapeXml(s.formula)
        : `"${escapeXml((s.values ?? []).join(','))}"`;
      return (
        `<dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1"${style} ` +
        `sqref="${col}2:${col}1000">` +
        `<formula1>${list}</formula1>` +
        `</dataValidation>`
      );
    })
    .join('');
  const block = `<dataValidations count="${specs.length}">${validations}</dataValidations>`;

  let at = close;
  for (const tag of TAGS_AFTER) {
    const i = xml.indexOf(tag);
    if (i >= 0 && i < at) at = i;
  }

  files[sheetName] = new TextEncoder().encode(xml.slice(0, at) + block + xml.slice(at));
  return zipSync(files, { level: 6 });
}

/** Sisipkan dropdown untuk satu kolom. Lihat addListValidations. */
export function addColumnListValidation(
  xlsx: Uint8Array,
  columnIndex: number,
  values: string[]
): Uint8Array {
  return addListValidations(xlsx, [{ columnIndex, values }]);
}
