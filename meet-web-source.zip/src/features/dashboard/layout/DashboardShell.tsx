import { useCallback, useEffect, useRef, useState } from 'react';
import type { ElementType, ReactNode } from 'react';
import { ChevronDown, ChevronLeft, ChevronRight, LogOut, Menu as MenuIcon, ShieldCheck, User, X } from 'lucide-react';
import { ThemeToggle } from '../../../shared';
import { DropdownMenu, Tooltip, cx } from '../components/ds';

export interface ShellNavItem {
  tab: string;
  icon: ElementType;
  label: string;
  tooltip: string;
  count: number | null;
}

export interface ShellNavGroup {
  /** Label kategori (Utama, Meeting, Pengaturan, Akun). */
  label: string;
  items: ShellNavItem[];
}

interface DashboardShellProps {
  navGroups: ShellNavGroup[];
  activeTab: string;
  onNavigate: (tab: string) => void;
  /** Nama halaman — leaf breadcrumb topbar (h1 besar ada di konten). */
  title: string;
  user: { name?: string | null; username?: string | null; role: string } | null;
  logo?: string;
  siteTitle: string;
  onLogout: () => void | Promise<void>;
  children: ReactNode;
}

const FOCUSABLE =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

const STORAGE_KEY = 'learnly:sidebar-collapsed';

function useMediaQuery(query: string): boolean {
  const [match, setMatch] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const onChange = () => setMatch(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [query]);
  return match;
}

/* ---------------------------------------------------------------------------
 * Item navigasi — indikator aktif (latar + teks tebal + aria-current),
 * badge hitung, dan tooltip saat mode ikon/di mobile drawer tertutup.
 * ------------------------------------------------------------------------ */
function SidebarItem({
  item,
  active,
  collapsed,
  onPick,
}: {
  item: ShellNavItem;
  active: boolean;
  collapsed: boolean;
  onPick: (tab: string) => void;
}) {
  const Icon = item.icon;
  const inner = (
    <button
      type="button"
      onClick={() => onPick(item.tab)}
      aria-current={active ? 'page' : undefined}
      className={cx(
        'ds-transition w-full flex items-center gap-2.5 min-h-10 px-2.5 py-2 rounded-[var(--ds-r-control)] cursor-pointer',
        'text-sm border text-left',
        collapsed && 'justify-center px-0',
        active
          ? 'bg-emerald-900/60 text-emerald-300 border-emerald-800/60 font-semibold'
          : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800 border-transparent',
      )}
    >
      <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
      {!collapsed && (
        <>
          <span className="flex-1 truncate">{item.label}</span>
          {item.count !== null && item.count > 0 && (
            <span className="text-[10px] bg-slate-800 border border-slate-700 text-slate-300 px-1.5 py-0.5 rounded-full tabular-nums shrink-0">
              {item.count}
            </span>
          )}
        </>
      )}
    </button>
  );

  if (collapsed) {
    return <Tooltip content={item.tooltip} side="right">{inner}</Tooltip>;
  }
  return inner;
}

/* ---------------------------------------------------------------------------
 * Isi sidebar (dipakai bersama oleh aside desktop/tablet dan drawer mobile).
 * Hanya navigasi + brand — identitas akun/keluar ada di dropdown avatar topbar.
 * ------------------------------------------------------------------------ */
function SidebarBody({
  navGroups,
  activeTab,
  onPick,
  collapsed,
  showToggle,
  onToggle,
  siteTitle,
  logo,
}: {
  navGroups: ShellNavGroup[];
  activeTab: string;
  onPick: (tab: string) => void;
  collapsed: boolean;
  showToggle: boolean;
  onToggle: () => void;
  siteTitle: string;
  logo?: string;
}) {
  return (
    <>
      {/* Brand + toggle collapse */}
      <div
        className={cx(
          'flex items-center gap-2 h-14 px-3 border-b border-slate-800 shrink-0',
          collapsed && !showToggle && 'justify-center px-0',
        )}
      >
        <img src={logo || '/learnly.svg'} alt="" className="w-7 h-7 shrink-0" />
        {!collapsed && (
          <span className="font-bold text-lg tracking-tight text-slate-100 truncate flex-1">{siteTitle}</span>
        )}
        {showToggle && (
          <button
            type="button"
            onClick={onToggle}
            aria-label={collapsed ? 'Perluas sidebar' : 'Ciutkan sidebar'}
            className="ds-focus ds-transition p-1.5 rounded-[var(--ds-r-control)] text-slate-400 hover:text-slate-100 hover:bg-slate-800 cursor-pointer shrink-0"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        )}
      </div>

      {/* Grup menu */}
      <nav aria-label="Menu utama" className="flex-1 overflow-y-auto overflow-x-hidden py-2 px-2">
        {navGroups.map(group => (
          <div key={group.label} className="mb-1">
            {!collapsed && (
              <p className="px-2.5 pt-3 pb-1 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
                {group.label}
              </p>
            )}
            {collapsed && <div className="my-2 border-t border-slate-800 mx-1.5" aria-hidden="true" />}
            <div className="flex flex-col gap-0.5">
              {group.items.map(item => (
                <SidebarItem
                  key={item.tab}
                  item={item}
                  active={activeTab === item.tab}
                  collapsed={collapsed}
                  onPick={onPick}
                />
              ))}
            </div>
          </div>
        ))}
      </nav>
    </>
  );
}

/* ---------------------------------------------------------------------------
 * DashboardShell — app shell responsif khusus rute /admin.
 * - Root memakai class `tetris-grid` (animasi background dipertahankan apa adanya).
 * - Topbar menempel: root h-dvh, hanya area konten yang di-scroll.
 *   Kiri = breadcrumb (grup / halaman), kanan = tema + dropdown avatar
 *   (identitas & Keluar hanya di sini; sidebar tanpa kaki profil).
 * - Sidebar/drawer: navigasi + brand saja.
 * - Desktop >=1024: sidebar penuh (bisa ciut, diingat di localStorage).
 * - Tablet 640-1023: mode ikon.
 * - Mobile <640: drawer kiri + overlay, focus trap, kunci scroll, Esc/tap/pilih.
 * - Z-index baru maksimal 70 (di bawah toast ds 90 dan modal ds 80).
 * ------------------------------------------------------------------------ */
export function DashboardShell({
  navGroups,
  activeTab,
  onNavigate,
  title,
  user,
  logo,
  siteTitle,
  onLogout,
  children,
}: DashboardShellProps) {
  const isDesktop = useMediaQuery('(min-width: 1024px)');
  const isMobile = useMediaQuery('(max-width: 639px)');

  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [drawerOpen, setDrawerOpen] = useState(false);
  const drawerRef = useRef<HTMLElement>(null);
  const restoreFocusRef = useRef<HTMLElement | null>(null);

  /* Hanya desktop yang boleh mengubah collapse; tablet selalu mode ikon. */
  const sidebarCollapsed = isDesktop ? collapsed : true;

  const toggleCollapse = useCallback(() => {
    setCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem(STORAGE_KEY, String(next));
      } catch {
        /* storage tidak tersedia — state tetap berlaku selama sesi */
      }
      return next;
    });
  }, []);

  const pick = useCallback(
    (tab: string) => {
      onNavigate(tab);
      setDrawerOpen(false);
    },
    [onNavigate],
  );

  /* Drawer hanya untuk mobile — tutup otomatis bila berpindah breakpoint. */
  useEffect(() => {
    if (!isMobile) setDrawerOpen(false);
  }, [isMobile]);

  /* Drawer mobile: kunci scroll, pindahkan fokus ke dalam, trap Tab, Esc. */
  useEffect(() => {
    if (!drawerOpen) return;
    restoreFocusRef.current = document.activeElement as HTMLElement | null;
    document.documentElement.classList.add('ds-scroll-locked');
    const t = setTimeout(() => drawerRef.current?.focus(), 0);

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setDrawerOpen(false);
        return;
      }
      if (e.key !== 'Tab') return;
      const nodes = drawerRef.current?.querySelectorAll<HTMLElement>(FOCUSABLE);
      if (!nodes || nodes.length === 0) return;
      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      const activeEl = document.activeElement;
      if (e.shiftKey && (activeEl === first || activeEl === drawerRef.current)) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && activeEl === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKeyDown, true);
    return () => {
      clearTimeout(t);
      document.removeEventListener('keydown', onKeyDown, true);
      document.documentElement.classList.remove('ds-scroll-locked');
      restoreFocusRef.current?.focus();
    };
  }, [drawerOpen]);

  const sidebarBodyProps = {
    navGroups,
    activeTab,
    onPick: pick,
    siteTitle,
    logo,
  };

  /* Breadcrumb topbar: grup / halaman (di HP cukup nama halaman). */
  const activeGroup = navGroups.find(g => g.items.some(i => i.tab === activeTab));

  return (
    <div className="h-dvh w-full tetris-grid flex flex-col overflow-x-hidden">
      {/* Topbar — menempel di atas (hanya konten yang di-scroll) */}
      <header className="shrink-0 z-30 border-b border-slate-800 bg-slate-950/80 pt-[env(safe-area-inset-top)]">
        <div className="flex items-center gap-2.5 h-14 px-3 sm:px-4">
          {/* Hamburger — hanya mobile */}
          <button
            type="button"
            onClick={() => setDrawerOpen(prev => !prev)}
            aria-label={drawerOpen ? 'Tutup menu navigasi' : 'Buka menu navigasi'}
            aria-expanded={drawerOpen}
            aria-controls="sidebar-drawer"
            className="ds-focus ds-transition sm:hidden p-2.5 -ml-1 rounded-[var(--ds-r-control)] text-slate-300 hover:text-slate-100 hover:bg-slate-800 cursor-pointer"
          >
            {drawerOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
          </button>

          {/* Logo — hanya mobile (di tablet/desktop sidebar sudah menampilkan brand) */}
          <img src={logo || '/learnly.svg'} alt="" className="sm:hidden w-6 h-6 shrink-0" />

          {/* Breadcrumb — grup / halaman (HP: hanya nama halaman).
              Bukan h1 — satu h1 per halaman ada di PageHeader konten. */}
          <nav aria-label="Breadcrumb" className="min-w-0 truncate text-sm">
            {activeGroup && (
              <>
                <span className="hidden sm:inline text-[var(--ds-text-faint)]">{activeGroup.label}</span>
                <span className="hidden sm:inline mx-1.5 text-slate-600" aria-hidden="true">/</span>
              </>
            )}
            <span className="font-medium text-slate-200">{title}</span>
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <ThemeToggle />

            <DropdownMenu
              label="Menu profil"
              align="end"
              header={
                user ? (
                  <div className="flex flex-col gap-1.5 min-w-0">
                    <span className="text-sm font-semibold text-[var(--ds-text)] truncate">
                      {user.name || user.username}
                    </span>
                    <span
                      className={cx(
                        'inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded border w-fit',
                        user.role === 'superadmin'
                          ? 'bg-violet-950 border-violet-700 text-violet-300'
                          : 'bg-emerald-950 border-emerald-700 text-emerald-300',
                      )}
                    >
                      <ShieldCheck className="w-3 h-3" aria-hidden="true" />
                      {user.role === 'superadmin' ? 'SUPERADMIN' : 'ADMIN'}
                    </span>
                  </div>
                ) : undefined
              }
              items={[
                {
                  id: 'logout',
                  label: 'Keluar',
                  icon: LogOut,
                  onSelect: () => onLogout(),
                },
              ]}
              trigger={triggerProps => (
                <button
                  {...triggerProps}
                  type="button"
                  aria-label="Menu profil"
                  className="ds-focus ds-transition flex items-center gap-2 pl-1.5 pr-2 py-1.5 rounded-[var(--ds-r-control)] text-slate-300 hover:text-slate-100 hover:bg-slate-800 cursor-pointer"
                >
                  <span className="grid place-items-center size-8 rounded-full bg-slate-800 border border-slate-700 shrink-0">
                    <User className="w-4 h-4" aria-hidden="true" />
                  </span>
                  <span className="hidden sm:block text-sm max-w-24 lg:max-w-36 truncate">
                    {user?.name || user?.username}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                </button>
              )}
            />
          </div>
        </div>
      </header>

      {/* Body: sidebar + konten */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Sidebar desktop/tablet */}
        <aside
          className={cx(
            'hidden sm:flex shrink-0 flex-col bg-slate-900 border-r border-slate-800 overflow-hidden',
            'transition-[width] duration-200 ease-out',
            sidebarCollapsed ? 'w-16' : 'w-64',
          )}
        >
          <SidebarBody
            {...sidebarBodyProps}
            collapsed={sidebarCollapsed}
            showToggle={isDesktop}
            onToggle={toggleCollapse}
          />
        </aside>

        {/* Konten */}
        <main className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[1440px] px-4 sm:px-6 lg:px-8 py-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))]">
            {children}
          </div>
        </main>
      </div>

      {/* Drawer mobile (hanya saat terbuka; tanpa backdrop-filter) */}
      {isMobile && drawerOpen && (
        <>
          <div
            className="fixed inset-0 z-[60] bg-slate-950/70"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <aside
            id="sidebar-drawer"
            ref={drawerRef}
            role="dialog"
            aria-modal="true"
            aria-label="Menu navigasi"
            tabIndex={-1}
            className="ds-z-dropdown ds-anim-dropdown fixed inset-y-0 left-0 w-72 max-w-[85vw] flex flex-col bg-slate-900 border-r border-slate-800 outline-none"
          >
            <SidebarBody {...sidebarBodyProps} collapsed={false} showToggle={false} onToggle={toggleCollapse} />
          </aside>
        </>
      )}
    </div>
  );
}
