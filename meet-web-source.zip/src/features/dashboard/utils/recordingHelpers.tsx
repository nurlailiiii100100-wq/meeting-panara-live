import type { RecordingItem } from '../types/dashboard.types';

export function formatDuration(seconds: number): string {
  const totalSecs = Math.floor(seconds);
  const hrs = Math.floor(totalSecs / 3600);
  const mins = Math.floor((totalSecs % 3600) / 60);
  const secs = totalSecs % 60;
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

export function formatResolution(width?: number | null, height?: number | null): string | null {
  if (!width || !height) return null;
  return `${width} × ${height}`;
}

export function getRecordingCountdown(expiresAt: string): { text: string; expired: boolean; urgent: boolean } {
  const remaining = new Date(expiresAt).getTime() - Date.now();
  if (remaining <= 0) return { text: 'Recording expired', expired: true, urgent: false };

  const totalSec = Math.floor(remaining / 1000);
  const days = Math.floor(totalSec / 86400);
  const hrs = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);

  let text = '';
  if (days > 0) text += `${days} hari `;
  if (hrs > 0 || days > 0) text += `${hrs} jam `;
  text += `${mins} menit`;

  return { text: text.trim(), expired: false, urgent: remaining < 24 * 60 * 60 * 1000 };
}

export function getRecordingStatusBadge(status: RecordingItem['status']) {
  switch (status) {
    case 'ready':
      return <span className="px-2 py-0.5 text-xs bg-emerald-950 border border-emerald-700 text-emerald-300 rounded font-medium">Ready</span>;
    case 'processing':
      return <span className="px-2 py-0.5 text-xs bg-amber-950 border border-amber-700 text-amber-300 rounded font-medium">Processing</span>;
    case 'failed':
      return <span className="px-2 py-0.5 text-xs bg-red-950 border border-red-700 text-red-300 rounded font-medium">Failed</span>;
    case 'expired':
      return <span className="px-2 py-0.5 text-xs bg-slate-800 border border-slate-700 text-slate-400 rounded font-medium">Expired</span>;
    default:
      return <span className="px-2 py-0.5 text-xs bg-slate-800 text-slate-300 rounded font-medium">{status}</span>;
  }
}

const RECORDING_EXTENSIONS = ['mp4', 'webm'];

// Ekstensi recording mengikuti file yang tersimpan: rekaman client-side
// dihasilkan MediaRecorder (video/webm), rekaman RealtimeKit mp4.
export function getRecordingExtension(recording: Pick<RecordingItem, 'storage_key' | 'file_name'>): string {
  const fromKey = /\.([A-Za-z0-9]{2,5})$/.exec(recording.storage_key || '');
  if (fromKey && RECORDING_EXTENSIONS.includes(fromKey[1].toLowerCase())) return fromKey[1].toLowerCase();
  const fromName = /\.([A-Za-z0-9]{2,5})$/.exec(recording.file_name || '');
  if (fromName && RECORDING_EXTENSIONS.includes(fromName[1].toLowerCase())) return fromName[1].toLowerCase();
  return 'mp4';
}

export function getRecordingMimeType(recording: Pick<RecordingItem, 'storage_key' | 'file_name'>): string {
  return getRecordingExtension(recording) === 'mp4' ? 'video/mp4' : 'video/webm';
}

export function getRecordingDisplayName(recording: RecordingItem, meetingName: string): string {
  const namePart = meetingName.replace(/\s+/g, '-').replace(/[^a-zA-Z0-9-]/g, '').replace(/-+/g, '-').replace(/^-|-$/g, '');
  const extension = getRecordingExtension(recording);

  const createdAt = new Date(recording.created_at);
  if (isNaN(createdAt.getTime())) {
    return `${namePart || 'Recording'}.${extension}`;
  }

  const day = String(createdAt.getDate()).padStart(2, '0');
  const month = String(createdAt.getMonth() + 1).padStart(2, '0');
  const year = createdAt.getFullYear();
  const hours = String(createdAt.getHours()).padStart(2, '0');
  const minutes = String(createdAt.getMinutes()).padStart(2, '0');

  return `${namePart || 'Recording'} - ${day}/${month}/${year} ${hours}:${minutes}.${extension}`;
}
