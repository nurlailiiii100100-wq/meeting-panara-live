import { useState, useEffect, useMemo, type FormEvent, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../auth/context/AuthContext';
import { getPersistentUserId, setActiveMeetingSession, useSiteLogo, notifySiteSettingsChanged, DEFAULT_SITE_TITLE } from '../../../shared';
import { useToast, ConfirmDialog, Tooltip } from '../../../shared';
import type { Column, CellObject, Sheet } from 'write-excel-file/browser';
import { PaginationControls } from '../components/PaginationControls';
import { RecordingCard } from '../components/RecordingCard';
import { PendingRecordingUploads } from '../components/PendingRecordingUploads';
import { ManageAdmins } from '../components/ManageAdmins';
import { DashboardShell, type ShellNavGroup } from '../layout/DashboardShell';
import {
  PageHeader,
  Button,
  Badge,
  Input,
  Select,
  Checkbox,
  DropdownMenu,
  Skeleton,
  EmptyState,
  ErrorState,
  StatCard,
  Sparkline,
  Modal,
  ConfirmDialog as DSConfirmDialog,
  cx,
  type DropdownMenuItem,
} from '../components/ds';
import { getRecordingDisplayName, getRecordingMimeType, formatDuration, formatFileSize, formatResolution } from '../utils/recordingHelpers';
import type { MeetingItem, ParticipantItem, PresetItem, RecordingItem, TentorItem, CategoryItem, SiteSettingsPayload } from '../types/dashboard.types';
import { VALID_RESOLUTIONS, VALID_SHARE_RESOLUTIONS, parseBulkSheetData, describeBulkOverrides, type BulkMeetingRow } from '../lib/bulkExcel';
import {
  Plus,
  LogIn,
  ShieldCheck,
  Users,
  Clock,
  Trash2,
  Edit2,
  Copy,
  Check,
  X,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  Calendar as CalendarIcon,
  Sparkles,
  Link as LinkIcon,
  ChevronLeft,
  ChevronDown,
  ChevronRight,
  List,
  CalendarDays,
  Layout,
  LayoutDashboard,
  Video,
  Sliders,
  Download,
  Upload,
  History,
  Search,
  CheckCircle2,
  MoreHorizontal
} from 'lucide-react';



const STATUS_COLORS: Record<string, string> = {
  scheduled: '#d97706',
  active: '#16a34a',
  ended: '#64748b',
  expired: '#dc2626',
};

type Align = 'left' | 'center' | 'right';

// Consistent styled cell used for every body row (borders + fixed row height)
const bodyCell = (value: string | number | Date, opts?: { align?: Align; color?: string }): CellObject => ({
  value,
  height: 20,
  fontSize: 11,
  align: opts?.align || 'left',
  textColor: opts?.color || '#1e293b',
  borderColor: '#cbd5e1',
  borderStyle: 'thin',
});

const headerCell = (value: string): CellObject => ({
  value,
  height: 24,
  fontSize: 11,
  align: 'center',
  textColor: '#ffffff',
  backgroundColor: '#047857',
  fontWeight: 'bold',
  borderColor: '#065f46',
  borderStyle: 'thin',
});

const randomHostCode = () => {
  const bytes = new Uint8Array(4);
  crypto.getRandomValues(bytes);
  return String(100000 + (bytes[0] * 16777216 + bytes[1] * 65536 + bytes[2] * 256 + bytes[3]) % 900000);
};

function getAuthTokenFromResponse(data: unknown): string | undefined {
  const d = data as { auth_token?: string; token?: string };
  return d?.auth_token ?? d?.token;
}

type ViewTab = 'dashboard' | 'upcoming' | 'past' | 'all' | 'planner' | 'presets' | 'recordings' | 'settings' | 'admins';

const PAGE_TITLES: Record<ViewTab, string> = {
  dashboard: 'Dasbor',
  upcoming: 'Meeting Akan Datang',
  past: 'Riwayat Meeting',
  all: 'Semua Meeting',
  planner: 'Perencana Kalender',
  presets: 'Preset Meeting',
  recordings: 'Rekaman',
  settings: 'Pengaturan',
  admins: 'Kelola Admin',
};

/** Kunci tanggal lokal (YYYY-MM-DD) untuk agregasi harian. */
const dayKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** StatusPill: ikon + teks Indonesia. Nilai enum `status` TIDAK diubah. */
function statusPill(status: MeetingItem['status']) {
  switch (status) {
    case 'active':
      return <Badge tone="success" icon={<Video className="w-3 h-3" aria-hidden="true" />}>Aktif</Badge>;
    case 'scheduled':
      return <Badge tone="info" icon={<Clock className="w-3 h-3" aria-hidden="true" />}>Terjadwal</Badge>;
    case 'ended':
      return <Badge tone="neutral" icon={<CheckCircle2 className="w-3 h-3" aria-hidden="true" />}>Selesai</Badge>;
    case 'expired':
      return <Badge tone="warning" icon={<AlertCircle className="w-3 h-3" aria-hidden="true" />}>Kedaluwarsa</Badge>;
    default:
      return <Badge tone="neutral">{status}</Badge>;
  }
}

/** Skeleton daftar — meniru baris tabel/kartu, bukan spinner layar penuh. */
function MeetingListSkeleton() {
  return (
    <div role="status" className="flex flex-col gap-3">
      <span className="sr-only">Memuat daftar meeting…</span>
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 py-1">
          <Skeleton className="w-5 h-5 shrink-0" />
          <Skeleton className="h-4 flex-1" />
          <Skeleton className="hidden md:block h-4 w-24" />
          <Skeleton className="h-6 w-20 rounded-full" />
        </div>
      ))}
    </div>
  );
}

/** Section berjudul di dalam form Create/Edit meeting (grid 2 kolom di desktop). */
function FormSection({
  title,
  collapsible = false,
  open = true,
  onToggle,
  children,
}: {
  title: string;
  collapsible?: boolean;
  open?: boolean;
  onToggle?: () => void;
  children: ReactNode;
}) {
  const heading = (
    <h3 className="text-sm font-semibold text-[var(--ds-text)] flex items-center gap-2">
      <span className="w-1 h-4 rounded-full bg-[var(--ds-accent)] shrink-0" aria-hidden="true" />
      {title}
    </h3>
  );
  const grid = (
    <div className={cx('grid grid-cols-1 sm:grid-cols-2 gap-4', !open && 'hidden')}>{children}</div>
  );
  if (!collapsible) {
    return (
      <section className="flex flex-col gap-3">
        {heading}
        {grid}
      </section>
    );
  }
  return (
    <section className="flex flex-col gap-3">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="ds-focus ds-transition flex items-center justify-between gap-2 w-full rounded-[var(--ds-r-control)] px-2 -mx-2 py-1.5 -my-1.5 text-left cursor-pointer hover:bg-[var(--ds-bg-hover)]"
      >
        {heading}
        <ChevronDown
          className={cx('w-4 h-4 text-[var(--ds-text-faint)] transition-transform', open && 'rotate-180')}
          aria-hidden="true"
        />
      </button>
      {grid}
    </section>
  );
}

type FieldErrors = Record<string, string>;

/* Urutan field form — dipakai untuk memfokuskan error pertama secara visual. */
const CREATE_FIELD_ORDER = [
  'cf-name', 'cf-public-id', 'cf-host-code', 'cf-category', 'cf-preset',
  'cf-schedule', 'cf-date', 'cf-time', 'cf-capacity', 'cf-duration',
  'cf-auto-record', 'cf-retention', 'cf-kick', 'cf-late', 'cf-cameras',
  'cf-host-res', 'cf-member-res', 'cf-share-res',
];
const CREATE_ADVANCED_FIELDS = new Set([
  'cf-auto-record', 'cf-retention', 'cf-kick', 'cf-late', 'cf-cameras',
  'cf-host-res', 'cf-member-res', 'cf-share-res',
]);
const EDIT_FIELD_ORDER = [
  'ef-name', 'ef-public-id', 'ef-category',
  'ef-schedule', 'ef-date', 'ef-time', 'ef-capacity', 'ef-duration',
  'ef-auto-record', 'ef-retention', 'ef-kick', 'ef-late', 'ef-cameras',
  'ef-host-res', 'ef-member-res', 'ef-share-res',
];
const EDIT_ADVANCED_FIELDS = new Set([
  'ef-auto-record', 'ef-retention', 'ef-kick', 'ef-late', 'ef-cameras',
  'ef-host-res', 'ef-member-res', 'ef-share-res',
]);

/* Validasi sisi klien saja — aturan & pesan sejalan dengan guard yang sudah
   ada di handleCreateMeeting/handleSaveEdit; payload tidak berubah. */
function validateCreateValues(v: {
  name: string;
  hostCode: string;
  scheduleMode: string;
  date: string;
  time: string;
  capacity: number;
  duration: number;
  retention: number;
  kick: number;
  late: number;
  cameras: number;
}): FieldErrors {
  const errs: FieldErrors = {};
  if (!v.name.trim()) errs['cf-name'] = 'Nama meeting wajib diisi.';
  if (!/^\d{4,10}$/.test(v.hostCode.trim())) errs['cf-host-code'] = 'Kode host harus 4–10 digit angka.';
  if (v.scheduleMode === 'scheduled') {
    if (!v.date || !v.time) errs['cf-date'] = 'Tanggal dan waktu wajib diisi pada mode Terjadwal.';
    else if (isNaN(new Date(`${v.date}T${v.time}`).getTime())) errs['cf-date'] = 'Tanggal atau waktu tidak valid.';
  }
  if (!Number.isInteger(v.capacity) || v.capacity < 1 || v.capacity > 500) errs['cf-capacity'] = 'Kapasitas harus bilangan bulat antara 1 dan 500.';
  if (!Number.isInteger(v.duration) || v.duration < 1 || v.duration > 1440) errs['cf-duration'] = 'Durasi harus bilangan bulat antara 1 dan 1440 menit.';
  if (!Number.isInteger(v.retention) || v.retention < 1 || v.retention > 720) errs['cf-retention'] = 'Retensi rekaman harus 1–720 jam.';
  if (!Number.isInteger(v.kick) || v.kick < 0 || v.kick > 1440) errs['cf-kick'] = 'Jeda kick harus 0–1440 menit (0 = tanpa jeda).';
  if (!Number.isInteger(v.late) || v.late < 0 || v.late > 1440) errs['cf-late'] = 'Batas join harus 0–1440 menit (0 = tanpa batas).';
  if (!Number.isInteger(v.cameras) || v.cameras < 0 || v.cameras > 500) errs['cf-cameras'] = 'Kamera aktif harus 0–500 (0 = tanpa batas).';
  return errs;
}

function validateEditValues(v: {
  name: string;
  scheduleMode: string;
  date: string;
  time: string;
  capacity: number;
  duration: number;
  retention: number;
  kick: number;
  late: number;
  cameras: number;
}): FieldErrors {
  const errs: FieldErrors = {};
  if (!v.name.trim()) errs['ef-name'] = 'Nama meeting wajib diisi.';
  if (v.scheduleMode === 'scheduled') {
    if (!v.date || !v.time) errs['ef-date'] = 'Tanggal dan waktu wajib diisi pada mode Terjadwal.';
    else if (isNaN(new Date(`${v.date}T${v.time}`).getTime())) errs['ef-date'] = 'Tanggal atau waktu tidak valid.';
  }
  if (!Number.isInteger(v.capacity) || v.capacity < 1 || v.capacity > 500) errs['ef-capacity'] = 'Kapasitas harus bilangan bulat antara 1 dan 500.';
  if (!Number.isInteger(v.duration) || v.duration < 1 || v.duration > 1440) errs['ef-duration'] = 'Durasi harus bilangan bulat antara 1 dan 1440 menit.';
  if (!Number.isInteger(v.retention) || v.retention < 1 || v.retention > 720) errs['ef-retention'] = 'Retensi rekaman harus 1–720 jam.';
  if (!Number.isInteger(v.kick) || v.kick < 0 || v.kick > 1440) errs['ef-kick'] = 'Jeda kick harus 0–1440 menit (0 = tanpa jeda).';
  if (!Number.isInteger(v.late) || v.late < 0 || v.late > 1440) errs['ef-late'] = 'Batas join harus 0–1440 menit (0 = tanpa batas).';
  if (!Number.isInteger(v.cameras) || v.cameras < 0 || v.cameras > 500) errs['ef-cameras'] = 'Kamera aktif harus 0–500 (0 = tanpa batas).';
  return errs;
}


export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { logo, title } = useSiteLogo();
  const { addToast } = useToast();

  // Confirm dialog state
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    loading?: boolean;
    variant?: 'danger' | 'warning';
  }>({ open: false, title: '', message: '', onConfirm: () => {} });

  const [meetings, setMeetings] = useState<MeetingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [viewTab, setViewTab] = useState<ViewTab>(() => {
    // Halaman utama setelah login adalah Dashboard. Role superadmin tetap
    // dipaksa ke tab 'admins' oleh useEffect di bawah.
    const requestedView = new URLSearchParams(window.location.search).get('view');
    const known: ViewTab[] = ['dashboard', 'upcoming', 'past', 'all', 'planner', 'presets', 'recordings', 'settings'];
    return requestedView && (known as string[]).includes(requestedView) ? (requestedView as ViewTab) : 'dashboard';
  });

  // Category State
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [categoryFilter, setCategoryFilter] = useState('');
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CategoryItem | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<CategoryItem | null>(null);
  const [categoryFormName, setCategoryFormName] = useState('');
  const [categoryFormLoading, setCategoryFormLoading] = useState(false);
  const [categoryFormError, setCategoryFormError] = useState<string | null>(null);
  const [deleteCategoryLoading, setDeleteCategoryLoading] = useState(false);

  // Settings State
  const [logoValue, setLogoValue] = useState('');
  const [logoInput, setLogoInput] = useState('');
  const [logoUrlInput, setLogoUrlInput] = useState('');
  const [titleValue, setTitleValue] = useState('');
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [settingsError, setSettingsError] = useState<string | null>(null);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Calendar Planner State
  const [calendarDate, setCalendarDate] = useState(new Date());
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string | null>(null);

  // Create Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createName, setCreateName] = useState('');
  const [createPublicId, setCreatePublicId] = useState('');
  const [createDate, setCreateDate] = useState('');
  const [createTime, setCreateTime] = useState('');
  const [createMaxParticipants, setCreateMaxParticipants] = useState(20);
  const [createDuration, setCreateDuration] = useState(60);
  const [createKickCooldown, setCreateKickCooldown] = useState(15);
  const [createLateJoin, setCreateLateJoin] = useState(30);
  const [createMaxActiveCameras, setCreateMaxActiveCameras] = useState(0);
  const [createHostResolution, setCreateHostResolution] = useState('360p');
  const [createMemberResolution, setCreateMemberResolution] = useState('240p');
  const [createScreenshareRes, setCreateScreenshareRes] = useState('720p');
  const [createScheduleMode, setCreateScheduleMode] = useState<'alltime' | 'scheduled'>('scheduled');
  const [createPresetId, setCreatePresetId] = useState('');
  const [createCategoryId, setCreateCategoryId] = useState('');
  const [createAutoRecord, setCreateAutoRecord] = useState(false);
  const [createRetentionHours, setCreateRetentionHours] = useState(48);
  const [createHostCode, setCreateHostCode] = useState(() => randomHostCode());
  const [createLoading, setCreateLoading] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [createFieldErrors, setCreateFieldErrors] = useState<FieldErrors>({});
  const [createAdvanced, setCreateAdvanced] = useState(false);
  const [createSnapshot, setCreateSnapshot] = useState('');
  const [discardCreate, setDiscardCreate] = useState(false);

  // Edit Modal State
  const [editingMeeting, setEditingMeeting] = useState<MeetingItem | null>(null);
  const [editName, setEditName] = useState('');
  const [editPublicId, setEditPublicId] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editTime, setEditTime] = useState('');
  const [editOriginalScheduledAt, setEditOriginalScheduledAt] = useState<string | null>(null);
  const [editMaxParticipants, setEditMaxParticipants] = useState(20);
  const [editDuration, setEditDuration] = useState(60);
  const [editKickCooldown, setEditKickCooldown] = useState(15);
  const [editLateJoin, setEditLateJoin] = useState(30);
  const [editMaxActiveCameras, setEditMaxActiveCameras] = useState(0);
  const [editHostResolution, setEditHostResolution] = useState('360p');
  const [editMemberResolution, setEditMemberResolution] = useState('240p');
  const [editScreenshareRes, setEditScreenshareRes] = useState('720p');
  const [editScheduleMode, setEditScheduleMode] = useState<'alltime' | 'scheduled'>('scheduled');
  const [editCategoryId, setEditCategoryId] = useState('');
  const [editAutoRecord, setEditAutoRecord] = useState(false);
  const [editRetentionHours, setEditRetentionHours] = useState(48);
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [editShortExpiryAck, setEditShortExpiryAck] = useState(false);
  const [editLifecycleLoading, setEditLifecycleLoading] = useState(false);
  const [editFieldErrors, setEditFieldErrors] = useState<FieldErrors>({});
  const [editAdvanced, setEditAdvanced] = useState(false);
  const [editSnapshot, setEditSnapshot] = useState('');
  const [discardEdit, setDiscardEdit] = useState(false);

  // Delete Confirm State
  const [deletingMeeting, setDeletingMeeting] = useState<MeetingItem | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Detail / Participant Inspector State
  const [inspectMeeting, setInspectMeeting] = useState<MeetingItem | null>(null);
  const [inspectParticipants, setInspectParticipants] = useState<ParticipantItem[]>([]);
  const [inspectLoading, setInspectLoading] = useState(false);


  // Quick Join State
  const [quickJoinCode, setQuickJoinCode] = useState('');
  const [quickJoinLoading, setQuickJoinLoading] = useState(false);

  // Preset State
  const [presets, setPresets] = useState<PresetItem[]>([]);
  const [presetsLoading, setPresetsLoading] = useState(false);
  const [showPresetCreateModal, setShowPresetCreateModal] = useState(false);
  const [editingPreset, setEditingPreset] = useState<PresetItem | null>(null);
  const [deletingPreset, setDeletingPreset] = useState<PresetItem | null>(null);
  const [presetFormName, setPresetFormName] = useState('');
  const [presetFormCapacity, setPresetFormCapacity] = useState(20);
  const [presetFormDuration, setPresetFormDuration] = useState(60);
  const [presetFormHostRes, setPresetFormHostRes] = useState('360p');
  const [presetFormMemberRes, setPresetFormMemberRes] = useState('240p');
  const [presetFormLoading, setPresetFormLoading] = useState(false);
  const [presetFormError, setPresetFormError] = useState<string | null>(null);
  const [deletePresetLoading, setDeletePresetLoading] = useState(false);

  // Recording State
  const [recordings, setRecordings] = useState<RecordingItem[]>([]);
  const [recordingsLoading, setRecordingsLoading] = useState(false);
  const [recordingsError, setRecordingsError] = useState<string | null>(null);
  const [selectedRecording, setSelectedRecording] = useState<RecordingItem | null>(null);
  const selectedRecordingResolution = selectedRecording
    ? formatResolution(selectedRecording.resolution_width, selectedRecording.resolution_height)
    : null;

  // Tentor State
  const [tentors, setTentors] = useState<TentorItem[]>([]);
  const [tentorsLoading, setTentorsLoading] = useState(false);
  const [showTentorCreateModal, setShowTentorCreateModal] = useState(false);
  const [editingTentor, setEditingTentor] = useState<TentorItem | null>(null);
  const [deletingTentor, setDeletingTentor] = useState<TentorItem | null>(null);
  const [tentorFormName, setTentorFormName] = useState('');
  const [tentorFormLoading, setTentorFormLoading] = useState(false);
  const [tentorFormError, setTentorFormError] = useState<string | null>(null);
  const [deleteTentorLoading, setDeleteTentorLoading] = useState(false);

  // Host join code (per meeting) — nama tentor baru jadi host kalau kode ini
  // benar saat join. NULL = fitur nonaktif.
  const [hostJoinCode, setHostJoinCode] = useState<string | null>(null);
  const [hostCodeCopied, setHostCodeCopied] = useState(false);

  // Bulk Import State
  const [showBulkImportModal, setShowBulkImportModal] = useState(false);
  const [bulkMeetings, setBulkMeetings] = useState<BulkMeetingRow[]>([{ name: '', publicId: '', scheduleMode: 'alltime', date: '', time: '' }]);
  const [bulkPresetId, setBulkPresetId] = useState('');
  const [bulkCategoryId, setBulkCategoryId] = useState('');
  const [bulkRetentionHours, setBulkRetentionHours] = useState(48);
  const [bulkDefaultScheduleMode, setBulkDefaultScheduleMode] = useState<'alltime' | 'scheduled'>('alltime');
  const [bulkLoading, setBulkLoading] = useState(false);
  const [bulkProgress, setBulkProgress] = useState({ total: 0, done: 0 });
  const [bulkError, setBulkError] = useState<string | null>(null);

  // Table Sort, Pagination State
  const [sortField, setSortField] = useState<'name' | 'scheduled_at' | 'status' | 'max_participants' | 'duration_minutes'>('scheduled_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [presetPage, setPresetPage] = useState(1);
  const [presetPerPage, setPresetPerPage] = useState(6);
  const [presetSearchQuery, setPresetSearchQuery] = useState('');
  const [recordingPage, setRecordingPage] = useState(1);
  const [recordingPerPage, setRecordingPerPage] = useState(6);
  const [recordingSearchQuery, setRecordingSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');

  const fetchMeetings = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/meetings', { credentials: 'include' });
      if (!res.ok) {
        if (res.status === 401) {
          navigate('/admin/login');
          return;
        }
        let detail = '';
        try {
          const errBody = await res.json();
          detail = errBody?.message || errBody?.error || '';
        } catch { /* non-JSON error body */ }
        throw new Error(detail ? `Failed to load meetings (${res.status}): ${detail}` : `Failed to load meetings (HTTP ${res.status})`);
      }
      const data = await res.json();
      setMeetings(data.meetings || []);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error fetching meetings');
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch('/api/categories', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        setCategories(data.categories || []);
      }
    } catch { /* ignore */ }
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings', { credentials: 'include' });
      if (res.ok) {
        const data = (await res.json()) as SiteSettingsPayload;
        const s = data.settings || {};
        setLogoValue(s['logo'] || '');
        setTitleValue(s['title'] || '');
      }
    } catch { /* ignore */ }
  };

  const handleExportExcel = async () => {
    if (displayedMeetings.length === 0 || exporting) return;
    setExporting(true);
    try {
      const { default: writeXlsxFile } = await import('write-excel-file/browser');

      const columns: Column<MeetingItem>[] = [
        { width: 26, header: headerCell('Nama'), cell: (m: MeetingItem) => bodyCell(m.name) },
        { width: 18, header: headerCell('Public ID'), cell: (m: MeetingItem) => bodyCell(m.public_id || m.id) },
        {
          width: 16,
          header: headerCell('Kategori'),
          cell: (m: MeetingItem) => bodyCell(categories.find(c => c.id === m.category_id)?.name || m.category_name || ''),
        },
        {
          width: 26,
          header: headerCell('Jadwal'),
          cell: (m: MeetingItem) => bodyCell(
            m.scheduled_at
              ? new Date(m.scheduled_at).toLocaleString('id-ID')
              : m.started_at
                ? new Date(m.started_at).toLocaleString('id-ID')
                : 'Instant / Unscheduled'
          ),
        },
        {
          width: 12,
          header: headerCell('Status'),
          cell: (m: MeetingItem) => bodyCell(m.status, { align: 'center', color: STATUS_COLORS[m.status] || '#1e293b' }),
        },
        { width: 11, header: headerCell('Kapasitas'), cell: (m: MeetingItem) => bodyCell(m.max_participants, { align: 'right' }) },
        { width: 13, header: headerCell('Durasi (menit)'), cell: (m: MeetingItem) => bodyCell(m.duration_minutes, { align: 'right' }) },
        { width: 9, header: headerCell('Host Res'), cell: (m: MeetingItem) => bodyCell(m.host_resolution || '360p', { align: 'center' }) },
        { width: 11, header: headerCell('Member Res'), cell: (m: MeetingItem) => bodyCell(m.member_resolution || '240p', { align: 'center' }) },
        { width: 13, header: headerCell('Screen Share Res'), cell: (m: MeetingItem) => bodyCell(m.screenshare_resolution || '720p', { align: 'center' }) },
        { width: 15, header: headerCell('Max Active Cameras'), cell: (m: MeetingItem) => bodyCell(m.max_active_cameras ?? 0, { align: 'right' }) },
        { width: 11, header: headerCell('Auto Record'), cell: (m: MeetingItem) => bodyCell(m.auto_record ? 'Ya' : 'Tidak', { align: 'center' }) },
        { width: 17, header: headerCell('Kick Cooldown (menit)'), cell: (m: MeetingItem) => bodyCell(m.kick_cooldown_minutes ?? 15, { align: 'right' }) },
        { width: 19, header: headerCell('Late Join Cutoff (menit)'), cell: (m: MeetingItem) => bodyCell(m.late_join_minutes ?? 30, { align: 'right' }) },
        { width: 14, header: headerCell('Retention (jam)'), cell: (m: MeetingItem) => bodyCell(m.recording_retention_hours ?? 48, { align: 'right' }) },
        { width: 26, header: headerCell('Tentor'), cell: (m: MeetingItem) => bodyCell(m.tentor_names || '') },
        {
          width: 44,
          header: headerCell('Link Join'),
          cell: (m: MeetingItem) => bodyCell(`${window.location.origin}/meeting/${m.public_id || m.id}`),
        },
      ];

      const writer = writeXlsxFile(displayedMeetings, { columns, sheet: 'Meetings', showGridLines: false });
      await writer.toFile(`meetings-${new Date().toISOString().slice(0, 10)}.xlsx`);
    } catch (err) {
      console.error('Excel export failed:', err);
      addToast('Gagal membuat file Excel. Silakan coba lagi.', 'error');
    } finally {
      setExporting(false);
    }
  };

  // --- Category CRUD ---

  const resetCategoryForm = () => { setCategoryFormName(''); setCategoryFormError(null); };

  const openCategoryCreate = () => { resetCategoryForm(); setEditingCategory(null); setShowCategoryModal(true); };

  const openCategoryEdit = (cat: CategoryItem) => { resetCategoryForm(); setEditingCategory(cat); setCategoryFormName(cat.name); setShowCategoryModal(true); };

  const handleSaveCategory = async () => {
    const name = categoryFormName.trim();
    if (!name) { setCategoryFormError('Category name is required'); return; }
    setCategoryFormLoading(true);
    setCategoryFormError(null);
    try {
      const isEditing = !!editingCategory;
      const url = isEditing ? `/api/categories/${editingCategory.id}` : '/api/categories';
      const method = isEditing ? 'PATCH' : 'POST';
      const res = await fetch(url, { method, headers: { 'content-type': 'application/json' }, credentials: 'include', body: JSON.stringify({ name }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Failed to save category');
      setShowCategoryModal(false);
      setEditingCategory(null);
      resetCategoryForm();
      await fetchCategories();
    } catch (err: unknown) {
      setCategoryFormError(err instanceof Error ? err.message : 'Operation failed');
    } finally {
      setCategoryFormLoading(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!deletingCategory) return;
    setDeleteCategoryLoading(true);
    try {
      const res = await fetch(`/api/categories/${deletingCategory.id}`, { method: 'DELETE', credentials: 'include' });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || data.error || 'Failed to delete category');
      }
      setDeletingCategory(null);
      if (categoryFilter === deletingCategory.id) setCategoryFilter('');
      await fetchCategories();
      await fetchMeetings();
    } catch (err: unknown) {
      addToast(err instanceof Error ? err.message : 'Failed to delete category', 'error');
    } finally {
      setDeleteCategoryLoading(false);
    }
  };

  // --- Settings Handlers ---

  const handleLogoFile = (file: File | undefined) => {
    if (!file) return;
    if (file.size > 512 * 1024) {
      setSettingsError('Logo file is too large. Maksimal 512KB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setLogoInput(String(reader.result || ''));
      setLogoUrlInput('');
      setSettingsError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveSettings = async () => {
    setSettingsLoading(true);
    setSettingsError(null);
    setSettingsSaved(false);
    try {
      const payload: Record<string, unknown> = {};
      if (logoInput || (logoUrlInput && logoUrlInput.trim())) {
        payload.logo = logoInput || logoUrlInput.trim();
      }
      payload.title = titleValue.trim();
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Failed to save settings');
      setLogoValue((payload.logo as string) || logoValue);
      setTitleValue(String(payload.title ?? ''));
      // Clear pending upload/URL so preview matches what was saved.
      setLogoInput('');
      setLogoUrlInput('');
      setSettingsSaved(true);
      notifySiteSettingsChanged();
    } catch (err: unknown) {
      setSettingsError(err instanceof Error ? err.message : 'Failed to save settings');
    } finally {
      setSettingsLoading(false);
    }
  };

  // --- Bulk Import Handlers ---

  const addBulkRow = () => {
    setBulkMeetings(prev => [...prev, { name: '', publicId: '', scheduleMode: bulkDefaultScheduleMode, date: '', time: '' }]);
  };

  const removeBulkRow = (index: number) => {
    setBulkMeetings(prev => prev.filter((_, i) => i !== index));
  };

  const updateBulkRow = (index: number, field: string, value: string) => {
    setBulkMeetings(prev => prev.map((m, i) => i === index ? { ...m, [field]: value } : m));
  };

  // Baca file Excel → gantikan daftar meeting. Kolom mengikuti format Export Excel.
  const handleBulkFile = async (file: File | undefined | null) => {
    if (!file) return;
    try {
      const { default: readXlsxFile } = await import('read-excel-file/browser');
      const sheets = await readXlsxFile(file);
      const data = sheets[0]?.data;
      if (!data || data.length < 2) throw new Error('EMPTY');

      const { rows, notes } = parseBulkSheetData(data, categories);
      if (rows.length === 0) throw new Error('EMPTY');

      setBulkMeetings(rows);
      addToast(`File terbaca: ${rows.length} meeting siap di-import`, 'success');
      if (notes.length) {
        addToast(`Catatan: ${notes.slice(0, 3).join('; ')}${notes.length > 3 ? `; +${notes.length - 3} lainnya` : ''}`, 'warning');
      }
    } catch (err) {
      const code = err instanceof Error ? err.message : '';
      addToast(
        code === 'FORMAT' ? 'Kolom "Nama" tidak ditemukan. Pakai tombol Template dulu.'
          : code === 'EMPTY' ? 'File tidak berisi baris meeting.'
            : 'Gagal membaca file. Pastikan format .xlsx.',
        'error'
      );
    }
  };

  // Download template Excel sesuai format yang bisa di-import
  const handleBulkTemplate = async () => {
    try {
      const { default: writeXlsxFile, getSheetData } = await import('write-excel-file/browser');
      const { addListValidations, categoryListFormula, hideListSheetFeature, LIST_SHEET_NAME } =
        await import('../lib/xlsxListValidation');
      const rows = [{
        nama: 'Kelas Frontend A',
        publicId: 'kelas-fe-a',
        kategori: '',
        tanggal: new Date(Date.UTC(2026, 8, 25)),
        jam: '08:00',
        kapasitas: 20,
        durasi: 60,
        hostRes: '360p',
        memberRes: '240p',
        shareRes: '720p',
        maxCam: 4,
        autoRec: 'Ya',
        kick: 15,
        late: 30,
        retention: 48,
        tentor: 'Budi, Sari',
        kodeHost: '1234',
      }];
      const templateColumns = [
        { width: 26, header: headerCell('Nama'), cell: (r: typeof rows[number]) => bodyCell(r.nama) },
        { width: 18, header: headerCell('Public ID'), cell: (r: typeof rows[number]) => bodyCell(r.publicId) },
        { width: 16, header: headerCell('Kategori'), cell: (r: typeof rows[number]) => bodyCell(r.kategori) },
        { width: 14, header: headerCell('Tanggal'), cell: (r: typeof rows[number]) => bodyCell(r.tanggal) },
        { width: 10, header: headerCell('Jam'), cell: (r: typeof rows[number]) => bodyCell(r.jam) },
        { width: 11, header: headerCell('Kapasitas'), cell: (r: typeof rows[number]) => bodyCell(r.kapasitas) },
        { width: 13, header: headerCell('Durasi (menit)'), cell: (r: typeof rows[number]) => bodyCell(r.durasi) },
        { width: 9, header: headerCell('Host Res'), cell: (r: typeof rows[number]) => bodyCell(r.hostRes) },
        { width: 11, header: headerCell('Member Res'), cell: (r: typeof rows[number]) => bodyCell(r.memberRes) },
        { width: 15, header: headerCell('Screen Share Res'), cell: (r: typeof rows[number]) => bodyCell(r.shareRes) },
        { width: 15, header: headerCell('Max Active Cameras'), cell: (r: typeof rows[number]) => bodyCell(r.maxCam) },
        { width: 11, header: headerCell('Auto Record'), cell: (r: typeof rows[number]) => bodyCell(r.autoRec) },
        { width: 17, header: headerCell('Kick Cooldown (menit)'), cell: (r: typeof rows[number]) => bodyCell(r.kick) },
        { width: 19, header: headerCell('Late Join Cutoff (menit)'), cell: (r: typeof rows[number]) => bodyCell(r.late) },
        { width: 14, header: headerCell('Retention (jam)'), cell: (r: typeof rows[number]) => bodyCell(r.retention) },
        { width: 26, header: headerCell('Tentor'), cell: (r: typeof rows[number]) => bodyCell(r.tentor) },
        { width: 12, header: headerCell('Kode Host'), cell: (r: typeof rows[number]) => bodyCell(r.kodeHost) },
      ];
      // Sheet daftar kategori (disembunyikan) → dropdown Kategori tanpa batas 255 karakter
      // dan aman untuk nama ber-koma; nilai dropdown = referensi sel ke sheet itu.
      const colIdx = (label: string) => {
        const i = templateColumns.findIndex(
          (c) => typeof c.header === 'object' && c.header !== null && c.header.value === label
        );
        return i >= 0 ? i : -1;
      };
      const catNames = categories.map((c) => c.name.trim()).filter(Boolean);
      const sheets: Sheet<File | Blob | ArrayBuffer>[] = [
        {
          data: getSheetData(rows, templateColumns),
          sheet: 'Import Meetings',
          showGridLines: false,
          // Kolom Tanggal berisi sel tanggal asli → tampil dd/mm/yyyy, bisa date-picker Excel
          dateFormat: 'dd/mm/yyyy',
          columns: templateColumns.map((c) => ({ width: c.width })),
        },
      ];
      if (catNames.length) {
        sheets.push({
          // header polos (bukan headerCell) supaya test ekstraksi header template tidak tertukar
          data: [[{ value: 'Kategori' }], ...catNames.map((n) => [bodyCell(n)])],
          sheet: LIST_SHEET_NAME,
          showGridLines: false,
          columns: [{ width: 30 }],
        });
      }
      const blob = await writeXlsxFile(sheets, {
        features: catNames.length ? [hideListSheetFeature] : [],
      }).toBlob();

      // Dropdown Excel asli (data validation) di kolom dengan nilai terbatas
      const staticSpecs = [
        { label: 'Host Res', values: VALID_RESOLUTIONS },
        { label: 'Member Res', values: VALID_RESOLUTIONS },
        { label: 'Screen Share Res', values: VALID_SHARE_RESOLUTIONS },
        { label: 'Auto Record', values: ['Ya', 'Tidak'] },
      ]
        .map((s) => ({ columnIndex: colIdx(s.label), values: s.values }))
        .filter((s) => s.columnIndex >= 0);
      const catSpec = catNames.length
        ? {
            columnIndex: colIdx('Kategori'),
            formula: categoryListFormula(catNames.length),
            errorStyle: 'warning' as const,
          }
        : undefined;
      const bytes = addListValidations(
        new Uint8Array(await blob.arrayBuffer()),
        catSpec ? [...staticSpecs, catSpec] : staticSpecs
      );
      const url = URL.createObjectURL(
        new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      );
      const a = document.createElement('a');
      a.href = url;
      a.download = 'template-import-meetings.xlsx';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      if (!catNames.length) {
        addToast('Belum ada kategori di aplikasi — dropdown Kategori tidak dibuat.', 'warning');
      }
    } catch (err) {
      console.error('Template export failed:', err);
      addToast('Gagal membuat template Excel.', 'error');
    }
  };

  const handleBulkImport = async () => {
    const validMeetings = bulkMeetings.filter(m => m.name.trim());
    if (validMeetings.length === 0) {
      setBulkError('Minimal 1 meeting dengan nama harus diisi');
      return;
    }

    // Preset = nilai default semua baris; kolom Excel per baris (kalau terisi) menimpa preset
    const basePreset = bulkPresetId ? presets.find(p => p.id === bulkPresetId) : undefined;

    setBulkLoading(true);
    setBulkError(null);
    setBulkProgress({ total: validMeetings.length, done: 0 });

    let successCount = 0;
    let failCount = 0;
    let tentorFailCount = 0;
    const failedNames: string[] = [];

    for (const meeting of validMeetings) {
      try {
        let scheduledAt: string | null = null;
        if (meeting.scheduleMode === 'scheduled' && meeting.date && meeting.time) {
          const combined = new Date(`${meeting.date}T${meeting.time}`);
          if (!isNaN(combined.getTime())) {
            scheduledAt = combined.toISOString();
          }
        }

        const res = await fetch('/api/meetings', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            name: meeting.name.trim(),
            public_id: meeting.publicId.trim() || undefined,
            scheduled_at: scheduledAt || undefined,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
            category_id: meeting.categoryId || bulkCategoryId || undefined,
            recording_retention_hours: meeting.retentionHours ?? (Number(bulkRetentionHours) || 48),
            max_participants: meeting.maxParticipants ?? basePreset?.max_participants,
            duration_minutes: meeting.durationMinutes ?? basePreset?.duration_minutes,
            host_resolution: meeting.hostResolution ?? basePreset?.host_resolution,
            member_resolution: meeting.memberResolution ?? basePreset?.member_resolution,
            screenshare_resolution: meeting.screenshareResolution,
            max_active_cameras: meeting.maxActiveCameras,
            auto_record: meeting.autoRecord,
            kick_cooldown_minutes: meeting.kickCooldownMinutes,
            late_join_minutes: meeting.lateJoinMinutes,
            host_join_code: meeting.hostJoinCode || undefined,
          })
        });

        if (res.ok) {
          successCount++;
          // Buat tentor per baris (opsional) — gagal di sini tidak membatalkan meeting
          if (meeting.tentors?.length) {
            const created = await res.json().catch(() => null) as { id?: string } | null;
            for (const name of meeting.tentors) {
              try {
                const tRes = await fetch('/api/tentors', {
                  method: 'POST',
                  headers: { 'content-type': 'application/json' },
                  credentials: 'include',
                  body: JSON.stringify({ meeting_id: created?.id, name })
                });
                if (!tRes.ok) tentorFailCount++;
              } catch {
                tentorFailCount++;
              }
            }
          }
        } else {
          failCount++;
          failedNames.push(meeting.name);
        }
      } catch {
        failCount++;
        failedNames.push(meeting.name);
      }

      setBulkProgress(prev => ({ ...prev, done: prev.done + 1 }));
    }

    setBulkLoading(false);
    setShowBulkImportModal(false);
    setBulkMeetings([{ name: '', publicId: '', scheduleMode: 'alltime', date: '', time: '' }]);
    setBulkPresetId('');
    setBulkCategoryId('');
    setBulkRetentionHours(48);
    setBulkDefaultScheduleMode('alltime');
    await fetchMeetings();

    const tentorNote = tentorFailCount > 0 ? `, ${tentorFailCount} tentor gagal dibuat` : '';
    if (failCount > 0) {
      const shown = failedNames.slice(0, 3).join(', ');
      addToast(`Import selesai: ${successCount} berhasil, ${failCount} gagal${tentorNote}${failedNames.length ? ` (${shown}${failedNames.length > 3 ? '…' : ''})` : ''}`, 'warning');
    } else if (tentorFailCount > 0) {
      addToast(`Import selesai: ${successCount} berhasil${tentorNote}`, 'warning');
    } else {
      addToast(`Import selesai: ${successCount} berhasil`, 'success');
    }
  };

  const fetchPresets = async () => {
    try {
      setPresetsLoading(true);
      const res = await fetch('/api/presets', { credentials: 'include' });
      if (!res.ok) {
        if (res.status === 401) {
          navigate('/admin/login');
          return;
        }
        throw new Error('Failed to load presets');
      }
      const data = await res.json();
      setPresets(data.presets || []);
    } catch {
      // silently keep existing presets
    } finally {
      setPresetsLoading(false);
    }
  };

  const fetchRecordings = async () => {
    try {
      setRecordingsLoading(true);
      setRecordingsError(null);
      const res = await fetch('/api/recordings', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        setRecordings((data.recordings || []) as RecordingItem[]);
      } else {
        let detail = '';
        try {
          const errBody = await res.json();
          detail = errBody?.message || errBody?.error || '';
        } catch { /* non-JSON error body */ }
        setRecordingsError(detail ? `Failed to load recordings (${res.status}): ${detail}` : `Failed to load recordings (HTTP ${res.status})`);
      }
    } catch (err: unknown) {
      setRecordingsError(err instanceof Error ? err.message : 'Error fetching recordings');
    } finally {
      setRecordingsLoading(false);
    }
  };

  useEffect(() => {
    // Superadmin hanya punya satu tampilan: Kelola Admin (bukan operator).
    if (user?.role === 'superadmin') setViewTab('admins');
  }, [user?.role]);

  useEffect(() => {
    if (user?.role !== 'admin') return;
    void fetchMeetings();
    fetchPresets();
    fetchRecordings();
    fetchCategories();
    fetchSettings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCopyLink = (m: MeetingItem) => {
    const publicUrl = `${window.location.origin}/meeting/${m.public_id || m.id}`;
    navigator.clipboard.writeText(publicUrl);
    setCopiedKey(`link-${m.id}`);
    setTimeout(() => setCopiedKey(null), 2000);
    // Dari menu titik-tiga tidak ada ikon berubah, jadi konfirmasi via toast.
    addToast('Tautan meeting disalin ke papan klip', 'success');
  };

  const handleCopyId = (m: MeetingItem) => {
    navigator.clipboard.writeText(m.public_id || m.id);
    setCopiedKey(`id-${m.id}`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const generateAutoId = (title: string) => {
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 15);
    const rand = Math.random().toString(36).substring(2, 7);
    return slug ? `${slug}-${rand}` : `meet-${rand}`;
  };

  // --- Preset Handlers ---

  const handlePresetFormSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!presetFormName.trim()) {
      setPresetFormError('Preset name is required');
      return;
    }
    if (!VALID_RESOLUTIONS.includes(presetFormHostRes)) {
      setPresetFormError('Invalid host resolution');
      return;
    }
    if (!VALID_RESOLUTIONS.includes(presetFormMemberRes)) {
      setPresetFormError('Invalid member resolution');
      return;
    }

    setPresetFormLoading(true);
    setPresetFormError(null);

    try {
      const payload = {
        name: presetFormName.trim(),
        max_participants: Number(presetFormCapacity),
        duration_minutes: Number(presetFormDuration),
        host_resolution: presetFormHostRes,
        member_resolution: presetFormMemberRes
      };

      const isEditing = !!editingPreset;
      const url = isEditing ? `/api/presets/${editingPreset.id}` : '/api/presets';
      const method = isEditing ? 'PATCH' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || `Failed to ${isEditing ? 'update' : 'create'} preset`);
      }

      setShowPresetCreateModal(false);
      setEditingPreset(null);
      resetPresetForm();
      await fetchPresets();
    } catch (err: unknown) {
      setPresetFormError(err instanceof Error ? err.message : 'Operation failed');
    } finally {
      setPresetFormLoading(false);
    }
  };

  const handleDeletePreset = async () => {
    if (!deletingPreset) return;
    setDeletePresetLoading(true);

    try {
      const res = await fetch(`/api/presets/${deletingPreset.id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || data.error || 'Failed to delete preset');
      }

      setDeletingPreset(null);
      await fetchPresets();
    } catch (err: unknown) {
      addToast(err instanceof Error ? err.message : 'Gagal menghapus preset', 'error');
    } finally {
      setDeletePresetLoading(false);
    }
  };

  const openPresetCreate = () => {
    resetPresetForm();
    setEditingPreset(null);
    setShowPresetCreateModal(true);
  };

  const openPresetEdit = (preset: PresetItem) => {
    setEditingPreset(preset);
    setPresetFormName(preset.name);
    setPresetFormCapacity(preset.max_participants);
    setPresetFormDuration(preset.duration_minutes);
    setPresetFormHostRes(preset.host_resolution);
    setPresetFormMemberRes(preset.member_resolution);
    setPresetFormError(null);
    setShowPresetCreateModal(true);
  };

  const resetPresetForm = () => {
    setPresetFormName('');
    setPresetFormCapacity(20);
    setPresetFormDuration(60);
    setPresetFormHostRes('360p');
    setPresetFormMemberRes('240p');
    setPresetFormError(null);
  };

  // --- Tentor CRUD ---
  const fetchTentors = async (meetingId: string) => {
    try {
      setTentorsLoading(true);
      const url = `/api/tentors?meeting_id=${encodeURIComponent(meetingId)}`;
      console.log('[Tentor] Fetching tentors:', url);
      const res = await fetch(url, { credentials: 'include' });
      console.log('[Tentor] Fetch response:', res.status, res.headers.get('content-type'));
      if (!res.ok) {
        if (res.status === 401) { navigate('/admin/login'); return; }
        const errText = await res.text();
        console.error('[Tentor] Fetch error body:', errText.substring(0, 500));
        throw new Error('Failed to load tentors');
      }
      const data = await res.json();
      setTentors(data.tentors || []);
    } catch (err) { console.error('[Tentor] fetchTentors error:', err); } finally {
      setTentorsLoading(false);
    }
  };

  const resetTentorForm = () => { setTentorFormName(''); setTentorFormError(null); };

  const openTentorCreate = () => { resetTentorForm(); setEditingTentor(null); setShowTentorCreateModal(true); };

  const openTentorEdit = (tentor: TentorItem) => { setEditingTentor(tentor); setTentorFormName(tentor.name); setTentorFormError(null); setShowTentorCreateModal(true); };

  const handleSaveTentor = async () => {
    if (!inspectMeeting) { console.error('[Tentor] inspectMeeting is null'); return; }
    if (!tentorFormName.trim()) { setTentorFormError('Tentor name is required'); return; }
    setTentorFormLoading(true);
    setTentorFormError(null);
    try {
      const payload = { name: tentorFormName.trim(), meeting_id: inspectMeeting.id };
      const isEditing = !!editingTentor;
      const url = isEditing ? `/api/tentors/${editingTentor.id}` : '/api/tentors';
      const method = isEditing ? 'PATCH' : 'POST';
      console.log('[Tentor] Request:', { url, method, payload, inspectMeetingId: inspectMeeting.id });
      const res = await fetch(url, { method, headers: { 'content-type': 'application/json' }, credentials: 'include', body: JSON.stringify(payload) });
      console.log('[Tentor] Response status:', res.status, res.statusText, 'Content-Type:', res.headers.get('content-type'));
      const text = await res.text();
      console.log('[Tentor] Response body (first 500):', text.substring(0, 500));
      let data;
      try { data = JSON.parse(text); } catch { console.error('[Tentor] Response is NOT JSON:', text.substring(0, 200)); throw new Error('Server returned HTML instead of JSON. Status: ' + res.status); }
      if (!res.ok) throw new Error(data.message || data.error || 'Failed');
      setShowTentorCreateModal(false); setEditingTentor(null); resetTentorForm(); await fetchTentors(inspectMeeting.id);
    } catch (err: unknown) { console.error('[Tentor] Error:', err); setTentorFormError(err instanceof Error ? err.message : 'Operation failed'); } finally { setTentorFormLoading(false); }
  };

  const handleDeleteTentor = async () => {
    if (!deletingTentor || !inspectMeeting) return;
    setDeleteTentorLoading(true);
    try {
      const res = await fetch(`/api/tentors/${deletingTentor.id}`, { method: 'DELETE', credentials: 'include' });
      if (!res.ok) { const data = await res.json(); throw new Error(data.message || data.error || 'Failed'); }
      setDeletingTentor(null); await fetchTentors(inspectMeeting.id);
    } catch (err: unknown) { addToast(err instanceof Error ? err.message : 'Gagal menghapus tentor', 'error'); } finally { setDeleteTentorLoading(false); }
  };

  const handleApplyPreset = (preset: PresetItem) => {
    setCreatePresetId(preset.id);
    setCreateMaxParticipants(preset.max_participants);
    setCreateDuration(preset.duration_minutes);
    setCreateKickCooldown(15);
    setCreateHostResolution(preset.host_resolution);
    setCreateMemberResolution(preset.member_resolution);
    setShowCreateModal(true);
    setCreatePublicId(generateAutoId(createName || 'class'));
    setCreateHostCode(randomHostCode());
  };

  // --- Meeting Handlers ---

  const handleCreateMeeting = async (e: FormEvent) => {
    e.preventDefault();
    if (!createName.trim()) {
      setCreateError('Meeting name is required');
      return;
    }
    const createHostCodeValue = createHostCode.trim();
    if (!/^\d{4,10}$/.test(createHostCodeValue)) {
      setCreateError('Kode host harus 4-10 digit angka.');
      return;
    }

    setCreateLoading(true);
    setCreateError(null);

    let scheduledAt: string | null = null;
    if (createScheduleMode === 'scheduled' && createDate && createTime) {
      const combined = new Date(`${createDate}T${createTime}`);
      if (!isNaN(combined.getTime())) {
        scheduledAt = combined.toISOString();
      }
    }

    try {
      const res = await fetch('/api/meetings', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          name: createName.trim(),
          public_id: createPublicId.trim() || undefined,
          max_participants: Number(createMaxParticipants),
          duration_minutes: Number(createDuration),
          kick_cooldown_minutes: Number.isFinite(Number(createKickCooldown))
            ? Math.min(1440, Math.max(0, Math.floor(Number(createKickCooldown))))
            : 15,
          late_join_minutes: Number.isFinite(Number(createLateJoin))
            ? Math.min(1440, Math.max(0, Math.floor(Number(createLateJoin))))
            : 30,
          max_active_cameras: Number.isFinite(Number(createMaxActiveCameras))
            ? Math.min(500, Math.max(0, Math.floor(Number(createMaxActiveCameras))))
            : 0,
          host_resolution: createHostResolution,
          member_resolution: createMemberResolution,
          screenshare_resolution: createScreenshareRes,
          scheduled_at: scheduledAt || undefined,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
          category_id: createCategoryId || undefined,
          auto_record: createAutoRecord,
          recording_retention_hours: Number(createRetentionHours) || 48,
          host_join_code: createHostCodeValue
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to create meeting');
      }

      setShowCreateModal(false);
      setCreateName('');
      setCreatePublicId('');
      setCreateDate('');
      setCreateTime('');
      setCreateMaxParticipants(20);
      setCreateDuration(60);
      setCreateKickCooldown(15);
      setCreateHostResolution('360p');
      setCreateMemberResolution('240p');
      setCreateScheduleMode('scheduled');
      setCreatePresetId('');
      setCreateCategoryId('');
      setCreateAutoRecord(false);
      setCreateRetentionHours(48);
      const createdHostCode = typeof data.host_join_code === 'string' && data.host_join_code
        ? data.host_join_code
        : createHostCodeValue;
      setCreateHostCode(randomHostCode());
      addToast(`Meeting dibuat. Kode host: ${createdHostCode} — bagikan ke tentor.`, 'success');
      await fetchMeetings();
    } catch (err: unknown) {
      setCreateError(err instanceof Error ? err.message : 'Creation failed');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleOpenEdit = (m: MeetingItem) => {
    setEditingMeeting(m);
    setEditName(m.name);
    setEditPublicId(m.public_id || '');
    setEditMaxParticipants(m.max_participants);
    setEditDuration(m.duration_minutes);
    setEditKickCooldown(typeof m.kick_cooldown_minutes === 'number' ? m.kick_cooldown_minutes : 15);
    setEditLateJoin(typeof m.late_join_minutes === 'number' ? m.late_join_minutes : 30);
    setEditMaxActiveCameras(typeof m.max_active_cameras === 'number' ? m.max_active_cameras : 0);
    setEditHostResolution(m.host_resolution || '360p');
    setEditMemberResolution(m.member_resolution || '240p');
    setEditScreenshareRes(m.screenshare_resolution || '720p');
    setEditOriginalScheduledAt(m.scheduled_at);
    setEditScheduleMode(m.scheduled_at ? 'scheduled' : 'alltime');
    setEditCategoryId(m.category_id || '');
    setEditAutoRecord(!!m.auto_record);
    setEditRetentionHours(typeof m.recording_retention_hours === 'number' && m.recording_retention_hours >= 1 ? m.recording_retention_hours : 48);

    if (m.scheduled_at) {
      const d = new Date(m.scheduled_at);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const hh = String(d.getHours()).padStart(2, '0');
      const min = String(d.getMinutes()).padStart(2, '0');
      setEditDate(`${yyyy}-${mm}-${dd}`);
      setEditTime(`${hh}:${min}`);
    } else {
      setEditDate('');
      setEditTime('');
    }

    setEditError(null);
    setEditShortExpiryAck(false);
  };

  // Lifecycle action derived from the current status (read-only badge in the form)
  const editLifecycleAction = !editingMeeting
    ? null
    : editingMeeting.status === 'scheduled'
      ? { target: 'active' as const, label: 'Mulai Sekarang' }
      : editingMeeting.status === 'active'
        ? { target: 'ended' as const, label: 'Akhiri Meeting' }
        : editingMeeting.status === 'expired' || editingMeeting.status === 'ended'
          ? { target: 'scheduled' as const, label: 'Buka Kembali' }
          : null;

  // True when the new duration would already be over for a running meeting
  const willExpireImmediately = (durationMinutes: number) =>
    !!editingMeeting &&
    editingMeeting.status === 'active' &&
    !!editingMeeting.started_at &&
    Number.isInteger(durationMinutes) &&
    new Date(editingMeeting.started_at).getTime() + durationMinutes * 60000 <= Date.now();

  const handleLifecycleAction = async () => {
    if (!editingMeeting || !editLifecycleAction || editLifecycleLoading) return;
    setEditLifecycleLoading(true);
    setEditError(null);
    try {
      const res = await fetch(`/api/meetings/${editingMeeting.id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ status: editLifecycleAction.target })
      });
      const data = await res.json().catch(() => ({}) as Record<string, unknown>);
      if (!res.ok) throw new Error(String(data.message || data.error || 'Failed to update meeting status'));
      const updated = (data.meeting || {}) as Partial<MeetingItem>;
      setEditingMeeting({
        ...editingMeeting,
        status: (updated.status ?? editLifecycleAction.target) as MeetingItem['status'],
        started_at: updated.started_at !== undefined ? updated.started_at : editingMeeting.started_at,
        expires_at: updated.expires_at !== undefined ? updated.expires_at : editingMeeting.expires_at
      });
      await fetchMeetings();
      addToast(
        editLifecycleAction.target === 'active'
          ? 'Meeting dimulai sekarang.'
          : editLifecycleAction.target === 'ended'
            ? 'Meeting diakhiri.'
            : 'Meeting dibuka kembali.',
        'success'
      );
    } catch (err: unknown) {
      setEditError(err instanceof Error ? err.message : 'Failed to update meeting status');
    } finally {
      setEditLifecycleLoading(false);
    }
  };

  const handleSaveEdit = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingMeeting) return;
    if (!editName.trim()) {
      setEditError('Meeting name is required');
      return;
    }

    const capacityValue = Number(editMaxParticipants);
    if (!Number.isInteger(capacityValue) || capacityValue < 1 || capacityValue > 500) {
      setEditError('Room Capacity harus berupa bilangan bulat antara 1 dan 500.');
      return;
    }

    const durationValue = Number(editDuration);
    if (!Number.isInteger(durationValue) || durationValue < 1 || durationValue > 1440) {
      setEditError('Duration harus berupa bilangan bulat antara 1 dan 1440 menit.');
      return;
    }

    const retentionValue = Number(editRetentionHours);
    if (!Number.isInteger(retentionValue) || retentionValue < 1 || retentionValue > 720) {
      setEditError('Retensi rekaman harus berupa bilangan bulat antara 1 dan 720 jam.');
      return;
    }

    const kickCooldownValue = Number(editKickCooldown);
    if (!Number.isInteger(kickCooldownValue) || kickCooldownValue < 0 || kickCooldownValue > 1440) {
      setEditError('Jeda kick harus berupa bilangan bulat antara 0 dan 1440 menit (0 = tanpa jeda).');
      return;
    }

    const lateJoinValue = Number(editLateJoin);
    if (!Number.isInteger(lateJoinValue) || lateJoinValue < 0 || lateJoinValue > 1440) {
      setEditError('Batas terlambat join harus berupa bilangan bulat antara 0 dan 1440 menit (0 = tanpa batas).');
      return;
    }

    let scheduledAt: string | null = null;
    if (editScheduleMode === 'scheduled') {
      if (!editDate || !editTime) {
        setEditError('Schedule Date dan Start Time wajib diisi pada mode Scheduled.');
        return;
      }
      const combined = new Date(`${editDate}T${editTime}`);
      if (isNaN(combined.getTime())) {
        setEditError('Schedule Date atau Start Time tidak valid.');
        return;
      }

      const origLocalMatch = editOriginalScheduledAt
        ? (() => {
            const od = new Date(editOriginalScheduledAt);
            const origDateStr = `${od.getFullYear()}-${String(od.getMonth() + 1).padStart(2, '0')}-${String(od.getDate()).padStart(2, '0')}`;
            const origTimeStr = `${String(od.getHours()).padStart(2, '0')}:${String(od.getMinutes()).padStart(2, '0')}`;
            return origDateStr === editDate && origTimeStr === editTime;
          })()
        : false;

      // Unchanged local date+time → resend the original ISO (avoids UTC↔local shift)
      scheduledAt = origLocalMatch && editOriginalScheduledAt ? editOriginalScheduledAt : combined.toISOString();
    }

    // Shortening a running meeting past its start makes it expire immediately —
    // require an explicit confirmation on the first click.
    if (willExpireImmediately(durationValue) && !editShortExpiryAck) {
      setEditShortExpiryAck(true);
      setEditError(null);
      return;
    }

    setEditLoading(true);
    setEditError(null);

    try {
      const res = await fetch(`/api/meetings/${editingMeeting.id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          name: editName.trim(),
          public_id: editPublicId.trim() || undefined,
          max_participants: capacityValue,
          duration_minutes: durationValue,
          host_resolution: editHostResolution,
          member_resolution: editMemberResolution,
          screenshare_resolution: editScreenshareRes,
          scheduled_at: scheduledAt,
          category_id: editCategoryId || null,
          auto_record: editAutoRecord,
          recording_retention_hours: retentionValue,
          kick_cooldown_minutes: kickCooldownValue,
          late_join_minutes: lateJoinValue,
          max_active_cameras: Number.isFinite(Number(editMaxActiveCameras))
            ? Math.min(500, Math.max(0, Math.floor(Number(editMaxActiveCameras))))
            : 0
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to update meeting');
      }

      setEditingMeeting(null);
      await fetchMeetings();
    } catch (err: unknown) {
      setEditError(err instanceof Error ? err.message : 'Update failed');
    } finally {
      setEditLoading(false);
    }
  };

  /* Snapshot form Create — diambil saat modal dibuka, dipakai untuk
     memperingatkan perubahan yang belum disimpan saat menutup. */
  const createSnapshotNow = () =>
    JSON.stringify({
      n: createName, p: createPublicId, c: createCategoryId, ps: createPresetId,
      ar: createAutoRecord, rh: createRetentionHours, hc: createHostCode,
      sm: createScheduleMode, d: createDate, t: createTime,
      mp: createMaxParticipants, du: createDuration, kc: createKickCooldown,
      lj: createLateJoin, mac: createMaxActiveCameras,
      hr: createHostResolution, mr: createMemberResolution, sr: createScreenshareRes,
    });

  const editSnapshotNow = () =>
    JSON.stringify({
      n: editName, p: editPublicId, c: editCategoryId,
      ar: editAutoRecord, rh: editRetentionHours,
      sm: editScheduleMode, d: editDate, t: editTime,
      mp: editMaxParticipants, du: editDuration, kc: editKickCooldown,
      lj: editLateJoin, mac: editMaxActiveCameras,
      hr: editHostResolution, mr: editMemberResolution, sr: editScreenshareRes,
    });

  useEffect(() => {
    if (showCreateModal) {
      setCreateSnapshot(createSnapshotNow());
    } else {
      setCreateFieldErrors({});
      setCreateAdvanced(false);
      setCreateError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showCreateModal]);

  useEffect(() => {
    if (editingMeeting) {
      setEditSnapshot(editSnapshotNow());
    } else {
      setEditFieldErrors({});
      setEditAdvanced(false);
      setEditError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingMeeting]);

  const requestCloseCreate = () => {
    if (createLoading || discardCreate) return;
    if (showCreateModal && createSnapshot && createSnapshotNow() !== createSnapshot) {
      setDiscardCreate(true);
      return;
    }
    setShowCreateModal(false);
  };

  const requestCloseEdit = () => {
    if (editLoading || editLifecycleLoading || discardEdit) return;
    if (editingMeeting && editSnapshot && editSnapshotNow() !== editSnapshot) {
      setDiscardEdit(true);
      return;
    }
    setEditingMeeting(null);
  };

  /* Submit wrapper: validasi inline klien → fokus error pertama →
     handler submit lama dipanggil tanpa perubahan (payload & endpoint sama). */
  const onCreateSubmit = (e: FormEvent) => {
    e.preventDefault();
    const errs = validateCreateValues({
      name: createName,
      hostCode: createHostCode,
      scheduleMode: createScheduleMode,
      date: createDate,
      time: createTime,
      capacity: Number(createMaxParticipants),
      duration: Number(createDuration),
      retention: Number(createRetentionHours),
      kick: Number(createKickCooldown),
      late: Number(createLateJoin),
      cameras: Number(createMaxActiveCameras),
    });
    setCreateFieldErrors(errs);
    const first = CREATE_FIELD_ORDER.find(k => errs[k]);
    if (first) {
      if (CREATE_ADVANCED_FIELDS.has(first)) setCreateAdvanced(true);
      requestAnimationFrame(() => document.getElementById(first)?.focus());
      return;
    }
    handleCreateMeeting(e);
  };

  const onEditSubmit = (e: FormEvent) => {
    e.preventDefault();
    const errs = validateEditValues({
      name: editName,
      scheduleMode: editScheduleMode,
      date: editDate,
      time: editTime,
      capacity: Number(editMaxParticipants),
      duration: Number(editDuration),
      retention: Number(editRetentionHours),
      kick: Number(editKickCooldown),
      late: Number(editLateJoin),
      cameras: Number(editMaxActiveCameras),
    });
    setEditFieldErrors(errs);
    const first = EDIT_FIELD_ORDER.find(k => errs[k]);
    if (first) {
      if (EDIT_ADVANCED_FIELDS.has(first)) setEditAdvanced(true);
      requestAnimationFrame(() => document.getElementById(first)?.focus());
      return;
    }
    handleSaveEdit(e);
  };

  const handleDeleteMeeting = async () => {
    if (!deletingMeeting) return;
    setDeleteLoading(true);

    try {
      const res = await fetch(`/api/meetings/${deletingMeeting.id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || data.error || 'Failed to delete meeting');
      }

      setDeletingMeeting(null);
      await fetchMeetings();
    } catch (err: unknown) {
      addToast(err instanceof Error ? err.message : 'Gagal menghapus meeting', 'error');
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleInspect = async (m: MeetingItem) => {
    setInspectMeeting(m);
    setInspectLoading(true);
    setHostJoinCode(null);
    fetchTentors(m.id);
    try {
      const res = await fetch(`/api/meetings/${m.id}`, { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        setInspectParticipants(data.participants || []);
        setHostJoinCode(typeof data.meeting?.host_join_code === 'string' && data.meeting.host_join_code ? data.meeting.host_join_code : null);
      }
    } catch {
      setInspectParticipants([]);
    } finally {
      setInspectLoading(false);
    }
  };

  // Auto-refresh participants while inspector is open
  useEffect(() => {
    if (!inspectMeeting) return;

    let cancelled = false;
    const fetchParticipants = async () => {
      try {
        const res = await fetch(`/api/meetings/${inspectMeeting.id}`, { credentials: 'include' });
        if (res.ok && !cancelled) {
          const data = await res.json();
          setInspectParticipants(data.participants || []);
        }
      } catch {
        // silently ignore
      }
    };

    fetchParticipants();
    const intervalId = setInterval(fetchParticipants, 4000);
    return () => {
      cancelled = true;
      clearInterval(intervalId);
    };
  }, [inspectMeeting]);

  const handleJoinMeeting = async (meetingIdOrCode: string) => {
    const code = meetingIdOrCode.trim();
    if (!code) return;
    setQuickJoinLoading(true);

    try {
      const userId = getPersistentUserId();
      const res = await fetch('/api/tokens', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          meetingId: code,
          userId,
          name: user?.name || user?.username || 'Host Admin',
          presetName: 'group_call_host'
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to join meeting');
      }

      const authToken = getAuthTokenFromResponse(data);
      if (!authToken) throw new Error('Missing auth token from response');

      const targetId = data.public_id || data.meeting_id || code;
      const adminName = user?.name || user?.username || 'Host Admin';
      const persistentId = getPersistentUserId();
      setActiveMeetingSession(targetId, persistentId, adminName);
      try {
        sessionStorage.setItem(`rtk:token:${targetId}`, authToken);
      } catch { /* ignore */ }

      navigate(`/meeting/${targetId}`);
    } catch (err: unknown) {
      addToast(err instanceof Error ? err.message : 'Gagal join meeting', 'error');
    } finally {
      setQuickJoinLoading(false);
    }
  };

  // Filtered lists
  const upcomingMeetings = useMemo(() => {
    return meetings
      .filter(m => m.status === 'active' || m.status === 'scheduled')
      .sort((a, b) => {
        const aTime = a.scheduled_at ? new Date(a.scheduled_at).getTime() : 0;
        const bTime = b.scheduled_at ? new Date(b.scheduled_at).getTime() : 0;
        return bTime - aTime;
      });
  }, [meetings]);

  const pastMeetings = useMemo(() => {
    return meetings
      .filter(m => m.status === 'expired' || m.status === 'ended')
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
  }, [meetings]);

  const displayedMeetings = useMemo(() => {
    let list = viewTab === 'upcoming' ? upcomingMeetings : viewTab === 'past' ? pastMeetings : meetings;

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(m =>
        m.name.toLowerCase().includes(q) ||
        (m.public_id && m.public_id.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (categoryFilter) {
      list = list.filter(m => m.category_id === categoryFilter);
    }

    // Sort
    list = [...list].sort((a, b) => {
      let cmp = 0;
      if (sortField === 'name') cmp = a.name.localeCompare(b.name);
      else if (sortField === 'scheduled_at') cmp = (a.scheduled_at || '').localeCompare(b.scheduled_at || '');
      else if (sortField === 'status') cmp = a.status.localeCompare(b.status);
      else if (sortField === 'max_participants') cmp = a.max_participants - b.max_participants;
      else if (sortField === 'duration_minutes') cmp = a.duration_minutes - b.duration_minutes;
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return list;
  }, [viewTab, meetings, upcomingMeetings, pastMeetings, searchQuery, categoryFilter, sortField, sortDir]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(displayedMeetings.length / perPage));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedMeetings = displayedMeetings.slice((safePage - 1) * perPage, safePage * perPage);

  // Filtered & Paginated Presets
  const filteredPresets = useMemo(() => {
    if (!presetSearchQuery.trim()) return presets;
    const q = presetSearchQuery.toLowerCase();
    return presets.filter(p => p.name.toLowerCase().includes(q));
  }, [presets, presetSearchQuery]);
  const safePresetPage = Math.min(presetPage, Math.max(1, Math.ceil(filteredPresets.length / presetPerPage)));
  const paginatedPresets = filteredPresets.slice((safePresetPage - 1) * presetPerPage, safePresetPage * presetPerPage);

  // Filtered & Paginated Recordings
  const filteredRecordings = useMemo(() => {
    if (!recordingSearchQuery.trim()) return recordings;
    const q = recordingSearchQuery.toLowerCase();
    return recordings.filter(r => {
      const meeting = meetings.find(m => m.id === r.meeting_id);
      const meetingName = meeting?.name?.toLowerCase() || '';
      const meetingPublicId = meeting?.public_id?.toLowerCase() || '';
      const fileName = r.file_name?.toLowerCase() || '';
      return fileName.includes(q) || meetingName.includes(q) || meetingPublicId.includes(q);
    });
  }, [recordings, recordingSearchQuery, meetings]);
  const safeRecordingPage = Math.min(recordingPage, Math.max(1, Math.ceil(filteredRecordings.length / recordingPerPage)));
  const paginatedRecordings = filteredRecordings.slice((safeRecordingPage - 1) * recordingPerPage, safeRecordingPage * recordingPerPage);

  // Reset to page 1 when filters change
  useEffect(() => { setCurrentPage(1); }, [searchQuery, categoryFilter, sortField, sortDir, perPage]);
  useEffect(() => { setPresetPage(1); }, [presetSearchQuery, presetPerPage]);
  useEffect(() => { setRecordingPage(1); }, [recordingSearchQuery, recordingPerPage]);

  // Sort toggle
  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };
  const ariaSort = (field: typeof sortField): 'ascending' | 'descending' | 'none' =>
    sortField === field ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none';

  // Menu aksi per baris (dipakai tabel desktop & kartu mobile)
  const meetingMenuItems = (m: MeetingItem): DropdownMenuItem[] => [
    { id: 'copy-id', label: 'Salin ID', icon: Copy, onSelect: () => handleCopyId(m) },
    { id: 'copy-link', label: 'Salin tautan', icon: LinkIcon, onSelect: () => handleCopyLink(m) },
    { id: 'inspect', label: 'Lihat peserta', icon: Users, onSelect: () => handleInspect(m) },
    { id: 'edit', label: 'Edit meeting', icon: Edit2, onSelect: () => handleOpenEdit(m) },
    { id: 'delete', label: 'Hapus meeting', icon: Trash2, danger: true, onSelect: () => setDeletingMeeting(m) },
  ];

  // Bulk select
  const toggleSelectAll = () => {
    if (selectedIds.size === paginatedMeetings.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(paginatedMeetings.map(m => m.id)));
  };
  const toggleSelectOne = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  // Bulk delete
  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;
    setConfirmDialog({
      open: true,
      title: 'Hapus Meeting?',
      message: `Anda yakin ingin menghapus ${selectedIds.size} meeting(s)? Tindakan ini tidak dapat dibatalkan.`,
      variant: 'danger',
      onConfirm: async () => {
        setConfirmDialog(prev => ({ ...prev, loading: true, open: true }));
        try {
          for (const id of selectedIds) {
            await fetch(`/api/meetings/${id}`, { method: 'DELETE', credentials: 'include' });
          }
          setSelectedIds(new Set());
          await fetchMeetings();
          addToast(`${selectedIds.size} meeting berhasil dihapus`, 'success');
        } catch {
          addToast('Gagal menghapus meeting', 'error');
        }
        setConfirmDialog({ open: false, title: '', message: '', onConfirm: () => {} });
      }
    });
  };

  // Calendar Planner calculations
  const monthYearStr = calendarDate.toLocaleString('id-ID', { month: 'long', year: 'numeric' });
  const daysInMonth = new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 0).getDate();
  const firstDayIndex = new Date(calendarDate.getFullYear(), calendarDate.getMonth(), 1).getDay();

  const calendarDays = useMemo(() => {
    const days: { dayNumber: number; dateStr: string; meetings: MeetingItem[] }[] = [];
    const year = calendarDate.getFullYear();
    const month = calendarDate.getMonth();

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayMeetings = meetings.filter(m => {
        if (!m.scheduled_at) return false;
        const mDate = new Date(m.scheduled_at);
        return (
          mDate.getFullYear() === year &&
          mDate.getMonth() === month &&
          mDate.getDate() === d
        );
      });
      days.push({ dayNumber: d, dateStr, meetings: dayMeetings });
    }
    return days;
  }, [calendarDate, daysInMonth, meetings]);

  const selectedDateMeetings = useMemo(() => {
    if (!selectedCalendarDate) return [];
    return meetings.filter(m => {
      if (!m.scheduled_at) return false;
      const mDate = new Date(m.scheduled_at);
      const dateStr = `${mDate.getFullYear()}-${String(mDate.getMonth() + 1).padStart(2, '0')}-${String(mDate.getDate()).padStart(2, '0')}`;
      return dateStr === selectedCalendarDate;
    });
  }, [selectedCalendarDate, meetings]);

  // Dashboard: meeting aktif/terjadwal, diurutkan prioritas — yang butuh
  // tindakan (berlangsung) dulu, lalu jadwal paling dekat.
  // Daftar ini yang punya scroll internal, jadi tidak dibatasi 5 item.
  const dashboardUpcoming = useMemo(() => {
    return meetings
      .filter(m => m.status === 'active' || m.status === 'scheduled')
      .sort((a, b) => {
        if (a.status !== b.status) return a.status === 'active' ? -1 : 1;
        const aTime = a.scheduled_at ? new Date(a.scheduled_at).getTime() : Number.MAX_SAFE_INTEGER;
        const bTime = b.scheduled_at ? new Date(b.scheduled_at).getTime() : Number.MAX_SAFE_INTEGER;
        return aTime - bTime;
      });
  }, [meetings]);

  // Dashboard: 5 rekaman terbaru
  const dashboardRecordings = useMemo(() => recordings.slice(0, 5), [recordings]);

  // Stat ringkas — hanya derivasi lokal dari data yang sudah dimuat (tanpa query baru).
  const activeMeetingCount = useMemo(
    () => meetings.filter(m => m.status === 'active').length,
    [meetings],
  );
  const todaysMeetingCount = useMemo(() => {
    const t = new Date();
    return meetings.filter(m => {
      if (!m.scheduled_at) return false;
      const d = new Date(m.scheduled_at);
      return d.getFullYear() === t.getFullYear() && d.getMonth() === t.getMonth() && d.getDate() === t.getDate();
    }).length;
  }, [meetings]);
  // Seret sparkline: jumlah meeting per hari (14 hari ke depan) & rekaman per hari (14 hari terakhir).
  const upcomingDaily = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const counts = Array.from({ length: 14 }, (_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      return { key: dayKey(d), n: 0 };
    });
    const idx = new Map(counts.map(c => [c.key, c]));
    for (const m of meetings) {
      if (!m.scheduled_at) continue;
      const cell = idx.get(dayKey(new Date(m.scheduled_at)));
      if (cell) cell.n++;
    }
    return counts.map(c => c.n);
  }, [meetings]);
  const recordingDaily = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const counts = Array.from({ length: 14 }, (_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() - (13 - i));
      return { key: dayKey(d), n: 0 };
    });
    const idx = new Map(counts.map(c => [c.key, c]));
    for (const r of recordings) {
      const cell = idx.get(dayKey(new Date(r.created_at)));
      if (cell) cell.n++;
    }
    return counts.map(c => c.n);
  }, [recordings]);

  const meetingDatesInMonth = useMemo(
    () => new Set(calendarDays.filter(d => d.meetings.length > 0).map(d => d.dateStr)),
    [calendarDays]
  );

  const getStatusBadge = (status: MeetingItem['status']) => {
    switch (status) {
      case 'active':
        return <span className="px-2 py-0.5 text-xs bg-emerald-950 border border-emerald-700 text-emerald-300 rounded font-medium">Active</span>;
      case 'scheduled':
        return <span className="px-2 py-0.5 text-xs bg-sky-950 border border-sky-700 text-sky-300 rounded font-medium">Scheduled</span>;
      case 'expired':
        return <span className="px-2 py-0.5 text-xs bg-amber-950 border border-amber-700 text-amber-300 rounded font-medium">Expired</span>;
      case 'ended':
        return <span className="px-2 py-0.5 text-xs bg-slate-800 border border-slate-700 text-slate-400 rounded font-medium">Ended</span>;
      default:
        return <span className="px-2 py-0.5 text-xs bg-slate-800 text-slate-300 rounded font-medium">{status}</span>;
    }
  };

  const formatSchedule = (scheduled_at: string | null, started_at?: string | null) => {
    // Tanpa jadwal tapi sudah pernah dipakai → tampilkan jam pemakaian pertama.
    if (!scheduled_at && started_at) {
      const d = new Date(started_at);
      return (
        <span className="inline-flex items-center gap-1 text-xs text-emerald-300 font-medium">
          <Clock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          {d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })} • {d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
        </span>
      );
    }
    if (!scheduled_at) return <span className="text-slate-500 italic text-xs">Instant / Unscheduled</span>;
    const d = new Date(scheduled_at);
    return (
      <span className="inline-flex items-center gap-1 text-xs text-sky-300 font-medium">
        <CalendarIcon className="w-3.5 h-3.5 text-sky-400 shrink-0" />
        {d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })} • {d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
      </span>
    );
  };

  // Superadmin = pengelola akun, bukan operator: hanya menu Kelola Admin.
  // Admin = operator: seluruh menu operasional + Pengaturan, tanpa Kelola Admin.
  const NAV_GROUPS: ShellNavGroup[] = user?.role === 'superadmin'
    ? [
        {
          label: 'Akun',
          items: [
            { tab: 'admins', icon: Users, label: 'Kelola Admin', tooltip: 'Kelola akun admin', count: null },
          ],
        },
      ]
    : [
        {
          label: 'Utama',
          items: [
            { tab: 'dashboard', icon: LayoutDashboard, label: 'Dasbor', tooltip: 'Ringkasan dasbor', count: null },
            { tab: 'upcoming', icon: Clock, label: 'Akan Datang', tooltip: 'Meeting akan datang', count: upcomingMeetings.length },
            { tab: 'past', icon: History, label: 'Riwayat', tooltip: 'Meeting yang sudah selesai', count: pastMeetings.length },
            { tab: 'all', icon: List, label: 'Semua Meeting', tooltip: 'Semua meeting', count: meetings.length },
          ],
        },
        {
          label: 'Meeting',
          items: [
            { tab: 'planner', icon: CalendarDays, label: 'Kalender', tooltip: 'Perencana kalender', count: null },
            { tab: 'presets', icon: Layout, label: 'Preset', tooltip: 'Preset meeting', count: presets.length },
            { tab: 'recordings', icon: Video, label: 'Rekaman', tooltip: 'Rekaman sesi', count: recordings.length },
          ],
        },
        {
          label: 'Pengaturan',
          items: [
            { tab: 'settings', icon: Sliders, label: 'Pengaturan', tooltip: 'Pengaturan situs', count: null },
          ],
        },
      ];

  const handleNavClick = (tab: ViewTab) => {
    setViewTab(tab);
    if (tab === 'recordings') fetchRecordings();
    if (tab === 'settings') fetchSettings();
    if (tab === 'dashboard' && recordings.length === 0 && !recordingsLoading) fetchRecordings();
  };

  // View tabel (4A) sudah punya PageHeader sendiri — judul & tombol "Tambah"
  // dipindah ke sana agar tidak ganda dengan toolbar atas.
  const isTableView = viewTab === 'upcoming' || viewTab === 'past' || viewTab === 'all';

  return (
    <DashboardShell
      navGroups={NAV_GROUPS}
      activeTab={viewTab}
      onNavigate={tab => handleNavClick(tab as ViewTab)}
      title={PAGE_TITLES[viewTab]}
      user={user}
      logo={logo}
      siteTitle={title || DEFAULT_SITE_TITLE}
      onLogout={async () => {
        await logout();
        navigate('/admin/login');
      }}
    >
        {/* Top Actions & Quick Join. Tidak ditampilkan di Dashboard supaya widget muat satu layar. */}
        {viewTab !== 'dashboard' && (
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6 sm:mb-8 bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 overflow-hidden">
          <div>
            {!isTableView && (
              <h1 className="text-lg sm:text-2xl font-bold text-slate-100">{PAGE_TITLES[viewTab]}</h1>
            )}
          </div>

          {/* Superadmin = pengelola akun: toolbar meeting (quick join/import/export/create) tidak ditampilkan. */}
          {user?.role !== 'superadmin' && (
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 w-full md:w-auto min-w-0">
            <div className="flex items-center gap-2 flex-1 md:flex-initial min-w-0">
              <input
                value={quickJoinCode}
                onChange={(e) => setQuickJoinCode(e.target.value)}
                placeholder="Meeting ID"
                className="px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-600 w-full sm:w-44"
              />
              <button
                onClick={() => handleJoinMeeting(quickJoinCode)}
                disabled={!quickJoinCode.trim() || quickJoinLoading}
                className="px-3 py-2 border-2 accent-btn text-sm font-medium disabled:opacity-50 inline-flex items-center gap-1 cursor-pointer shrink-0"
              >
                <LogIn className="w-4 h-4" />
                Join
              </button>
            </div>

            <Tooltip content="Bulk Import Meetings">
              <button
                onClick={() => {
                  setShowBulkImportModal(true);
                  setBulkMeetings([{ name: '', publicId: '', scheduleMode: bulkDefaultScheduleMode, date: '', time: '' }]);
                  setBulkError(null);
                }}
                aria-label="Bulk Import Meetings"
                className="p-2 min-w-10 min-h-10 flex items-center justify-center border-2 border-slate-600 bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer rounded"
              >
                <Upload className="w-4 h-4" />
              </button>
            </Tooltip>

            <Tooltip content="Export to Excel">
              <button
                onClick={handleExportExcel}
                disabled={displayedMeetings.length === 0 || exporting}
                aria-label="Export to Excel"
                className="p-2 min-w-10 min-h-10 flex items-center justify-center border-2 border-slate-600 bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer rounded disabled:opacity-50"
              >
                <Sliders className="w-4 h-4 rotate-90" />
              </button>
            </Tooltip>

            {!isTableView && (
            <button
              onClick={() => {
                setShowCreateModal(true);
                setCreatePublicId(generateAutoId(createName || 'class'));
                setCreateHostCode(randomHostCode());
              }}
              className="px-3 sm:px-4 py-2 border-2 accent-btn text-sm font-medium inline-flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">New Meeting</span><span className="sm:hidden">New</span>
            </button>
            )}
          </div>
          )}
        </div>
        )}

        {/* View: Dashboard */}
        {viewTab === 'dashboard' && (
          <div className="flex flex-col gap-4 sm:gap-6">
            <PageHeader
              title={PAGE_TITLES[viewTab]}
              description="Ringkasan meeting, aktivitas hari ini, dan rekaman terbaru."
              actions={
                <Button
                  variant="primary"
                  icon={<Plus className="w-4 h-4" />}
                  onClick={() => {
                    setShowCreateModal(true);
                    setCreatePublicId(generateAutoId(createName || 'class'));
                    setCreateHostCode(randomHostCode());
                  }}
                >
                  Tambah Meeting
                </Button>
              }
            />

            {/* Stat ringkas — diurutkan prioritas: yang butuh tindakan dulu */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              <StatCard
                label="Meeting berlangsung"
                value={activeMeetingCount}
                icon={<Video className="w-4 h-4" />}
                hint={activeMeetingCount > 0 ? 'Sedang berjalan sekarang' : 'Tidak ada yang berjalan'}
              />
              <StatCard
                label="Meeting hari ini"
                value={todaysMeetingCount}
                icon={<CalendarIcon className="w-4 h-4" />}
                hint={`dari ${meetings.length} total meeting`}
              />
              <StatCard
                label="Meeting akan datang"
                value={dashboardUpcoming.length}
                icon={<Clock className="w-4 h-4" />}
                hint="14 hari ke depan"
                visual={<Sparkline values={upcomingDaily} />}
              />
              <StatCard
                label="Rekaman tersimpan"
                value={recordings.length}
                icon={<Video className="w-4 h-4" />}
                hint="14 hari terakhir"
                visual={<Sparkline values={recordingDaily} />}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:min-h-[calc(100dvh-6.5rem)]">
            {/* Kolom kiri: daftar prioritas (berlangsung → terdekat), satu-satunya area dengan scroll */}
            <section className="lg:col-span-2 rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-sm p-4 sm:p-5 flex flex-col min-h-0">
              <div className="flex items-center justify-between gap-3 mb-4 shrink-0">
                <h2 className="text-sm sm:text-base font-semibold text-[var(--ds-text)] flex items-center gap-2 min-w-0">
                  <Clock className="w-4 h-4 text-[var(--ds-accent-text)] shrink-0" />
                  <span className="truncate">Meeting Akan Datang</span>
                  <Badge tone="neutral">{dashboardUpcoming.length}</Badge>
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<ExternalLink className="w-4 h-4" />}
                  onClick={() => setViewTab('upcoming')}
                >
                  Lihat semua
                </Button>
              </div>

              {loading && meetings.length === 0 ? (
                <MeetingListSkeleton />
              ) : error ? (
                <ErrorState message={error} onRetry={fetchMeetings} />
              ) : dashboardUpcoming.length === 0 ? (
                <EmptyState
                  icon={<CalendarDays className="w-8 h-8" aria-hidden="true" />}
                  title="Tidak ada meeting akan datang"
                  description="Meeting baru atau jadwal berikutnya akan muncul di sini."
                  action={
                    <Button
                      variant="primary"
                      size="sm"
                      icon={<Plus className="w-4 h-4" />}
                      onClick={() => {
                        setShowCreateModal(true);
                        setCreatePublicId(generateAutoId(createName || 'class'));
                        setCreateHostCode(randomHostCode());
                      }}
                    >
                      Tambah Meeting
                    </Button>
                  }
                />
              ) : (
                <ul className="flex-1 min-h-0 overflow-y-auto flex flex-col gap-2 pr-1">
                  {dashboardUpcoming.map((m) => (
                    <li
                      key={m.id}
                      className="flex flex-wrap items-center gap-3 p-3 bg-[var(--ds-bg-raised)] border border-[var(--ds-border)] rounded-[var(--ds-r-control)] hover:border-slate-600 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-100 truncate" title={m.name}>{m.name}</p>
                        <div className="mt-1">{formatSchedule(m.scheduled_at, m.started_at)}</div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {statusPill(m.status)}
                        <Button
                          variant="primary"
                          size="sm"
                          icon={<ExternalLink className="w-4 h-4" />}
                          onClick={() => handleJoinMeeting(m.public_id || m.id)}
                          aria-label={`Gabung ${m.name}`}
                        >
                          Gabung
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* Kolom kanan: Recordings (detail) di atas, Calendar mini di bawah */}
            <div className="flex flex-col gap-4 sm:gap-6 min-h-0 lg:h-full">
            <section className="rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-sm flex flex-col min-h-0 lg:flex-1">
              <header className="flex items-center justify-between gap-3 px-4 sm:px-5 py-3.5 border-b border-[var(--ds-border)] shrink-0">
                <h2 className="text-sm sm:text-base font-semibold text-[var(--ds-text)] flex items-center gap-2 min-w-0">
                  <Video className="w-4 h-4 text-[var(--ds-accent-text)] shrink-0" />
                  <span className="truncate">Rekaman</span>
                  <Badge tone="neutral">{recordings.length}</Badge>
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<ExternalLink className="w-4 h-4" />}
                  onClick={() => setViewTab('recordings')}
                >
                  Lihat semua
                </Button>
              </header>

              <PendingRecordingUploads onUploaded={fetchRecordings} />

              <div className="p-4 sm:p-5 flex flex-col min-h-0 flex-1">
              {recordingsLoading && dashboardRecordings.length === 0 ? (
                <MeetingListSkeleton />
              ) : recordingsError ? (
                <ErrorState message={recordingsError} onRetry={fetchRecordings} />
              ) : dashboardRecordings.length === 0 ? (
                <EmptyState
                  icon={<Video className="w-8 h-8" aria-hidden="true" />}
                  title="Belum ada rekaman"
                  description="Rekaman dari meeting yang selesai akan muncul di sini."
                />
              ) : (
                <div className="flex-1 min-h-0 overflow-y-auto flex flex-col gap-3 pr-1">
                  {dashboardRecordings.map((rec) => (
                    <RecordingCard
                      key={rec.id}
                      recording={rec}
                      meetings={meetings}
                      onPlay={setSelectedRecording}
                    />
                  ))}
                </div>
              )}
              </div>
            </section>

            {/* Kolom kanan bawah: Calendar mini read-only */}
            <section className="rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] shadow-sm flex flex-col shrink-0">
              <header className="flex items-center justify-between gap-3 px-4 sm:px-5 py-3.5 border-b border-[var(--ds-border)]">
                <h2 className="text-sm sm:text-base font-semibold text-[var(--ds-text)] flex items-center gap-2 min-w-0">
                  <CalendarDays className="w-4 h-4 text-[var(--ds-accent-text)] shrink-0" />
                  <span className="truncate capitalize">{monthYearStr}</span>
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<ExternalLink className="w-4 h-4" />}
                  onClick={() => setViewTab('planner')}
                >
                  Lihat semua
                </Button>
              </header>

              <div className="p-4 sm:p-5">
              <div className="flex items-center justify-between mb-2">
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Bulan sebelumnya"
                  onClick={() => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() - 1, 1))}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCalendarDate(new Date())}
                >
                  Hari ini
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Bulan berikutnya"
                  onClick={() => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 1))}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

              {loading && meetings.length === 0 ? (
                <div className="grid grid-cols-7 gap-1" aria-hidden="true">
                  {Array.from({ length: 35 }).map((_, i) => (
                    <Skeleton key={i} className="h-9" />
                  ))}
                </div>
              ) : error ? (
                <ErrorState message={error} onRetry={fetchMeetings} />
              ) : meetings.length === 0 ? (
                <EmptyState
                  icon={<CalendarDays className="w-8 h-8" aria-hidden="true" />}
                  title="Belum ada meeting"
                  description="Buat meeting untuk mengisi kalender."
                  className="py-6"
                />
              ) : (
                <>
                  <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-semibold text-slate-400 mb-1">
                    <div>Min</div>
                    <div>Sel</div>
                    <div>Rab</div>
                    <div>Kam</div>
                    <div>Jum</div>
                    <div>Sab</div>
                    <div>Min</div>
                  </div>

                  <div className="grid grid-cols-7 gap-1">
                    {Array.from({ length: firstDayIndex }).map((_, i) => (
                      <div key={`dash-empty-${i}`} className="h-9 bg-slate-950/30 border border-slate-800/40 rounded"></div>
                    ))}

                    {calendarDays.map((item) => {
                      const isToday = new Date().toISOString().slice(0, 10) === item.dateStr;
                      const hasMeeting = meetingDatesInMonth.has(item.dateStr);
                      return (
                        <button
                          key={item.dateStr}
                          onClick={() => {
                            setSelectedCalendarDate(item.dateStr);
                            const [y, mo] = item.dateStr.split('-').map(Number);
                            setCalendarDate(new Date(y, mo - 1, 1));
                            setViewTab('planner');
                          }}
                          aria-label={`${item.dateStr}, ${item.meetings.length} meeting. Buka kalender.`}
                          className={`h-9 border rounded p-1 flex items-start justify-between cursor-pointer transition-all focus:outline-none focus:ring-2 focus:ring-emerald-600 ${
                            isToday
                              ? 'border-slate-600 bg-slate-800/80'
                              : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                          }`}
                        >
                          <span className={`text-xs font-semibold ${isToday ? 'text-emerald-400' : 'text-slate-300'}`}>
                            {item.dayNumber}
                          </span>
                          {hasMeeting && <span className="w-2 h-2 rounded-full bg-emerald-400 mt-1 shrink-0"></span>}
                        </button>
                      );
                    })}
                  </div>

                  {meetingDatesInMonth.size === 0 && (
                    <p className="text-xs text-slate-500 text-center mt-3">Tidak ada meeting bulan ini.</p>
                  )}
                </>
              )}
              </div>
            </section>
            </div>
            </div>
          </div>
        )}

        {/* View: Presets */}
        {viewTab === 'presets' && (
          <div className="bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
                <Layout className="w-5 h-5 text-emerald-400" />
                Meeting Presets
                <span className="text-xs bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                  {presets.length}
                </span>
              </h2>
              <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                <input
                  type="text"
                  placeholder="Cari preset..."
                  value={presetSearchQuery}
                  onChange={(e) => setPresetSearchQuery(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-slate-800 border border-slate-700 text-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-emerald-600 w-36 sm:w-48"
                />
                <button
                  onClick={fetchPresets}
                  disabled={presetsLoading}
                  className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${presetsLoading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
                <button
                  onClick={openPresetCreate}
                  className="px-3 py-1.5 border-2 accent-btn text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Create Preset
                </button>
              </div>
            </div>

            {presetsLoading && presets.length === 0 ? (
              <div className="py-16 text-center text-slate-400">
                <div className="w-8 h-8 border-4 border-slate-700 border-t-emerald-500 rounded-full animate-spin mx-auto mb-3"></div>
                Loading presets...
              </div>
            ) : presets.length === 0 ? (
              <div className="py-16 text-center text-slate-400 border border-dashed border-slate-800">
                <p className="text-base font-medium text-slate-300">No presets created yet.</p>
                <p className="text-xs text-slate-500 mt-1">Create a preset to speed up meeting configuration.</p>
              </div>
            ) : filteredPresets.length === 0 ? (
              <div className="py-12 text-center text-slate-400 border border-dashed border-slate-800">
                <p className="text-sm font-medium text-slate-300">Tidak ada preset yang cocok dengan pencarian.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {paginatedPresets.map((preset) => (
                  <div key={preset.id} className="p-4 bg-slate-800/80 border border-slate-700 rounded-lg hover:border-slate-600 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-sm text-slate-100">{preset.name}</h3>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => openPresetEdit(preset)}
                          title="Edit preset"
                          className="p-1 border border-slate-600 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded transition-colors cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeletingPreset(preset)}
                          title="Delete preset"
                          className="p-1 border border-red-900/60 hover:bg-red-950 text-red-400 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1 text-xs text-slate-400 mb-3">
                      <p>{preset.max_participants} users • {preset.duration_minutes} min</p>
                      <p>Host {preset.host_resolution} • Member {preset.member_resolution}</p>
                    </div>

                    <button
                      onClick={() => handleApplyPreset(preset)}
                      className="w-full py-1.5 text-xs border border-emerald-700 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 rounded font-medium inline-flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <Video className="w-3 h-3" />
                      Use for New Meeting
                    </button>
                  </div>
                  ))}
                </div>
                <PaginationControls
                  total={filteredPresets.length}
                  perPage={presetPerPage}
                  onPerPage={setPresetPerPage}
                  page={safePresetPage}
                  onPage={setPresetPage}
                />
              </>
            )}
          </div>
        )}

        {/* View: Recordings */}
        {viewTab === 'recordings' && (
          <div className="bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
                <Video className="w-5 h-5 text-emerald-400" />
                Meeting Recordings
                <span className="text-xs bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                  {recordings.length}
                </span>
              </h2>
              <div className="flex items-center gap-2 sm:gap-3">
                <input
                  type="text"
                  placeholder="Cari rekaman..."
                  value={recordingSearchQuery}
                  onChange={(e) => setRecordingSearchQuery(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-slate-800 border border-slate-700 text-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-emerald-600 w-36 sm:w-48"
                />
                <button
                  onClick={fetchRecordings}
                  disabled={recordingsLoading}
                  className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${recordingsLoading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>
            </div>

            <PendingRecordingUploads onUploaded={fetchRecordings} />

            {recordingsLoading && recordings.length === 0 ? (
              <div className="py-16 text-center text-slate-400">
                <div className="w-8 h-8 border-4 border-slate-700 border-t-emerald-500 rounded-full animate-spin mx-auto mb-3"></div>
                Loading recordings...
              </div>
            ) : recordings.length === 0 ? (
              <div className="py-16 text-center text-slate-400 border border-dashed border-slate-800">
                <p className="text-base font-medium text-slate-300">No recordings yet.</p>
                <p className="text-xs text-slate-500 mt-1">Recordings will appear here after a meeting is recorded.</p>
              </div>
            ) : filteredRecordings.length === 0 ? (
              <div className="py-12 text-center text-slate-400 border border-dashed border-slate-800">
                <p className="text-sm font-medium text-slate-300">Tidak ada rekaman yang cocok dengan pencarian.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {paginatedRecordings.map((rec) => (
                    <RecordingCard
                      key={rec.id}
                      recording={rec}
                      meetings={meetings}
                      onPlay={setSelectedRecording}
                    />
                  ))}
                </div>
                <PaginationControls
                  total={filteredRecordings.length}
                  perPage={recordingPerPage}
                  onPerPage={setRecordingPerPage}
                  page={safeRecordingPage}
                  onPage={setRecordingPage}
                />
              </>
            )}
          </div>
        )}

{/* View: Settings */}
        {viewTab === 'settings' && (
          <div className="bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2 mb-5">
              <Sliders className="w-5 h-5 text-emerald-400" />
              Pengaturan Aplikasi
            </h2>

            {/* Logo */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-slate-300 mb-3">Logo</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm text-slate-300 mb-1">Upload File Logo</label>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/svg+xml,image/webp,image/avif"
                      onChange={(e) => handleLogoFile(e.target.files?.[0])}
                      className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-slate-500 cursor-pointer file:mr-3 file:px-3 file:py-1 file:border-0 file:bg-slate-700 file:text-slate-200 file:cursor-pointer file:text-sm"
                    />
                    <p className="text-[11px] text-slate-400 mt-1">Maksimal 512KB. Logo disimpan di database.</p>
                  </div>
                  <div>
                    <label className="block text-sm text-slate-300 mb-1">Atau tempel URL logo</label>
                    <input
                      type="url"
                      value={logoUrlInput}
                      onChange={(e) => { setLogoUrlInput(e.target.value); if (e.target.value.trim()) setLogoInput(''); }}
                      placeholder="https://..."
                      className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-slate-500"
                    />
                  </div>
                </div>
                <div className="flex flex-col items-start gap-2">
                  <span className="text-sm text-slate-300">Pratinjau</span>
                  <div className="bg-slate-800 border border-slate-700 rounded-lg p-4 min-h-[72px] flex items-center gap-3 w-full">
                    {(logoInput || (logoValue && !logoInput && !logoUrlInput)) ? (
                      <>
                        <img
                          src={logoInput || logoValue}
                          alt="Logo"
                          className="w-9 h-9 object-contain"
                        />
                        <span className="font-bold text-lg text-slate-100 truncate min-w-0">{titleValue.trim() || title || DEFAULT_SITE_TITLE}</span>
                      </>
                    ) : (
                      <>
                        <img src="/learnly.svg" alt="Learnly" className="w-9 h-9" />
                        <span className="font-bold text-lg text-slate-100 truncate min-w-0">{titleValue.trim() || title || DEFAULT_SITE_TITLE}</span>
                      </>
                    )}
                  </div>
                  {(logoInput || logoUrlInput) && (
                    <button
                      onClick={() => { setLogoInput(''); setLogoUrlInput(''); }}
                      className="text-xs text-red-400 hover:underline cursor-pointer"
                    >
                      Batal preview
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Judul Aplikasi */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-slate-300 mb-3">Judul Aplikasi</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm text-slate-300 mb-1">Nama aplikasi yang tampil di header</label>
                  <input
                    type="text"
                    value={titleValue}
                    onChange={(e) => setTitleValue(e.target.value)}
                    placeholder={DEFAULT_SITE_TITLE}
                    maxLength={60}
                    className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-slate-500"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">Maksimal 60 karakter. Kosongkan untuk kembali ke default "{DEFAULT_SITE_TITLE}".</p>
                </div>
                <div className="flex flex-col items-start gap-2">
                  <span className="text-sm text-slate-300">Pratinjau Header</span>
                  <div className="bg-slate-800 border border-slate-700 rounded-lg p-4 min-h-[72px] flex items-center gap-3 w-full">
                    <img src={(logoInput || logoValue) || '/learnly.svg'} alt="Learnly" className="w-9 h-9 object-contain" />
                    <span className="font-bold text-lg text-slate-100 truncate min-w-0">{titleValue.trim() || title || DEFAULT_SITE_TITLE}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recording notes */}
            <div className="text-sm text-slate-400 mb-4">
              Auto-record dan retensi file rekaman diatur per meeting lewat checkbox "Auto-record sesuai jadwal" dan isian "Retensi rekaman (jam)" pada saat membuat/mengedit meeting.
            </div>

            {settingsError && (
              <div className="p-3 mb-4 bg-red-950/60 border border-red-800 text-red-300 text-sm">{settingsError}</div>
            )}
            {settingsSaved && (
              <div className="p-3 mb-4 bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-sm">Pengaturan berhasil disimpan.</div>
            )}

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={fetchSettings}
                className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer"
              >
                Reset
              </button>
              <button
                onClick={handleSaveSettings}
                disabled={settingsLoading}
                className="px-4 py-2 border-2 accent-btn font-medium text-sm disabled:opacity-50 cursor-pointer"
              >
                {settingsLoading ? 'Menyimpan...' : 'Simpan Pengaturan'}
              </button>
            </div>
          </div>
        )}

        {/* View: Kelola Admin (hanya superadmin) */}
        {viewTab === 'admins' && user?.role === 'superadmin' && (
          <ManageAdmins />
        )}

        {/* View: Table View (Upcoming / Past / All) */}
        {isTableView && (
          <div className="flex flex-col gap-4">
            <PageHeader
              title={PAGE_TITLES[viewTab]}
              description={
                viewTab === 'upcoming'
                  ? 'Meeting yang akan datang beserta jadwalnya.'
                  : viewTab === 'past'
                    ? 'Meeting yang sudah selesai beserta riwayatnya.'
                    : 'Seluruh meeting yang pernah dibuat.'
              }
              badge={
                <Badge tone="neutral" icon={<List className="w-3 h-3" aria-hidden="true" />}>
                  {displayedMeetings.length} meeting
                </Badge>
              }
              actions={
                <Button
                  variant="primary"
                  icon={<Plus className="w-4 h-4" />}
                  onClick={() => {
                    setShowCreateModal(true);
                    setCreatePublicId(generateAutoId(createName || 'class'));
                    setCreateHostCode(randomHostCode());
                  }}
                >
                  Tambah Meeting
                </Button>
              }
            />

            {/* Toolbar: pencarian, filter, chip aktif, dan bar bulk (ruangnya
                selalu disediakan agar tidak terjadi layout shift). */}
            <div className="rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border border-[var(--ds-border)] p-4 flex flex-col gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <Input
                  label="Cari meeting"
                  hideLabel
                  type="search"
                  placeholder="Cari nama atau ID…"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="sm:w-56"
                />
                <Select
                  label="Filter kategori"
                  hideLabel
                  value={categoryFilter}
                  onChange={e => setCategoryFilter(e.target.value)}
                  className="w-auto sm:w-44"
                  options={[
                    { value: '', label: 'Semua Kategori' },
                    ...categories.map(c => ({ value: c.id, label: c.name })),
                  ]}
                />
                <Button variant="ghost" size="sm" icon={<List className="w-4 h-4" />} onClick={openCategoryCreate}>
                  Kelola Kategori
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<RefreshCw className="w-4 h-4" />}
                  loading={loading}
                  onClick={fetchMeetings}
                >
                  Muat ulang
                </Button>
              </div>

              {(searchQuery.trim() || categoryFilter) && (
                <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter aktif">
                  {searchQuery.trim() && (
                    <span className="inline-flex items-center gap-1 rounded-full border border-[var(--ds-border-control)] bg-[var(--ds-bg-raised)] pl-3 pr-1 py-1 text-xs text-[var(--ds-text-muted)]">
                      Cari: “{searchQuery.trim()}”
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        aria-label="Hapus filter pencarian"
                        className="ds-focus p-1 rounded-full hover:bg-slate-700 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </span>
                  )}
                  {categoryFilter && (
                    <span className="inline-flex items-center gap-1 rounded-full border border-[var(--ds-border-control)] bg-[var(--ds-bg-raised)] pl-3 pr-1 py-1 text-xs text-[var(--ds-text-muted)]">
                      Kategori: {categories.find(c => c.id === categoryFilter)?.name ?? '—'}
                      <button
                        type="button"
                        onClick={() => setCategoryFilter('')}
                        aria-label="Hapus filter kategori"
                        className="ds-focus p-1 rounded-full hover:bg-slate-700 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setCategoryFilter('');
                    }}
                    className="ds-focus text-xs font-medium text-emerald-400 hover:text-emerald-300 px-1 py-1.5 rounded cursor-pointer"
                  >
                    Reset filter
                  </button>
                </div>
              )}

              <div
                aria-hidden={selectedIds.size === 0}
                className={cx(
                  'flex flex-wrap items-center gap-2 min-h-9',
                  selectedIds.size === 0 && 'invisible pointer-events-none',
                )}
              >
                <span className="text-sm text-[var(--ds-text-muted)] tabular-nums">
                  {selectedIds.size} meeting dipilih
                </span>
                <Button
                  variant="danger"
                  size="sm"
                  icon={<Trash2 className="w-4 h-4" />}
                  onClick={handleBulkDelete}
                  disabled={confirmDialog.loading}
                >
                  Hapus terpilih
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setSelectedIds(new Set())}>
                  Batal pilih
                </Button>
              </div>
            </div>

            {error ? (
              <ErrorState message={error} onRetry={fetchMeetings} />
            ) : loading && meetings.length === 0 ? (
              <MeetingListSkeleton />
            ) : displayedMeetings.length === 0 ? (
              <div className="rounded-[var(--ds-r-card)] border border-dashed border-[var(--ds-border)] bg-[var(--ds-bg-card)]">
                {searchQuery.trim() || categoryFilter ? (
                  <EmptyState
                    icon={<Search className="w-8 h-8" aria-hidden="true" />}
                    title="Tidak ada meeting yang cocok"
                    description="Coba ubah kata kunci atau hapus filter yang sedang aktif."
                    action={
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => {
                          setSearchQuery('');
                          setCategoryFilter('');
                        }}
                      >
                        Reset filter
                      </Button>
                    }
                  />
                ) : (
                  <EmptyState
                    icon={<CalendarDays className="w-8 h-8" aria-hidden="true" />}
                    title={
                      viewTab === 'upcoming'
                        ? 'Belum ada meeting akan datang'
                        : viewTab === 'past'
                          ? 'Belum ada riwayat meeting'
                          : 'Belum ada meeting'
                    }
                    description="Buat meeting baru atau jadwalkan kelas berikutnya."
                    action={
                      <Button
                        variant="primary"
                        size="sm"
                        icon={<Plus className="w-4 h-4" />}
                        onClick={() => {
                          setShowCreateModal(true);
                          setCreatePublicId(generateAutoId(createName || 'class'));
                          setCreateHostCode(randomHostCode());
                        }}
                      >
                        Tambah Meeting
                      </Button>
                    }
                  />
                )}
              </div>
            ) : (
              <>
              {/* Tabel desktop (>= md). Tanpa wrapper overflow-x agar thead
                  sticky menempel ke scroll utama halaman. */}
              <div className="hidden md:block rounded-[var(--ds-r-card)] border border-[var(--ds-border)] bg-[var(--ds-bg-card)] overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <caption className="sr-only">Daftar {PAGE_TITLES[viewTab]}</caption>
                  <thead>
                    <tr className="border-b border-slate-800 text-xs text-slate-300 uppercase tracking-wider bg-slate-800">
                      <th scope="col" className="sticky top-0 z-10 bg-slate-800 py-3 px-3 w-10">
                        <input
                          type="checkbox"
                          aria-label="Pilih semua meeting di halaman ini"
                          checked={paginatedMeetings.length > 0 && selectedIds.size === paginatedMeetings.length}
                          onChange={toggleSelectAll}
                          className="rounded border-slate-600 bg-slate-800 cursor-pointer"
                        />
                      </th>
                      <th scope="col" aria-sort={ariaSort('name')} onClick={() => toggleSort('name')} className="sticky top-0 z-10 bg-slate-800 py-3 px-3 cursor-pointer hover:text-slate-100 select-none">
                        Nama {sortField === 'name' ? (sortDir === 'asc' ? '↑' : '↓') : ''}
                      </th>
                      <th scope="col" className="sticky top-0 z-10 bg-slate-800 py-3 px-3 hidden md:table-cell">ID Publik</th>
                      <th scope="col" className="sticky top-0 z-10 bg-slate-800 py-3 px-3 hidden xl:table-cell">Kategori</th>
                      <th scope="col" aria-sort={ariaSort('scheduled_at')} onClick={() => toggleSort('scheduled_at')} className="sticky top-0 z-10 bg-slate-800 py-3 px-3 cursor-pointer hover:text-slate-100 select-none hidden sm:table-cell">
                        Jadwal {sortField === 'scheduled_at' ? (sortDir === 'asc' ? '↑' : '↓') : ''}
                      </th>
                      <th scope="col" aria-sort={ariaSort('status')} onClick={() => toggleSort('status')} className="sticky top-0 z-10 bg-slate-800 py-3 px-3 cursor-pointer hover:text-slate-100 select-none">
                        Status {sortField === 'status' ? (sortDir === 'asc' ? '↑' : '↓') : ''}
                      </th>
                      <th scope="col" aria-sort={ariaSort('max_participants')} onClick={() => toggleSort('max_participants')} className="sticky top-0 z-10 bg-slate-800 py-3 px-3 hidden lg:table-cell cursor-pointer hover:text-slate-100 select-none">
                        Kapasitas/Durasi {sortField === 'max_participants' ? (sortDir === 'asc' ? '↑' : '↓') : ''}
                      </th>
                      <th scope="col" className="sticky top-0 z-10 bg-slate-800 py-3 px-3 hidden lg:table-cell">Resolusi</th>
                      <th scope="col" className="sticky top-0 z-10 bg-slate-800 py-3 px-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-sm text-slate-200">
                    {paginatedMeetings.map((m) => (
                      <tr key={m.id} className={`transition-colors hover:bg-slate-800/40 ${selectedIds.has(m.id) ? 'bg-slate-800/20' : ''}`}>
                        <td className="py-3 px-3">
                          <input
                            type="checkbox"
                            aria-label={`Pilih ${m.name}`}
                            checked={selectedIds.has(m.id)}
                            onChange={() => toggleSelectOne(m.id)}
                            className="rounded border-slate-600 bg-slate-800 cursor-pointer"
                          />
                        </td>
                        <td className="py-3 px-3 font-medium text-slate-100">
                          <div className="truncate max-w-[160px] lg:max-w-[180px]" title={m.name}>{m.name}</div>
                        </td>
                        <td className="py-3 px-3 hidden md:table-cell">
                          <div className="flex items-center gap-1.5 font-mono text-xs text-emerald-400 bg-slate-800/80 px-2 py-1 rounded w-fit border border-slate-700">
                            <span>{m.public_id || m.id.slice(0, 10)}</span>
                            <button
                              onClick={() => handleCopyId(m)}
                              title="Salin ID" aria-label="Salin ID"
                              className="p-0.5 hover:text-slate-100 transition-colors cursor-pointer"
                            >
                              {copiedKey === `id-${m.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                            </button>
                          </div>
                        </td>
                        <td className="py-3 px-3 hidden xl:table-cell">
                          {m.category_id ? (
                            <Badge tone="accent">
                              {categories.find(c => c.id === m.category_id)?.name || m.category_name || '—'}
                            </Badge>
                          ) : (
                            <span className="text-slate-500 italic text-xs">—</span>
                          )}
                        </td>
                        <td className="py-3 px-3 hidden sm:table-cell">
                          {formatSchedule(m.scheduled_at, m.started_at)}
                        </td>
                        <td className="py-3 px-3">{statusPill(m.status)}</td>
                        <td className="py-3 px-3 text-xs text-slate-300 hidden lg:table-cell">
                          <div>{m.max_participants} peserta</div>
                          <div className="text-slate-400">{m.duration_minutes} menit</div>
                        </td>
                        <td className="py-3 px-3 text-xs text-slate-300 hidden lg:table-cell whitespace-nowrap">
                          <span title={`Host ${m.host_resolution || '360p'} / Member ${m.member_resolution || '240p'}`}>
                            {m.host_resolution || '360p'} · {m.member_resolution || '240p'}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              variant="primary"
                              size="sm"
                              icon={<ExternalLink className="w-4 h-4" />}
                              onClick={() => handleJoinMeeting(m.public_id || m.id)}
                              aria-label={`Gabung sebagai host: ${m.name}`}
                            >
                              Gabung
                            </Button>
                            <DropdownMenu
                              label={`Aksi untuk ${m.name}`}
                              align="end"
                              items={meetingMenuItems(m)}
                              trigger={p => (
                                <Button {...p} variant="secondary" size="icon" aria-label={`Aksi lain untuk ${m.name}`}>
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              )}
                            />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Kartu mobile (< md): daftar vertikal, tanpa scroll horizontal */}
              <div className="md:hidden flex flex-col gap-3">
                {paginatedMeetings.map((m) => (
                  <div
                    key={m.id}
                    className={`rounded-[var(--ds-r-card)] bg-[var(--ds-bg-card)] border p-4 ${
                      selectedIds.has(m.id) ? 'border-[var(--ds-accent)]' : 'border-[var(--ds-border)]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        aria-label={`Pilih ${m.name}`}
                        checked={selectedIds.has(m.id)}
                        onChange={() => toggleSelectOne(m.id)}
                        className="mt-1 rounded border-slate-600 bg-slate-800 cursor-pointer"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-slate-100 truncate">{m.name}</p>
                            <p className="text-xs font-mono text-emerald-400 truncate">{m.public_id || m.id.slice(0, 10)}</p>
                          </div>
                          <DropdownMenu
                            label={`Aksi untuk ${m.name}`}
                            align="end"
                            items={meetingMenuItems(m)}
                            trigger={p => (
                              <Button {...p} variant="ghost" size="icon" aria-label={`Aksi lain untuk ${m.name}`}>
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            )}
                          />
                        </div>
                        <div className="mt-2 flex flex-wrap items-center gap-2">
                          {statusPill(m.status)}
                          {m.category_id && (
                            <Badge tone="accent">
                              {categories.find(c => c.id === m.category_id)?.name || m.category_name || '—'}
                            </Badge>
                          )}
                        </div>
                        <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                          <div className="min-w-0">
                            <dt className="text-slate-500">Jadwal</dt>
                            <dd className="text-slate-300 truncate">{formatSchedule(m.scheduled_at, m.started_at)}</dd>
                          </div>
                          <div className="min-w-0">
                            <dt className="text-slate-500">Kapasitas</dt>
                            <dd className="text-slate-300 truncate">{m.max_participants} peserta · {m.duration_minutes} menit</dd>
                          </div>
                        </dl>
                        <Button
                          variant="primary"
                          size="sm"
                          className="mt-3 w-full"
                          icon={<ExternalLink className="w-4 h-4" />}
                          onClick={() => handleJoinMeeting(m.public_id || m.id)}
                        >
                          Gabung sebagai host
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              <PaginationControls
                total={displayedMeetings.length}
                perPage={perPage}
                onPerPage={setPerPage}
                page={safePage}
                onPage={setCurrentPage}
              />
              </>
            )}
          </div>
        )}

        {/* View: Calendar Planner */}
        {viewTab === 'planner' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
            {/* Calendar Grid */}
            <div className="lg:col-span-2 bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-emerald-400" />
                  {monthYearStr}
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() - 1, 1))}
                    className="p-1.5 border border-slate-700 hover:bg-slate-800 text-slate-300 rounded cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setCalendarDate(new Date())}
                    className="px-2.5 py-1 text-xs border border-slate-700 hover:bg-slate-800 text-slate-300 rounded cursor-pointer"
                  >
                    Today
                  </button>
                  <button
                    onClick={() => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 1))}
                    className="p-1.5 border border-slate-700 hover:bg-slate-800 text-slate-300 rounded cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-slate-400 mb-2">
                <div>Sun</div>
                <div>Mon</div>
                <div>Tue</div>
                <div>Wed</div>
                <div>Thu</div>
                <div>Fri</div>
                <div>Sat</div>
              </div>

              <div className="grid grid-cols-7 gap-0.5 sm:gap-1">
                {Array.from({ length: firstDayIndex }).map((_, i) => (
                  <div key={`empty-${i}`} className="h-12 sm:h-16 md:h-20 bg-slate-950/30 border border-slate-800/40 rounded p-0.5 sm:p-1"></div>
                ))}

                {calendarDays.map((item) => {
                  const isSelected = selectedCalendarDate === item.dateStr;
                  const isToday =
                    new Date().toISOString().slice(0, 10) === item.dateStr;

                  return (
                    <div
                      key={item.dateStr}
                      onClick={() => setSelectedCalendarDate(item.dateStr)}
                      className={`h-12 sm:h-16 md:h-20 border rounded p-0.5 sm:p-1 flex flex-col justify-between cursor-pointer transition-all ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-950/30'
                          : isToday
                          ? 'border-slate-600 bg-slate-800/80'
                          : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-semibold ${isToday ? 'text-emerald-400 font-bold' : 'text-slate-300'}`}>
                          {item.dayNumber}
                        </span>
                        {item.meetings.length > 0 && (
                          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                        )}
                      </div>

                      <div className="space-y-1 overflow-hidden">
                        {item.meetings.slice(0, 2).map((m) => (
                          <div
                            key={m.id}
                            className="text-[10px] bg-slate-800 text-slate-200 px-1 py-0.5 rounded truncate border border-slate-700"
                            title={m.name}
                          >
                            {m.name}
                          </div>
                        ))}
                        {item.meetings.length > 2 && (
                          <div className="text-[9px] text-slate-400">+{item.meetings.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Selected Date Details */}
            <div className="bg-slate-900 border-2 border-slate-800 p-4 sm:p-6 shadow-sm flex flex-col">
              <h3 className="text-base font-bold text-slate-100 mb-3 flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-emerald-400" />
                {selectedCalendarDate ? (
                  <span>Schedule for {new Date(selectedCalendarDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                ) : (
                  <span>Select a date on calendar</span>
                )}
              </h3>

              {!selectedCalendarDate ? (
                <div className="flex-1 flex items-center justify-center text-slate-500 text-sm italic border border-dashed border-slate-800 p-4 text-center">
                  Click on any day on the calendar to see scheduled sessions.
                </div>
              ) : selectedDateMeetings.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-400 text-sm border border-dashed border-slate-800 p-4 sm:p-6 text-center">
                  <p>No meetings scheduled on this date.</p>
                  <button
                    onClick={() => {
                      setCreateDate(selectedCalendarDate);
                      setShowCreateModal(true);
                      setCreatePublicId(generateAutoId('class'));
                      setCreateHostCode(randomHostCode());
                    }}
                    className="mt-3 px-3 py-1.5 border-2 accent-btn text-xs font-medium cursor-pointer"
                  >
                    Schedule Meeting on this date
                  </button>
                </div>
              ) : (
                <div className="space-y-3 overflow-y-auto max-h-[400px]">
                  {selectedDateMeetings.map((m) => (
                    <div key={m.id} className="p-3 bg-slate-800/90 border border-slate-700 rounded space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold text-sm text-slate-100">{m.name}</h4>
                          <span className="font-mono text-xs text-emerald-400">ID: {m.public_id}</span>
                        </div>
                        {getStatusBadge(m.status)}
                      </div>

                      <div className="text-xs text-slate-300 flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          {m.scheduled_at
                            ? new Date(m.scheduled_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
                            : m.started_at
                              ? new Date(m.started_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
                              : 'Unscheduled'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-slate-400" />
                           {m.max_participants} room cap.
                        </span>
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={() => handleJoinMeeting(m.public_id || m.id)}
                          className="flex-1 py-1 text-xs border border-emerald-700 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded text-center cursor-pointer"
                        >
                          Host Join
                        </button>
                        <button
                          onClick={() => handleCopyLink(m)}
                          className="py-1 px-2 text-xs border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded cursor-pointer"
                        >
                          {copiedKey === `link-${m.id}` ? 'Copied!' : 'Copy Link'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      {/* CREATE MEETING MODAL */}
      {showCreateModal && (
        <Modal
          open
          onClose={requestCloseCreate}
          title="Buat Meeting"
          icon={<Plus className="w-5 h-5 text-emerald-400" />}
          maxWidth="max-w-3xl"
          fullscreenMobile
          busy={createLoading || discardCreate}
          footer={
            <>
              <Button variant="secondary" onClick={requestCloseCreate} disabled={createLoading}>
                Batal
              </Button>
              <Button
                type="submit"
                variant="primary"
                form="create-meeting-form"
                loading={createLoading}
              >
                Buat Meeting
              </Button>
            </>
          }
        >
            <form id="create-meeting-form" onSubmit={onCreateSubmit} noValidate className="flex flex-col gap-6">
              {createError && (
                <div role="alert" className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {createError}
                </div>
              )}

              {/* ===== Informasi Dasar ===== */}
              <FormSection title="Informasi Dasar">
                <div className="sm:col-span-2">
                  <Input
                    id="cf-name"
                    label="Nama Meeting"
                    required
                    autoFocus
                    value={createName}
                    onChange={e => {
                      setCreateName(e.target.value);
                      if (!createPublicId || createPublicId.startsWith('meet-')) {
                        setCreatePublicId(generateAutoId(e.target.value));
                      }
                    }}
                    placeholder="mis. Diskusi Arsitektur Frontend"
                    error={createFieldErrors['cf-name']}
                  />
                </div>

                <div className="sm:col-span-2">
                  <Input
                    id="cf-public-id"
                    label={
                      <span className="flex items-center justify-between gap-2 w-full">
                        <span>ID Meeting / Slug Kustom</span>
                        <button
                          type="button"
                          onClick={() => setCreatePublicId(generateAutoId(createName || 'class'))}
                          className="text-xs font-normal text-emerald-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3" aria-hidden="true" />
                          Auto Generate
                        </button>
                      </span>
                    }
                    value={createPublicId}
                    onChange={e => setCreatePublicId(e.target.value)}
                    placeholder="mis. frontend-01"
                    className="font-mono text-sm"
                    error={createFieldErrors['cf-public-id']}
                    hint={
                      <>
                        Tautan singkat:{' '}
                        <code className="text-emerald-400">
                          {window.location.origin}/meeting/{createPublicId || 'your-id'}
                        </code>
                      </>
                    }
                  />
                </div>

                <Input
                  id="cf-host-code"
                  label="Kode Host (untuk tentor)"
                  required
                  type="text"
                  inputMode="numeric"
                  maxLength={10}
                  value={createHostCode}
                  onChange={e => setCreateHostCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="4–10 digit angka"
                  className="font-mono tracking-[0.3em]"
                  error={createFieldErrors['cf-host-code']}
                  hint="Dibuat otomatis dan tidak bisa diubah setelah meeting dibuat. Bagikan ke tentor — mereka masukkan kode ini saat join."
                />

                {categories.length > 0 && (
                  <Select
                    id="cf-category"
                    label="Kategori"
                    value={createCategoryId}
                    onChange={e => setCreateCategoryId(e.target.value)}
                    error={createFieldErrors['cf-category']}
                    options={[
                      { value: '', label: 'Tanpa Kategori' },
                      ...categories.map(c => ({ value: c.id, label: c.name })),
                    ]}
                  />
                )}

                {presets.length > 0 && (
                  <Select
                    id="cf-preset"
                    label="Preset"
                    value={createPresetId}
                    onChange={e => {
                      const selected = presets.find(p => p.id === e.target.value);
                      if (selected) {
                        setCreatePresetId(selected.id);
                        setCreateMaxParticipants(selected.max_participants);
                        setCreateDuration(selected.duration_minutes);
                        setCreateKickCooldown(15);
                        setCreateLateJoin(30);
                        setCreateHostResolution(selected.host_resolution);
                        setCreateMemberResolution(selected.member_resolution);
                      } else {
                        setCreatePresetId('');
                      }
                    }}
                    error={createFieldErrors['cf-preset']}
                    hint="Mengisi otomatis kapasitas, durasi, dan resolusi di bawah."
                    options={[
                      { value: '', label: 'Tanpa preset' },
                      ...presets.map(p => ({ value: p.id, label: p.name })),
                    ]}
                  />
                )}
              </FormSection>

              {/* ===== Jadwal ===== */}
              <FormSection title="Jadwal">
                <fieldset className="sm:col-span-2">
                  <legend className="sr-only">Mode jadwal</legend>
                  <div className="flex flex-wrap items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        id="cf-schedule"
                        type="radio"
                        name="createScheduleMode"
                        value="alltime"
                        checked={createScheduleMode === 'alltime'}
                        onChange={() => setCreateScheduleMode('alltime')}
                        className="ds-focus size-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-sm text-[var(--ds-text-muted)]">Sepanjang waktu</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="radio"
                        name="createScheduleMode"
                        value="scheduled"
                        checked={createScheduleMode === 'scheduled'}
                        onChange={() => setCreateScheduleMode('scheduled')}
                        className="ds-focus size-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-sm text-[var(--ds-text-muted)]">Terjadwal</span>
                    </label>
                  </div>
                </fieldset>

                {createScheduleMode === 'scheduled' && (
                  <>
                    <Input
                      id="cf-date"
                      label="Tanggal Jadwal"
                      type="date"
                      value={createDate}
                      onChange={e => setCreateDate(e.target.value)}
                      error={createFieldErrors['cf-date']}
                    />
                    <Input
                      id="cf-time"
                      label="Jam Mulai"
                      type="time"
                      value={createTime}
                      onChange={e => setCreateTime(e.target.value)}
                      error={createFieldErrors['cf-time']}
                      hint={`Timezone: ${Intl.DateTimeFormat().resolvedOptions().timeZone}`}
                    />
                  </>
                )}
              </FormSection>

              {/* ===== Peserta dan Kapasitas ===== */}
              <FormSection title="Peserta dan Kapasitas">
                <Input
                  id="cf-capacity"
                  label="Kapasitas Ruangan (termasuk host)"
                  type="number"
                  min={1}
                  max={500}
                  value={createMaxParticipants}
                  onChange={e => setCreateMaxParticipants(Number(e.target.value))}
                  placeholder="20"
                  error={createFieldErrors['cf-capacity']}
                />
                <Input
                  id="cf-duration"
                  label="Durasi (menit)"
                  type="number"
                  min={1}
                  max={1440}
                  value={createDuration}
                  onChange={e => setCreateDuration(Number(e.target.value))}
                  placeholder="60"
                  error={createFieldErrors['cf-duration']}
                />
              </FormSection>

              {/* ===== Pengaturan Lanjutan (progressive disclosure) ===== */}
              <FormSection
                title="Pengaturan Lanjutan"
                collapsible
                open={createAdvanced}
                onToggle={() => setCreateAdvanced(v => !v)}
              >
                <div className="sm:col-span-2">
                  <Checkbox
                    id="cf-auto-record"
                    label="Auto-record sesuai jadwal"
                    checked={createAutoRecord}
                    onChange={e => setCreateAutoRecord(e.target.checked)}
                  />
                  <p className="text-xs text-[var(--ds-text-faint)] mt-1.5">
                    Rekaman otomatis mulai saat jadwal dimulai dan berhenti di akhir durasi. Tetap bisa dihentikan manual.
                  </p>
                </div>

                <Input
                  id="cf-retention"
                  label="Retensi rekaman (jam)"
                  type="number"
                  min={1}
                  max={720}
                  value={createRetentionHours}
                  onChange={e => setCreateRetentionHours(Number(e.target.value))}
                  error={createFieldErrors['cf-retention']}
                  hint="File rekaman meeting ini dihapus setelah periode ini (default 48 jam). Rentang 1–720 jam."
                />

                <Input
                  id="cf-kick"
                  label="Jeda kick (menit)"
                  type="number"
                  min={0}
                  max={1440}
                  value={createKickCooldown}
                  onChange={e => setCreateKickCooldown(Number(e.target.value))}
                  placeholder="15"
                  error={createFieldErrors['cf-kick']}
                  hint="Jeda sebelum peserta yang di-kick bisa join lagi (0 = tanpa jeda)."
                />

                <Input
                  id="cf-late"
                  label="Batas join terlambat (menit)"
                  type="number"
                  min={0}
                  max={1440}
                  value={createLateJoin}
                  onChange={e => setCreateLateJoin(Number(e.target.value))}
                  placeholder="30"
                  error={createFieldErrors['cf-late']}
                  hint="Batas member join setelah jadwal dimulai; lewat dari ini ditolak (0 = tanpa batas)."
                />

                <Input
                  id="cf-cameras"
                  label="Kamera aktif maksimal"
                  type="number"
                  min={0}
                  max={500}
                  value={createMaxActiveCameras}
                  onChange={e => setCreateMaxActiveCameras(Number(e.target.value))}
                  placeholder="0"
                  error={createFieldErrors['cf-cameras']}
                  hint="Jumlah kamera peserta yang boleh menyala serentak (0 = tanpa batas)."
                />

                <Select
                  id="cf-host-res"
                  label="Resolusi Host"
                  value={createHostResolution}
                  onChange={e => setCreateHostResolution(e.target.value)}
                  error={createFieldErrors['cf-host-res']}
                  options={VALID_RESOLUTIONS.map(r => ({ value: r, label: r }))}
                />

                <Select
                  id="cf-member-res"
                  label="Resolusi Peserta"
                  value={createMemberResolution}
                  onChange={e => setCreateMemberResolution(e.target.value)}
                  error={createFieldErrors['cf-member-res']}
                  options={VALID_RESOLUTIONS.map(r => ({ value: r, label: r }))}
                />

                <Select
                  id="cf-share-res"
                  label="Resolusi Screen Share"
                  value={createScreenshareRes}
                  onChange={e => setCreateScreenshareRes(e.target.value)}
                  error={createFieldErrors['cf-share-res']}
                  hint="Dipakai otomatis saat share layar — tanpa pilihan di ruang meeting"
                  options={VALID_SHARE_RESOLUTIONS.map(r => ({ value: r, label: r }))}
                />
              </FormSection>
            </form>
        </Modal>
      )}

      <DSConfirmDialog
        open={discardCreate}
        onClose={() => setDiscardCreate(false)}
        onConfirm={() => {
          setDiscardCreate(false);
          setShowCreateModal(false);
        }}
        title="Tutup form meeting?"
        message="Ada perubahan yang belum disimpan. Menutup sekarang akan membuang perubahan tersebut."
        confirmLabel="Tutup tanpa menyimpan"
        cancelLabel="Lanjut mengedit"
        variant="warning"
      />

      {/* BULK IMPORT MODAL */}
      {showBulkImportModal && (
        <Modal
          open
          onClose={() => { setShowBulkImportModal(false); setBulkError(null); }}
          title="Impor Massal Meeting"
          icon={<Plus className="w-5 h-5 text-emerald-400" />}
          maxWidth="max-w-2xl"
          fullscreenMobile
          busy={bulkLoading}
          footer={
            <>
              <Button
                variant="secondary"
                onClick={() => { setShowBulkImportModal(false); setBulkError(null); }}
                disabled={bulkLoading}
              >
                Batal
              </Button>
              <Button
                variant="primary"
                onClick={handleBulkImport}
                loading={bulkLoading}
                disabled={bulkMeetings.every(m => !m.name.trim())}
              >
                Impor Semua
              </Button>
            </>
          }
        >
            <form className="flex flex-col gap-6" onSubmit={e => e.preventDefault()}>
              {/* ===== Pengaturan default ===== */}
              <FormSection title="Pengaturan Default untuk Semua">
                {presets.length > 0 && (
                  <Select
                    id="bulk-preset"
                    label="Terapkan Preset ke Semua"
                    value={bulkPresetId}
                    onChange={e => setBulkPresetId(e.target.value)}
                    options={[
                      { value: '', label: 'Tanpa preset (Default)' },
                      ...presets.map(p => ({ value: p.id, label: p.name })),
                    ]}
                  />
                )}

                {categories.length > 0 && (
                  <Select
                    id="bulk-category"
                    label="Terapkan Kategori ke Semua"
                    value={bulkCategoryId}
                    onChange={e => setBulkCategoryId(e.target.value)}
                    options={[
                      { value: '', label: 'Tanpa Kategori' },
                      ...categories.map(c => ({ value: c.id, label: c.name })),
                    ]}
                  />
                )}

                <Input
                  id="bulk-retention"
                  label="Terapkan Retensi Rekaman (jam) ke Semua"
                  type="number"
                  min={1}
                  max={720}
                  value={bulkRetentionHours}
                  onChange={e => setBulkRetentionHours(Number(e.target.value))}
                  hint="File rekaman dihapus setelah periode ini (default 48 jam). Rentang 1–720 jam."
                />

                <fieldset>
                  <legend className="text-sm font-medium text-[var(--ds-text-muted)] mb-1.5">Jadwal Bawaan</legend>
                  <div className="flex flex-wrap items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="radio"
                        name="bulkDefaultSchedule"
                        value="alltime"
                        checked={bulkDefaultScheduleMode === 'alltime'}
                        onChange={() => {
                          setBulkDefaultScheduleMode('alltime');
                          setBulkMeetings(prev => prev.map(m => ({ ...m, scheduleMode: 'alltime' })));
                        }}
                        className="ds-focus size-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-sm text-[var(--ds-text-muted)]">Sepanjang waktu</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="radio"
                        name="bulkDefaultSchedule"
                        value="scheduled"
                        checked={bulkDefaultScheduleMode === 'scheduled'}
                        onChange={() => {
                          setBulkDefaultScheduleMode('scheduled');
                          setBulkMeetings(prev => prev.map(m => ({ ...m, scheduleMode: 'scheduled' })));
                        }}
                        className="ds-focus size-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-sm text-[var(--ds-text-muted)]">Terjadwal</span>
                    </label>
                  </div>
                </fieldset>
              </FormSection>

              {/* ===== File Excel ===== */}
              <FormSection title="File Excel">
                <div className="sm:col-span-2 flex flex-col sm:flex-row gap-2">
                  <label className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 min-h-11 border border-dashed border-[var(--ds-border-control)] rounded-[var(--ds-r-control)] text-[var(--ds-text-muted)] hover:text-emerald-400 hover:border-emerald-600 text-sm cursor-pointer transition-colors">
                    <Upload className="w-4 h-4" />
                    Pilih file Excel (.xlsx)
                    <input
                      type="file"
                      accept=".xlsx,.xlsm"
                      className="hidden"
                      onChange={(e) => { void handleBulkFile(e.target.files?.[0]); e.target.value = ''; }}
                    />
                  </label>
                  <Button type="button" variant="secondary" onClick={handleBulkTemplate} className="shrink-0">
                    <Download className="w-4 h-4" />
                    Template
                  </Button>
                </div>
                <p className="sm:col-span-2 text-xs text-[var(--ds-text-faint)]">
                  Kolom: Nama, Public ID, Kategori, Tanggal, Jam, Kapasitas, Durasi (menit), Host Res, Member Res, Screen Share Res, Max Active Cameras, Auto Record, Kick Cooldown (menit), Late Join Cutoff (menit), Retention (jam), Tentor (dipisah koma), Kode Host. Tanggal (dd/mm/yyyy) + Jam (HH:MM) terpisah seperti form Add Meeting — kosong = All Time (kolom Jadwal gabungan lama tetap diterima). Host Res/Member Res/Screen Share Res/Auto Record berdropdown; Kategori berdropdown dari daftar kategori aplikasi. File menggantikan daftar di bawah; kolom kosong mengikuti Preset/Kategori di atas. Kolom Status & Link Join dari hasil Export hanya laporan — tidak di-impor.
                </p>
              </FormSection>

              {/* ===== Daftar Meeting ===== */}
              <FormSection title={`Daftar Meeting (${bulkMeetings.length})`}>
                <div className="sm:col-span-2 space-y-3">
                  {bulkMeetings.map((meeting, idx) => {
                    const overrides = describeBulkOverrides(meeting, categories);
                    return (
                    <div
                      key={idx}
                      className="p-3 rounded-[var(--ds-r-card)] border border-[var(--ds-border-control)] bg-[var(--ds-bg-raised)] space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-[var(--ds-text-muted)]">Meeting {idx + 1}</span>
                        {bulkMeetings.length > 1 && (
                          <button
                            type="button"
                            aria-label={`Hapus Meeting ${idx + 1}`}
                            onClick={() => removeBulkRow(idx)}
                            className="p-1 text-red-400 hover:text-red-300 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <Input
                          label="Nama Meeting"
                          hideLabel
                          required
                          value={meeting.name}
                          onChange={e => updateBulkRow(idx, 'name', e.target.value)}
                          placeholder="Nama Meeting *"
                          className="text-sm"
                        />
                        <Input
                          label="ID Kustom (auto)"
                          hideLabel
                          value={meeting.publicId}
                          onChange={e => updateBulkRow(idx, 'publicId', e.target.value)}
                          placeholder="ID Kustom (auto)"
                          className="font-mono text-sm"
                        />
                      </div>
                      <div className="flex flex-wrap items-center gap-3">
                        <label className="flex items-center gap-1.5 cursor-pointer select-none">
                          <input
                            type="radio"
                            name={`bulkSchedule-${idx}`}
                            checked={meeting.scheduleMode === 'alltime'}
                            onChange={() => updateBulkRow(idx, 'scheduleMode', 'alltime')}
                            className="size-3 accent-emerald-600 cursor-pointer"
                          />
                          <span className="text-xs text-[var(--ds-text-muted)]">Sepanjang waktu</span>
                        </label>
                        <label className="flex items-center gap-1.5 cursor-pointer select-none">
                          <input
                            type="radio"
                            name={`bulkSchedule-${idx}`}
                            checked={meeting.scheduleMode === 'scheduled'}
                            onChange={() => updateBulkRow(idx, 'scheduleMode', 'scheduled')}
                            className="size-3 accent-emerald-600 cursor-pointer"
                          />
                          <span className="text-xs text-[var(--ds-text-muted)]">Terjadwal</span>
                        </label>
                        {meeting.scheduleMode === 'scheduled' && (
                          <>
                            <input
                              type="date"
                              aria-label={`Tanggal Meeting ${idx + 1}`}
                              value={meeting.date}
                              onChange={(e) => updateBulkRow(idx, 'date', e.target.value)}
                              className="ds-focus px-2 py-1 rounded-[var(--ds-r-control)] border border-[var(--ds-border-control)] bg-[var(--ds-bg-inset)] text-[var(--ds-text)] text-xs"
                            />
                            <input
                              type="time"
                              aria-label={`Jam Meeting ${idx + 1}`}
                              value={meeting.time}
                              onChange={(e) => updateBulkRow(idx, 'time', e.target.value)}
                              className="ds-focus px-2 py-1 rounded-[var(--ds-r-control)] border border-[var(--ds-border-control)] bg-[var(--ds-bg-inset)] text-[var(--ds-text)] text-xs"
                            />
                          </>
                        )}
                      </div>
                      {overrides && (
                        <p className="text-xs text-amber-400/90">Dari Excel: {overrides}</p>
                      )}
                    </div>
                    );
                  })}

                  <Button
                    type="button"
                    variant="secondary"
                    onClick={addBulkRow}
                    className="w-full border-dashed"
                  >
                    <Plus className="w-4 h-4" />
                    Tambah Meeting
                  </Button>
                </div>
              </FormSection>

              {/* Progress */}
              {bulkLoading && (
                <div className="space-y-2">
                  <div
                    className="w-full h-2 rounded-full bg-[var(--ds-bg-inset)] border border-[var(--ds-border-control)]"
                    role="progressbar"
                    aria-valuemin={0}
                    aria-valuemax={bulkProgress.total || 0}
                    aria-valuenow={bulkProgress.done}
                  >
                    <div
                      className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${bulkProgress.total > 0 ? (bulkProgress.done / bulkProgress.total) * 100 : 0}%` }}
                    />
                  </div>
                  <p className="text-xs text-[var(--ds-text-muted)] text-center">
                    Mengimpor {bulkProgress.done} / {bulkProgress.total}...
                  </p>
                </div>
              )}

              {bulkError && (
                <div role="alert" className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {bulkError}
                </div>
              )}
            </form>
        </Modal>
      )}

      {/* EDIT MEETING MODAL */}
      {editingMeeting && (
        <Modal
          open
          onClose={requestCloseEdit}
          title="Edit Meeting"
          icon={<Edit2 className="w-5 h-5 text-sky-400" />}
          maxWidth="max-w-3xl"
          fullscreenMobile
          busy={editLoading || editLifecycleLoading || discardEdit}
          footer={
            <>
              <Button variant="secondary" onClick={requestCloseEdit} disabled={editLoading || editLifecycleLoading}>
                Batal
              </Button>
              <Button
                type="submit"
                variant="primary"
                form="edit-meeting-form"
                loading={editLoading}
              >
                {willExpireImmediately(Number(editDuration))
                  ? (editShortExpiryAck ? 'Ya, Simpan & Akhiri' : 'Simpan')
                  : 'Simpan Perubahan'}
              </Button>
            </>
          }
        >
            <form id="edit-meeting-form" onSubmit={onEditSubmit} noValidate className="flex flex-col gap-6">
              {willExpireImmediately(Number(editDuration)) && (
                <div role="alert" className="p-3 bg-amber-950/60 border border-amber-700 text-amber-300 text-sm">
                  Durasi baru membuat meeting langsung berakhir (expired) dan semua peserta akan dikeluarkan.
                  Klik tombol simpan untuk konfirmasi, lalu klik lagi untuk menyimpan.
                </div>
              )}

              {editError && (
                <div role="alert" className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {editError}
                </div>
              )}

              {/* ===== Informasi Dasar ===== */}
              <FormSection title="Informasi Dasar">
                <div className="sm:col-span-2">
                  <p className="text-sm font-medium text-[var(--ds-text-muted)] mb-1.5">Status</p>
                  <div className="flex items-center justify-between gap-3 px-3 py-2.5 rounded-[var(--ds-r-control)] border border-[var(--ds-border-control)] bg-[var(--ds-bg-raised)]">
                    <span className="flex items-center gap-2 flex-wrap min-w-0">
                      {statusPill(editingMeeting.status)}
                      <span className="text-xs text-[var(--ds-text-faint)]">
                        {editingMeeting.status === 'scheduled' && 'Belum dimulai — timer masih kosong'}
                        {editingMeeting.status === 'active' && 'Sedang berjalan'}
                        {(editingMeeting.status === 'expired' || editingMeeting.status === 'ended') && 'Tertutup — peserta tidak bisa join'}
                        {editingMeeting.status === 'deleted' && 'Terhapus'}
                      </span>
                    </span>
                    {editLifecycleAction && (
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={handleLifecycleAction}
                        loading={editLifecycleLoading}
                      >
                        {editLifecycleAction.label}
                      </Button>
                    )}
                  </div>
                  <p className="text-xs text-[var(--ds-text-faint)] mt-1.5">
                    Status mengikuti lifecycle meeting; aksi di atas mengubah status dan timer sekaligus.
                  </p>
                </div>

                <div className="sm:col-span-2">
                  <Input
                    id="ef-name"
                    label="Nama Meeting"
                    required
                    value={editName}
                    onChange={e => setEditName(e.target.value)}
                    error={editFieldErrors['ef-name']}
                  />
                </div>

                <div className="sm:col-span-2">
                  <Input
                    id="ef-public-id"
                    label="ID Meeting / Slug"
                    value={editPublicId}
                    onChange={e => setEditPublicId(e.target.value)}
                    placeholder="Kosongkan untuk auto-generate"
                    className="font-mono text-sm"
                    error={editFieldErrors['ef-public-id']}
                  />
                </div>

                {categories.length > 0 && (
                  <Select
                    id="ef-category"
                    label="Kategori"
                    value={editCategoryId}
                    onChange={e => setEditCategoryId(e.target.value)}
                    error={editFieldErrors['ef-category']}
                    options={[
                      { value: '', label: 'Tanpa Kategori' },
                      ...categories.map(c => ({ value: c.id, label: c.name })),
                    ]}
                  />
                )}
              </FormSection>

              {/* ===== Jadwal ===== */}
              <FormSection title="Jadwal">
                <fieldset className="sm:col-span-2">
                  <legend className="sr-only">Mode jadwal</legend>
                  <div className="flex flex-wrap items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        id="ef-schedule"
                        type="radio"
                        name="editScheduleMode"
                        value="alltime"
                        checked={editScheduleMode === 'alltime'}
                        onChange={() => setEditScheduleMode('alltime')}
                        className="ds-focus size-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-sm text-[var(--ds-text-muted)]">Sepanjang waktu</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="radio"
                        name="editScheduleMode"
                        value="scheduled"
                        checked={editScheduleMode === 'scheduled'}
                        onChange={() => setEditScheduleMode('scheduled')}
                        className="ds-focus size-4 accent-emerald-600 cursor-pointer"
                      />
                      <span className="text-sm text-[var(--ds-text-muted)]">Terjadwal</span>
                    </label>
                  </div>
                </fieldset>

                {editScheduleMode === 'scheduled' && (
                  <>
                    <Input
                      id="ef-date"
                      label="Tanggal Jadwal"
                      type="date"
                      value={editDate}
                      onChange={e => setEditDate(e.target.value)}
                      error={editFieldErrors['ef-date']}
                    />
                    <Input
                      id="ef-time"
                      label="Jam Mulai"
                      type="time"
                      value={editTime}
                      onChange={e => setEditTime(e.target.value)}
                      error={editFieldErrors['ef-time']}
                      hint={`Timezone: ${Intl.DateTimeFormat().resolvedOptions().timeZone}`}
                    />
                  </>
                )}
              </FormSection>

              {/* ===== Peserta dan Kapasitas ===== */}
              <FormSection title="Peserta dan Kapasitas">
                <Input
                  id="ef-capacity"
                  label="Kapasitas Ruangan (termasuk host)"
                  type="number"
                  min={1}
                  max={500}
                  value={editMaxParticipants}
                  onChange={e => {
                    setEditMaxParticipants(Number(e.target.value));
                  }}
                  error={editFieldErrors['ef-capacity']}
                />
                <Input
                  id="ef-duration"
                  label="Durasi (menit)"
                  type="number"
                  min={1}
                  max={1440}
                  value={editDuration}
                  onChange={e => {
                    setEditDuration(Number(e.target.value));
                    setEditShortExpiryAck(false);
                  }}
                  error={editFieldErrors['ef-duration']}
                />
              </FormSection>

              {/* ===== Pengaturan Lanjutan (progressive disclosure) ===== */}
              <FormSection
                title="Pengaturan Lanjutan"
                collapsible
                open={editAdvanced}
                onToggle={() => setEditAdvanced(v => !v)}
              >
                <div className="sm:col-span-2">
                  <Checkbox
                    id="ef-auto-record"
                    label="Auto-record sesuai jadwal"
                    checked={editAutoRecord}
                    onChange={e => setEditAutoRecord(e.target.checked)}
                  />
                </div>

                <Input
                  id="ef-retention"
                  label="Retensi rekaman (jam)"
                  type="number"
                  min={1}
                  max={720}
                  value={editRetentionHours}
                  onChange={e => setEditRetentionHours(Number(e.target.value))}
                  error={editFieldErrors['ef-retention']}
                  hint="Berlaku untuk rekaman baru. Perubahan tidak mengubah file rekaman lama. Rentang 1–720 jam."
                />

                <Input
                  id="ef-kick"
                  label="Jeda kick (menit)"
                  type="number"
                  min={0}
                  max={1440}
                  value={editKickCooldown}
                  onChange={e => setEditKickCooldown(Number(e.target.value))}
                  placeholder="15"
                  error={editFieldErrors['ef-kick']}
                  hint="Jeda sebelum peserta yang di-kick bisa join lagi (0 = tanpa jeda)."
                />

                <Input
                  id="ef-late"
                  label="Batas join terlambat (menit)"
                  type="number"
                  min={0}
                  max={1440}
                  value={editLateJoin}
                  onChange={e => setEditLateJoin(Number(e.target.value))}
                  placeholder="30"
                  error={editFieldErrors['ef-late']}
                  hint="Batas member join setelah jadwal dimulai; lewat dari ini ditolak (0 = tanpa batas)."
                />

                <Input
                  id="ef-cameras"
                  label="Kamera aktif maksimal"
                  type="number"
                  min={0}
                  max={500}
                  value={editMaxActiveCameras}
                  onChange={e => setEditMaxActiveCameras(Number(e.target.value))}
                  placeholder="0"
                  error={editFieldErrors['ef-cameras']}
                  hint="Jumlah kamera peserta yang boleh menyala serentak (0 = tanpa batas)."
                />

                <Select
                  id="ef-host-res"
                  label="Resolusi Host"
                  value={editHostResolution}
                  onChange={e => setEditHostResolution(e.target.value)}
                  error={editFieldErrors['ef-host-res']}
                  options={VALID_RESOLUTIONS.map(r => ({ value: r, label: r }))}
                />

                <Select
                  id="ef-member-res"
                  label="Resolusi Peserta"
                  value={editMemberResolution}
                  onChange={e => setEditMemberResolution(e.target.value)}
                  error={editFieldErrors['ef-member-res']}
                  options={VALID_RESOLUTIONS.map(r => ({ value: r, label: r }))}
                />

                <Select
                  id="ef-share-res"
                  label="Resolusi Screen Share"
                  value={editScreenshareRes}
                  onChange={e => setEditScreenshareRes(e.target.value)}
                  error={editFieldErrors['ef-share-res']}
                  options={VALID_SHARE_RESOLUTIONS.map(r => ({ value: r, label: r }))}
                />
              </FormSection>
            </form>
        </Modal>
      )}

      <DSConfirmDialog
        open={discardEdit}
        onClose={() => setDiscardEdit(false)}
        onConfirm={() => {
          setDiscardEdit(false);
          setEditingMeeting(null);
        }}
        title="Tutup form meeting?"
        message="Ada perubahan yang belum disimpan. Menutup sekarang akan membuang perubahan tersebut."
        confirmLabel="Tutup tanpa menyimpan"
        cancelLabel="Lanjut mengedit"
        variant="warning"
      />

      {/* CATEGORY MANAGEMENT MODAL */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-slate-700 p-4 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <List className="w-5 h-5 text-emerald-400" />
                Kelola Kategori
              </h3>
              <button onClick={() => setShowCategoryModal(false)} className="text-slate-400 hover:text-slate-100 p-1 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={categoryFormName}
                  onChange={(e) => setCategoryFormName(e.target.value)}
                  placeholder={editingCategory ? 'Nama kategori baru' : 'Nama kategori baru'}
                  className="flex-1 min-w-0 px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-500"
                />
                <button
                  onClick={handleSaveCategory}
                  disabled={categoryFormLoading}
                  className="px-4 py-2 border-2 accent-btn font-medium text-sm disabled:opacity-50 cursor-pointer shrink-0"
                >
                  {editingCategory ? 'Simpan' : 'Tambah'}
                </button>
              </div>
              {categoryFormError && (
                <div className="p-2.5 bg-red-950/60 border border-red-800 text-red-300 text-xs">{categoryFormError}</div>
              )}

              <div className="space-y-2 max-h-[50vh] overflow-y-auto">
                {categories.length === 0 ? (
                  <p className="text-sm text-slate-400 text-center py-6 border border-dashed border-slate-800">
                    Belum ada kategori. Tambahkan kategori pertama.
                  </p>
                ) : categories.map(cat => (
                  <div key={cat.id} className="p-2.5 bg-slate-800/80 border border-slate-700 rounded flex items-center justify-between gap-2">
                    <span className="text-sm text-slate-200 truncate">{cat.name}</span>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => openCategoryEdit(cat)}
                        title="Edit kategori"
                        className="p-1 border border-slate-600 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeletingCategory(cat)}
                        title="Hapus kategori"
                        className="p-1 border border-red-900/60 hover:bg-red-950 text-red-400 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CATEGORY CONFIRM MODAL */}
      {deletingCategory && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-red-800 p-4 sm:p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-red-400 mb-2 flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              Hapus Kategori?
            </h3>
            <p className="text-sm text-slate-300 mb-4">
              Menghapus kategori <strong className="text-slate-100 font-semibold">"{deletingCategory.name}"</strong> akan melepas semua meeting dari kategori ini.
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setDeletingCategory(null)} className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer">
                Batal
              </button>
              <button
                onClick={handleDeleteCategory}
                disabled={deleteCategoryLoading}
                className="px-4 py-2 bg-red-800 hover:bg-red-700 border border-red-600 text-white font-medium text-sm disabled:opacity-50 cursor-pointer"
              >
                {deleteCategoryLoading ? 'Menghapus...' : 'Confirm Hapus'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE MEETING CONFIRM MODAL */}
      {deletingMeeting && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-red-800 p-4 sm:p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-red-400 mb-2 flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              Delete Meeting?
            </h3>
            <p className="text-sm text-slate-300 mb-4">
              Are you sure you want to delete <strong className="text-slate-100 font-semibold">"{deletingMeeting.name}"</strong> (ID: {deletingMeeting.public_id || deletingMeeting.id})? This will invalidate the meeting link.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeletingMeeting(null)}
                className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteMeeting}
                disabled={deleteLoading}
                className="px-4 py-2 bg-red-800 hover:bg-red-700 border border-red-600 text-white font-medium text-sm disabled:opacity-50 cursor-pointer"
              >
                {deleteLoading ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* INSPECT PARTICIPANTS MODAL */}
      {inspectMeeting && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-xl bg-slate-900 border-2 border-slate-700 p-4 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2 min-w-0">
                  <Users className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="truncate break-words min-w-0">{inspectMeeting.name}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  Public ID: {inspectMeeting.public_id || inspectMeeting.id} • Max guests: {inspectMeeting.max_participants} (host not included)
                </p>
              </div>
              <button onClick={() => setInspectMeeting(null)} className="text-slate-400 hover:text-slate-100 p-1 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold text-slate-300">Registered Tentors</h4>
                  <div className="flex items-center gap-2">
                    <button onClick={() => inspectMeeting && fetchTentors(inspectMeeting.id)} disabled={tentorsLoading} className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer inline-flex items-center gap-1">
                      <RefreshCw className={`w-3 h-3 ${tentorsLoading ? 'animate-spin' : ''}`} />
                    </button>
                    <button onClick={openTentorCreate} className="text-xs text-emerald-400 hover:text-emerald-300 cursor-pointer inline-flex items-center gap-1">
                      <Plus className="w-3 h-3" /> Add
                    </button>
                  </div>
                </div>
                {tentors.length === 0 ? (
                  <p className="text-xs text-slate-500">No tentors registered. Add tentor names so they can join as host without login.</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {tentors.map((t) => (
                      <div key={t.id} className="group flex items-center gap-1 px-2 py-1 bg-slate-800 border border-slate-700 text-xs text-slate-300">
                        <span>{t.name}</span>
                        <button onClick={() => openTentorEdit(t)} className="text-slate-500 hover:text-slate-300 cursor-pointer ml-1"><Edit2 className="w-3 h-3" /></button>
                        <button onClick={() => setDeletingTentor(t)} className="text-slate-500 hover:text-red-400 cursor-pointer"><Trash2 className="w-3 h-3" /></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="border-t border-slate-800 pt-4">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-semibold text-slate-300">Host Join Code</h4>
                </div>
                <p className="text-xs text-slate-500 mb-2">
                  Set when the meeting is created and cannot be changed. A registered tentor name joins as host only after entering this code. Share it with your tentors.
                </p>
                {hostJoinCode ? (
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-lg tracking-[0.35em] text-emerald-300 select-all">{hostJoinCode}</span>
                    <button
                      onClick={() => {
                        if (!hostJoinCode) return;
                        navigator.clipboard?.writeText(hostJoinCode).then(() => {
                          setHostCodeCopied(true);
                          setTimeout(() => setHostCodeCopied(false), 1500);
                        }).catch(() => {});
                      }}
                      className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer inline-flex items-center gap-1"
                      title="Copy code"
                    >
                      {hostCodeCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      {hostCodeCopied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">Not active — registered tentor names become host without a code.</p>
                )}
              </div>

              <div className="border-t border-slate-800 pt-4">
                <h4 className="text-sm font-semibold text-slate-300 mb-2">Live Participants in Room</h4>
                {inspectLoading ? (
                  <div className="py-8 text-center text-slate-400 text-sm">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2" />
                    Checking live room participants...
                  </div>
                ) : inspectParticipants.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 text-sm border border-dashed border-slate-800">
                    No active participants connected right now.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {inspectParticipants.map((p) => {
                      const isHost = p.preset_name === 'group_call_host' || p.name?.toLowerCase().includes('admin');
                      return (
                        <div key={p.id} className="flex items-center justify-between p-3 bg-slate-800/80 border border-slate-700">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold ${isHost ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-slate-700 text-slate-300'}`}>
                              {p.name ? p.name.charAt(0).toUpperCase() : 'U'}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <p className="text-sm font-medium text-slate-100">{p.name || 'Anonymous'}</p>
                                {isHost && (
                                  <span className="text-[10px] px-1.5 py-0.2 bg-emerald-950 text-emerald-300 border border-emerald-700 rounded font-semibold">
                                    HOST
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-400 font-mono">ID: {p.id}</p>
                            </div>
                          </div>
                          {isHost && (
                            <span className="text-xs text-slate-500 italic px-2 py-1">
                              Host (Kebal)
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button onClick={() => setInspectMeeting(null)} className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EDIT PRESET MODAL */}
      {showPresetCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-slate-700 p-4 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Sliders className="w-5 h-5 text-emerald-400" />
                {editingPreset ? 'Edit Preset' : 'Create Preset'}
              </h3>
              <button
                onClick={() => { setShowPresetCreateModal(false); setEditingPreset(null); }}
                className="text-slate-400 hover:text-slate-100 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePresetFormSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-sm text-slate-300 mb-1">Preset Name *</label>
                <input
                  type="text"
                  value={presetFormName}
                  onChange={(e) => setPresetFormName(e.target.value)}
                  placeholder="e.g. Kelas Standar"
                  required
                  autoFocus
                  className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-300 mb-1">Room Capacity</label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={presetFormCapacity}
                    onChange={(e) => setPresetFormCapacity(Number(e.target.value))}
                    className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-500"
                  />
                </div>

                <div>
                  <label className="block text-sm text-slate-300 mb-1">Duration (Minutes)</label>
                  <input
                    type="number"
                    min={1}
                    max={1440}
                    value={presetFormDuration}
                    onChange={(e) => setPresetFormDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-300 mb-1">Host Resolution</label>
                  <select
                    value={presetFormHostRes}
                    onChange={(e) => setPresetFormHostRes(e.target.value)}
                    className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-500"
                  >
                    {VALID_RESOLUTIONS.map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-slate-300 mb-1">Member Resolution</label>
                  <select
                    value={presetFormMemberRes}
                    onChange={(e) => setPresetFormMemberRes(e.target.value)}
                    className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-500"
                  >
                    {VALID_RESOLUTIONS.map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
              </div>

              {presetFormError && (
                <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">
                  {presetFormError}
                </div>
              )}

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => { setShowPresetCreateModal(false); setEditingPreset(null); }}
                  className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={presetFormLoading}
                  className="px-4 py-2 border-2 accent-btn font-medium text-sm disabled:opacity-50 cursor-pointer"
                >
                  {presetFormLoading ? 'Saving...' : (editingPreset ? 'Save Changes' : 'Create Preset')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE PRESET CONFIRM MODAL */}
      {deletingPreset && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-red-800 p-4 sm:p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-red-400 mb-2 flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              Delete Preset?
            </h3>
            <p className="text-sm text-slate-300 mb-4">
              Are you sure you want to delete preset <strong className="text-slate-100 font-semibold">"{deletingPreset.name}"</strong>?
              Meetings created using this preset will <strong className="text-slate-100">not</strong> be affected.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setDeletingPreset(null)}
                className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeletePreset}
                disabled={deletePresetLoading}
                className="px-4 py-2 bg-red-800 hover:bg-red-700 border border-red-600 text-white font-medium text-sm disabled:opacity-50 cursor-pointer"
              >
                {deletePresetLoading ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TENTOR CREATE/EDIT MODAL */}
      {showTentorCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-slate-700 p-4 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                {editingTentor ? 'Edit Tentor' : 'Add Tentor'}
              </h3>
              <button onClick={() => { setShowTentorCreateModal(false); setEditingTentor(null); }} className="text-slate-400 hover:text-slate-100 p-1 cursor-pointer"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); handleSaveTentor(); }} className="mt-4 space-y-4">
              <div>
                <label className="block text-sm text-slate-300 mb-1">Tentor Name *</label>
                <input type="text" value={tentorFormName} onChange={(e) => setTentorFormName(e.target.value)} placeholder="e.g. Pak Budi" required autoFocus className="w-full px-3 py-2 border-2 border-slate-700 bg-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-500" />
                <p className="text-xs text-slate-500 mt-1">When this name is used to join, they will automatically become host.</p>
              </div>
              {tentorFormError && <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-sm">{tentorFormError}</div>}
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button type="button" onClick={() => { setShowTentorCreateModal(false); setEditingTentor(null); }} className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer">Cancel</button>
                <button type="submit" disabled={tentorFormLoading} className="px-4 py-2 border-2 accent-btn font-medium text-sm disabled:opacity-50 cursor-pointer">
                  {tentorFormLoading ? 'Saving...' : (editingTentor ? 'Save Changes' : 'Add Tentor')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE TENTOR CONFIRM MODAL */}
      {deletingTentor && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-red-800 p-4 sm:p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-red-400 mb-2 flex items-center gap-2"><Trash2 className="w-5 h-5" />Delete Tentor?</h3>
            <p className="text-sm text-slate-300 mb-4">Are you sure you want to remove tentor <strong className="text-slate-100 font-semibold">"{deletingTentor.name}"</strong>? They will no longer be able to join as host.</p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setDeletingTentor(null)} className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm cursor-pointer">Cancel</button>
              <button onClick={handleDeleteTentor} disabled={deleteTentorLoading} className="px-4 py-2 bg-red-800 hover:bg-red-700 border border-red-600 text-white font-medium text-sm disabled:opacity-50 cursor-pointer">
                {deleteTentorLoading ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RECORDING PLAYBACK MODAL */}
      {selectedRecording && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="w-full max-w-4xl bg-slate-900 border-2 border-slate-700 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 border-b border-slate-800">
              <div>
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2 min-w-0">
                  <Video className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span className="truncate break-words min-w-0">{getRecordingDisplayName(selectedRecording, meetings.find(m => m.id === selectedRecording.meeting_id)?.name || 'Unknown Meeting')}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {meetings.find(m => m.id === selectedRecording.meeting_id)?.name || 'Unknown Meeting'}
                </p>
              </div>
              <button
                onClick={() => setSelectedRecording(null)}
                className="text-slate-400 hover:text-slate-100 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-6">
              <video
                key={selectedRecording.id}
                controls
                autoPlay
                className="w-full rounded bg-black"
                style={{ maxHeight: '60vh' }}
              >
                <source src={`/api/recordings/${selectedRecording.id}/stream`} type={getRecordingMimeType(selectedRecording)} />
                Your browser does not support the video tag.
              </video>

              <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-800">
                <div className="text-xs text-slate-400 space-y-1">
                  <p>Status: <span className="text-slate-200 font-medium capitalize">{selectedRecording.status}</span></p>
                  {selectedRecording.duration_seconds != null && (
                    <p>Duration: <span className="text-slate-200">{formatDuration(selectedRecording.duration_seconds)}</span></p>
                  )}
                  {selectedRecording.size_bytes != null && (
                    <p>Size: <span className="text-slate-200">{formatFileSize(selectedRecording.size_bytes)}</span></p>
                  )}
                  {selectedRecordingResolution && (
                    <p>Resolution: <span className="text-slate-200">{selectedRecordingResolution}</span></p>
                  )}
                </div>
                <a
                  href={`/api/recordings/${selectedRecording.id}/download`}
                  className="px-4 py-2 text-sm border-2 accent-btn font-medium inline-flex items-center gap-2"
                  download={getRecordingDisplayName(selectedRecording, meetings.find(m => m.id === selectedRecording.meeting_id)?.name || 'Unknown Meeting')}
                >
                  <Download className="w-4 h-4" />
                  Download
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Dialog */}
      <ConfirmDialog
        open={confirmDialog.open}
        onClose={() => setConfirmDialog({ open: false, title: '', message: '', onConfirm: () => {} })}
        onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title}
        message={confirmDialog.message}
        confirmLabel="Ya, Hapus"
        cancelLabel="Batal"
        variant={confirmDialog.variant || 'danger'}
        loading={confirmDialog.loading}
      />
    </DashboardShell>
  );
}

