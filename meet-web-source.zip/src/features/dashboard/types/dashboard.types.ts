export interface MeetingItem {
  id: string;
  public_id: string;
  provider_meeting_id: string;
  name: string;
  created_by: string;
  max_participants: number;
  duration_minutes: number;
  host_resolution: string;
  member_resolution: string;
  screenshare_resolution?: string | null;
  allow_member_annotation?: number | boolean;
  category_id?: string | null;
  category_name?: string | null;
  auto_record?: number | boolean;
  recording_retention_hours?: number | null;
  kick_cooldown_minutes?: number | null;
  late_join_minutes?: number | null;
  max_active_cameras?: number | null;
  tentor_names?: string | null;
  vps_dispatched_at?: string | null;
  status: 'scheduled' | 'active' | 'ended' | 'expired' | 'deleted';
  scheduled_at: string | null;
  timezone: string | null;
  started_at: string | null;
  expires_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ParticipantItem {
  id: string;
  name?: string;
  custom_participant_id?: string;
  preset_name?: string;
  created_at?: string;
}

export interface PresetItem {
  id: string;
  name: string;
  max_participants: number;
  duration_minutes: number;
  host_resolution: string;
  member_resolution: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface RecordingItem {
  id: string;
  meeting_id: string;
  storage_key: string;
  file_name: string;
  duration_seconds: number | null;
  size_bytes: number | null;
  resolution_width: number | null;
  resolution_height: number | null;
  download_count: number;
  status: 'processing' | 'ready' | 'failed' | 'expired' | 'deleted';
  expires_at: string;
  source?: 'manual' | 'auto';
  storage?: 'r2' | 'vps';
  vps_file_path?: string | null;
  created_at: string;
  updated_at: string;
}

export interface TentorItem {
  id: string;
  meeting_id: string;
  name: string;
  created_at: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  created_at: string;
}

export interface SiteSettingsPayload {
  settings: Record<string, string>;
}
