import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './features/auth/context/AuthContext';
import { ToastProvider, useSiteLogo } from './shared';
import { AdminProtectedRoute } from './features/auth/components/AdminProtectedRoute';
import Home from './features/home/pages/Home';
import Meeting from './features/meeting/pages/Meeting';
import AdminLogin from './features/auth/pages/AdminLogin';
import AdminDashboard from './features/dashboard/pages/AdminDashboard';

function App() {
  // App-wide site identity — applies the custom logo & title to the
  // favicon (<link rel="icon">) and browser tab (<title>) on every route.
  useSiteLogo();

  return (
    <AuthProvider>
      <ToastProvider>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Home />} />
        <Route path="/meeting/:id" element={<Meeting />} />
        <Route path="/admin/login" element={<AdminLogin />} />

        {/* Protected Admin routes */}
        <Route element={<AdminProtectedRoute />}>
          <Route path="/admin" element={<AdminDashboard />} />
        </Route>

        {/* Catch-all redirect */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;
