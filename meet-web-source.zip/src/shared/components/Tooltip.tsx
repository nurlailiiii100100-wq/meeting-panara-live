import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';

type TooltipSide = 'top' | 'bottom' | 'left' | 'right';

interface TooltipProps {
  content: string;
  children: React.ReactElement;
  side?: TooltipSide;
}

interface TooltipPosition {
  left: number;
  top: number;
  axis: 'x' | 'y';
}

// Jarak tooltip ke trigger (termasuk ruang arrow 4px) & jarak minimum dari tepi viewport
const GAP = 8;
const EDGE = 8;
const HIDE_DELAY_MS = 100;

function Arrow({ side, color, inset }: { side: TooltipSide; color: string; inset: number }) {
  const offset = `${inset - 4}px`;
  const base: React.CSSProperties = { position: 'absolute', width: 0, height: 0, borderStyle: 'solid' };

  if (side === 'top') {
    return (
      <div
        style={{
          ...base,
          bottom: offset,
          left: '50%',
          transform: 'translateX(-50%)',
          borderWidth: '4px 4px 0',
          borderColor: `${color} transparent transparent`,
        }}
      />
    );
  }
  if (side === 'bottom') {
    return (
      <div
        style={{
          ...base,
          top: offset,
          left: '50%',
          transform: 'translateX(-50%)',
          borderWidth: '0 4px 4px',
          borderColor: `transparent transparent ${color}`,
        }}
      />
    );
  }
  if (side === 'right') {
    return (
      <div
        style={{
          ...base,
          left: offset,
          top: '50%',
          transform: 'translateY(-50%)',
          borderWidth: '4px 4px 4px 0',
          borderColor: `transparent ${color} transparent transparent`,
        }}
      />
    );
  }
  return (
    <div
      style={{
        ...base,
        right: offset,
        top: '50%',
        transform: 'translateY(-50%)',
        borderWidth: '4px 0 4px 4px',
        borderColor: `transparent transparent transparent ${color}`,
      }}
    />
  );
}

export function Tooltip({ content, children, side = 'top' }: TooltipProps) {
  const triggerRef = useRef<HTMLSpanElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const hideTimerRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);

  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);
  const [placement, setPlacement] = useState<TooltipSide>(side);
  const [position, setPosition] = useState<TooltipPosition | null>(null);

  const show = useCallback(() => {
    if (hideTimerRef.current !== null) {
      window.clearTimeout(hideTimerRef.current);
      hideTimerRef.current = null;
    }
    setReady(false);
    setPosition(null);
    setPlacement(side);
    setOpen(true);
  }, [side]);

  const hide = useCallback(() => {
    if (hideTimerRef.current !== null) window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = window.setTimeout(() => {
      setOpen(false);
      setReady(false);
      setPosition(null);
    }, HIDE_DELAY_MS);
  }, []);

  // Bersihkan timer/raf saat unmount
  useEffect(() => {
    return () => {
      if (hideTimerRef.current !== null) window.clearTimeout(hideTimerRef.current);
      if (rafRef.current !== null) window.cancelAnimationFrame(rafRef.current);
    };
  }, []);

  // Hitung posisi + flip viewport safety sebelum paint, lalu jalankan animasi di frame berikutnya
  useLayoutEffect(() => {
    if (!open) return;
    const trigger = triggerRef.current;
    const tooltip = tooltipRef.current;
    if (!trigger || !tooltip) return;

    const rect = trigger.getBoundingClientRect();
    const size = tooltip.getBoundingClientRect();

    // Flip: tukar side bila ruang tidak cukup
    let finalSide = side;
    if (side === 'top' && rect.top < size.height + GAP) finalSide = 'bottom';
    else if (side === 'bottom' && window.innerHeight - rect.bottom < size.height + GAP) finalSide = 'top';
    else if (side === 'right' && window.innerWidth - rect.right < size.width + GAP) finalSide = 'left';
    else if (side === 'left' && rect.left < size.width + GAP) finalSide = 'right';

    const pageLeft = rect.left + window.scrollX;
    const pageTop = rect.top + window.scrollY;
    let left = 0;
    let top = 0;
    let axis: 'x' | 'y' = 'x';

    if (finalSide === 'top' || finalSide === 'bottom') {
      left = pageLeft + rect.width / 2;
      top = finalSide === 'top' ? pageTop - size.height - GAP : pageTop + rect.height + GAP;
      axis = 'x';
      // Clamp horizontal: tooltip (max-w 200px) tidak boleh keluar viewport
      const half = size.width / 2;
      const min = window.scrollX + EDGE + half;
      const max = window.scrollX + window.innerWidth - EDGE - half;
      left = Math.max(min, Math.min(left, Math.max(min, max)));
    } else {
      top = pageTop + rect.height / 2;
      left = finalSide === 'right' ? pageLeft + rect.width + GAP : pageLeft - size.width - GAP;
      axis = 'y';
      const min = window.scrollX + EDGE;
      const max = window.scrollX + window.innerWidth - size.width - EDGE;
      left = Math.max(min, Math.min(left, Math.max(min, max)));
    }

    setPlacement(finalSide);
    setPosition({ left, top, axis });

    // Satu frame setelah posisi terpasang → naikkan ready agar transisi fade jalan
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      setReady(true);
    });

    return () => {
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [open, side]);

  return (
    <>
      <span
        ref={triggerRef}
        className="inline-flex"
        onMouseEnter={show}
        onMouseLeave={hide}
        onFocus={show}
        onBlur={hide}
      >
        {children}
      </span>
      {open &&
        ReactDOM.createPortal(
          <div
            ref={tooltipRef}
            role="tooltip"
            className="pointer-events-none fixed z-[9999]"
            style={{
              left: position ? position.left : -99999,
              top: position ? position.top : -99999,
              transform: position?.axis === 'y' ? 'translateY(-50%)' : 'translateX(-50%)',
            }}
          >
            <div
              className={`relative transition-all duration-150 ease-out ${
                ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-1'
              }`}
            >
              <div className="bg-slate-800 border border-slate-700 text-slate-100 text-xs px-2 py-1 rounded max-w-[200px] whitespace-nowrap">
                {content}
              </div>
              <Arrow side={placement} color="var(--color-slate-700)" inset={0} />
              <Arrow side={placement} color="var(--color-slate-800)" inset={1} />
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
