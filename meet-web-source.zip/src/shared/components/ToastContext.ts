import { createContext } from 'react';
import type { ToastItem } from '../types/ui.types';

export interface ToastContextValue {
  toasts: ToastItem[];
  addToast: (message: string, type?: ToastItem['type'], duration?: number) => void;
  removeToast: (id: string) => void;
}

export const ToastContext = createContext<ToastContextValue | null>(null);
