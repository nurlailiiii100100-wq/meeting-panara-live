import { useEffect, useRef, useCallback } from 'react';
import { X } from 'lucide-react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  maxWidth?: string;
  showClose?: boolean;
}

export function Modal({ open, onClose, title, icon, children, maxWidth = 'max-w-md', showClose = true }: ModalProps) {
  const overlayRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const handleEscape = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  }, [onClose]);

  useEffect(() => {
    if (open) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
      // Focus trap: focus the content
      setTimeout(() => contentRef.current?.focus(), 50);
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [open, handleEscape]);

  if (!open) return null;

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  return (
    <div
      ref={overlayRef}
      onClick={handleOverlayClick}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        ref={contentRef}
        tabIndex={-1}
        className={`w-full ${maxWidth} bg-slate-900 border-2 border-slate-700 p-4 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto outline-none`}
      >
        {(title || showClose) && (
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            {title && (
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                {icon}
                {title}
              </h3>
            )}
            {showClose && (
              <button
                onClick={onClose}
                className="text-slate-400 hover:text-slate-100 p-1 cursor-pointer"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
