// Cadangan rekaman client-side yang BELUM terkonfirmasi tersimpan di server.
//
// Rekaman ditulis ke IndexedDB SEBELUM unggahan dimulai dan hanya dihapus
// setelah server merespons sukses. Dengan begitu tab tertutup, jaringan putus,
// atau unggahan gagal tidak pernah menghilangkan file: selalu ada salinan yang
// bisa dikirim ulang dari dashboard admin (menu Rekaman).

const DB_NAME = 'meet-pending-recordings';
const DB_VERSION = 1;
const STORE_NAME = 'recordings';

export interface PendingRecording {
  id: string;
  createdAt: number;
  meetingId: string;
  /** Token unggah host (berbatas waktu) — dipakai lagi saat kirim ulang. */
  uploadToken: string | null;
  durationSeconds: number;
  resolutionWidth: number;
  resolutionHeight: number;
  fileName: string;
  mimeType: string;
  blob: Blob;
  attempts: number;
  lastError: string | null;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB tidak tersedia'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Gagal membuka IndexedDB'));
  });
}

function withStore<T>(
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest
): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, mode);
        const request = run(tx.objectStore(STORE_NAME)) as IDBRequest<T>;
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error ?? new Error('Operasi IndexedDB gagal'));
        tx.oncomplete = () => db.close();
        tx.onerror = () => db.close();
        tx.onabort = () => db.close();
      })
  );
}

export async function savePendingRecording(record: PendingRecording): Promise<void> {
  await withStore<IDBValidKey>('readwrite', (store) => store.put(record));
}

export async function listPendingRecordings(): Promise<PendingRecording[]> {
  const rows = await withStore<PendingRecording[]>('readonly', (store) => store.getAll());
  return (rows ?? []).sort((a, b) => a.createdAt - b.createdAt);
}

export async function patchPendingRecording(
  id: string,
  patch: Partial<Pick<PendingRecording, 'attempts' | 'lastError'>>
): Promise<void> {
  const existing = await withStore<PendingRecording | undefined>('readonly', (store) =>
    store.get(id)
  );
  if (!existing) return;
  await withStore<IDBValidKey>('readwrite', (store) => store.put({ ...existing, ...patch }));
}

export async function deletePendingRecording(id: string): Promise<void> {
  await withStore<undefined>('readwrite', (store) => store.delete(id));
}
