// Pipeline unggah rekaman client-side yang tahan gagal:
//  • file kecil (≤12 MiB): satu request POST /api/recordings/upload (jalur lama,
//    tetap dipakai app Android) dengan retry;
//  • file besar: dipecah per 12 MiB → init → PUT chunk (retry per bagian) →
//    complete, digabung kembali oleh worker lewat R2 multipart upload menjadi
//    SATU file utuh. Lolos limit 100 MB/request Cloudflare sehingga rekaman
//    berjam-jam pun muat.
// Progres dilaporkan dalam persen (0–100) lewat onProgress.

export const CHUNKED_THRESHOLD_BYTES = 12 * 1024 * 1024;

const CHUNK_SIZE_BYTES = 12 * 1024 * 1024;
const SINGLE_ATTEMPTS = 3;
const CHUNK_ATTEMPTS = 4;
const SINGLE_TIMEOUT_MS = 5 * 60 * 1000;
const CHUNK_TIMEOUT_MS = 3 * 60 * 1000;
const RETRY_BASE_DELAY_MS = 2000;

export interface RecordingUploadMeta {
  meetingId: string;
  uploadToken: string | null;
  durationSeconds: number;
  resolutionWidth: number;
  resolutionHeight: number;
  fileName: string;
}

export function fileExtensionFor(blob: Blob): string {
  return (blob.type || '').includes('mp4') ? 'mp4' : 'webm';
}

interface XhrResponse {
  status: number;
  body: unknown;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function xhrRequest(options: {
  method: string;
  url: string;
  body?: XMLHttpRequestBodyInit | null;
  headers?: Record<string, string>;
  timeoutMs: number;
  onUploadProgress?: (fraction: number) => void;
}): Promise<XhrResponse> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open(options.method, options.url);
    request.withCredentials = true;
    request.timeout = options.timeoutMs;
    for (const [key, value] of Object.entries(options.headers ?? {})) {
      request.setRequestHeader(key, value);
    }
    if (options.onUploadProgress) {
      request.upload.onprogress = (event) => {
        if (event.lengthComputable && event.total > 0) {
          options.onUploadProgress?.(Math.min(1, event.loaded / event.total));
        }
      };
    }
    request.onload = () => {
      let body: unknown = null;
      try {
        body = JSON.parse(request.responseText) as unknown;
      } catch {
        body = null;
      }
      resolve({ status: request.status, body });
    };
    request.onerror = () => reject(new Error(`Network error (${options.method} ${options.url})`));
    request.ontimeout = () => reject(new Error(`Timeout (${options.method} ${options.url})`));
    request.onabort = () => reject(new Error(`Terputus (${options.method} ${options.url})`));
    request.send(options.body ?? null);
  });
}

async function withRetries(run: () => Promise<void>, attempts: number): Promise<void> {
  let lastError: unknown = null;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      await run();
      return;
    } catch (error) {
      lastError = error;
      // Backoff bertahap — gangguan sesaat tidak langsung membatalkan unggahan.
      if (attempt < attempts) await sleep(RETRY_BASE_DELAY_MS * attempt);
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Unggahan gagal');
}

function bodyField(body: unknown, key: string): string {
  if (typeof body !== 'object' || body === null) return '';
  const value = (body as Record<string, unknown>)[key];
  return typeof value === 'string' ? value : '';
}

async function uploadSingle(
  blob: Blob,
  meta: RecordingUploadMeta,
  onProgress?: (percent: number) => void
): Promise<void> {
  await withRetries(async () => {
    const form = new FormData();
    form.append('meeting_id', meta.meetingId);
    form.append('duration_seconds', String(meta.durationSeconds));
    form.append('resolution_width', String(meta.resolutionWidth));
    form.append('resolution_height', String(meta.resolutionHeight));
    if (meta.uploadToken) form.append('upload_token', meta.uploadToken);
    form.append('file', blob, meta.fileName);
    const response = await xhrRequest({
      method: 'POST',
      url: '/api/recordings/upload',
      body: form,
      timeoutMs: SINGLE_TIMEOUT_MS,
      onUploadProgress: (fraction) => onProgress?.(Math.min(99, Math.round(fraction * 100))),
    });
    if (response.status < 200 || response.status >= 300) {
      throw new Error(`Server menolak unggahan (HTTP ${response.status})`);
    }
  }, SINGLE_ATTEMPTS);
}

async function uploadChunked(
  blob: Blob,
  meta: RecordingUploadMeta,
  onProgress?: (percent: number) => void
): Promise<void> {
  const totalParts = Math.max(1, Math.ceil(blob.size / CHUNK_SIZE_BYTES));

  // 1) Init — worker membuat multipart upload di R2 dan mengembalikan
  //    upload_id + storage_key untuk semua request berikut.
  let uploadId = '';
  let storageKey = '';
  await withRetries(async () => {
    const response = await xhrRequest({
      method: 'POST',
      url: '/api/recordings/upload/init',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        meeting_id: meta.meetingId,
        upload_token: meta.uploadToken,
        duration_seconds: meta.durationSeconds,
        resolution_width: meta.resolutionWidth,
        resolution_height: meta.resolutionHeight,
        file_name: meta.fileName,
        mime_type: blob.type || (fileExtensionFor(blob) === 'mp4' ? 'video/mp4' : 'video/webm'),
        file_size: blob.size,
        total_parts: totalParts,
      }),
      timeoutMs: SINGLE_TIMEOUT_MS,
    });
    if (response.status !== 201) throw new Error(`Init unggahan gagal (HTTP ${response.status})`);
    uploadId = bodyField(response.body, 'upload_id');
    storageKey = bodyField(response.body, 'storage_key');
    if (!uploadId || !storageKey) throw new Error('Respons init unggahan tidak lengkap');
  }, SINGLE_ATTEMPTS);

  // 2) Kirim per bagian — tiap bagian punya retry sendiri, jadi gangguan di
  //    tengah jalan tidak membatalkan seluruh unggahan.
  const parts: { partNumber: number; etag: string }[] = [];
  const baseHeaders: Record<string, string> = {
    'content-type': 'application/octet-stream',
    'x-meeting-id': meta.meetingId,
    'x-storage-key': storageKey,
  };
  if (meta.uploadToken) baseHeaders['x-upload-token'] = meta.uploadToken;

  try {
    for (let index = 0; index < totalParts; index++) {
      const start = index * CHUNK_SIZE_BYTES;
      const end = Math.min(blob.size, start + CHUNK_SIZE_BYTES);
      const slice = blob.slice(start, end);
      const isLast = index === totalParts - 1;
      let etag = '';
      await withRetries(async () => {
        const response = await xhrRequest({
          method: 'PUT',
          url: `/api/recordings/upload/chunk/${encodeURIComponent(uploadId)}/${index + 1}`,
          body: slice,
          headers: { ...baseHeaders, 'x-last-part': isLast ? '1' : '0' },
          timeoutMs: CHUNK_TIMEOUT_MS,
          onUploadProgress: (fraction) => {
            const bytes = start + fraction * (end - start);
            onProgress?.(Math.min(99, Math.round((bytes / blob.size) * 100)));
          },
        });
        if (response.status !== 200) {
          throw new Error(`Bagian ${index + 1} ditolak (HTTP ${response.status})`);
        }
        etag = bodyField(response.body, 'etag');
        if (!etag) throw new Error(`Respons bagian ${index + 1} tidak berisi etag`);
      }, CHUNK_ATTEMPTS);
      parts.push({ partNumber: index + 1, etag });
    }

    // 3) Complete — worker menggabungkan bagian jadi satu file lalu mencatatnya
    //    ke database.
    await withRetries(async () => {
      const response = await xhrRequest({
        method: 'POST',
        url: '/api/recordings/upload/complete',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          upload_id: uploadId,
          storage_key: storageKey,
          meeting_id: meta.meetingId,
          upload_token: meta.uploadToken,
          parts,
          file_name: meta.fileName,
          duration_seconds: meta.durationSeconds,
          resolution_width: meta.resolutionWidth,
          resolution_height: meta.resolutionHeight,
        }),
        timeoutMs: SINGLE_TIMEOUT_MS,
      });
      if (response.status !== 201) {
        throw new Error(`Finalisasi unggahan gagal (HTTP ${response.status})`);
      }
    }, SINGLE_ATTEMPTS);
  } catch (error) {
    // Gagal total di tengah jalan → minta worker membatalkan multipart upload
    // supaya tidak ada potongan menggantung di R2 (best-effort).
    void xhrRequest({
      method: 'POST',
      url: '/api/recordings/upload/abort',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        upload_id: uploadId,
        storage_key: storageKey,
        meeting_id: meta.meetingId,
        upload_token: meta.uploadToken,
      }),
      timeoutMs: 30_000,
    }).catch(() => {});
    throw error;
  }
}

/** true = server mengonfirmasi tersimpan; false = gagal (pemanggil menyimpan cadangan). */
export async function uploadRecordingBlob(
  blob: Blob,
  meta: RecordingUploadMeta,
  onProgress?: (percent: number) => void
): Promise<boolean> {
  if (blob.size === 0) return false;
  try {
    if (blob.size > CHUNKED_THRESHOLD_BYTES) {
      await uploadChunked(blob, meta, onProgress);
    } else {
      await uploadSingle(blob, meta, onProgress);
    }
    onProgress?.(100);
    return true;
  } catch (error) {
    console.warn('[recording] unggahan gagal total:', error);
    return false;
  }
}
