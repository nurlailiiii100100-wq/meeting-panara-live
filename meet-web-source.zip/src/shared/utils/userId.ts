const USER_ID_KEY = 'learnly:userId';
const MEETING_ID_KEY = 'meeting_id';
const PARTICIPANT_ID_KEY = 'participant_id';
const PARTICIPANT_NAME_KEY = 'participant_name';

export interface MeetingSession {
  meetingId: string;
  participantId: string;
  participantName: string;
}

export function getPersistentUserId(): string {
  try {
    const existing = localStorage.getItem(USER_ID_KEY);
    if (existing) return existing;
  } catch {
    // localStorage unavailable (SSR, private browsing edge cases)
  }

  const id = crypto.randomUUID();

  try {
    localStorage.setItem(USER_ID_KEY, id);
  } catch {
    // localStorage full or unavailable
  }

  return id;
}

export function getActiveMeetingSession(): MeetingSession | null {
  try {
    const meetingId = sessionStorage.getItem(MEETING_ID_KEY);
    if (!meetingId) return null;
    const participantId = sessionStorage.getItem(PARTICIPANT_ID_KEY) || getPersistentUserId();
    const participantName = sessionStorage.getItem(PARTICIPANT_NAME_KEY) || '';
    return { meetingId, participantId, participantName };
  } catch {
    return null;
  }
}

export function setActiveMeetingSession(meetingId: string, participantId?: string, participantName?: string): void {
  try {
    const pid = participantId || getPersistentUserId();
    sessionStorage.setItem(MEETING_ID_KEY, meetingId);
    sessionStorage.setItem(PARTICIPANT_ID_KEY, pid);
    if (participantName) {
      sessionStorage.setItem(PARTICIPANT_NAME_KEY, participantName);
    }
  } catch {
    // sessionStorage unavailable
  }
}

export function clearActiveMeetingSession(meetingId?: string): void {
  try {
    sessionStorage.removeItem(MEETING_ID_KEY);
    sessionStorage.removeItem(PARTICIPANT_ID_KEY);
    sessionStorage.removeItem(PARTICIPANT_NAME_KEY);
    if (meetingId) {
      sessionStorage.removeItem(`rtk:token:${meetingId}`);
    }
  } catch {
    // sessionStorage unavailable
  }
}
