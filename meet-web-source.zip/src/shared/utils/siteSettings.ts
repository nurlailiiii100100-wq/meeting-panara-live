import { useEffect, useState, useSyncExternalStore } from 'react';

export const DEFAULT_SITE_TITLE = 'learnly';

// Shared across every useSiteLogo() call so a settings save refreshes
// navbar, Home, AdminLogin, and favicon together — not only the dashboard.
let siteSettingsVersion = 0;
const listeners = new Set<() => void>();

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getSiteSettingsVersion(): number {
  return siteSettingsVersion;
}

/** Call after PUT /api/settings so all logo/title consumers refetch. */
export function notifySiteSettingsChanged(): void {
  siteSettingsVersion += 1;
  for (const listener of listeners) listener();
}

export function useSiteLogo(): { logo: string; title: string; loading: boolean } {
  const version = useSyncExternalStore(subscribe, getSiteSettingsVersion, getSiteSettingsVersion);
  const [logo, setLogo] = useState('');
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    // cache: 'no-store' — settings can change right after save; never reuse a stale body.
    fetch('/api/settings/public', { cache: 'no-store' })
      .then(r => (r.ok ? r.json() : {}))
      .then((d: { logo?: string; title?: string }) => {
        if (!cancelled) {
          setLogo(d.logo || '');
          setTitle(d.title || '');
        }
      })
      .catch(() => {
        if (!cancelled) {
          setLogo('');
          setTitle('');
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [version]);

  // Apply the site identity to the browser tab & favicon too — not just the UI:
  // the <title> and <link rel="icon"> follow the custom title & logo settings.
  useEffect(() => {
    document.title = (title || DEFAULT_SITE_TITLE).trim();
    const faviconHref = logo || '/learnly.svg';
    const links = document.head.querySelectorAll<HTMLLinkElement>('link[rel="icon"], link[rel="apple-touch-icon"]');
    for (const link of links) {
      link.href = faviconHref;
    }
  }, [logo, title]);

  return { logo, title, loading };
}
