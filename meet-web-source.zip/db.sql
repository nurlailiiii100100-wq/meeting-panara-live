-- Snapshot schema produksi (learnly-db) — diregenerate dari:
--   npx wrangler d1 execute learnly-db --remote "SELECT type, name, sql FROM sqlite_master ..."
--   2026-09-30 — sesuai migrasi 0001-0008 + seedAdmin; TIDAK memuat tabel legacy mute_state/mute_read_tokens (sudah di-drop).

-- Schema
CREATE TABLE app_settings (key TEXT PRIMARY KEY, value TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE categories (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE meetings (id TEXT PRIMARY KEY, provider_meeting_id TEXT NOT NULL, name TEXT NOT NULL, created_by TEXT NOT NULL, max_participants INTEGER NOT NULL DEFAULT 20, duration_minutes INTEGER NOT NULL DEFAULT 60, status TEXT NOT NULL DEFAULT 'scheduled', started_at DATETIME, expires_at DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, public_id TEXT, scheduled_at DATETIME, timezone TEXT DEFAULT 'UTC', host_resolution TEXT DEFAULT '360p', member_resolution TEXT DEFAULT '240p', allow_member_whiteboard INTEGER DEFAULT 0, allow_member_annotation INTEGER DEFAULT 0, category_id TEXT, auto_record INTEGER DEFAULT 0, recording_retention_hours INTEGER DEFAULT 48, kick_cooldown_minutes INTEGER NOT NULL DEFAULT 15, host_join_code TEXT, late_join_minutes INTEGER NOT NULL DEFAULT 30, max_active_cameras INTEGER NOT NULL DEFAULT 0, screenshare_resolution TEXT NOT NULL DEFAULT '720p');

CREATE TABLE participant_name_overrides (id INTEGER PRIMARY KEY AUTOINCREMENT, meeting_id TEXT NOT NULL, custom_participant_id TEXT NOT NULL, name TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(meeting_id, custom_participant_id));

CREATE TABLE meeting_kicks (id TEXT PRIMARY KEY, meeting_id TEXT NOT NULL, user_id TEXT NOT NULL, kicked_by TEXT, kicked_at DATETIME NOT NULL, expires_at DATETIME NOT NULL);

CREATE INDEX idx_meeting_kicks_lookup ON meeting_kicks (meeting_id, user_id, expires_at);

CREATE TABLE password_reset_codes (id TEXT PRIMARY KEY, email TEXT NOT NULL, code_hash TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, expires_at DATETIME NOT NULL, consumed_at DATETIME, created_at DATETIME NOT NULL);

CREATE TABLE presets (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, max_participants INTEGER NOT NULL DEFAULT 20, duration_minutes INTEGER NOT NULL DEFAULT 60, host_resolution TEXT NOT NULL DEFAULT '360p', member_resolution TEXT NOT NULL DEFAULT '240p', created_by TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE recordings (id TEXT PRIMARY KEY, meeting_id TEXT NOT NULL, provider_recording_id TEXT, storage_key TEXT NOT NULL, file_name TEXT NOT NULL, duration_seconds INTEGER, size_bytes INTEGER, status TEXT NOT NULL DEFAULT 'ready', expires_at DATETIME NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, download_url TEXT, download_count INTEGER DEFAULT 0, resolution_width INTEGER, resolution_height INTEGER);

CREATE TABLE tentors (id TEXT PRIMARY KEY, meeting_id TEXT NOT NULL, name TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE users (   id TEXT PRIMARY KEY,   username TEXT UNIQUE NOT NULL,   password_hash TEXT NOT NULL,   salt TEXT NOT NULL,   role TEXT NOT NULL DEFAULT 'member',   name TEXT,   created_at DATETIME DEFAULT CURRENT_TIMESTAMP , email TEXT);

CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_meetings_created_by ON meetings(created_by);
CREATE INDEX idx_meetings_provider_id ON meetings(provider_meeting_id);
CREATE UNIQUE INDEX idx_meetings_public_id_live ON meetings(public_id) WHERE status != 'deleted';
CREATE INDEX idx_meetings_status ON meetings(status);
CREATE INDEX idx_password_reset_codes_email ON password_reset_codes(email, created_at);
CREATE INDEX idx_pno_meeting ON participant_name_overrides(meeting_id);
CREATE INDEX idx_recordings_expires_at ON recordings(expires_at);
CREATE INDEX idx_recordings_meeting_id ON recordings(meeting_id);
CREATE UNIQUE INDEX idx_tentors_meeting_name ON tentors(meeting_id, name);
CREATE UNIQUE INDEX idx_users_email ON users(email) WHERE email IS NOT NULL;
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_username ON users(username);

-- Sample Data (satu admin — sama dengan INITIAL_ADMIN_USERNAME di .dev.vars)
INSERT OR REPLACE INTO users (id, username, password_hash, salt, role, name, email) VALUES
('usr_admin_01', 'admin', 'ec36b9de0aa69bee4c5ef1eb8ef96bfc446f84d53076c7676acd035944c3a6a4', '26a9ae1622bce0b154e84465774d004d', 'admin', 'Administrator Utama', 'annisaaaafitri100100@gmail.com');

INSERT OR REPLACE INTO presets (id, name, max_participants, duration_minutes, host_resolution, member_resolution, created_by) VALUES
('pst_std', 'Standard Classroom', 20, 60, '360p', '240p', 'usr_admin_01'),
('pst_webinar', 'Large Webinar', 100, 90, '720p', '240p', 'usr_admin_01'),
('pst_workshop', 'Interactive Workshop', 15, 120, '480p', '360p', 'usr_admin_01');
