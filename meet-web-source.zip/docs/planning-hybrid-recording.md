# Planning Hybrid Auto-Recording: Web (PC) & Mobile (Aplikasi/Tablet)

> **Status:** Web (PC) Aktif & Stabil | Mobile (VPS) On-Demand Siap Diterapkan  
> **Tanggal:** 22 Oktober 2026  
> **Target:** Memisahkan beban rekaman antara Web Laptop/PC (Client-Side) dan Mobile/Tablet (Server-Side VPS) dalam satu ekosistem terpadu.

---

## 1. Latar Belakang & Masalah

### Mengapa Perlu Hybrid?
1. **Limitasi Perangkat Mobile:**
   - Browser dan aplikasi di HP/Tablet Android memiliki keterbatasan sistem operasi saat merekam canvas secara simultan dengan kamera/screenshare.
   - Throttling latar belakang dan manajemen RAM agresif di HP sering memutus rekaman di tengah jalan.
   - Solusi tepat untuk Mobile: **Server-Side Recording via VPS Bot**.
2. **Keterbatasan Resource VPS:**
   - VPS Panara (104.129.17.204) memiliki RAM 6 GB (tersisa ~4.4 GB) dan CPU Xeon 5 vCPU yang berbagi resource dengan service lain (Chatloop, Uptime Kuma, Nginx, MariaDB).
   - Kapasitas maksimal VPS yang aman: **Maksimal 2 meeting paralel**.
   - Jika semua meeting PC juga dipaksa rekam di VPS, RAM server akan habis seketika.
3. **Kekuatan Web Komputer (PC/Laptop):**
   - Laptop/PC memiliki CPU kuat, RAM lega, dan koneksi stabil.
   - Fitur bawaan web client-side (`useClientRecorder`) menghasilkan video lossless jernih (1080p/720p) langsung ke Cloudflare R2 dengan cadangan IndexedDB anti-hilang.
   - Beban di VPS: **0% CPU, 0 MB RAM**.

---

## 2. Arsitektur Terpadu (Web & Mobile Terhubung)

Meskipun jalurnya dipisahkan sesuai tipe perangkat, keduanya tetap menggunakan satu database D1 yang sama, sistem penguncian (*recording lock*) yang sama, dan dashboard rekaman yang sama.

```
                      ┌─────────────────────────────────────────┐
                      │          Host Masuk ke Meeting          │
                      └────────────────────┬────────────────────┘
                                           │
                           Deteksi Perangkat (isMobile?)
                                           │
                ┌──────────────────────────┴──────────────────────────┐
                ▼                                                     ▼
    [ FALSE - Web Laptop/PC ]                             [ TRUE - Mobile/Tablet ]
                │                                                     │
       PLAN 1: JALUR WEB                                     PLAN 2: JALUR MOBILE
 (Client-Side Browser -> R2)                           (Server-Side VPS Bot Service)
                │                                                     │
   - Klaim lock D1 ('auto')                              - Request ke Worker API
   - Render canvas + mix audio                           - Dispatch HMAC ke VPS :4000
   - Upload chunked ke R2                                - Bot Playwright rekam room
   - Backup IndexedDB lokal                              - FFmpeg convert MP4 di VPS
   - 0% Beban di VPS                                     - Callback selesai ke Worker
                │                                                     │
                └──────────────────────────┬──────────────────────────┘
                                           ▼
                      ┌─────────────────────────────────────────┐
                      │         Sistem Manajemen Terpadu        │
                      ├─────────────────────────────────────────┤
                      │ • Lock Meeting D1 (Cegah rekam dobel)   │
                      │ • Dashboard Rekaman (Badge "Otomatis")  │
                      │ • Retensi 48 Jam (Auto-Cleanup)         │
                      │ • Stream & Download (R2 / VPS Redirect) │
                      └─────────────────────────────────────────┘
```

---

## 3. PLAN 1: Sisi Web (Desktop / Laptop PC) — [FOKUS SAAT INI]

Tujuan: **Mengembalikan auto-record Web ke performa awal client-side yang stabil, jernih, dan 0 beban VPS.**

### Alur Kerja:
1. **Deteksi Perangkat:**
   - Host membuka meeting lewat browser PC (Chrome/Edge/Firefox di Windows/Mac/Linux).
   - `shareSupport.isMobile === false`.
2. **Pengecekan Waktu & Status:**
   - `auto_record === true`.
   - Waktu saat ini melewati atau sama dengan `scheduled_at`.
   - Tidak ada operator lain atau bot yang sedang merekam (`recordingLock.active === false`).
3. **Klaim Kunci Rekaman (Lock):**
   - Browser PC memanggil `POST /api/meetings/:id/recording-claim` dengan `{ operator_id: userId, source: 'auto' }`.
   - Jika berhasil mengunci, browser PC resmi menjadi operator rekaman sesi tersebut.
4. **Eksekusi Perekaman Lokal:**
   - `startClientRecording()` berjalan di browser host.
   - Me-render video dari track kamera peserta dan screenshare ke `<canvas>`.
   - Menggabungkan seluruh audio peserta via `AudioContext`.
   - Meng-encode stream menjadi WebM/VP9 menggunakan `MediaRecorder`.
5. **Penyimpanan & Pengiriman (Cloudflare R2):**
   - Rekaman disimpan sementara di IndexedDB browser sebagai cadangan anti-hilang.
   - Diunggah berkala menggunakan chunked upload langsung ke bucket Cloudflare R2 (`storage: 'r2'`).
   - Setelah upload selesai dan dikonfirmasi server, cadangan IndexedDB dibersihkan.
6. **Kunci Dilepas:**
   - Panggilan `POST /api/meetings/:id/recording-release` dikirim saat meeting berhenti atau selesai.

### Keuntungan Sisi Web:
- Kualitas rekaman sangat tajam (lossless 1080p/720p).
- Penggunaan kuota server VPS = **0 MB**.
- Tidak terpengaruh antrian atau limit 2 rekaman VPS.

---

## 4. PLAN 2: Sisi Mobile (Aplikasi / Tablet) — [FASE BERIKUTNYA]

Tujuan: **Memanggil Bot Headless di VPS secara On-Demand hanya bila Host masuk menggunakan perangkat Mobile.**

### Alur Kerja:
1. **Deteksi Perangkat:**
   - Host masuk room meeting melalui aplikasi mobile Android / browser HP / tablet.
   - `shareSupport.isMobile === true`.
2. **Pencegahan Rekam Lokal:**
   - Browser/aplikasi mobile **TIDAK** menjalankan `startClientRecording()` lokal agar HP tidak panas/crash.
3. **Pemanggilan Bot VPS (On-Demand):**
   - Host mobile memanggil endpoint Worker:
     ```http
     POST /api/meetings/:id/request-vps-record
     ```
   - Worker memverifikasi hak akses Host.
   - Worker memeriksa apakah meeting sudah memiliki rekaman aktif.
   - Jika aman, Worker menandai `vps_dispatched_at` dan mengirim request job berotentikasi HMAC ke VPS:
     ```http
     POST http://104.129.17.204:4000/api/jobs
     Headers:
       X-Timestamp: <unix_timestamp>
       X-Signature: <hmac_sha256_signature>
     Body:
       { meeting_id, meeting_url, duration_minutes, resolution }
     ```
4. **Perekaman oleh Bot VPS:**
   - Service VPS (`/opt/meet-recorder/`) menerima job.
   - Bot Playwright Chromium headless masuk ke room meeting menggunakan session cookie admin (`role: 'admin'`).
   - Bot mengklaim recording lock: `{ operator_id: 'vps-recorder', source: 'auto' }`.
   - Bot merekam tampilan meeting dan audio room.
   - Bot mengirim heartbeat setiap 15 detik ke Worker.
5. **Finalisasi & Konversi di VPS:**
   - Saat meeting selesai atau host keluar, bot menghentikan rekaman.
   - FFmpeg di VPS mengonversi hasil ke MP4:
     ```bash
     ffmpeg -i /var/lib/meet/tmp/<job_id>.webm \
       -c:v libx264 -preset veryfast -crf 23 -r 25 -s 1280x720 \
       -c:a aac -b:a 128k -ac 2 -movflags +faststart \
       -y /var/lib/meet/recordings/<meeting_id>/<job_id>.mp4
     ```
   - Bot melepas kunci rekaman.
   - VPS memanggil callback ke Worker:
     ```http
     POST /api/internal/vps/recording-completed
     ```
   - D1 mencatat baris baru dengan `storage: 'vps'`, `source: 'auto'`, dan `vps_file_path`.
6. **Penanganan Kegagalan (Fallback):**
   - Jika bot VPS terputus, crash, atau antrian penuh, status kunci di D1 akan kadaluarsa (>90 detik).
   - Di antarmuka host akan muncul popup:
     *"Koneksi perekam VPS terputus atau rekaman otomatis berhenti mendadak."*
   - Host dapat menekan tombol **"Rekam Manual"** sebagai cadangan.

---

## 5. Matriks Perbandingan & Interoperabilitas

| Fitur | Sisi Web (Komputer / Laptop) | Sisi Mobile (Aplikasi / Tablet) |
|---|---|---|
| **Eksekutor** | Browser Host (Client-Side) | Bot VPS Chromium (Server-Side) |
| **Kebutuhan VPS** | **0% (Tidak menggunakan VPS)** | Ya (1 instance browser Playwright) |
| **Penyimpanan Video** | Cloudflare R2 (`storage: 'r2'`) | Disk Lokal VPS (`storage: 'vps'`) |
| **Format Akhir** | WebM / MP4 via browser | MP4 (H.264 + AAC) via FFmpeg |
| **Pencegahan Konflik** | Mengklaim kunci D1 `source: 'auto'` | Mengklaim kunci D1 `source: 'auto'` |
| **Jika Ada Kunci Aktif** | Mengalah (yield) agar tidak dobel | Mengalah (yield) agar tidak dobel |
| **Retensi File** | 48 Jam (Dihapus cron Worker dari R2) | 48 Jam (Dihapus cron script VPS dari disk) |
| **Playback & Download** | Streaming langsung dari R2 | Redirect signed URL HMAC ke port 4000 VPS |
| **Tampilan Dashboard** | Muncul di Admin/Host Dashboard | Muncul dengan badge `Otomatis` |

---

## 6. Status Pengerjaan

### Tahap 1: Sisi Web (Desktop PC) — [SELESAI ✅]
- [x] Deteksi perangkat mobile `shareSupport.isMobile` di `Meeting.tsx`.
- [x] Auto-record client-side PC dipulihkan (`maybeAutoRecord` langsung ke `startClientRecording`).
- [x] Cron Worker dinonaktifkan dari memanggil VPS secara buta.
- [x] Alert kegagalan VPS dispesifikasikan hanya untuk `operatorId: 'vps-recorder'`.
- [x] Verifikasi build TypeScript dan Vite (`npm run build`: 0 error).

### Tahap 2: Sisi Mobile (VPS Bot On-Demand) — [LANGKAH BERIKUTNYA]
- [ ] Buat endpoint `POST /api/meetings/:id/request-vps-record` di Cloudflare Worker.
- [ ] Sambungkan tombol/trigger dari aplikasi mobile/tablet ke endpoint request VPS.
- [ ] Deploy script service Node.js/Playwright di VPS `/opt/meet-recorder/`.
- [ ] Konfigurasi cron retention cleanup 48 jam di VPS.
