# IMPLEMENTASI — Rekaman Otomatis Server-Side di VPS

> Status: **Siap dikerjakan**
> Tanggal: 21 Oktober 2026 (Revisi: 22 Oktober 2026)
> Dokumen induk: `docs/planning-rekaman-vps-otomatis.md`

---

## 0. Kondisi VPS Saat Ini (Hasil Audit 21 Okt 2026)

```
IP              : 104.129.17.204
Hostname        : panara
OS              : Ubuntu 24.04.4 LTS x86_64
CPU             : 5 vCPU — Intel Xeon E5-2697 v2 @ 2.7GHz
RAM             : 5924 MB (available ~4400 MB)
Disk            : 96 GB total, ~45 GB tersisa (setelah cleanup)
Swap            : 3 GB (belum terpakai)
Panel           : aaPanel (port 34151)
```

### Software Tersedia

| Software      | Versi      | Status            |
|---------------|------------|-------------------|
| Docker        | 29.4.1     | ✅ Ada            |
| Node.js       | v22.23.2   | ✅ Ada            |
| Nginx         | 1.30.0     | ✅ Ada            |
| Python        | 3.12.3     | ✅ Ada            |
| MariaDB       | via aaPanel | ✅ Ada            |
| **FFmpeg**    | —          | ❌ **Perlu install** |
| **Chromium**  | —          | ❌ **Perlu install** |

### Service Aktif yang Makan Resource

| Proses                    | RAM    | Port          |
|---------------------------|--------|---------------|
| Chatloop app + backend    | ~305 MB | 3030          |
| Uptime Kuma (monitoring)  | ~170 MB | 3001 (Docker) |
| MariaDB (aaPanel)         | ~137 MB | 3306          |
| MariaDB (Docker/chatloop) | ~108 MB | —             |
| aaPanel Python            | ~118 MB | 34151         |
| Docker + containerd       | ~150 MB | —             |
| Nginx (5 workers)         | ~190 MB | 80, 443, 887, 8389 |
| Apache + LiteSpeed        | ~200 MB | 81, 7080, 8188-8290 |
| Email (exim4 + dovecot)   | ~30 MB  | 25, 465, 587, 110, 143, 993, 995 |

### Kapasitas untuk Recording

| Skenario               | Max Meeting Concurrent |
|------------------------|------------------------|
| VPS saat ini (sibuk)   | **2 meeting**          |
| VPS kosongan           | 3 meeting (720p), 4 meeting (480p) |

**Bottleneck utama:** RAM (6 GB shared). Disk ~45 GB tersisa — cukup aman.

---

## 1. Yang Perlu Diinstall di VPS

### 1a. Install FFmpeg

```bash
apt update
apt install -y ffmpeg
ffmpeg -version  # verifikasi
```

### 1b. Install Chromium + Dependencies

```bash
# Chromium headless + dependency untuk Playwright
apt install -y chromium-browser fonts-liberation fonts-noto-color-emoji \
  libnss3 libatk-bridge2.0-0t64 libdrm2 libxcomposite1 libxdamage1 \
  libxrandr2 libgbm1 libasound2t64 libpangocairo-1.0-0 libgtk-3-0t64 \
  libxshmfence1

# Verifikasi
chromium-browser --version
```

### 1c. Setup Playwright (Alternatif — lebih stabil dari Puppeteer)

```bash
mkdir -p /opt/meet-recorder
cd /opt/meet-recorder
npm init -y
npm install playwright@latest
npx playwright install chromium --with-deps
```

> **Catatan:** Playwright di-*prefer* daripada Puppeteer karena:
> - Built-in auto-download Chromium yang kompatibel
> - API screen recording bawaan (`page.video()`)
> - Lebih stabil untuk long-running headless sessions

### 1d. Setup Folder Storage

```bash
mkdir -p /var/lib/meet/recordings
mkdir -p /var/lib/meet/tmp
mkdir -p /var/log/meet-recorder
chown -R root:root /var/lib/meet
chmod 755 /var/lib/meet/recordings
```

### 1e. Setup Swap (Sudah Ada 3 GB — Aman)

```bash
# Verifikasi swap
swapon --show
free -h
# Swap 3 GB sudah ada. Cukup untuk bantalan saat 2 recording paralel.
```

---

## 2. Akses VPS Recorder (IP Langsung + Port)

**Tidak pakai subdomain.** Worker memanggil VPS langsung via IP + port:

```
URL: http://104.129.17.204:4000
```

### Setup Firewall

Port 4000 dibuka **hanya untuk IP Cloudflare** (agar hanya Worker yang bisa akses):

```bash
# Blokir port 4000 dari publik (default)
ufw deny 4000/tcp

# Izinkan HANYA dari IP range Cloudflare Workers
# (lihat: https://www.cloudflare.com/ips-v4/)
ufw allow from 173.245.48.0/20 to any port 4000 proto tcp
ufw allow from 103.21.244.0/22 to any port 4000 proto tcp
ufw allow from 103.22.200.0/22 to any port 4000 proto tcp
ufw allow from 103.31.4.0/22 to any port 4000 proto tcp
ufw allow from 141.101.64.0/18 to any port 4000 proto tcp
ufw allow from 108.162.192.0/18 to any port 4000 proto tcp
ufw allow from 190.93.240.0/20 to any port 4000 proto tcp
ufw allow from 188.114.96.0/20 to any port 4000 proto tcp
ufw allow from 197.234.240.0/22 to any port 4000 proto tcp
ufw allow from 198.41.128.0/17 to any port 4000 proto tcp
ufw allow from 162.158.0.0/15 to any port 4000 proto tcp
ufw allow from 104.16.0.0/13 to any port 4000 proto tcp
ufw allow from 104.24.0.0/14 to any port 4000 proto tcp
ufw allow from 172.64.0.0/13 to any port 4000 proto tcp
ufw allow from 131.0.72.0/22 to any port 4000 proto tcp

ufw reload
```

> **Kenapa tidak pakai SSL?**
> - Komunikasi Worker → VPS sudah diamankan via HMAC signature (§9a)
> - Port 4000 tidak bisa diakses publik (firewall)
> - Ini machine-to-machine, bukan browser → tidak perlu HTTPS
> - Lebih simpel, tidak perlu Nginx tambahan atau sertifikat

> **Untuk stream/download ke browser user:**
> Worker yang redirect — user mengakses `/api/recordings/:id/stream`
> di Worker (HTTPS), lalu Worker proxy/redirect ke VPS secara internal.

---

## 3. Arsitektur Service Recorder

### 3a. Struktur Project di VPS

```
/opt/meet-recorder/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts              # Entry point — HTTP server (Express/Fastify)
│   ├── recorder.ts           # Playwright: join meeting, record viewport
│   ├── scheduler.ts          # Terima job dari Worker, kelola antrian
│   ├── cleanup.ts            # Cleanup file expired, alert disk
│   ├── auth.ts               # Verifikasi HMAC dari Worker + generate session cookie
│   └── config.ts             # Environment variables & defaults
├── .env                      # Secrets (HMAC key, SESSION_SECRET, dll)
└── recordings/               # Symlink → /var/lib/meet/recordings/
```

> **Catatan:** File `transcoder.ts` (FFmpeg WebM→MP4) **tidak diperlukan**.
> Playwright `page.video()` langsung menghasilkan WebM yang bisa di-pipe ke
> FFmpeg CLI saat finalisasi — tidak perlu modul transcoder terpisah.

### 3b. API Endpoints Service Recorder

```
POST /api/jobs                      # Worker memanggil: mulai recording
  Body: { meeting_id, meeting_url, duration_minutes, resolution }
  Auth: HMAC signature (lihat §9a)
  Response: { job_id, status: "joining" }

POST /api/jobs/:id/stop             # Worker memanggil: paksa stop
  Auth: HMAC signature
  Response: { job_id, status: "stopping" }

GET  /api/jobs/:id/status           # Cek status job
  Auth: HMAC signature
  Response: { job_id, status, duration_seconds, file_size }

GET  /api/stream/:filename          # Stream MP4 (Range request support)
  Auth: Signed URL (lihat §9c)
  Response: 200/206 video/mp4

GET  /api/download/:filename        # Download MP4
  Auth: Signed URL (lihat §9c)
  Response: attachment video/mp4

GET  /health                        # Health check (tanpa auth)
  Response: { ok: true, active_jobs: N, disk_free_gb: N }
```

### 3c. Alur Recording Bot — Detail Lengkap

```
1. Worker cron (tiap 1 menit) → dispatchAutoRecordJobs():
   - Query meeting: status IN ('scheduled','active'), auto_record = 1,
     scheduled_at <= now + 1 menit, vps_dispatched_at IS NULL
   - POST ke VPS /api/jobs (dengan HMAC signature)
   - Tandai vps_dispatched_at = now (mencegah dispatch ganda)

2. VPS Scheduler:
   - Cek kapasitas: aktif < 2? → lanjut. Aktif >= 2? → antri (max 5)

3. Recorder.start(job):

   a. GENERATE SESSION COOKIE ADMIN (lihat §9b untuk detail lengkap):
      - VPS punya SESSION_SECRET yang sama dengan Worker
      - Buat payload: { userId: "vps-recorder", username: "Perekam",
                        role: "admin", exp: now + 4 jam }
      - Sign: payloadB64url + "." + HMAC-SHA256(SESSION_SECRET, payloadB64url)
      - Hasilnya = valid admin session cookie (format sama persis
        dengan yang dibuat `createSessionToken()` di worker/auth.ts)

   b. Launch Playwright Chromium headless

   c. SET COOKIE pada browser context:
      - Cookie name: "learnly_session"
      - Cookie value: <token dari langkah 3a>
      - Domain: <domain meet-web>
      - Path: "/"

   d. Navigasi ke URL meeting (mis: https://meet.learnly.id/<public_id>)
      - Karena punya cookie admin, bot OTOMATIS mendapat:
        ✅ Bypass gate jadwal (scheduled_at belum tercapai)
        ✅ Bypass gate kapasitas (MEETING_FULL)
        ✅ Bypass gate late-join cutoff
        ✅ Bypass gate kick cooldown
        ✅ Preset "group_call_host" (bukan participant)
        ✅ upload_token untuk upload rekaman (jika diperlukan nanti)

   e. Bot join meeting dengan nama "Perekam":
      - Kamera: OFF
      - Mikrofon: OFF (hanya terima audio)

   f. Klaim recording lock:
      POST /api/meetings/:id/recording-claim
      { operator_id: "vps-recorder", source: "auto" }
      → Kode di worker/handlers/meetings.ts sudah mendukung source: "auto"
      → Jika gagal (409 LOCKED — host sudah merekam): stop, callback gagal

   g. Mulai recording via Playwright:
      - Gunakan page.video() API untuk capture viewport
      - ATAU: captureStream() dari tab → pipe ke FFmpeg
      - Audio otomatis ter-capture dari tab audio (meeting voices)
      - Output: WebM sementara di /var/lib/meet/tmp/

   h. Setelah recording selesai, konversi ke MP4:
      ffmpeg -i /var/lib/meet/tmp/<job_id>.webm \
        -c:v libx264 -preset veryfast -crf 23 -r 25 -s 1280x720 \
        -c:a aac -b:a 128k -ac 2 \
        -movflags +faststart \
        -y /var/lib/meet/recordings/<meeting_id>/<job_id>.mp4

4. Selama recording berjalan:
   - Heartbeat tiap 15 detik:
     POST /api/meetings/:id/recording-heartbeat
     { operator_id: "vps-recorder" }
     → Stale threshold 90 detik (sudah di kode: RECORDING_LOCK_STALE_SECONDS = 90)
   - Cek peserta tiap 30 detik:
     * 0 peserta manusia > 5 menit → stop (ruangan kosong)
     * Meeting expired/ended → stop
   - Cek disk space tiap 60 detik:
     * < 2 GB free → emergency stop + alert

5. Stop & Callback:
   a. Stop recording Playwright
   b. Konversi WebM → MP4 via FFmpeg (langkah 3h)
   c. Release recording lock:
      POST /api/meetings/:id/recording-release
      { operator_id: "vps-recorder" }
   d. Callback ke Worker (dengan HMAC signature):
      POST <WORKER_URL>/api/internal/vps/recording-completed
      {
        meeting_id, job_id,
        file_name: "<job_id>.mp4",
        vps_file_path: "/var/lib/meet/recordings/<meeting_id>/<job_id>.mp4",
        duration_seconds, size_bytes,
        resolution_width: 1280, resolution_height: 720,
        source: "auto", storage: "vps"
      }
   e. Worker tulis baris di D1 (insertRecordingRow — lihat §4b)
   f. Bot leave meeting, tutup Playwright
```

### 3d. Systemd Service

```ini
# /etc/systemd/system/meet-recorder.service
[Unit]
Description=Meet Recorder Service
After=network.target nginx.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/meet-recorder
ExecStart=/usr/bin/node --import tsx src/index.ts
Restart=always
RestartSec=10
Environment=NODE_ENV=production
EnvironmentFile=/opt/meet-recorder/.env

# Batas resource supaya tidak membunuh service lain
MemoryMax=3G
CPUQuota=300%

# Logging
StandardOutput=append:/var/log/meet-recorder/stdout.log
StandardError=append:/var/log/meet-recorder/stderr.log

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable meet-recorder
systemctl start meet-recorder
systemctl status meet-recorder
```

---

## 4. Perubahan di Cloudflare Worker (meet-web)

### 4a. Environment Variables Baru

**Di `wrangler.jsonc`:**

```jsonc
"vars": {
    "ACCOUNT_ID": "e428c402137e5081c9c30afa21c1009b",
    "VPS_RECORDER_URL": "http://104.129.17.204:4000"
}
```

**Sebagai secret (wrangler secret):**

```bash
wrangler secret put RECORDING_HMAC_SECRET   # shared secret untuk HMAC Worker↔VPS
# SESSION_SECRET sudah ada — VPS juga perlu nilainya (lihat §7)
```

**Update `worker-configuration.d.ts`:**

```typescript
// Tambahkan di interface __BaseEnv_Env:
VPS_RECORDER_URL: string;
RECORDING_HMAC_SECRET: string;
```

### 4b. File Baru: `worker/handlers/vpsRecording.ts`

Endpoint internal yang dipanggil VPS setelah recording selesai.
Verifikasi HMAC sebelum diproses (lihat §9a).

```
POST /api/internal/vps/recording-completed
  → Verifikasi HMAC header
  → Panggil insertRecordingRow() dengan parameter tambahan:
    {
      id: crypto.randomUUID(),
      meetingId: body.meeting_id,
      storageKey: "",                    // tidak ada di R2
      fileName: body.file_name,
      durationSeconds: body.duration_seconds,
      sizeBytes: body.size_bytes,
      resolutionWidth: body.resolution_width,
      resolutionHeight: body.resolution_height,
      source: "auto",                   // KOLOM BARU
      storage: "vps",                   // KOLOM BARU
      vpsFilePath: body.vps_file_path   // KOLOM BARU
    }
  → Response: { ok: true, recording_id }

POST /api/internal/vps/recording-failed
  → Verifikasi HMAC header
  → Log error di D1 (optional: buat baris recording dengan status 'failed')
  → Response: { ok: true }

POST /api/internal/vps/recording-deleted
  → Verifikasi HMAC header
  → UPDATE recordings SET status = 'deleted' WHERE vps_file_path = body.file_path
  → Response: { ok: true }
```

**Registrasi route di `worker/index.ts`:**

```typescript
// Tambah di routing (setelah baris recordings)
if (url.pathname.startsWith("/api/internal/vps/")) {
  const { handleVpsCallback } = await import("./handlers/vpsRecording");
  return handleVpsCallback(request, env, url);
}
```

> **Catatan:** Saat ini `worker/index.ts` belum punya route `/api/internal/*`.
> Route ini baru dan pattern-nya mengikuti flat if/else routing yang sudah ada.

### 4c. Modifikasi Cron (worker/index.ts)

```typescript
// scheduled() — SEBELUM:
async scheduled(_event: ScheduledEvent, env: Env): Promise<void> {
    await handleScheduledCleanups(env);
}

// scheduled() — SESUDAH:
async scheduled(_event: ScheduledEvent, env: Env): Promise<void> {
    await handleScheduledCleanups(env);        // yang sudah ada
    await dispatchAutoRecordJobs(env);          // BARU: kirim job ke VPS
}
```

**Cron interval** perlu diperkecil:

```jsonc
// wrangler.jsonc — SEBELUM:
"triggers": {
    "crons": ["0 * * * *"]    // setiap jam
}

// wrangler.jsonc — SESUDAH:
"triggers": {
    "crons": ["* * * * *"]    // setiap menit
}
```

> **Dampak:** Cloudflare Workers Free plan mendukung hingga 100.000 cron invokasi/hari.
> Per menit = 1.440 invokasi/hari — jauh di bawah batas.
> Setiap invokasi melakukan 1 query SELECT D1 + 0–N POST ke VPS.

### 4d. File Baru: `worker/handlers/vpsDispatch.ts`

```typescript
// Pseudocode — logika utama
export async function dispatchAutoRecordJobs(env: Env): Promise<void> {
  const nowISO = new Date().toISOString();
  const windowISO = new Date(Date.now() + 60_000).toISOString();

  // Query meeting yang perlu di-dispatch
  const rows = await env.DB.prepare(`
    SELECT id, public_id, duration_minutes, host_resolution
    FROM meetings
    WHERE auto_record = 1
      AND status IN ('scheduled', 'active')
      AND scheduled_at <= ?
      AND vps_dispatched_at IS NULL
  `).bind(windowISO).all<MeetingRow>();

  for (const meeting of rows.results || []) {
    try {
      // Kirim job ke VPS (dengan HMAC — lihat §9a)
      const body = JSON.stringify({
        meeting_id: meeting.id,
        meeting_url: `${env.MEETING_BASE_URL || ''}/${meeting.public_id}`,
        duration_minutes: meeting.duration_minutes,
        resolution: meeting.host_resolution || '720p',
      });

      const timestamp = Math.floor(Date.now() / 1000).toString();
      const signaturePayload = `${timestamp}.${body}`;
      const signature = await hmacHex(env.RECORDING_HMAC_SECRET, signaturePayload);

      const res = await fetch(`${env.VPS_RECORDER_URL}/api/jobs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Signature': signature,
          'X-Timestamp': timestamp,
        },
        body,
      });

      if (res.ok) {
        // Tandai sudah dispatch — mencegah dispatch ganda
        await env.DB.prepare(
          'UPDATE meetings SET vps_dispatched_at = ? WHERE id = ?'
        ).bind(nowISO, meeting.id).run();
      }
    } catch (err) {
      console.error(`VPS dispatch failed for meeting ${meeting.id}:`, err);
      // Tidak tandai — akan retry di cron menit berikutnya
    }
  }
}
```

### 4e. Modifikasi `worker/handlers/recordings.ts`

Stream/download perlu membedakan storage `r2` vs `vps`.

**SEBELUM** (kode saat ini — hanya R2):

```typescript
// Stream: selalu ambil dari R2
const object = await env.RECORDINGS_BUCKET.get(rec.storage_key, { range: req.headers });

// Download: selalu ambil dari R2
const object = await env.RECORDINGS_BUCKET.get(rec.storage_key);
```

**SESUDAH** (tambah branch VPS):

```typescript
// Cek storage location
if (rec.storage === 'vps' && rec.vps_file_path) {
  // Buat signed URL → redirect ke VPS
  // Format: <vps_file_path>.<expSeconds>.<hmacHex>
  // (Reuse pola dari worker/lib/uploadToken.ts)
  const exp = Math.floor(Date.now() / 1000) + 3600; // 1 jam
  const payload = `${rec.vps_file_path}.${exp}`;
  const sig = await hmacHex(env.RECORDING_HMAC_SECRET, payload);
  const signedUrl = `${env.VPS_RECORDER_URL}/api/stream/${encodeURIComponent(rec.vps_file_path)}?sig=${sig}&exp=${exp}`;
  return Response.redirect(signedUrl, 302);
}

// R2 path (existing — tidak berubah)
const object = await env.RECORDINGS_BUCKET.get(rec.storage_key, { range: req.headers });
```

### 4f. Modifikasi `insertRecordingRow()` di `recordings.ts`

**SEBELUM** (kode saat ini):

```typescript
async function insertRecordingRow(db, env, params: {
  id, meetingId, storageKey, fileName,
  durationSeconds, sizeBytes, resolutionWidth, resolutionHeight
})
// INSERT INTO recordings (id, meeting_id, storage_key, file_name,
//   duration_seconds, size_bytes, resolution_width, resolution_height,
//   status, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ready', ?)
```

**SESUDAH** (tambah parameter VPS):

```typescript
async function insertRecordingRow(db, env, params: {
  id, meetingId, storageKey, fileName,
  durationSeconds, sizeBytes, resolutionWidth, resolutionHeight,
  // Parameter baru (optional — default untuk backward compatibility):
  source?: 'manual' | 'auto',       // default 'manual'
  storage?: 'r2' | 'vps',           // default 'r2'
  vpsFilePath?: string | null,      // default null
})
// INSERT INTO recordings (id, meeting_id, storage_key, file_name,
//   duration_seconds, size_bytes, resolution_width, resolution_height,
//   status, expires_at, source, storage, vps_file_path)
// VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ready', ?, ?, ?, ?)
```

### 4g. Migrasi D1 Baru

```sql
-- migrations/0016_vps_recording_columns.sql

-- Kolom baru di tabel recordings
ALTER TABLE recordings ADD COLUMN source TEXT DEFAULT 'manual';
-- 'manual' = rekaman dari browser peserta (R2)
-- 'auto'   = rekaman otomatis dari VPS

ALTER TABLE recordings ADD COLUMN storage TEXT DEFAULT 'r2';
-- 'r2'  = file di Cloudflare R2
-- 'vps' = file di VPS lokal

ALTER TABLE recordings ADD COLUMN vps_file_path TEXT;
-- Path file di VPS, mis: /var/lib/meet/recordings/<meeting_id>/<job_id>.mp4

-- Kolom baru di tabel meetings
ALTER TABLE meetings ADD COLUMN vps_dispatched_at TEXT;
-- Kapan job recording terakhir dikirim ke VPS (mencegah dispatch ganda)
```

> **Catatan:** Nomor migrasi = `0016` (setelah `0015_meeting_recording_lock.sql`
> yang merupakan migrasi terakhir saat ini).

**Update `seedAdmin()` di `worker/auth.ts`:**

Tambahkan ALTER TABLE idempoten setelah baris recording_source (line ~315):

```typescript
// VPS recording columns — migration 0016
try { await db.exec("ALTER TABLE recordings ADD COLUMN source TEXT DEFAULT 'manual'"); } catch { /* ignore */ }
try { await db.exec("ALTER TABLE recordings ADD COLUMN storage TEXT DEFAULT 'r2'"); } catch { /* ignore */ }
try { await db.exec("ALTER TABLE recordings ADD COLUMN vps_file_path TEXT"); } catch { /* ignore */ }
try { await db.exec("ALTER TABLE meetings ADD COLUMN vps_dispatched_at TEXT"); } catch { /* ignore */ }
```

**Update `RecordingRow` di `worker/auth.ts`:**

```typescript
export interface RecordingRow {
  // ... field yang sudah ada ...
  source: 'manual' | 'auto';           // BARU
  storage: 'r2' | 'vps';               // BARU
  vps_file_path: string | null;        // BARU
}
```

---

## 5. Perubahan di Frontend (src/)

### 5a. Dashboard — Type Update

**File: `src/features/dashboard/types/dashboard.types.ts`**

Tambah field di interface `RecordingItem`:

```typescript
export interface RecordingItem {
  // ... field yang sudah ada ...
  source?: 'manual' | 'auto';           // BARU
  storage?: 'r2' | 'vps';               // BARU
  vps_file_path?: string | null;        // BARU
}
```

### 5b. Dashboard — RecordingCard.tsx

Tambah badge sumber recording:

```tsx
{/* Tambah setelah badge status yang sudah ada */}
{recording.source === 'auto' && (
  <span className="px-2 py-0.5 text-xs bg-blue-950 border border-blue-700
    text-blue-300 rounded font-medium">
    Otomatis
  </span>
)}
```

> **Catatan:** Play/Download URL tetap sama (`/api/recordings/:id/stream`
> dan `/api/recordings/:id/download`). Worker yang handle redirect ke VPS
> secara transparan jika `storage === 'vps'` (lihat §4e).

### 5c. Meeting.tsx — Prioritas VPS vs Browser Auto-Record

**Masalah:**
Saat ini, jika meeting memiliki `auto_record = true`, fungsi `maybeAutoRecord()`
di `Meeting.tsx` akan otomatis merekam dari browser host. Jika VPS juga dispatch
recorder, **kedua-duanya** akan mencoba klaim recording lock secara bersamaan.

Recording lock (migration 0015) **sudah mencegah konflik** — hanya satu yang
bisa klaim. Tapi prioritas siapa duluan harus jelas.

**Solusi:**
VPS dispatch selalu set `vps_dispatched_at` di database. Endpoint
`getMeetingDetail()` di `worker/handlers/meetings.ts` sudah return semua kolom
meeting termasuk kolom baru ini. Frontend tinggal cek:

```typescript
// Di Meeting.tsx — modifikasi maybeAutoRecord():
function maybeAutoRecord() {
  // ... existing checks (isHost, autoRecord enabled, dll) ...

  // BARU: Jika VPS sudah dispatch recorder untuk meeting ini,
  // browser host YIELD — biarkan VPS yang merekam.
  if (meetingDetail?.vps_dispatched_at) {
    console.log('[Recording] VPS recorder dispatched — skipping browser auto-record');
    return;
  }

  // ... existing auto-record logic (claimRecordingLock, startRecording, dll) ...
}
```

**Catatan kode yang sudah mendukung:**
- `claimRecordingLock` di `worker/handlers/meetings.ts` sudah mendukung
  `source: 'auto'` (line 99: `body.source === 'auto' ? 'auto' : 'manual'`).
- `Meeting.tsx` sudah menampilkan toast "direkam otomatis oleh sistem" ketika
  `recordingLock.source === 'auto'`.
- Tombol Start nonaktif saat ada recording lock aktif.
- Tombol Pause/Stop hanya muncul untuk operator yang merekam.

**Jadi perubahan di Meeting.tsx hanya 1:** Tambah pengecekan `vps_dispatched_at`
di `maybeAutoRecord()`.

---

## 6. Jadwal & Urutan Kerja

| Fase | Tugas | Estimasi | Prasyarat |
|------|-------|----------|-----------|
| **1. Fondasi VPS** | Install FFmpeg, Chromium, setup folder, subdomain + SSL, skeleton service + `/health` | 0.5 hari | DNS subdomain di-pointing ke VPS |
| **2. Bot Recorder** | Playwright join meeting (dengan admin cookie), page.video() capture, FFmpeg konversi, recording lock (`source: 'auto'`), heartbeat, stop logic | 1.5 – 2 hari | Fase 1 selesai |
| **3. Worker Integration** | Migrasi D1 (0016), cron dispatch per menit, endpoint callback VPS (`/api/internal/vps/*`), modifikasi `insertRecordingRow`, redirect stream/download | 0.5 – 1 hari | Fase 2 selesai |
| **4. Dashboard** | Badge "Otomatis", update tipe `RecordingItem`, `maybeAutoRecord` yield ke VPS | 0.5 hari | Fase 3 selesai |
| **5. Testing** | Semua skenario di checklist planning §9 | 0.5 – 1 hari | Fase 4 selesai |

**Total estimasi: 3.5 – 5 hari kerja**

---

## 7. Environment Variables

### VPS (.env)

```env
# Port service
PORT=4000

# Keamanan — HMAC untuk komunikasi Worker↔VPS (lihat §9a)
RECORDING_HMAC_SECRET=1dd0a3cbca73db919a2cc1f10b94ac9bb093bd3b015b77aa2e02fda76d440fb1

# Session secret — HARUS SAMA dengan SESSION_SECRET di Cloudflare Worker
# Nilai ada di file .dev.vars (development) atau Cloudflare dashboard (production)
# Digunakan untuk generate admin session cookie agar bot bisa join meeting
# (lihat §9b untuk penjelasan lengkap)
SESSION_SECRET=BzD0fiocw56htQzrkVTjgHXZMBNDT3jv6B7uZupHMnm/JrLvzcwCwJZgwk7mo1qJ

# Meet-web worker URL (untuk callback recording-completed/failed)
WORKER_URL=https://panara.<domain>.workers.dev

# Kapasitas
MAX_CONCURRENT_RECORDINGS=2
MAX_QUEUE_SIZE=5

# Recording defaults
DEFAULT_RESOLUTION=720p
DEFAULT_FPS=25
FFMPEG_PRESET=veryfast
FFMPEG_CRF=23

# Cleanup
RETENTION_HOURS=48
DISK_ALERT_THRESHOLD_PERCENT=80

# Meeting URL base (untuk bot join — domain frontend meet-web)
MEETING_BASE_URL=https://<domain-meet-web>

# Bot identity
BOT_NAME=Perekam
BOT_USER_ID=vps-recorder
```

### Cloudflare Worker (wrangler.jsonc / secrets)

```bash
# Tambahan secret:
wrangler secret put RECORDING_HMAC_SECRET   # sama dengan yang di VPS .env

# VPS_RECORDER_URL sudah di vars (bukan secret — IP publik)
# SESSION_SECRET sudah ada — nilainya sudah di-copy ke VPS .env di atas
```

---

## 8. Monitoring & Alerting

### Log Rotation

```bash
cat > /etc/logrotate.d/meet-recorder << 'EOF'
/var/log/meet-recorder/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    copytruncate
}
EOF
```

### Cron Cleanup di VPS

```bash
# /etc/cron.d/meet-recorder-cleanup
# Hapus file recording yang lebih tua dari 48 jam, setiap jam
0 * * * * root find /var/lib/meet/recordings -name "*.mp4" -mmin +2880 -delete 2>/dev/null

# Alert kalau disk > 80%
*/10 * * * * root df / | awk 'NR==2 {gsub(/%/,"",$5); if($5>80) print "DISK ALERT: "$5"% used"}' >> /var/log/meet-recorder/disk-alert.log
```

### Monitoring via Uptime Kuma (Sudah Ada di VPS)

Tambah monitor baru di Uptime Kuma (port 3001):
- **Type:** HTTP(s)
- **URL:** `http://127.0.0.1:4000/health`
- **Interval:** 60 detik
- **Alert:** Notifikasi kalau service down

---

## 9. Keamanan — Spesifikasi HMAC & Auth

### 9a. HMAC untuk Komunikasi Worker ↔ VPS

**Tujuan:** Memastikan hanya Worker yang sah yang bisa memanggil API VPS,
dan hanya VPS yang sah yang bisa callback ke Worker.

**Algoritma:** HMAC-SHA256 (sama seperti `hmacHex()` di `worker/auth.ts`)

**Format request:**

```
Header:
  X-Timestamp: <unix-seconds>         # timestamp saat request dibuat
  X-Signature: <hex HMAC-SHA256>      # signature dari payload

Payload yang di-sign:
  "<timestamp>.<JSON body>"
  Contoh: "1729555200.{\"meeting_id\":\"abc\",\"meeting_url\":\"...\"}"

Verifikasi di penerima:
  1. Parse X-Timestamp — tolak jika |now - timestamp| > 300 detik (replay protection)
  2. Reconstruct: signaturePayload = X-Timestamp + "." + rawBody
  3. Compute: expected = HMAC-SHA256(RECORDING_HMAC_SECRET, signaturePayload)
  4. Compare: timingSafeEqual(expected, X-Signature)
  5. Jika cocok → proses request. Jika tidak → 401 Unauthorized
```

**Secret:** `RECORDING_HMAC_SECRET` — shared secret yang sama di Worker dan VPS.
Ini **berbeda** dari `SESSION_SECRET`. `SESSION_SECRET` untuk auth cookie user,
`RECORDING_HMAC_SECRET` khusus untuk komunikasi machine-to-machine Worker↔VPS.

**Referensi kode:**
- `worker/auth.ts` → `hmacHex(secret, data)` — fungsi HMAC-SHA256 yang sudah ada
- `worker/auth.ts` → `timingSafeEqualHex(a, b)` — constant-time comparison
- VPS `auth.ts` harus mengimplementasi fungsi yang sama (gunakan Node.js `crypto.createHmac`)

### 9b. Bot Join Gate — Admin Session Cookie

**Masalah:**
Bot VPS harus join meeting via `POST /api/tokens` di Worker. Endpoint ini punya
beberapa "gate" yang bisa menolak peserta:

| Gate | Non-admin | Admin |
|------|-----------|-------|
| Meeting belum dimulai (scheduled_at) | ❌ Ditolak | ✅ Bypass |
| Late-join cutoff | ❌ Ditolak | ✅ Bypass |
| Kapasitas penuh (MEETING_FULL) | ❌ Ditolak | ✅ Bypass |
| Kick cooldown | ❌ Ditolak | ✅ Bypass |
| Capacity check unavailable (503) | ❌ Ditolak | ✅ Bypass |

> Ref: `worker/handlers/tokens.ts` lines 113, 119, 173, 194, 224

**Gate yang TIDAK bisa di-bypass (bahkan admin):**

| Gate | Semua role |
|------|-----------|
| Meeting deleted | ❌ Ditolak |
| Meeting ended/expired | ❌ Ditolak |
| Meeting missed (jadwal lewat, tidak pernah dimulai) | ❌ Ditolak |
| Durasi habis (expires_at) | ❌ Ditolak |
| Superadmin role | ❌ Ditolak (khusus superadmin) |

> Ref: `worker/handlers/tokens.ts` lines 32, 55, 87, 104, 141

**Solusi:**
Session cookie di meet-web bersifat **stateless** — signed HMAC, tanpa session
store di server. Artinya siapa pun yang punya `SESSION_SECRET` bisa membuat
cookie admin yang valid.

```
Format session token (dari worker/auth.ts createSessionToken):
  <base64url(JSON payload)>.<hex HMAC-SHA256 signature>

Payload:
  { userId: "vps-recorder", username: "Perekam", role: "admin", exp: <unix_seconds> }

Proses di VPS:
  1. const payload = { userId: "vps-recorder", username: "Perekam", role: "admin",
                       exp: Math.floor(Date.now()/1000) + 4*3600 };
  2. const payloadB64 = base64UrlEncode(JSON.stringify(payload));
  3. const signature = HMAC-SHA256(SESSION_SECRET, payloadB64);  // hex output
  4. const token = payloadB64 + "." + signatureHex;
  5. Set cookie: learnly_session=<token>; pada Playwright browser context

  Setelah ini, setiap request dari browser bot ke Worker akan membawa cookie
  yang dikenali sebagai admin session → semua gate yang bisa di-bypass akan lolos.
```

**Dampak:**
- Bot mendapat preset `group_call_host` (bukan `group_call_participant`)
  → ref: `tokens.ts` line 245: `if (isAdmin) presetName = 'group_call_host'`
- Bot mendapat `upload_token` (untuk upload rekaman jika diperlukan nanti)
  → ref: `tokens.ts` lines 290-301
- Bot **TIDAK** dihitung dalam kapasitas peserta
  → ref: `tokens.ts` line 224: admin bypass capacity check

**Keamanan:**
- `SESSION_SECRET` harus dijaga ketat — hanya ada di Cloudflare Worker secrets
  dan VPS `.env`
- Bot userId = `"vps-recorder"` (bukan userId admin asli)
- Cookie expiry = 4 jam (lebih dari cukup untuk 1 sesi meeting)

### 9c. Signed URL untuk Stream/Download dari VPS

**Tujuan:** Ketika user klik Play/Download di dashboard, Worker redirect ke VPS
dengan URL yang ditandatangani agar VPS bisa memverifikasi request datang dari
Worker yang sah.

**Format** (reuse pola dari `worker/lib/uploadToken.ts`):

```
<vps_file_path>.<expSeconds>.<hex HMAC-SHA256>

Contoh:
  /var/lib/meet/recordings/abc123/job456.mp4.1729558800.a1b2c3d4...

Proses pembuatan di Worker:
  1. payload = vps_file_path + "." + expSeconds
  2. signature = HMAC-SHA256(RECORDING_HMAC_SECRET, payload)
  3. token = payload + "." + signature
  4. URL = VPS_RECORDER_URL + "/api/stream/" + encodeURIComponent(filename)
         + "?sig=" + signature + "&exp=" + expSeconds + "&path=" + vps_file_path

Verifikasi di VPS:
  1. Parse query params: sig, exp, path
  2. Cek exp > now (belum expired — berlaku 1 jam)
  3. payload = path + "." + exp
  4. expected = HMAC-SHA256(RECORDING_HMAC_SECRET, payload)
  5. timingSafeEqual(expected, sig)
  6. Jika valid → serve file. Jika tidak → 403 Forbidden
```

**Referensi kode:**
- `worker/lib/uploadToken.ts` → `createHostUploadToken` dan `verifyHostUploadToken`
  menggunakan pola yang **persis sama**: `<id>.<exp>.<hmac>`

### 9d. Firewall (UFW)

```bash
# Port dasar (kalau belum):
ufw allow 80/tcp     # Nginx HTTP
ufw allow 443/tcp    # Nginx HTTPS
ufw allow 22/tcp     # SSH
ufw allow 34151/tcp  # aaPanel (sudah ada)

# Port 4000 — HANYA untuk IP Cloudflare (lihat §2 untuk detail)
# Publik TIDAK bisa akses langsung
```

### 9e. Spesifikasi FFmpeg

```bash
ffmpeg -i input.webm \
  -c:v libx264 \
  -preset veryfast \
  -crf 23 \
  -r 25 \
  -s 1280x720 \
  -c:a aac \
  -b:a 128k \
  -ac 2 \
  -movflags +faststart \
  -y \
  output.mp4
```

| Parameter | Nilai | Alasan |
|-----------|-------|--------|
| Input | WebM (dari Playwright `page.video()`) | Output native Playwright |
| Codec video | H.264 (libx264) | Universal — semua browser, player, device bisa putar |
| Preset | veryfast | Hemat CPU di VPS yang terbatas |
| CRF | 23 | Kualitas bagus, ukuran wajar |
| Frame rate | 25 fps | Sama dengan canvas recorder saat ini (`CANVAS_FPS = 25`) |
| Resolusi | 1280×720 | Default, configurable (720p / 480p) |
| Codec audio | AAC | Universal |
| Audio bitrate | 128 kbps | Sama dengan client recorder (`audioBitsPerSecond: 128_000`) |
| Channels | 2 (stereo) | Standar |
| movflags | +faststart | Metadata di awal file → bisa streaming/seek tanpa download penuh |

> **Catatan:** Input adalah WebM dari Playwright `page.video()`, bukan
> pipe:0 dari MediaRecorder. File `worker/lib/mp4.ts` **tidak ada** di repo
> dan **tidak diperlukan** — VPS menghasilkan MP4 dengan resolusi yang
> sudah diketahui (1280×720 atau 854×480), jadi tidak perlu parsing MP4.

### Estimasi Ukuran File

| Durasi | 720p | 480p |
|--------|------|------|
| 30 menit | ~75 MB | ~40 MB |
| 1 jam | ~150 MB | ~80 MB |
| 2 jam | ~300 MB | ~160 MB |
| 3 jam | ~450 MB | ~240 MB |

---

## 10. Skenario Edge Case & Mitigasi

### 10a. VPS Tidak Bisa Dihubungi Saat Dispatch

```
Skenario: Cron dispatch → POST ke VPS → timeout/error
Mitigasi:
  - vps_dispatched_at TIDAK di-set → cron retry menit berikutnya
  - Setelah 5 menit gagal terus → meeting sudah berjalan, skip dispatch
  - Log error untuk monitoring
```

### 10b. Bot Gagal Join (Meeting Ended/Deleted)

```
Skenario: VPS terima job → bot coba join → meeting sudah ended
Mitigasi:
  - POST /api/tokens return error (gate: ended/expired/deleted)
  - Bot tangkap error → callback recording-failed ke Worker
  - Job selesai, resource dilepas
```

### 10c. Host Sudah Merekam, VPS Coba Klaim

```
Skenario: Host klik "Start Recording" (manual) → VPS bot join → klaim lock
Mitigasi:
  - POST /api/meetings/:id/recording-claim return 409 LOCKED
  - Bot TIDAK merekam → tunggu lock release atau leave
  - Opsi: bot tetap di meeting (standby), mulai rekam setelah host stop
```

### 10d. VPS Crash Saat Recording — Pop-up Notifikasi ke Host

```
Skenario: Playwright/FFmpeg crash → heartbeat berhenti → stale setelah 90 detik

Yang terjadi otomatis:
  1. Lock stale setelah 90 detik (RECORDING_LOCK_STALE_SECONDS = 90)
  2. Polling 3 detik berikutnya: recording_lock.active = false
  3. Meeting.tsx deteksi: "tadi source=auto aktif, sekarang tiba-tiba mati"

Notifikasi pop-up di Meeting.tsx:
  ┌────────────────────────────────────────────────────┐
  │  ⚠️ Rekaman otomatis berhenti                     │
  │                                                    │
  │  Penyebab: Koneksi perekam VPS terputus.           │
  │  Sistem akan mencoba reconnect otomatis.           │
  │                                                    │
  │  [Rekam Manual]   [Tutup]                          │
  └────────────────────────────────────────────────────┘

  - Host bisa klik "Rekam Manual" untuk ambil alih
  - Atau tunggu — systemd restart service (10 detik),
    bot reconnect dan klaim lock lagi

Implementasi di Meeting.tsx:
  - Track state: wasAutoRecording = true (saat lock.source === 'auto')
  - Polling berikutnya: lock.active === false && wasAutoRecording
  - Tampilkan toast/modal warning
  - Reset wasAutoRecording setelah ditampilkan
```

### 10e. Disk Penuh

```
Skenario: Recording berjalan → disk < 2 GB
Mitigasi:
  - Cek disk tiap 60 detik di recorder
  - Emergency stop recording → finalize file yang ada
  - Callback recording-completed (durasi terpotong tapi file valid)
  - Alert via disk-alert.log

Notifikasi pop-up di Meeting.tsx:
  ┌────────────────────────────────────────────────────┐
  │  ⚠️ Rekaman otomatis berhenti                     │
  │                                                    │
  │  Penyebab: Penyimpanan VPS hampir penuh.           │
  │  Rekaman tersimpan sampai durasi saat ini.         │
  │                                                    │
  │  [Tutup]                                           │
  └────────────────────────────────────────────────────┘
```
```

---

## 11. Checklist Sebelum Mulai

- [x] ~~Persetujuan atasan untuk implementasi~~ → **Disetujui**
- [x] ~~Subdomain~~ → **Tidak pakai subdomain** — akses IP langsung `104.129.17.204:4000`
- [x] ~~DNS A record / SSL~~ → **Tidak diperlukan** (IP langsung, HMAC auth)
- [x] ~~Konfirmasi: VPS boleh install FFmpeg + Chromium~~ → **Boleh**
- [x] ~~Konfirmasi: disk~~ → **~45 GB tersisa** (sudah cleanup) — aman
- [x] ~~SESSION_SECRET~~ → **Ada di `.dev.vars`**
- [x] ~~Generate RECORDING_HMAC_SECRET~~ → **`1dd0a3cbca73db919a2cc1f10b94ac9bb093bd3b015b77aa2e02fda76d440fb1`**
- [x] ~~Implementasi kode Worker & Frontend~~ → **Selesai (build lolos 100%)**
- [ ] Terapkan migrasi 0016 ke D1 (`wrangler d1 migrations apply learnly-db --remote`)
- [ ] Set secret di Cloudflare Worker (`wrangler secret put RECORDING_HMAC_SECRET`)
- [ ] Buka port 4000 di firewall VPS (hanya IP Cloudflare)
- [ ] Setup service recorder di VPS (install FFmpeg, Playwright, script service, systemd)

---

## 12. Keputusan yang Sudah Ditetapkan

| Item | Keputusan |
|------|-----------|
| Akses VPS | IP langsung `http://104.129.17.204:4000` (tanpa subdomain) |
| Max concurrent recording | 2 (sisanya antrian) — test 1 dulu baru 2 |
| Retensi | 48 jam |
| Notifikasi gagal | Pop-up langsung di halaman meeting (bukan email/Telegram) |
| Disk tersedia | ~45 GB (sudah cleanup) |
| `SESSION_SECRET` | Ada di `.dev.vars` — copy ke VPS `.env` |

---

## Lampiran A — Ringkasan Masalah Kritis & Solusinya

| # | Masalah | Solusi | Referensi Kode |
|---|---------|--------|----------------|
| 1 | Bot tidak bisa join meeting — gate menolak non-admin | VPS generate admin session cookie (stateless HMAC). VPS punya `SESSION_SECRET` → buat token format `base64url(payload).hmacHex`. Cookie name: `learnly_session` | `worker/auth.ts` → `createSessionToken()` line 459 |
| 2 | Format HMAC Worker↔VPS tidak dispesifikasi | Header `X-Timestamp` + `X-Signature`, payload = `timestamp.jsonBody`, replay protection 300 detik | `worker/auth.ts` → `hmacHex()` line 504, `timingSafeEqualHex()` line 510 |
| 3 | Signed URL VPS stream/download tidak ada spec | Format `path.expSeconds.hmacHex` — reuse pola `uploadToken.ts` | `worker/lib/uploadToken.ts` → `createHostUploadToken()` line 10 |
| 4 | Race condition browser vs VPS auto-record | Cek `vps_dispatched_at` di `maybeAutoRecord()` — browser yield jika VPS sudah dispatch | `Meeting.tsx` → `maybeAutoRecord()`, `meetings.ts` → `getMeetingDetail()` |
| 5 | Nomor migrasi salah (0017, padahal terakhir 0015) | Diperbaiki → `0016_vps_recording_columns.sql` | `migrations/0015_meeting_recording_lock.sql` |
| 6 | §10 hilang (loncat dari §9 ke §11) | Ditambahkan → §10 Edge Case & Mitigasi | — |
| 7 | `worker/lib/mp4.ts` direferensi tapi tidak ada | Tidak diperlukan — VPS output MP4 dengan resolusi yang sudah diketahui | — |
