-- Batas jumlah kamera (video) aktif serentak per meeting.
--
-- meetings.max_active_cameras : berapa member yang boleh menyalakan kamera
--   pada saat bersamaan di room tersebut. default 0 = tanpa batas (perilaku lama).
--   Host menegakkan batas lewat updatePermissions (provider SDK); server hanya
--   menyimpan & mengirim batasnya lewat token meeting + daftar meeting.
--
-- Applied via: wrangler d1 migrations apply learnly-db

ALTER TABLE meetings ADD COLUMN max_active_cameras INTEGER NOT NULL DEFAULT 0;
