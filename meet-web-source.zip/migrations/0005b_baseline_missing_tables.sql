-- Pengisi agar migration chain bisa jalan dari database KOSONG.
--
-- Masalah: 0006_recording_resolution.sql melakukan ALTER TABLE recordings,
-- tetapi tidak ada migration yang pernah membuat tabel recordings (tabel itu
-- hanya dibuat saat runtime oleh worker/auth.ts seedAdmin). Begitu juga kolom
-- meetings.public_id yang dibutuhkan index unik di 0007, tidak pernah dibuat
-- oleh 0001_init.sql. Akibatnya migrasi gagal: "no such table: recordings".
--
-- Migration ini membuat fondasi yang kurang sehingga 0006 dan 0007 bisa
-- diterapkan. Ikuti asumsi rantai migrasi (0001-0005): tabel dibuat polos,
-- kolom ditambahkan oleh migrasi berikutnya lewat ALTER.
--
-- Catatan: resolution_width / resolution_height TIDAK dibuat di sini karena
-- 0006 menambahkannya via ALTER. download_count juga tidak, mengikuti 0006.

CREATE TABLE IF NOT EXISTS recordings (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL,
  provider_recording_id TEXT,
  storage_key TEXT NOT NULL,
  file_name TEXT NOT NULL,
  download_url TEXT,
  duration_seconds INTEGER,
  size_bytes INTEGER,
  status TEXT NOT NULL DEFAULT 'ready',
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_recordings_meeting_id ON recordings(meeting_id);
CREATE INDEX IF NOT EXISTS idx_recordings_expires_at ON recordings(expires_at);

-- 0007 membuat partial unique index ON meetings(public_id); kolom ini belum
-- ada sejak 0001_init.sql.
ALTER TABLE meetings ADD COLUMN public_id TEXT;
