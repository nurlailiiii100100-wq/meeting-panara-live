-- Batas terlambat join untuk meeting terjadwal.
--
-- meetings.late_join_minutes : menit setelah scheduled_at tempat member/siswa
--   masih boleh join. default 30, 0 = tanpa batas (perilaku lama).
--   Admin/tentor selalu lolos; peserta yang sudah pernah ada di room (reconnect)
--   juga lolos. issueToken menolak join dengan 403 LATE_JOIN_CLOSED.
--
-- Applied via: wrangler d1 migrations apply learnly-db

ALTER TABLE meetings ADD COLUMN late_join_minutes INTEGER NOT NULL DEFAULT 30;
