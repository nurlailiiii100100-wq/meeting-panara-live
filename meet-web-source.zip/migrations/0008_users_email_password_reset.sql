-- Login accepts username OR email, and password reset uses a one-time code
-- (OTP) delivered to the user's email via Resend.
--
-- users.email is nullable: an account without an email simply cannot use
-- "forgot password" (login by username still works).
-- The code itself is never stored in plaintext — only HMAC(email:code) —
-- so a leaked D1 dump cannot be turned into working reset codes.
--
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts also applies this idempotently via seedAdmin for safety)

ALTER TABLE users ADD COLUMN email TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email)
  WHERE email IS NOT NULL;

CREATE TABLE IF NOT EXISTS password_reset_codes (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  consumed_at DATETIME,
  created_at DATETIME NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_password_reset_codes_email
  ON password_reset_codes(email, created_at);
