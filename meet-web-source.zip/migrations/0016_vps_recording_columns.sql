-- Kolom baru di tabel recordings untuk mendukung rekaman VPS
-- source: 'manual' (browser) atau 'auto' (VPS recorder)
ALTER TABLE recordings ADD COLUMN source TEXT DEFAULT 'manual';

-- storage: 'r2' (Cloudflare R2) atau 'vps' (disk VPS lokal)  
ALTER TABLE recordings ADD COLUMN storage TEXT DEFAULT 'r2';

-- Path file di VPS, mis: /var/lib/meet/recordings/<meeting_id>/<job_id>.mp4
ALTER TABLE recordings ADD COLUMN vps_file_path TEXT;

-- Kolom baru di tabel meetings: kapan job recording terakhir dikirim ke VPS
-- Mencegah dispatch ganda oleh cron per menit
ALTER TABLE meetings ADD COLUMN vps_dispatched_at TEXT;
