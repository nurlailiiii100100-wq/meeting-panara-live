-- Global meeting link categories + app settings (logo, recording retention).
-- Also adds category_id and auto_record to meetings.
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts also applies this idempotently via seedAdmin for safety)

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name);

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE meetings ADD COLUMN category_id TEXT;
ALTER TABLE meetings ADD COLUMN auto_record INTEGER DEFAULT 0;

INSERT OR IGNORE INTO app_settings (key, value) VALUES ('recording_retention_hours', '48');