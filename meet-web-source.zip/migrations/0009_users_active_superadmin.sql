-- Phase 1 superadmin role:
-- 1) users.active — soft enable/disable akun (lebih aman daripada DELETE:
--    meetings.created_by & presets.created_by tetap menunjuk baris asli).
-- 2) Nonaktifkan akun demo dari 0001_init.sql (password hardcoded di repo).
--    Baris TIDAK dihapus — cukup tidak bisa login.
-- Role 'superadmin' tidak butuh migrasi: kolom role TEXT tanpa CHECK.
--
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts juga menerapkan ALTER + deaktivasi ini via seedAdmin)

ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1;

UPDATE users SET active = 0
WHERE active = 1
  AND (
    (id = 'usr_teacher_01' AND username = 'teacher1')
    OR (id = 'usr_student_01' AND username = 'student1')
    OR (id = 'usr_student_02' AND username = 'student2')
  );
