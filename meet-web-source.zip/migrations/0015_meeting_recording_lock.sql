-- Kunci rekaman (recording lock): SATU perekaman per sesi meeting.
-- Host/admin yang menekan Start mengklaim kunci (recording_operator_id).
-- Selama kunci dipegang, host/admin lain tidak bisa memulai rekaman, dan
-- hanya operator yang boleh pause/resume/stop.
-- recording_heartbeat_at dikirim operator tiap ~15 detik selama merekam;
-- bila denyut hilang > 90 detik (tab crash/putus), kunci dianggap kadaluarsa
-- dan host lain boleh mengambil alih — mencegah rekaman terkunci selamanya.
ALTER TABLE meetings ADD COLUMN recording_operator_id TEXT;
ALTER TABLE meetings ADD COLUMN recording_started_at TEXT;
ALTER TABLE meetings ADD COLUMN recording_heartbeat_at TEXT;
-- 'manual' (browser host/admin) | 'auto' (bot perekam VPS, fase berikutnya)
ALTER TABLE meetings ADD COLUMN recording_source TEXT;
