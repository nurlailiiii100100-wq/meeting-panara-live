-- Recording resolution displayed on the Recording page (e.g. 1280 × 720).
-- The RealtimeKit webhook payload carries no width/height, so the worker reads
-- it from the MP4 itself at webhook time; NULL means "not available yet"
-- (old recordings, expired download URL) and the UI hides the row.
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts also applies this idempotently via seedAdmin for safety)

ALTER TABLE recordings ADD COLUMN resolution_width INTEGER;
ALTER TABLE recordings ADD COLUMN resolution_height INTEGER;
