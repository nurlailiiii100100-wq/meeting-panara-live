-- Store participant name overrides so renamed names persist across sessions
CREATE TABLE IF NOT EXISTS participant_name_overrides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  meeting_id TEXT NOT NULL,
  custom_participant_id TEXT NOT NULL,
  name TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(meeting_id, custom_participant_id)
);

CREATE INDEX IF NOT EXISTS idx_pno_meeting ON participant_name_overrides(meeting_id);
