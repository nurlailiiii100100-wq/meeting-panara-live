-- Resolusi screen share per meeting.
--
-- meetings.screenshare_resolution : resolusi yang dipakai saat host/member
--   men-share layar. Pilihan hanya 2: '480p' | '720p'. default '720p'.
--   Dipilih admin saat create meeting (dropdown) atau bulk import (kolom Excel);
--   di room tidak ada pilihan — tombol Share langsung jalan pakai nilai ini.
--
-- Applied via: wrangler d1 migrations apply learnly-db

ALTER TABLE meetings ADD COLUMN screenshare_resolution TEXT NOT NULL DEFAULT '720p';
