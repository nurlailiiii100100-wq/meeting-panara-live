-- Per-meeting recording retention (each tentor has their own preference).
-- Moves recording_retention_hours from the global app_settings to the meeting row.
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts also applies this idempotently via seedAdmin for safety)

ALTER TABLE meetings ADD COLUMN recording_retention_hours INTEGER DEFAULT 48;

-- The global app_settings value is no longer read. Leave existing rows in place
-- (harmless) so this migration is safe on databases that already ran 0003.