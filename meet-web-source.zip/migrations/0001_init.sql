-- Initial schema for Learnly/Panara video conferencing app
-- Applied via: wrangler d1 migrations apply learnly-db

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member',
  name TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Meetings table
CREATE TABLE IF NOT EXISTS meetings (
  id TEXT PRIMARY KEY,
  provider_meeting_id TEXT NOT NULL,
  name TEXT NOT NULL,
  created_by TEXT NOT NULL,
  max_participants INTEGER NOT NULL DEFAULT 20,
  duration_minutes INTEGER NOT NULL DEFAULT 60,
  status TEXT NOT NULL DEFAULT 'scheduled',
  started_at DATETIME,
  expires_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_meetings_provider_id ON meetings(provider_meeting_id);
CREATE INDEX IF NOT EXISTS idx_meetings_created_by ON meetings(created_by);
CREATE INDEX IF NOT EXISTS idx_meetings_status ON meetings(status);

-- Seed data: default users (INSERT OR IGNORE to avoid overwriting existing data)
INSERT OR IGNORE INTO users (id, username, password_hash, salt, role, name) VALUES
('usr_admin_01', 'admin', 'f1e63b89a4369c63b396bb6953a8a197fcce14979ade34940ef35855f91454d0', 'admin_salt_123456', 'admin', 'Administrator Utama'),
('usr_teacher_01', 'teacher1', 'a7d4944215ce27e62af77cdde54054ce4d68bfe7b7480400fae80997ef4021b7', 'teacher_salt_123', 'admin', 'Budi Santoso (Guru)'),
('usr_student_01', 'student1', '8aad791ed868a32e5677be00bd25bbafc72b1ed2cd4f78f42f3415d1c3f56d2a', 'student_salt_123', 'member', 'Siti Rahma (Siswa)'),
('usr_student_02', 'student2', 'f6fb5f7f783339121a915de3fa2109e7f33e015a6500dafed223f4f6efe9564b', 'student_salt_456', 'member', 'Ahmad Dani (Siswa)');
