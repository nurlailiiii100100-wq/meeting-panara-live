-- Jeda (cooldown) setelah peserta dikick.
--
-- meetings.kick_cooldown_minutes : lama jeda per meeting, dalam menit.
--   default 15, 0 = tanpa jeda (bisa langsung join lagi seperti perilaku lama).
-- meeting_kicks                  : catatan kick yang masih berlaku.
--   issueToken menolak join dengan 403 KICKED_COOLDOWN selama expires_at belum lewat.
--
-- Applied via: wrangler d1 migrations apply learnly-db

ALTER TABLE meetings ADD COLUMN kick_cooldown_minutes INTEGER NOT NULL DEFAULT 15;

CREATE TABLE IF NOT EXISTS meeting_kicks (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  kicked_by TEXT,
  kicked_at DATETIME NOT NULL,
  expires_at DATETIME NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_meeting_kicks_lookup ON meeting_kicks (meeting_id, user_id, expires_at);
