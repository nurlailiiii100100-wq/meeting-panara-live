-- Screen Share Annotation permission flag (mirrors allow_member_whiteboard).
-- 1 = members may draw on the shared screen annotation canvas.
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts also applies this idempotently via seedAdmin for safety)
ALTER TABLE meetings ADD COLUMN allow_member_annotation INTEGER DEFAULT 0;
