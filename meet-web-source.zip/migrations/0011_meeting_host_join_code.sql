-- Kode host (angka) untuk elevasi tentor → host.
--
-- meetings.host_join_code : 4-10 digit. NULL = fitur nonaktif, nama yang
--   terdaftar di tabel tentors tetap langsung jadi host seperti sebelumnya.
-- Saat kolom terisi, POST /api/tokens hanya meng-elevasi nama tentor jika
-- body.hostCode cocok; selain itu peserta tetap masuk sebagai member biasa
-- dan response menyertakan host_code_error: 'required' | 'invalid' | 'locked'.
-- Percobaan salah dibatasi per meeting + IP (worker/lib/hostCode.ts).
--
-- Applied via: wrangler d1 migrations apply learnly-db

ALTER TABLE meetings ADD COLUMN host_join_code TEXT;
