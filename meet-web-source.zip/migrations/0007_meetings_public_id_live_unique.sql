-- public_id must be unique among LIVE meetings.
--
-- Legacy databases (created from 0001, which has no UNIQUE on public_id) can hold several
-- rows sharing one public_id: soft-deleted rows plus their replacement. The join lookup in
-- worker/handlers/tokens.ts used `LIMIT 1` without ordering, so it could pick a deleted row
-- and answer 404 "This meeting does not exist or has been deleted." for a meeting that is
-- actually alive.
--
-- A partial index only covers status != 'deleted', so deleted rows may keep duplicates.
-- Applied via: wrangler d1 migrations apply learnly-db
-- (worker/auth.ts also applies this idempotently via seedAdmin for safety)

CREATE UNIQUE INDEX IF NOT EXISTS idx_meetings_public_id_live
  ON meetings(public_id)
  WHERE status != 'deleted';
