# PROJECT.md

This document is the architectural and behavioral memory of this project.

AI agents MUST read this file before modifying the project.

However, when implementing a change, agents MUST verify the relevant source files if the requested behavior is not fully described here or if the implementation may have changed since this document was generated.

PROJECT.md is a guide and architectural memory, not a replacement for source-code verification.

> **Rule:** `Actual source code > PROJECT.md`. Jika ada perbedaan, source code yang benar — lalu perbarui PROJECT.md.

Generated from full audit of the repository at commit `2d5a60d` (branch `main`), September 2026.
Last updated: sinkronisasi penuh dengan kode pada commit `c52aed6` (September 2026) — meeting lifecycle contract (§40) + penghapusan host mute/lock (§16).
Last updated: hardening join gate (September 2026) — preview admin/tentor sebelum `scheduled_at` tidak memulai timer & tidak membuka gate member; capacity check fail-closed (`CAPACITY_CHECK_UNAVAILABLE`); validasi jadwal create = update.
Last updated: pembersihan schema legacy (September 2026) — tabel `mute_state` + `mute_read_tokens` di-drop dari DB (local & production) dan dihapus dari `seedAdmin`; `db.sql` di-regenerate sesuai schema produksi; `d1_migrations` tercatat `0001`–`0008` (local & remote).
Last updated: auth OTP (commit `845c0d1` + `f868999`, September 2026) — login username **atau** email (§5), reset password 3 langkah via kode 6 digit dikirim email (`/api/auth/forgot*`, §24), tabel `password_reset_codes` + kolom `users.email` (§22), dep `@ryyr/worker-mailer` (§26), env `SMTP_USER`/`SMTP_PASS` (§27).
Last updated: redesign dashboard UI (issue #52, commit `0d8ed2f`/`e6f9f00`/`fdce969`/`46a8f34`) — topbar + sidebar collapse, shared `Tooltip` portal (§2/§3), tombol toolbar icon-only, konten dashboard `max-w 1536px`, tabel meetings tanpa scroll horizontal.

---

## 1. What Is This Project

**Learnly Meet** (worker name: `panara`) — aplikasi web video conference / ruang kelas berbasis Cloudflare:

- **Guest/Member (siswa):** join meeting via Meeting ID/Code, TANPA login.
- **Admin (host/guru):** login dengan username **atau** email + password (lupa password via kode OTP email, §5b), kelola meeting & preset, kontrol peserta (kick, screen share permission), whiteboard bersama. Mic/kamera TIDAK bisa dikontrol admin dari aplikasi (host mute/lock dihapus, §16).

---

## 2. Tech Stack

| Layer | Teknologi |
|---|---|
| Frontend | React 19, TypeScript ~5.8, React Router DOM v7, Tailwind CSS v4 (via `@tailwindcss/vite`), lucide-react icons, Vite 7 |
| UI System | Custom Toast (`ToastProvider`, `useToast`), Modal, ConfirmDialog, **Tooltip (portal, `src/shared/components/Tooltip.tsx`)** (`src/shared/components/`) |
| Email | `@ryyr/worker-mailer` ^0.2.0 (SMTP Gmail :465) — template OTP reset password di `worker/lib/emailTemplate.ts` (brand, warna, copy — logo diambil dari `app_settings`) |
| Export | `write-excel-file` ^4.1.1 (dynamic import `/browser`, export .xlsx styled) |
| Import Excel | `read-excel-file` ^9.3.10 (dynamic import `/browser`, baca file .xlsx bulk import) |
| Video SDK | `@cloudflare/realtimekit-react` ^2.0.2 + `@cloudflare/realtimekit-react-ui` ^2.0.2 (RtkMeeting, registerAddons, UIConfig tree surgery) |
| Addon | `@cloudflare/realtimekit-ui-addons` ^0.0.4 (video background: blur/virtual/random) + Custom `hostBadgeAddon` |
| Backend | Cloudflare Workers — vanilla fetch handler (TIDAK pakai Hono/framework). Router `worker/index.ts` (286 baris) + handler per domain di `worker/handlers/` |
| Database | Cloudflare D1 binding `DB` (database `learnly-db`) |
| Storage | Cloudflare R2 binding `RECORDINGS_BUCKET` (bucket `meet`) |
| Auth | Cookie `learnly_session` (HMAC-SHA256 signed token), password PBKDF2-SHA256 100k iterasi |
| Build/Deploy | Vite + `@cloudflare/vite-plugin`, Wrangler 4 |

**Tidak ada:** testing framework / CI test (hanya script regression manual `scripts/test-meeting-lifecycle.mjs` — lihat §26/§28), external state management library (Redux/Zustand), CSS framework selain Tailwind, ORM (query D1 pakai prepared statements manual).

---

## 3. Project Structure (aktual)

```text
meet-web/
├── index.html                      # Vite entry HTML
├── package.json                    # name: "learnly"
├── vite.config.ts                  # plugins: react(swc) + cloudflare + tailwindcss
├── wrangler.jsonc                  # Worker "panara", D1 learnly-db, R2 meet, assets SPA, run_worker_first /api/*, crons
├── worker-configuration.d.ts       # tipe Env (cf-typegen)
├── .dev.vars.example               # ACCOUNT_ID (terisi), APP_ID, CF_API_TOKEN, R2_*
├── db.sql                          # Snapshot schema produksi (di-regenerate agar sesuai D1) — referensi manual, tidak dipakai runtime
├── migrations/
│   ├── 0001_init.sql               # Migrasi awal: users + meetings + seed users
│   ├── 0002_allow_member_annotation.sql  # Add allow_member_annotation column to meetings
│   ├── 0003_categories_settings.sql      # Add categories + app_settings + meetings.category_id/auto_record
│   ├── 0004_meeting_recording_retention.sql # Add recording_retention_hours column to meetings
│   ├── 0005_participant_name_overrides.sql # Table participant_name_overrides for persistent renames
│   ├── 0006_recording_resolution.sql # Add resolution_width/height columns to recordings
│   ├── 0007_meetings_public_id_live_unique.sql # Partial unique index: public_id among live rows
│   └── 0008_users_email_password_reset.sql # users.email + table password_reset_codes (OTP reset)
├── worker/
│   ├── index.ts   (286 ln)         # Router utama: fetch() & scheduled()
│   ├── auth.ts    (491 ln)         # PBKDF2 hash/verify, session HMAC, cookies, ensureSeeded / seedAdmin (idempotent DDL, fast-path), reset-token HMAC
│   ├── lib/
│   │   ├── emailTemplate.ts        # brand + buildResetEmail (subject/text/html OTP) — SATU-SATUNYA tempat kustomisasi email
│   │   ├── mp4.ts                  # parser box MP4 (moov→stsd) untuk membaca resolusi video recording
│   │   └── utils.ts                # json, resolveMeetingId, generatePublicId, isValidPublicId, retention helpers
│   └── handlers/
│       ├── auth.ts                 # handleLogin (username ATAU email), handleLogout, handleMe, handleForgotPassword, handleVerifyResetCode, handleResetPassword
│       ├── meetings.ts             # listMeetings, createMeeting, getMeetingDetail, updateMeeting, deleteMeeting, removeParticipant, renameParticipant, updateAnnotationPermission
│       ├── presets.ts              # listPresets, createPreset, updatePreset, deletePreset
│       ├── tentors.ts              # listTentors, createTentor, updateTentor, deleteTentor
│       ├── categories.ts           # listCategories, createCategory, updateCategory, deleteCategory
│       ├── settings.ts             # getPublicSettings, getAllSettings, updateSettings
│       ├── tokens.ts               # issueToken
│       └── recordings.ts           # handleRecordingsApi, handleScheduledCleanups
├── src/
│   ├── main.tsx                    # React entry → App
│   ├── App.tsx                     # Routes + AuthProvider + ToastProvider + useSiteLogo global sync
│   ├── index.css                   # Tailwind + util classes (tetris-grid, accent-btn)
│   ├── vite-env.d.ts               # Vite client types reference
│   ├── assets/
│   │   ├── Cloudflare_Logo.svg
│   │   └── react.svg
│   │
│   ├── shared/                     # Kode yang dipakai oleh beberapa fitur
│   │   ├── index.ts                # Barrel re-export semua shared
│   │   ├── components/             # UI primitif bersama
│   │   │   ├── index.ts
│   │   │   ├── Modal.tsx           # Generic accessible modal dialog
│   │   │   ├── ConfirmDialog.tsx   # Dialog konfirmasi destruktif (danger/info)
│   │   │   ├── Toast.tsx           # ToastProvider + rendering floating notifications
│   │   │   ├── ToastContext.ts     # Toast context definition
│   │   │   └── Tooltip.tsx         # Tooltip portal-based (arrow, fade, flip/clamp ke viewport) utk tombol icon-only
│   │   ├── hooks/
│   │   │   ├── index.ts
│   │   │   └── useToast.ts         # Hook useToast()
│   │   ├── types/
│   │   │   ├── index.ts
│   │   │   └── ui.types.ts         # ToastItem & UI types
│   │   └── utils/
│   │       ├── index.ts
│   │       ├── userId.ts           # getPersistentUserId, getActiveMeetingSession, setActiveMeetingSession, clearActiveMeetingSession
│   │       └── siteSettings.ts     # useSiteLogo — ambil {logo, title} dari /api/settings/public; title & favicon sync
│   │
│   └── features/                   # Feature-based modules (tiap folder = 1 fitur)
│       ├── auth/                   # Autentikasi & guard admin
│       │   ├── index.ts
│       │   ├── components/
│       │   │   └── AdminProtectedRoute.tsx  # Guard route admin
│       │   ├── context/
│       │   │   └── AuthContext.tsx          # user/status/login/logout/refreshAuth
│       │   └── pages/
│       │       └── AdminLogin.tsx           # Form login admin
│       │
│       ├── home/                   # Halaman join publik
│       │   ├── index.ts
│       │   └── pages/
│       │       └── Home.tsx        # Join by code + name gate (135 ln)
│       │
│       ├── meeting/                # Ruang meeting realtime
│       │   ├── index.ts
│       │   ├── components/
│       │   │   ├── Whiteboard.tsx      # Whiteboard realtime (676 ln)
│       │   │   └── AnnotationStage.tsx # Screen share annotation overlay (1303 ln)
│       │   ├── hooks/
│       │   │   └── useScreenShare.ts   # Detect screen sharer via RTK events (~105 ln)
│       │   ├── lib/
│       │   │   └── annotationProtocol.ts # Annotation types, constants, math, serialization (~427 ln)
│       │   ├── utils/
│       │   │   └── hostBadge.ts    # Web Component <meet-host-badge>, hostBadgeAddon, Shadow DOM sync
│       │   └── pages/
│       │       └── Meeting.tsx     # Ruang meeting + host controls + semua fitur (1627 ln)
│       │
│       └── dashboard/              # Admin dashboard
│           ├── index.ts
│           ├── types/
│           │   └── dashboard.types.ts  # MeetingItem, PresetItem, RecordingItem, TentorItem, CategoryItem, dll.
│           ├── components/
│           │   ├── PaginationControls.tsx  # Pagination footer reusable (meetings + presets + recordings)
│           │   └── RecordingCard.tsx       # Card rekaman (status, countdown, play, download)
│           ├── utils/
│           │   └── recordingHelpers.tsx    # formatDuration, formatFileSize, formatResolution, getRecordingCountdown, getRecordingStatusBadge, getRecordingDisplayName
│           └── pages/
│               └── AdminDashboard.tsx  # topbar + sidebar collapse, CRUD meeting+preset+tentor, kalender, inspector, recordings,
│                                       # bulk import, export excel, settings, lifecycle aksi (3713 ln)
│
├── public/learnly.svg              # Logo default
├── scripts/
│   └── test-meeting-lifecycle.mjs  # Regression join gate/lifecycle (bundle worker via esbuild, D1 in-memory, provider di-mock)
├── README.md                       # Dokumentasi singkat (fitur, stack, commands)
├── PetunjukTesting.md              # Panduan testing manual (cara kerja aplikasi + langkah QA)
├── bedah.md                        # Roadmap/riset
├── DESIGN.md                       # Palet warna (hijau/emas "panara")
└── PROJECT.md                      # Dokumentasi arsitektur ini
```

**Entry points:** frontend `src/main.tsx`; backend `worker/index.ts` (`export default { fetch, scheduled }`).

**Import convention:** fitur mengimpor shared via `'../../shared'` (atau `'../../../shared'`). Fitur TIDAK mengimpor sesama fitur. Shared TIDAK mengimpor fitur.

```text
shared/ ← features/* ← App.tsx
```

**Catatan schema:** `worker/auth.ts` → `ensureSeeded()` (sekali per isolate, hasil di-cache module-level `seedPromise`) memanggil `seedAdmin()` yang berisi `CREATE TABLE IF NOT EXISTS` untuk SEMUA tabel + kolom migrasi + backfill (users+`email`, presets, meetings, categories, app_settings, tentors, recordings, **password_reset_codes**). **Fast-path:** `schemaLooksReady()` (admin + tabel meetings/tentors/recordings ada + kolom `recordings.resolution_*` & `users.email` terbaca + tabel `password_reset_codes` ada) → skip seluruh DDL sehingga request normal tidak membayar ratusan query D1. **Bahkan di fast-path, `ensureSingleAdmin()` tetap dijalankan** (bukan DDL): merekonsiliasi SATU-satunya akun admin dari `INITIAL_ADMIN_USERNAME`/`INITIAL_ADMIN_PASSWORD` (buat/adopsi admin, kolom email disamakan, `created_by` meetings & presets dialihkan, **user lain di-DELETE**) — jadi tabel `users` praktis hanya berisi 1 baris. `participant_name_overrides` TIDAK dibuat di seedAdmin — hanya lewat `migrations/0005`. Tabel legacy `mute_state` **sudah di-drop dari DB (local & production) dan tidak lagi dibuat seedAdmin** (lihat §16). Migrasi SQL formal di `migrations/` (`0001`–`0008`) melengkapi `wrangler d1 migrations apply`; `d1_migrations` kini tercatat 0001–0008 di local **dan** remote (schema sudah di titik terbaru, sebagian lewat DDL idempoten `seedAdmin`).

---

## 4. Frontend Architecture & Routing

```text
App (AuthProvider → ToastProvider)
 ├── /              → Home           (publik)
 ├── /meeting/:id   → Meeting        (publik)
 ├── /admin/login   → AdminLogin     (publik)
 ├── /admin         → AdminDashboard (AdminProtectedRoute → wajib role admin)
 └── *              → redirect /
```

| Route | Page | Access | Fungsi |
|---|---|---|---|
| `/` | Home | Guest | Join meeting by code: pre-check jadwal/status → mint token → navigate |
| `/meeting/:id` | Meeting | Guest/Member/Admin | Ruang video (RtkMeeting) + kontrol. `:id` menerima uuid / public_id / provider id |
| `/admin/login` | AdminLogin | Guest | Login (username ATAU email) → `/admin`; link "Lupa password?" membuka wizard OTP 3 langkah (§5b) |
| `/admin` | AdminDashboard | Admin (cookie) | Kelola meeting, tentors, preset, kalender, recordings, settings |

### Ringkasan per page penting

**Home.tsx** — Input: meeting code + display name (cached `learnly:name`). Flow: pre-check `GET /api/meetings/:code` (tolak lebih dulu jika status `expired`/`ended`/`deleted`; cek jadwal HANYA jika `started_at` masih NULL — sebelum `scheduled_at` → "menunggu jadwal", lewat `scheduled_at + duration` → "sudah terlewat") → `POST /api/tokens` (preset `group_call_participant` / auto host jika nama terdaftar di tentor) → simpan token ke `sessionStorage['rtk:token:'+targetId]` → navigate `/meeting/:targetId`. Nama wajib diisi (button disabled + error jika kosong). Header memakai logo dari settings (`useSiteLogo`), fallback `/learnly.svg`.

**Meeting.tsx** — Ruang video utama. Input: `:id` dari URL. State utama: `meeting` (RTK client), `participantsList`, `expiresAt/timeLeft/isNearExpired`, `allowMemberWhiteboard`, `allowMemberAnnotation`, `resolutionPolicy`, `showHostTools/showWhiteboard`, `annotationSession`, `mediaError`, `expiryMessage`, `recordingState/recordingElapsed`, `tokenRole`, **name gate** (`showNameGate`/`gateName`), **self-rename modal** (`showSelfRenameModal`/`selfRenameName`), **admin-rename modal** (`renameMember`), **share modal** (`showShareModal`), **screenshare res otomatis** (`shareRes`, dari setting admin — tanpa pilihan di room), dan **auto-record** (`autoRecord`/`scheduledAt`). `runtimeIdRef` mengunci **uuid internal** meeting dari response pertama — semua polling/call API di room memakainya sehingga rename `public_id` oleh admin di tengah meeting tidak memutus polling (lihat §40). Mic/kamera TIDAK punya toggle custom: memakai control bar bawaan RealtimeKit (lihat §16). UI Config surgery: `stripRecordingUi` menyembunyikan toggle & indicator recording bawaan SDK untuk non-host; `hostBadgeAddon` + `startHostBadgeSync` menginjeksi badge "HOST" hijau ke video tile dan sidebar partisipan.

**AdminDashboard.tsx** — **Layout (issue #52):** `topbar` (judul halaman dari `PAGE_TITLES[viewTab]` + quick join + aksi toolbar **icon-only** ber-`Tooltip`) di atas area konten `max-w-[1536px]`, dan **sidebar kiri yang bisa dilipat** (`learnly:sidebar-collapsed` di localStorage; `w-56` ↔ `w-14`; saat collapsed tiap item jadi icon + Tooltip). Navigasi pindah dari tab horizontal ke sidebar: `upcoming | past | all | planner | presets | recordings | settings` (tiap item punya ikon + count). Tabel meetings dirapikan tanpa scroll horizontal. Semua CRUD via fetch + `credentials: 'include'`; 401 → redirect `/admin/login`. Fitur: create/edit/soft-delete meeting, copy link/ID, quick join sebagai host (`POST /api/tokens` preset `group_call_host`), inspector peserta (poll 4 dtk + kick + manage tentors), CRUD tentor per-meeting, kalender bulanan, CRUD preset, apply preset ke form create meeting, toggle `allow_member_annotation`, recording management (list/stream/download/delete, bulk select), export excel (`write-excel-file`), bulk import meetings (form manual + file Excel `.xlsx` — lihat §37b2), dan pengaturan app (logo + judul). **Modal edit tanpa dropdown status** — status diubah lewat tombol lifecycle terderive (`Mulai Sekarang` → active, `Akhiri Meeting` → ended, `Buka Kembali` → scheduled) yang PATCH `{status}` saja; form menghitung ulang validasi kapasitas (1–500), durasi (1–1440), retensi (1–720) dan konfirmasi 2-klik bila durasi baru membuat meeting aktif langsung kedaluwarsa (§40).

**AuthContext.tsx** — `status: 'loading' | 'authenticated' | 'unauthenticated'`, auto `refreshAuth()` (GET /api/auth/me) saat mount. Exposes `login/logout/refreshAuth`.

**Toast, Modal & Tooltip System (`src/shared/components/`)** — `ToastProvider` menyediakan `useToast()` (`addToast(message, type)` — success/error/info/warning) dengan animasi slide-in & auto-dismiss 4 dtk. `Modal` untuk modal wrapper accessible dan `ConfirmDialog` untuk dialog konfirmasi destruktif (delete meeting/preset/tentor/recording). `Tooltip` (issue #52) dirender lewat **portal ke `document.body`**, punya arrow, animasi fade, dan flip/clamp ke viewport (`side: top|bottom|left|right`) — dipakai untuk semua tombol icon-only (toolbar dashboard, overlay meeting, whiteboard/annotation, sidebar collapsed).

---

## 5. Authentication

**Admin login flow (aktual):**
```text
AdminLogin → POST /api/auth/login { username, password }
  → Worker: lookup users WHERE username = ? OR LOWER(email) = LOWER(?)   // boleh username ATAU email
  → verifyPassword (PBKDF2-SHA256, 100.000 iterasi, salt 16 byte hex, constant-time compare)
  → createSessionToken: base64url(JSON payload).hex(HMAC-SHA256)
    payload = { userId, username, role, exp }  // exp = now + 7 hari
  → Set-Cookie: learnly_session=...; HttpOnly; Secure (jika https); SameSite=Lax; Path=/; Max-Age=604800
  → Frontend setUser → navigate /admin
```

- **Session verification:** `getSessionFromRequest()` baca cookie → `verifySessionToken()` (HMAC constant-time + cek exp). Tidak ada session store server-side — stateless signed cookie.
- **Logout:** POST /api/auth/logout → Set-Cookie Max-Age=0 + frontend clear state.
- **Secret:** `SESSION_SECRET` (secret/`.dev.vars`). Local dev (localhost) fallback ke hardcoded dev secret. Produksi TANPA `SESSION_SECRET` → login gagal 500 `SERVER_CONFIG_ERROR`.
- **Login username ATAU email (commit `845c0d1`):** satu field "Username atau Email" di `AdminLogin.tsx`; worker memakai `WHERE username = ? OR LOWER(email) = LOWER(?)`. Pesan gagal selalu `INVALID_CREDENTIALS` generik (tidak membedakan user tidak ada / password salah).
- **Seed admin:** `ensureSeeded()` → `seedAdmin()` dipanggil tiap `fetch`, tetapi hasilnya di-cache module-level (sekali per isolate). Bila `schemaLooksReady()` → lewati DDL, tapi **`ensureSingleAdmin()` tetap jalan**: admin dibuat/diadopsi dari `INITIAL_ADMIN_USERNAME`/`INITIAL_ADMIN_PASSWORD` (default `admin`/`admin123` — ganti di produksi!), `email` disamakan (username yang mengandung `@` dijadikan email), `created_by` meetings/presets dialihkan ke admin, **user lain dihapus** → tabel `users` praktis 1 baris. Password admin TIDAK ditimpa oleh env bila akunnya sudah ada (reset password lewat wizard §5b yang mengubah `password_hash` + `salt`).
- **Guest:** tidak login sama sekali; identitas = `custom_participant_id` = `getPersistentUserId()` (UUID di localStorage `learnly:userId`).

### 5b. Password Reset via OTP Email (commit `845c0d1` + `f868999`)

Wizard 3 langkah di **`AdminLogin.tsx`** (state `view: 'login' | 'email' | 'code' | 'password' | 'done'`, link "Lupa password?"):

```text
1. email   → POST /api/auth/forgot { email }
             worker: rate-limit (cooldown 60 dtk, maks 3 kirim / 15 menit per email)
             → insert baris password_reset_codes (code_hash = HMAC-SHA256(email:code), attempts 0, expires 10 menit)
             → kirim email kalau email terdaftar (lihat anti-probing di bawah)
2. code    → POST /api/auth/forgot/verify { email, code: "123456" }
             → cocokkan HMAC (timing-safe), attempts++ (maks 5 → kode dihapus)
             → sukses: baris ditandai consumed_at + balas { reset_token, expires_in: 600 }
3. password → POST /api/auth/forgot/reset { reset_token, password, confirm }
             → verifikasi reset_token (HMAC, TTL 10 menit), password ≥ 8 char & confirm cocok
             → UPDATE users.password_hash + salt, hapus SEMUA kode reset utk email itu
```

- **Kode 6 digit** dihasilkan `crypto.getRandomValues` — **tidak pernah disimpan plaintext**, hanya `HMAC(email:code)` (dump D1 tidak bisa dipakai jadi kode kerja). Kode = `reset_token` memakai HMAC dari `SESSION_SECRET` (lihat `createResetToken`/`verifyResetToken` di `worker/auth.ts`).
- **Anti account-enumeration:** `/forgot` SELALU membalas **HTTP 200 `FORGOT_GENERIC`** = `{ success: true, message: "Jika email terdaftar, kode verifikasi sudah dikirim (berlaku 10 menit)." }` (email tak valid, tak terdaftar, cooldown, atau kuota tercapai — semua sama). Baris kode tetap dibuat untuk email yang tidak terdaftar (decoy, tanpa email dikirim) supaya langkah verify juga menjawab sama. Kode error yang membedakan hanya `EMAIL_SEND_FAILED` (502, SMTP gagal — baris kode ikut dihapus) dan `SERVER_CONFIG_ERROR` (500, `SMTP_USER`/`SMTP_PASS` belum diset).
- **Konstanta** (`worker/handlers/auth.ts`): `OTP_TTL_MS` 10 menit, `OTP_COOLDOWN_MS` 60 dtk, `OTP_WINDOW_MS` 15 menit, `OTP_MAX_SENDS_PER_WINDOW` 3, `OTP_MAX_ATTEMPTS` 5, `RESET_TOKEN_TTL_SEC` 600, `PASSWORD_MIN_LENGTH` 8.
- **Email:** kirim via `@ryyr/worker-mailer` → SMTP Gmail `smtp.gmail.com:465` (`SMTP_USER`/`SMTP_PASS` = App Password). Isi email (subjek, warna, copy, `validMinutes`) dikustom **hanya** di `worker/lib/emailTemplate.ts` (`brand` + `buildResetEmail`); logo header diambil dari `app_settings.logo` (gagal membaca logo tidak memblokir kirim).

## 6. Authorization / Roles

| Role | Sumber | Bisa |
|---|---|---|
| **Admin (Host)** | Cookie session `role: 'admin'` | Semua CRUD meeting/preset/tentors/settings, kick, join sebagai host (preset `group_call_host`), bypass jadwal & participant limit, clear whiteboard, screen share annotation host control, whiteboard/annotation permission toggle, in-meeting rename semua member, lifecycle status (mulai/akhiri/buka kembali), imun kick detection |
| **Superadmin** | Cookie session `role: 'superadmin'` (hanya dari bootstrap env `INITIAL_ADMIN_USERNAME`/`INITIAL_ADMIN_PASSWORD` — tidak bisa dibuat/diubah lewat UI) | **HANYA Kelola Admin:** `GET/POST /api/admins` + `PATCH /api/admins/:id` (lihat daftar, tambah akun admin, edit username/nama/email, aktif/nonaktif). **TIDAK punya permission operasional apa pun:** semua endpoint meeting/presets/tentors/categories/recordings/settings → 403, rename peserta → 403, dan `POST /api/tokens` → 403 (**dilarang join meeting sebagai host maupun member**). Juga tidak bisa: mengubah role siapapun, mengubah password akun mana pun (reset = urusan admin masing-masing via "Lupa password?" OTP email), menonaktifkan diri sendiri, mengubah/menonaktifkan akun superadmin lain, menghapus akun permanen (endpoint DELETE tidak ada). Tampilan: badge `SUPERADMIN`, sidebar **hanya** menu Kelola Admin (tanpa menu operasional) |
| **Tentor (Host tanpa login)** | Terdaftar di tabel `tentors` per meeting + input nama sesuai di name gate/Home | Otomatis dinaikkan ke host (`preset_name = 'group_call_host'`), bypass jadwal & limit, semua host controls di dalam room. **Occupancy check:** jika nama tentor sedang dipakai peserta aktif di room, hak host dicabut |
| **Guest/Member** | Tanpa session; custom_participant_id | Join via code (respect jadwal+kapasitas), preset `group_call_participant` (dipaksa server), toggle mic/cam/screen share sendiri lewat control bar SDK, self-rename nama sendiri via modal/in-meeting, gambar whiteboard jika `allow_member_whiteboard`, anotasi jika `allow_member_annotation` |

**Enforcement = kombinasi, backend adalah source of truth:**
- Backend (Worker): helper `isOperatorRole()` (**hanya** `role === 'admin'`) untuk semua endpoint operasional (CRUD meeting/kick/annotation-PUT/tentors/categories/presets/settings/recordings) — session `superadmin` → **403**, tanpa session → **401**; gate ketat `role === 'superadmin'` hanya untuk `/api/admins` (admin → 403); `POST /api/tokens` **menolak session `superadmin` → 403** sebelum resolusi meeting, elevasi tentor, dan sebelum UPDATE apa pun di DB; verifikasi nama tentor di D1; paksa preset participant untuk non-admin non-tentor; participant limit & jadwal dicek saat issue token.
- RealtimeKit (provider): preset menentukan capability dasar; **mikrofon/kamera dikontrol penuh oleh control bar SDK + capability preset** — aplikasi tidak lagi mem-patch permission (lihat §16).
- Frontend: sidebar/menu dibedakan per permission (admin = menu operasional + Settings; superadmin = hanya Kelola Admin), badge role `ADMIN`/`SUPERADMIN` di topbar, dan join superadmin dicegah di backend (bukan oleh UI). **React state BUKAN security** — enforcement operasional ada di backend.

---

## 7. Meeting Architecture & Join Flow

```text
User isi code di Home / Direct Link
  ↓ GET /api/meetings/:code           (pre-check jadwal/status — frontend)
  ↓ POST /api/tokens { meetingId, userId, name, presetName }
Worker issueToken:
  ↓ resolve meeting (id | public_id | provider_meeting_id, status != deleted)
  ↓ cek status deleted → 404
  ↓ status 'ended' → 403 MEETING_ENDED | status 'expired' → 403 MEETING_EXPIRED  (closed state TIDAK dihidupkan lagi oleh timer NULL)
  ↓ (Tentor Check) query tabel tentors WHERE meeting_id AND lower(name) = lower(input.name)
  ↓    jika match → isTentor=true, isAdmin=true (elevate ke host sebelum gate jadwal!)
  ↓ scheduled_at di masa depan DAN started_at masih NULL & bukan admin/tentor → 403 MEETING_NOT_STARTED
  ↓ scheduled_at + duration_minutes LEWAT DAN started_at masih NULL (slot kelas [jadwal, jadwal+durasi] belum pernah dibuka) → 403 MEETING_MISSED — semua role termasuk admin; host membuka ulang via "Buka Kembali"/"Mulai Sekarang"
  ↓ expires_at lewat → set status expired → 403 MEETING_EXPIRED
  ↓ expires_at NULL (status scheduled/active) DAN jadwal sudah tercapai (atau meeting tanpa jadwal) → set started_at=now, expires_at=now+duration_minutes, status='active'  ← timer mulai di partisipan PERTAMA; preview admin/tentor SEBELUM jadwal TIDAK memulai timer & TIDAK melepas gate member
  ↓ (Tentor occupancy check) jika isTentor tapi nama sudah online di room → cabut hak host (demote)
  ↓ (non-admin) count peserta live via RealtimeKit API, exclude preset host
  ↓    jika >= max_participants & bukan reconnecting → 403 MEETING_FULL
  ↓    jika daftar peserta provider TIDAK bisa dibaca → 503 CAPACITY_CHECK_UNAVAILABLE (fail-closed; admin tetap lolos)
  ↓ set preset_name = 'group_call_host' (admin/tentor) ATAU 'group_call_participant' (member)
  ↓ POST RealtimeKit /meetings/:providerMeetingId/participants
  ↓    { name, preset_name, custom_participant_id: userId } → auth_token
  ↓ response: auth_token, public_id, provider_meeting_id, expires_at, duration_minutes,
  ↓            host_resolution, member_resolution, max_allowed_resolution,
  ↓            allow_member_whiteboard, allow_member_annotation, user_role, auto_record,
  ↓            recording_retention_hours, scheduled_at
  ↓ Frontend simpan token ke sessionStorage → navigate /meeting/:public_id
  ↓ Meeting.tsx initMeeting({ authToken }) → RtkMeeting render + hostBadgeAddon + stripRecordingUi
```

- **Meeting creation (admin):** `POST /api/meetings` → buat meeting di RealtimeKit REST (`POST .../meetings` title=name) → dapat `provider_meeting_id` → simpan snapshot lengkap ke D1 (public_id, limits, resolutions, scheduled_at, timezone, category_id, auto_record, recording_retention_hours, status awal `'scheduled'`).
- **Status lifecycle:** `scheduled` → (partisipan pertama join **setelah `scheduled_at` tercapai** — preview admin/tentor sebelum jadwal hanya mengeluarkan token, tidak mengubah state — **atau** tombol "Mulai Sekarang") `active` → `expired` (lewat expires_at; juga auto-expire saat GET /api/meetings list) / `ended` (tombol "Akhiri Meeting" via PATCH) → `deleted` (soft-delete via DELETE; provider meeting ikut di-DELETE ke RealtimeKit). **Slot kelas:** meeting `scheduled` yang belum pernah dibuka sampai lewat `scheduled_at + duration_minutes` → auto-`expired` saat GET list (pindah ke tab Past) dan join ditolak `403 MEETING_MISSED`. **Tombol "Buka Kembali"** mengembalikan `expired`/`ended` → `scheduled` dengan timer di-reset NULL; bila `scheduled_at` sudah lewat slot, jadwal basi dibersihkan (jadi meeting instant/terbuka). Kontrak lengkap status ↔ `started_at`/`expires_at` ada di **§40**.
- **Meeting lookup:** `resolveMeetingId` / query `(id = ? OR public_id = ? OR provider_meeting_id = ?) AND status != 'deleted'` — backward compatible dengan ketiga bentuk ID.

## 8. Custom Meeting ID (public_id)

- **Validasi:** `^[a-zA-Z0-9_-]{3,50}$` → invalid → 400 `INVALID_CUSTOM_ID`.
- **Duplikat:** cek unique di antara meeting non-deleted → 409 `MEETING_ID_ALREADY_EXISTS`.
- **Auto-generate** (jika kosong): `slug(nama, max 15)-random5` (mis. `frontend-01-x7k2p`); 5 attempt cek unique, fallback `meet-` + uuid slice.
- **Backward compat:** URL `/meeting/:id` menerima public_id ATAU uuid ATAU provider id. Legacy meetings tanpa public_id di-backfill `seedAdmin` jadi `meet-<6 char id>`.
- public_id bisa diubah saat edit meeting (PATCH) dengan validasi & duplikat check sama.

## 9. Scheduler / Planner

- `meetings.scheduled_at` disimpan **UTC ISO string**; `timezone` disimpan (default `'UTC'`; frontend mengirim `Intl.DateTimeFormat().resolvedOptions().timeZone`) — timezone saat ini hanya metadata, TIDAK dipakai konversi.
- **Create (frontend):** `new Date(`${date}T${time}`)` dianggap waktu LOKAL browser → `toISOString()`. Validasi backend: tolak masa lalu (toleransi 5 menit) → 400 `PAST_SCHEDULE_DATE`.
- **Edit — FIX TIMEZONE BUG (jangan rusak):** `handleOpenEdit` menampilkan scheduled_at dalam waktu LOKAL; `handleSaveEdit` membandingkan tanggal+jam lokal dengan `editOriginalScheduledAt`. **Jika tidak berubah → kirim nilai original apa adanya** (hindari double-conversion UTC↔local yang menggeser jadwal). Jika berubah → parse lokal baru → ISO. Jangan hapus logika `origLocalMatch`.
- **Enforcement jadwal:** server (`issueToken`) + pre-check Home + cek di Meeting.tsx — non-admin ditolak sebelum scheduled_at **hanya selama `started_at` masih NULL** (begitu meeting pernah dimulai, jadwal tidak lagi menahan join; banner → redirect). **Batas akhir:** belum pernah dimulai + lewat `scheduled_at + duration` → ditolak semua role (`403 MEETING_MISSED`), status disweep jadi `expired` — slot kelas = [jadwal, jadwal+durasi].
- **Planner UI:** kalender bulanan (state `calendarDate`, `selectedCalendarDate`), meeting dipetakan per tanggal LOKAL; tab `upcoming` = scheduled_at >= now-30min dan status belum ended/expired.

## 10. Participant Limit

> **`max_participants` = TOTAL kapasitas ruangan TERMASUK HOST? TIDAK — aktual: HANYA GUEST/MEMBER.**

Implementasi aktual (`issueToken`): hitung peserta live via RealtimeKit API, `filter(p => p.preset_name !== 'group_call_host')`, bandingkan dengan `max_participants`. Jadi:
- `max_participants = 5` → **5 guest** + host (host tidak masuk hitungan).
- Cek HANYA untuk non-admin; **admin/host bypass** limit (dan bypass jadwal).
- **Fail-closed (sejak hardening join gate):** jika API provider gagal/di-luar jangkauan saat cek, kapasitas dianggap tidak terverifikasi → token peserta **ditolak** 503 `CAPACITY_CHECK_UNAVAILABLE` (admin tetap diterbitkan karena tidak dihitung terhadap limit). Jangan kembalikan ke fail-open.
- Default 20 (backend & UI), min 1 max 500.

## 11. Duration Limit

- `duration_minutes` (default 60, 1–1440).
- **Timer mulai saat partisipan PERTAMA minta token** (`expires_at` NULL → set `started_at=now`, `expires_at=now+duration`, status `active`) **atau** saat admin menekan "Mulai Sekarang" (§40).
- Source of truth: `expires_at` di D1. Worker menolak token baru jika lewat (dan set expired); status `ended`/`expired` langsung ditolak tanpa cek timer (`MEETING_ENDED`/`MEETING_EXPIRED`). Frontend Meeting.tsx poll `GET /api/meetings/:id` tiap 3 dtk (memakai `runtimeIdRef` — uuid internal, bukan `:id` URL); jika status `expired`/`ended`/`deleted` → stop recording, hapus token, `meeting.leave()`, banner, redirect. Countdown UI per detik, merah <5 menit.
- Catatan: koneksi peserta yang SUDAH di dalam room tidak diputus paksa oleh provider saat expires_at lewat — yang dicek adalah penerbitan token & polling status.

## 12. Kick Participant

- **API:** `DELETE` (atau POST) `/api/meetings/:id/participants/:participantId` — admin only. Worker resolve provider_meeting_id → **cek preset peserta via GET provider API; jika `group_call_host` → 403 "Host tidak dapat dikeluarkan"** → DELETE ke RealtimeKit REST.
- **Frontend (Meeting.tsx):** SDK kick jika tersedia (`participant.kick()`) + SELALU panggil backend (`runtimeIdRef.current || id`); lalu hapus dari list UI.
- **Deteksi sisi peserta yang di-kick:** poll `GET /api/meetings/:id` tiap 3 dtk — HANYA jika `hasJoinedRef` (sudah `roomJoined`, mencegah false positive saat load/refresh) dan role bukan admin: jika custom_participant_id/id tidak ada di daftar → leave + banner "Anda telah dikeluarkan" + redirect. Safety net tambahan: event SDK `roomLeft` (state `kicked`) & `participants.joined.on('kicked')`.
- Inspector dashboard juga bisa kick (same endpoint) dengan auto-refresh 4 dtk.

## 13. Preset System

**Table `presets`:** `id (uuid), name (UNIQUE), max_participants (default 20), duration_minutes (default 60), host_resolution ('360p'), member_resolution ('240p'), created_by, created_at, updated_at`. Seed: `pst_std` Standard Classroom (20/60/360p/240p), `pst_webinar` Large Webinar (100/90/720p/240p), `pst_workshop` Interactive Workshop (15/120/480p/360p).

**API:** `GET /api/presets` (admin) · `POST` (admin; nama unik → 409) · `PATCH /api/presets/:id` (admin) · `DELETE /api/presets/:id` (admin).

**Behavior — preset adalah TEMPLATE (copy-by-value):** `handleApplyPreset` menyalin nilai preset ke form create meeting → meeting menyimpan **snapshot** di tabel meetings. **Mengubah/menghapus preset SETELAH meeting dibuat TIDAK mengubah meeting tersebut.** Catatan: preset RealtimeKit yang sesungguhnya (`group_call_host`/`group_call_participant`) adalah preset provider yang berbeda — preset D1 hanya template policy (kapasitas/durasi/resolusi).

## 14. Video Resolution

- Field: `host_resolution` & `member_resolution` (dan sama di presets). Nilai valid: `240p|360p|480p|720p|1080p`. Default: **host `360p`, member `240p`**.
- **Token response** membawa `host_resolution`, `member_resolution`, dan `max_allowed_resolution` (dihitung server: admin→host_res, non-admin→member_res) — server-authoritative policy.
- **Enforcement aktual = CLIENT-SIDE best-effort:** Meeting.tsx memanggil `meeting.self.updateVideoConstraints({ width: {ideal: h*16/9}, height: {ideal: h} })`. Ini hanya mengatur constraint ideal kamera lokal — **BUKAN enforcement server/provider yang memaksa resolusi**. Peserta yang memodifikasi client bisa mengabaikannya. Dokumentasikan sebagai policy, bukan keamanan.
- Validasi di create/update meeting & preset (server + UI dropdown).
- **Screenshare**: field `meetings.screenshare_resolution` (migrasi `migrations/0014`, seedAdmin ALTER idempotent), nilai cuma `480p|720p`, default `720p` — dipilih admin (dropdown Add/Edit Meeting + kolom Excel `Screen Share Res`), dipakai otomatis saat share di room (lihat §18).

## 15. Whiteboard (Corat-coret)

`src/features/meeting/components/Whiteboard.tsx` — overlay fullscreen Canvas 2D, sinkron realtime via RealtimeKit **broadcastMessage** (bukan polling, bukan D1).

**Protokol pesan** (payload `Record<string, string|number|boolean>` — data kompleks dikirim sebagai JSON string; semua bawa `userId`; sender mengabaikan echo sendiri):

| Type | Payload | Arti |
|---|---|---|
| `WB_STROKE_START` | `{ userId, id, mode:'pen'\|'eraser', color, width, x, y }` | Mulai stroke (koordinat **normalized 0..1**) |
| `WB_STROKE_POINT` | `{ userId, id, points: JSON-string }` | Batch titik (flush ~33ms / 30fps untuk kurangi chatter) |
| `WB_STROKE_END` | `{ userId, id }` | Selesai stroke |
| `WB_CLEAR` | `{ userId }` | Hapus semua — **host only** |
| `WB_DELETE` | `{ userId, id }` | Hapus 1 stroke milik sendiri (eraser) |
| `WB_UNDO` | `{ userId, id }` | Undo stroke milik sendiri |
| `WB_REDO` | `{ userId, stroke: JSON-string }` | Redo (stroke ter-serialize penuh) |
| `WB_REQUEST_SYNC` | `{ userId }` | Late joiner minta state |
| `WB_SYNC` | `{ userId, strokes: JSON-string }` | **Hanya host** yang menjawab (cegah flood N×N) |
| `WB_PERMISSION_UPDATE` | `{ userId, allowMemberWhiteboard }` | Host memperbarui izin gambar → semua client sinkron state (dikirim dari `Meeting.tsx` setelah PATCH meeting) |

**Rendering:** satu rAF loop, redraw hanya saat `dirtyRef` true; eraser pakai `globalCompositeOperation='destination-out'`; koordinat normalized → tahan resize & devicePixelRatio.

**Permission:** `canDraw = isAdmin || allowMemberWhiteboard` (dari meeting record / token response). Non-draw = view-only (label kuning). Clear = host only.

**Lifecycle state:** strokes **in-memory per meeting**. Late joiner: kirim `WB_REQUEST_SYNC` 600ms setelah buka → host balas `WB_SYNC`. **Jika semua peserta keluar, state HILANG (tidak persist ke D1 — by design).**

Flow: `Participant menggambar → broadcastMessage → peserta lain terima event → render stroke`.

## 15b. Screen Share Annotation (Zoom-style)

Fitur anotasi di atas live screen share — terpisah dari Whiteboard (§15), protocol berbeda, permission terpisah.

**Komponen:**
- `src/features/meeting/components/AnnotationStage.tsx` (1303 ln) — overlay fullscreen, canvas 2D di atas video screen share
- `src/features/meeting/hooks/useScreenShare.ts` (~105 ln) — detect siapa yang screen share via RTK events
- `src/features/meeting/lib/annotationProtocol.ts` (~427 ln) — tipe, konstanta, matematika koordinat, serialisasi

**Protokol pesan** (independen dari `WB_*`, menggunakan `ANNOT_*` prefix):

| Type | Payload | Arti |
|---|---|---|
| `ANNOT_SESSION_START` | `{ userId, sessionId, sharerId }` | Host mulai session → semua client buka AnnotationStage |
| `ANNOT_SESSION_END` | `{ userId, sessionId }` | Host stop → semua client tutup AnnotationStage (screen share tetap jalan) |
| `ANNOT_STATE_REQUEST` | `{ userId }` | Late joiner minta state |
| `ANNOT_STATE_SYNC` | `{ userId, sessionId, sharerId, strokes }` | Hanya host yang jawab (cegah flood) |
| `ANNOT_STROKE_START` | `{ userId, sessionId, id, kind, color, width, size, ... }` | Mulai stroke/shape/text |
| `ANNOT_STROKE_POINT` | `{ userId, sessionId, id, points }` | Batch freehand points (~30fps) |
| `ANNOT_STROKE_END` | `{ userId, sessionId, id }` | Selesai stroke |
| `ANNOT_CLEAR` | `{ userId, sessionId }` | Hapus semua — host only |
| `ANNOT_DELETE` | `{ userId, sessionId, annotationId }` | Hapus 1 annotation (eraser) |
| `ANNOT_UNDO` | `{ userId, sessionId, annotationId }` | Undo milik sendiri |
| `ANNOT_REDO` | `{ userId, sessionId, annotation }` | Redo (full serialized annotation) |
| `ANNOT_PERMISSION_UPDATE` | `{ userId, allowMemberAnnotation }` | Host memperbarui izin anotasi → semua client sinkron state (dikirim dari `Meeting.tsx` setelah PATCH `/annotation`) |

**Tools:** pen, highlighter, line, arrow, rectangle, circle, text, eraser (touch-to-delete), undo/redo.

**Koordinat:** normalized 0..1 terhadap video frame aktual (contain-fit math) — tahan resize & perbedaan screen.

**Permission:** `canDraw = isAdmin || allowMemberAnnotation`. Field `allow_member_annotation` di meetings (kolom DB, default 0). Host toggle via `PATCH /api/meetings/:id/annotation`. Non-draw = view-only.

**Session ownership:** Host membuka session (`ANNOT_SESSION_START`), mengikat ke satu sharer. Semua peserta membuka AnnotationStage yang sama. Late joiner minta sync → host balas.

**Lifecycle:** annotations in-memory per session. Jika host keluar → session berakhir. Jika semua keluar → state hilang (tidak persist ke D1, by design).

**Perbedaan dengan Whiteboard:**
- Whiteboard = canvas kosong, semua orang menggambar di kanvas yang sama
- Annotation = overlay di atas live screen share, anotasi terikat ke frame video
- Protocol terpisah (WB_* vs ANNOT_*), permission terpisah (`allow_member_whiteboard` vs `allow_member_annotation`)

## 16. Microphone — Host Mute & Lock (FITUR DIHAPUS)

> **Status aktual:** seluruh mekanisme host mute/lock **tidak ada lagi di kode** (dihapus pada commit `5337a37`, September 2026, saat reset kontrol mic/kamera ke SDK). Bagian ini didokumentasikan sebagai riwayat + kontrak "jangan dikembalikan setengah-setengah".

**Yang dihapus (jangan ditulis ulang sepotong-sepotong):**
- Endpoint `GET`/`PUT /api/meetings/:id/mute-state` — tidak ada route di `worker/index.ts`.
- Broadcast `HOST_MUTE`, state `isHostMutedAudio/Video`, poll mute-state 2 dtk, guard pre-enable, reactive enforcement.
- `participant.disableAudio()/disableVideo()` dan `meeting.participants.updatePermissions(...)` dari sisi aplikasi.
- Tombol custom mic/cam di `Meeting.tsx` **dan** pem hapusan tombol SDK (`rtk-mic-toggle`, `rtk-camera-toggle`) — keduanya tidak ada; kini memakai control bar bawaan RealtimeKit.

**Yang sudah dihapus (legacy, tidak tersisa):** tabel `mute_state` (kolom `is_host_muted_audio`/`is_host_muted_video`) dan tabel legacy `mute_read_tokens` **sudah di-drop dari DB local & production dan tidak lagi dibuat `seedAdmin()`** (`worker/auth.ts`) — tidak ada kode yang membaca/menulis keduanya. Sisa dokumentasi di bagian ini hanya riwayat; jangan ditulis ulang.

**Perilaku saat ini:** mikrofon & kamera dikontrol penuh oleh control bar SDK + capability dari preset provider (`canProduceAudio/canProduceVideo`). Admin TIDAK bisa mematikan mic peserta lain dari aplikasi. Enforcement = provider-side capability, bukan kode aplikasi. Riwayat bug Issue #6 (unlock 2 arah) ada di §33.

## 17. Camera

- Toggle peserta: control bar bawaan RealtimeKit (`meeting.self` capability) — tidak ada tombol custom di aplikasi.
- Host control: **tidak ada** (lihat §16).
- Permission browser ditolak → event `mediaPermissionError` → banner merah 4 detik (state `mediaError`).

## 18. Screen Share

- `meeting.self.enableScreenShare()/disableScreenShare()` — **media RealtimeKit asli** (track layar didistribusikan ke peserta lain), bukan state lokal palsu.
- **Resolusi otomatis dari admin (tanpa dialog):** Klik tombol built-in `rtk-screen-share-toggle` dicegat di fase capture (`useEffect` capture listener) → `screenshareConstraints` di-set dari `meetings.screenshare_resolution` (dipilih admin di Excel kolom `Screen Share Res` / dropdown form Add-Edit Meeting, cuma `480p`|`720p`, default `720p`) lalu `enableScreenShare()` langsung. Tidak ada lagi modal pilihan resolusi di room.
- **Screenshare Constraints:** Diterapkan via class instance `ScreenshareConstraints` di passing ke RTK `initMeeting({ defaults: { mediaConfiguration: { screenshare } } })`. Karena SDK memakai Lodash merge pada non-plain objects, mutasi `screenshareConstraints.width/height` sebelum `enableScreenShare()` secara langsung memperbarui constraints `getDisplayMedia`.
- Izin: **khusus host** (admin login / tentor berkode host) — member tidak bisa share sama sekali. Tiga lapis: (1) `stripRecordingUi(cfg, ['rtk-screen-share-toggle'])` pada `buildConfig` saat `!isHost` menyembunyikan tombol kit dari control bar desktop & menu More (⋮); (2) intercept klik `rtk-screen-share-toggle` menolak non-host dengan toast "Hanya host yang dapat berbagi layar."; (3) tombol cadangan native (`shareSupport.mode === 'native'`) dan banner `ShareScreenNotice` juga digate `isHost`. Member tetap dapat **menonton** share host (dan anotasi bila `allow_member_annotation`).
- Event/state: hook `useScreenShare(meeting)` (`src/features/meeting/hooks/useScreenShare.ts`) subscribe `screenShareUpdate` pada `self` + semua `participants.joined` → daftar `sharers` & `active`. Tombol = `rtk-screen-share-toggle` bawaan SDK (dicegat untuk set resolusi otomatis lalu mulai share); overlay share aktif dirender `Meeting.tsx` (`screenShare.active`).
- **HP/tablet tidak didukung (bukan bug app):** browser mobile tidak mengekspos `navigator.mediaDevices.getDisplayMedia` (Safari iOS/iPadOS & semua browser iOS = WebKit; Chrome/Firefox Android) → RTK menyembunyikan `rtk-screen-share-toggle` (`data-hidden`). Aplikasi mendeteksi via `isScreenShareSupported()` (`src/features/meeting/utils/screenShareSupport.ts`) di komponen **`ShareScreenNotice.tsx`** → **banner amber dismissible** "Fitur Share Screen tidak didukung di browser HP/tablet — gunakan Chrome/Edge di laptop/PC…" (geser `top-28` bila ada banner error izin; hanya ditampilkan untuk host). Di layar <1080px yang support (PC jendela kecil) tombol pindah ke **menu More (⋮)** karena layout `rtk-controlbar.sm`/`.md` → `div#controlbar-mobile`.
- **Aplikasi mobile (Android native) share-nya 720p-class @15fps:** karena browser HP tidak bisa share (di atas), HP memakai app `mobile/` yang share via MediaProjection native. Tanpa pembatasan, capture memakai resolusi native layar (mis. 1080×2340 / 1440×3200 portrait) → H.264 level 5.0 yang gagal didecode decoder hardware banyak HP penerima (tile share **hitam** di HP; PC tampil karena software decoder). Dibatasi lewat patch `mobile/patches/@cloudflare+react-native-webrtc+<versi>.patch` (`ScreenCaptureController.java`: sisi terpanjang ≤1280px, rasio dipertahankan, dimensi genap, 15fps) — otomatis dipasang saat `npm install` (`postinstall` → `patch-package`). Detail: `mobile/README.md` §3.

## 18b. Host Badge & Host-Only Recording UI

- **Host Badge (`src/features/meeting/utils/hostBadge.ts`):** Web Component kustom `<meet-host-badge>` yang merender pill hijau "HOST". Didaftarkan sebagai addon `hostBadgeAddon` ke `registerAddons` RTK, menginjeksi badge ke dalam elemen `rtk-name-tag`. Fungsi `startHostBadgeSync()` menjalankan interval 500ms yang menembus Shadow DOM (`RTK-PARTICIPANT`) untuk menambahkan badge host di sidebar peserta.
- **Host-Only Recording UI (`stripRecordingUi`):** Fungsi tree-surgery pada objek `UIConfig` RTK sebelum dirender. Menghapus tag `rtk-recording-toggle` dan `rtk-recording-indicator` dari `root` config jika pengguna saat ini bukan host (`!isHost`), sehingga tombol & indikator recording hanya dapat dilihat oleh host/tentor/admin.

## 19. RealtimeKit — API/Method/Event yang BENAR-BENAR dipakai

**REST API (server→Cloudflare, di worker):**
| Call | Lokasi | Tujuan |
|---|---|---|
| `POST /accounts/:id/realtime/kit/:app/meetings` | createMeeting | Buat meeting provider |
| `DELETE /accounts/:id/realtime/kit/:app/meetings/:mid` | deleteMeeting | Invalidate provider meeting |
| `GET  .../meetings/:mid/participants` | issueToken (limit), getMeetingDetail (presence) | List peserta live |
| `POST .../meetings/:mid/participants` | issueToken | Add participant → `auth_token` (name, preset_name, custom_participant_id) |
| `GET/DELETE .../meetings/:mid/participants/:pid` | removeParticipant | Cek preset (blokir kick host) + kick |
| `PATCH .../meetings/:mid/participants/:pid` | renameParticipant | Update nama peserta (admin rename siapapun / member self-rename, simpan ke `participant_name_overrides`) |

**SDK client (frontend):**

| API | Lokasi | Siapa | Tujuan/Event terkait |
|---|---|---|---|
| `useRealtimeKitClient` → `initMeeting({ authToken, defaults })` | Meeting.tsx | semua | Inisialisasi (guard `didInitRef` per `${id}:${token}`, custom `ScreenshareConstraints`) |
| `meeting.self.enableScreenShare/disableScreenShare` | Meeting.tsx | peserta (izin) | Screen share langsung dengan resolusi setting admin (`shareRes`) |
| `meeting.self.updateVideoConstraints` | Meeting.tsx | semua | Terapkan resolution policy (best-effort) |
| `meeting.self.customParticipantId`, `roomJoined`, `screenShareEnabled` | Meeting.tsx | semua | Identitas, status masuk room, status share |
| `meeting.self.on/off: mediaPermissionError` | Meeting.tsx | semua | Banner error izin browser (mic/cam/screenshare) |
| `meeting.self.on/off: roomLeft` | Meeting.tsx | semua | Redirect; state `kicked` → banner |
| `meeting.self.on/off: screenShareUpdate` | useScreenShare.ts | semua | Update daftar sharer (juga pada `participants.joined`) |
| `meeting.participants.broadcastMessage(type, payload)` | Meeting.tsx (MEMBER_RENAME), Whiteboard.tsx, AnnotationStage.tsx | host & semua | Rename, whiteboard, anotasi, permission update (WB_/ANNOT_) |
| `meeting.participants.on/off: broadcastedMessage` | Meeting.tsx, Whiteboard.tsx, AnnotationStage.tsx | semua | Terima pesan broadcast realtime |
| `meeting.participants.joined` map: `.toArray()`, `.get(id)`, `on/off: participantJoined, participantLeft, kicked` | Meeting.tsx (kick lookup, safety net), Whiteboard.tsx (peer count), useScreenShare.ts | host/semua | Cari peserta, presence |
| `participant.kick()`, `participant.customParticipantId` | Meeting.tsx | host | Kick peserta |
| `meeting.leave()` | Meeting.tsx | semua | Keluar paksa saat expiry/kick |
| `meeting.recording.start / stop / pause / resume` + `on/off: recordingUpdate` | Meeting.tsx | host | Kontrol & render state recording |
| `registerAddons([videoBackground, hostBadgeAddon], meeting)` | Meeting.tsx | semua | Addon background blur/virtual + badge host |
| `stripRecordingUi(customConfig, tags)` | Meeting.tsx | non-host | Hapus UI recording dari peserta biasa |

**TIDAK dipakai lagi (jangan dikembalikan tanpa alasan):** `meeting.self.enableAudio/disableAudio/enableVideo/disableVideo`, event `audioUpdate`/`videoUpdate`/`mediaPermissionUpdate`, `meeting.participants.updatePermissions`, `participant.disableAudio/disableVideo` — sisa dari fitur host mute yang dihapus (§16).

**Jangan mengarang API lain** — jika butuh method/event baru, verifikasi ke docs SDK dulu.

## 20. Token System (`/api/tokens`)

- **Input:** `{ meetingId, userId, name?, presetName? }` — publik (tanpa auth), tapi role dideteksi dari cookie session.
- **Auth/role:** admin (cookie) → preset host diizinkan; non-admin **dipaksa** `group_call_participant` meski kirim preset lain.
- **Urutan pengecekan (lihat flow §7):** deleted→404, status `ended`/`expired`→403 (`MEETING_ENDED`/`MEETING_EXPIRED`), jadwal (hanya bila `started_at` NULL)→403, expiry→403 (+flip status), first-join→mulai timer **hanya bila jadwal sudah tercapai**, limit→403 `MEETING_FULL`, dan bila daftar peserta provider tidak bisa dibaca → **fail-closed** 503 `CAPACITY_CHECK_UNAVAILABLE` (non-admin).
- **Output:** `auth_token, meeting_id, public_id, provider_meeting_id, expires_at, duration_minutes, host_resolution, member_resolution, max_allowed_resolution, allow_member_whiteboard, allow_member_annotation, user_role, auto_record, recording_retention_hours, scheduled_at`.
- Frontend menyimpan `auth_token` di `sessionStorage` (lihat §21) dan Meeting.tsx auto-mint ulang jika token hilang.

## 21. Session/Storage (Browser)

| Key | Storage | Isi | Dibuat | Dibaca | Dihapus |
|---|---|---|---|---|---|
| `rtk:token:${id}` | sessionStorage | RTK auth_token | Home/AdminDashboard/Meeting setelah `/api/tokens` | Meeting.tsx saat init (fallback jika URL tanpa `?authToken=`) | saat meeting expired/ended/kicked/scheduled-block |
| `learnly:userId` | localStorage | UUID persistent (`getPersistentUserId`) | awal akses | semua join (jadi `custom_participant_id`) | tidak pernah |
| `learnly:name` | localStorage | Display name | Home | Home & Meeting | tidak pernah |
| `meeting_id` | sessionStorage | uuid meeting aktif (`setActiveMeetingSession`) | sebelum masuk room / name gate | Meeting.tsx (resume sesi, name gate) | `clearActiveMeetingSession` (leave/expired/kick) |
| `participant_id` | sessionStorage | custom participant id sesi aktif | sama | Meeting.tsx (fallback ke `learnly:userId`) | sama |
| `participant_name` | sessionStorage | nama peserta sesi aktif | sama | Meeting.tsx (name gate prefill) | sama |

`id` pada `rtk:token` = targetId = `public_id || meeting_id || code` yang diketik. Cookie `learnly_session` = HttpOnly (tidak diakses JS).

## 22. Database Schema (D1 `learnly-db`)

**users** — purpose: akun admin (praktis cuma 1 baris — `ensureSingleAdmin` menghapus user lain, §3/§5).
`id TEXT PK · username TEXT UNIQUE NOT NULL · password_hash TEXT NOT NULL · salt TEXT NOT NULL · role TEXT NOT NULL DEFAULT 'member' ('admin'|'member') · name TEXT · email TEXT (nullable) · created_at DATETIME`
Indexes: `idx_users_username`, `idx_users_role`, `idx_users_email` (UNIQUE, **partial**: hanya `WHERE email IS NOT NULL` — migrasi `0008`). Constraint: username unique. `email` dipakai utk login (opsional, case-insensitive) & reset password; tanpa email = fitur "Lupa password" tidak bisa dipakai (login username tetap jalan).

**password_reset_codes** — purpose: kode OTP sekali pakai untuk reset password. (SQL: `migrations/0008` + `seedAdmin`.)
`id TEXT PK · email TEXT NOT NULL · code_hash TEXT NOT NULL (HMAC-SHA256 dari SESSION_SECRET, BUKAN kode plaintext) · attempts INTEGER DEFAULT 0 · expires_at DATETIME NOT NULL · consumed_at DATETIME · created_at DATETIME`
Indexes: `idx_password_reset_codes_email ON (email, created_at)`. Behavior: kode kedaluwarsa dibersihkan saat `/forgot`, `attempts >= 5` → kode dihapus, `consumed_at` di-set saat verifikasi sukses, semua kode utk email ikut dihapus setelah reset berhasil (§5b).

**meetings** — purpose: metadata + policy snapshot meeting.
`id TEXT PK · public_id TEXT UNIQUE · provider_meeting_id TEXT NOT NULL · name · created_by (FK→users.id) · max_participants INT DEFAULT 20 · duration_minutes INT DEFAULT 60 · host_resolution DEFAULT '360p' · member_resolution DEFAULT '240p' · screenshare_resolution DEFAULT '720p' (migrasi `0014`) · allow_member_whiteboard INT DEFAULT 0 · allow_member_annotation INT DEFAULT 0 · category_id TEXT (FK→categories.id, nullable) · auto_record INT DEFAULT 0 · recording_retention_hours INT DEFAULT 48 · status DEFAULT 'scheduled' ('scheduled'|'active'|'ended'|'expired'|'deleted') · scheduled_at DATETIME · timezone DEFAULT 'UTC' · started_at · expires_at · created_at · updated_at`
Indexes: `idx_meetings_provider_id`, `idx_meetings_created_by`, `idx_meetings_status` (dari `migrations/0001`); `idx_meetings_public_id`, `idx_meetings_scheduled_at` (hanya ada di `db.sql`, tidak dibuat runtime). **Tidak ada index `idx_meetings_category_id`** di kode/migrasi mana pun. unique `public_id`. `recording_retention_hours` (migrasi `0004`, default 48, ditulis saat create/edit).

**tentors** — purpose: nama tentor per meeting yang diizinkan join sebagai host tanpa login. (Dibuat `seedAdmin`.)
`id TEXT PK · meeting_id TEXT NOT NULL · name TEXT NOT NULL · created_at DATETIME`
Index/Constraint: `idx_tentors_meeting_name UNIQUE (meeting_id, name)`.

**participant_name_overrides** — purpose: persistence nama peserta yang di-rename (baik oleh admin maupun self-rename). (SQL: `migrations/0005`.)
`id INTEGER PRIMARY KEY AUTOINCREMENT · meeting_id TEXT NOT NULL · custom_participant_id TEXT NOT NULL · name TEXT NOT NULL · created_at DATETIME · updated_at DATETIME`
Index/Constraint: `UNIQUE (meeting_id, custom_participant_id)`, `idx_pno_meeting ON (meeting_id)`.

**categories** — purpose: global list kategori/link (label & filter). (SQL: `migrations/0003` + seedAdmin.)
`id TEXT PK · name TEXT NOT NULL UNIQUE · created_at DATETIME`

**app_settings** — purpose: key-value settings global (logo + judul aplikasi). (SQL: `migrations/0003` + seedAdmin.)
`key TEXT PK · value TEXT NOT NULL · updated_at DATETIME`
Keys terpakai: `logo` (data URL ≤ ~700KB atau URL https://); `title` (nama aplikasi ≤ 60 char, fallback `'learnly'`).

**presets** — purpose: template policy. (Dibuat `seedAdmin`.)
`id TEXT PK · name TEXT UNIQUE · max_participants INT DEFAULT 20 · duration_minutes INT DEFAULT 60 · host_resolution DEFAULT '360p' · member_resolution DEFAULT '240p' · created_by · created_at · updated_at`

**mute_state** — purpose: **DROPPED / sudah dihapus** (sisa fitur host mute yang dihapus, §16). Tabel tidak ada lagi di DB (local & production) dan tidak dibuat `seedAdmin()`; tidak ada endpoint yang membaca/menulis.
_Struktur lama (arsip):_ `meeting_id TEXT · participant_custom_id TEXT · is_host_muted_audio INT DEFAULT 0 · is_host_muted_video INT DEFAULT 0 · updated_at` — **PK composite (meeting_id, participant_custom_id)**.

**recordings** — purpose: metadata rekaman video di R2. (Dibuat `seedAdmin`.)
`id TEXT PK · meeting_id TEXT NOT NULL · provider_recording_id TEXT · storage_key TEXT NOT NULL · file_name TEXT NOT NULL · download_url TEXT · duration_seconds INT · size_bytes INT · resolution_width INT · resolution_height INT · download_count INT DEFAULT 0 · status TEXT DEFAULT 'ready' · expires_at DATETIME NOT NULL · created_at DATETIME · updated_at DATETIME` — `resolution_*` **nullable** (ALTER idempotent di seedAdmin); NULL = belum terbaca (recordings lama / URL expired) → UI menyembunyikan baris resolusi.
Indexes: `idx_recordings_meeting_id`, `idx_recordings_expires_at`.

## 23. Database Relationships

```text
users (id)
  ├──< meetings.created_by   (FK)
  └──< presets.created_by    (referensi id)

meetings (id = canonical; public_id & provider_meeting_id = alias lookup)
  ├──< tentors.meeting_id                     (UNIQUE dengan name)
  ├──< participant_name_overrides.meeting_id  (UNIQUE dengan custom_participant_id)
  ├──< recordings.meeting_id                  (metadata file R2)
  └──> categories.id                          (FK nullable)

provider_meeting_id ──→ RealtimeKit meeting (eksternal)
custom_participant_id ──→ localStorage UUID peserta (learnly:userId)
password_reset_codes.email ──→ users.email (link by value, TANPA FK — bisa berisi decoy email tak terdaftar)
```

## 24. API Inventory

Error JSON selalu `{ error: "CODE", message: "..." }` (kecuali `/api/auth/forgot` yang sengaja membalas `{ success: true, message }` generik — §5b). Beberapa endpoint sukses membalas `{ success: true, ... }`. Semua endpoint same-origin (tidak ada CORS headers). `credentials: 'include'` di frontend.

| Method | Endpoint | Auth | Purpose / Validasi penting |
|---|---|---|---|
| POST | `/api/auth/login` | Publik | Lookup **username ATAU email**; PBKDF2 verify; Set-Cookie 7 hari; 401 INVALID_CREDENTIALS; 500 jika SESSION_SECRET hilang |
| POST | `/api/auth/logout` | Semua | Clear cookie |
| GET | `/api/auth/me` | Publik | `{authenticated, user{id,username,role,name}}`; 401 jika tidak login |
| POST | `/api/auth/forgot` | Publik | Minta kode OTP reset password dikirim ke email. **Selalu balas `FORGOT_GENERIC` yang sama** (email invalid/tidak terdaftar/cooldown/kuota) — anti account-enumeration; rate-limit: cooldown 60 dtk + maks 3 kirim / 15 menit per email; 500 `SERVER_CONFIG_ERROR` bila `SMTP_USER`/`SMTP_PASS` belum diset; 502 `EMAIL_SEND_FAILED` bila kirim gagal |
| POST | `/api/auth/forgot/verify` | Publik | `{email, code}` — cocokkan `HMAC(email:code)` (timing-safe), maks 5 attempts lalu kode dihapus → `{success, reset_token, expires_in: 600}`; 400 `CODE_INVALID` |
| POST | `/api/auth/forgot/reset` | Publik | `{reset_token, password, confirm}` — password ≥ 8 & confirm cocok → update `password_hash`+`salt`, hapus semua kode reset utk email; 400 `RESET_TOKEN_INVALID` / `PASSWORD_TOO_SHORT` / `PASSWORD_MISMATCH` |
| GET | `/api/meetings` | Admin | List non-deleted + **auto-expire** active yang lewat expires_at |
| POST | `/api/meetings` | Admin | Buat meeting provider + D1; validasi public_id/duplikat/jadwal-past/resolusi; 201 |
| GET | `/api/meetings/:id` | Publik | Detail + peserta live (dari provider) + merge name overrides. Lookup id/public_id/provider |
| PATCH | `/api/meetings/:id` | Admin | Update semua field; **kontrak lifecycle**: `status` + `started_at` + `expires_at` ditulis bersamaan (lihat §40); public_id duplikat check; validasi kapasitas 1–500 / durasi 1–1440 / retensi 1–720; **validasi jadwal sama dengan create** (`INVALID_SCHEDULE_DATE`/`PAST_SCHEDULE_DATE`; nilai jadwal yang tidak berubah dikecualikan agar meeting lewat jadwal tetap bisa diedit) |
| PATCH | `/api/meetings/:id/annotation` | Admin | Toggle `allow_member_annotation` (body: `{allow_member_annotation: boolean}`) |
| DELETE | `/api/meetings/:id` | Admin | Soft-delete + DELETE ke provider |
| DELETE/POST | `/api/meetings/:id/participants/:pid` | Admin | Kick via provider; **403 jika preset = group_call_host** |
| PATCH | `/api/meetings/:id/participants/:pid` | Admin / Member | Rename peserta. Admin dapat rename siapapun; non-admin hanya self-rename. Disimpan ke `participant_name_overrides` |
| GET | `/api/tentors?meeting_id=:id` | Admin | List nama tentor terdaftar untuk meeting |
| POST | `/api/tentors` | Admin | Tambah tentor (`{meeting_id, name}`); nama unik per meeting → 409 `TENTOR_NAME_EXISTS` |
| PATCH | `/api/tentors/:id` | Admin | Update nama tentor (`{name}`); duplikat per meeting → 409 |
| DELETE | `/api/tentors/:id` | Admin | Hapus tentor dari meeting |
| GET | `/api/presets` | Admin | List preset |
| POST | `/api/presets` | Admin | Buat; nama unik → 409 |
| PATCH | `/api/presets/:id` | Admin | Update (duplikat nama → 409) |
| DELETE | `/api/presets/:id` | Admin | Hard-delete |
| POST | `/api/tokens` | Publik (role via cookie / tentor) | Issue token — flow §7; elevasi tentor → host; 403 `MEETING_ENDED`/`MEETING_EXPIRED`/`MEETING_NOT_STARTED`/`MEETING_FULL`; 404 deleted |
| GET | `/api/categories` | Admin | List semua kategori (global) |
| POST | `/api/categories` | Admin | Buat kategori; nama unik → 409 `CATEGORY_EXISTS`; body `{name}` |
| PATCH | `/api/categories/:id` | Admin | Update kategori nama |
| DELETE | `/api/categories/:id` | Admin | Hapus kategori; meeting terkait di-set `category_id = NULL` |
| GET | `/api/settings/public` | Publik | Baca setting publik (`logo`, `title`) — dipakai frontend `useSiteLogo` |
| GET | `/api/settings` | Admin | Baca semua settings (logo + title) |
| PUT | `/api/settings` | Admin | Update settings: `{logo?, title?}`; logo data URL ≤ ~700KB → 400 `INVALID_LOGO`; title > 60 char → 400 `INVALID_TITLE` |
| GET | `/api/recordings?meeting_id=:id` | Login (admin utk list global; admin/pemilik meeting saat filter) | List recording (support filter meeting_id) |
| GET | `/api/recordings/:id/stream` | Login (admin / pembuat meeting) | Stream video MP4 langsung dari R2 (inline header, Range support, check expiry) |
| GET | `/api/recordings/:id/download` | Login (admin / pembuat meeting) | Download video MP4 dari R2 (attachment header, check expiry, increment download_count) |

**Endpoint yang TIDAK ADA** (pernah ada, dihapus — jangan didokumentasikan ulang): `GET/PUT /api/meetings/:id/mute-state`; `POST /api/recordings` (register metadata Cloud Export) dan `POST /api/webhooks/realtimekit` (webhook recording RealtimeKit) — keduanya dihapus bersama RealtimeKit Cloud Export karena rekaman sepenuhnya client-side (host mengunggah file sendiri ke `/api/recordings/upload`).

Side effects penting: issueToken bisa men-set `started_at/expires_at/status` (first join / expire) dan menolak status closed; PATCH /api/meetings menulis `status + started_at + expires_at` secara atomik (§40); GET /api/meetings bisa mass-expire; DELETE meeting menghapus meeting provider.

## 25. Error Handling

- **Format konsisten:** `{ error: "ERROR_CODE", message: "human readable" }`. Pesan umumnya Bahasa Indonesia (kick/rename/validasi), tetapi pesan dari `/api/tokens` (§7) kini berbahasa Inggris — jangan anggap semua message berbahasa Indonesia.
- Kode yang dipakai (hasil audit kode): `UNAUTHORIZED, FORBIDDEN, NOT_FOUND, INVALID_INPUT, INVALID_NAME, INVALID_CREDENTIALS, INVALID_CUSTOM_ID, INVALID_SCHEDULE_DATE, INVALID_CATEGORY, INVALID_LOGO, INVALID_TITLE, INVALID_EVENT, PAST_SCHEDULE_DATE, MEETING_NOT_FOUND, MEETING_NOT_STARTED, MEETING_ENDED, MEETING_EXPIRED, MEETING_FULL, CAPACITY_CHECK_UNAVAILABLE, MEETING_ID_ALREADY_EXISTS, MEETING_CREATE_FAILED, PARTICIPANT_REMOVE_FAILED, TOKEN_ISSUE_FAILED, PRESET_NAME_EXISTS, TENTOR_NAME_EXISTS, CATEGORY_EXISTS, RECORDING_EXPIRED, RECORDING_NOT_READY, DOWNLOAD_FAILED, PROVIDER_ERROR, SERVER_ERROR, SERVER_CONFIG_ERROR, EMAIL_SEND_FAILED, CODE_INVALID, RESET_TOKEN_INVALID, PASSWORD_TOO_SHORT, PASSWORD_MISMATCH`.
- **TIDAK ADA di kode:** `MEETING_NOT_SCHEDULED` (pernah didokumentasikan, sudah tidak dipakai).
- **Frontend:** parse `data.message || data.error`; 401 di dashboard → redirect login; alert() untuk beberapa kegagalan (kick/delete/join).
- **Limitasi:** provider fetch error di-swallow di beberapa jalur (presence, provider delete) — **tapi limit check kini fail-closed 503 `CAPACITY_CHECK_UNAVAILABLE`** (§10); tidak ada logging terstruktur selain console; rate limiting HANYA ada di alur reset OTP (cooldown + kuota per email, §5b) — login & `/api/tokens` tetap tanpa rate limiting.

## 26. Dependencies

**Core:** react ^19.1.1, react-dom ^19.1.1, react-router-dom ^7.9.5, typescript ~5.8.3, vite ^7.1.2.
**UI:** tailwindcss ^4.1.16 (+@tailwindcss/vite), lucide-react ^0.552.0.
**Export:** write-excel-file ^4.1.1 (dynamic import `/browser`, export .xlsx ringan + styling); read-excel-file ^9.3.10 (dynamic import `/browser`, bulk import .xlsx).
**Email:** @ryyr/worker-mailer ^0.2.0 (SMTP client di worker, dipakai kirim kode OTP reset password).
**Cloudflare/Video:** @cloudflare/realtimekit-react ^2.0.2, @cloudflare/realtimekit-react-ui ^2.0.2, @cloudflare/realtimekit-ui-addons ^0.0.4, wrangler ^4.42.0, @cloudflare/vite-plugin ^1.13.10.
**Dev:** @vitejs/plugin-react-swc, eslint ^9 (+typescript-eslint, react-hooks, react-refresh plugins), @types/react(-dom).
**Testing: TIDAK ADA test runner/CI test.** Yang ada hanya script regression manual `scripts/test-meeting-lifecycle.mjs` (`npm run test:lifecycle`) — menjalankan kode worker asli (di-bundle esbuild) dengan D1 in-memory & provider RealtimeKit di-mock; plus checklist manual `PetunjukTesting.md`.

## 27. Environment & Cloudflare

`wrangler.jsonc`: name `panara`; main `worker/index.ts`; assets binding `ASSETS`, SPA fallback, `run_worker_first: ["/api/*"]`; observability on; D1 binding `DB` → `learnly-db`; R2 binding `RECORDINGS_BUCKET` → bucket `meet`; Cron Trigger `0 * * * *` (setiap jam).

| Var | Jenis | Keterangan |
|---|---|---|
| `DB` | binding D1 | database learnly-db |
| `ASSETS` | binding assets | SPA static |
| `RECORDINGS_BUCKET` | binding R2 | bucket `meet` — S3 endpoint: `https://e428c402137e5081c9c30afa21c1009b.r2.cloudflarestorage.com/meet` |
| `ACCOUNT_ID` | var (plaintext di wrangler.jsonc) | Cloudflare account utk RealtimeKit REST |
| `APP_ID` | secret/vars | RealtimeKit app id |
| `CF_API_TOKEN` | secret | API token dengan izin Realtime(Kit) |
| `SESSION_SECRET` | secret | HMAC session cookie; REQUIRED di produksi |
| `INITIAL_ADMIN_USERNAME` / `INITIAL_ADMIN_PASSWORD` | secret/vars | seed admin pertama (default admin/admin123) |
| `SMTP_USER` / `SMTP_PASS` | secret (Gmail App Password) | Kirim email OTP reset password via `smtp.gmail.com:465` — wajib bila fitur "Lupa password" dipakai (§5b) |
| `R2_ACCESS_KEY_ID` / `R2_SECRET_ACCESS_KEY` / `R2_S3_ENDPOINT` | secret (di `.dev.vars.example`, TIDAK dibaca worker) | Konfigurasi S3 external storage RealtimeKit ke R2 |

Variabel yang benar-benar dibaca kode worker (`env.*`): `DB, ACCOUNT_ID, APP_ID, CF_API_TOKEN, RECORDINGS_BUCKET, SESSION_SECRET, SMTP_USER, SMTP_PASS, INITIAL_ADMIN_USERNAME, INITIAL_ADMIN_PASSWORD`.

DEV: salin `.dev.vars.example` → `.dev.vars` (contoh sudah berisi `ACCOUNT_ID`; isi `APP_ID, CF_API_TOKEN`, plus `SESSION_SECRET`, `INITIAL_ADMIN_*`). **Jangan pernah menulis nilai secret ke file mana pun di repo.**

## 28. Build & Development Commands

```bash
npm install              # install deps
npm run dev              # Vite dev server + Cloudflare plugin (worker jalan lokal, .dev.vars dipakai)
npm run lint             # eslint .
npm run test:lifecycle   # regression join gate/lifecycle (scripts/test-meeting-lifecycle.mjs, tanpa dependency tambahan)
npm run build            # tsc -b && vite build
npm run preview          # build + vite preview
npm run deploy           # build + wrangler deploy
npm run cf-typegen       # wrangler types → worker-configuration.d.ts
npm run db:migrate:local # wrangler d1 migrations apply learnly-db --local
npm run db:migrate:remote# wrangler d1 migrations apply learnly-db --remote
npx tsc -p tsconfig.app.json --noEmit    # typecheck frontend
npx tsc -p tsconfig.worker.json --noEmit # typecheck worker
```

## 29. Current Project Status

| Sprint | Scope | Status |
|---|---|---|
| Sprint 1 | Auth & role system (login admin, cookie session, guard) | **DONE** |
| Sprint 2 | Meeting management & limitation (CRUD, kick, limit, duration) | **DONE** |
| Sprint 3 | Custom Meeting ID & scheduler (public_id, jadwal, kalender, timezone fix) | **DONE** |
| Sprint 4 | Preset & video resolution (CRUD preset, policy 240p–1080p) | **DONE** |
| Sprint 5 | Camera / Mic / Screen Share / Whiteboard (host mute-lock 3 lapis, allow/unlock, whiteboard realtime, video background) | **DONE** |
| Sprint 6 | Recording (R2 storage, webhook RealtimeKit, retention expiry + cron cleanup, streaming/download with Range support, pagination/search/sort/bulk select, download tracking, AdminDashboard recording tab) | **DONE** |
| Sprint 7 | Screen Share Annotation (Zoom-style overlay, pen/shapes/text/eraser, undo/redo, host session control, allow_member_annotation toggle) | **DONE** |
| Sprint 8 | Dashboard Enhancements — global link categories + filter/assign, Export Excel (.xlsx), Settings tab (logo & judul), per-meeting recording retention, scheduled auto-record, member name gate | **DONE** |
| Sprint 9 | Admin live controls & dashboard polish — in-meeting rename member, in-meeting share link + class code (one-click copy), app title setting, pagination on Presets & Recordings tabs | **DONE** |
| Sprint 10 | Tentor system (per-meeting tentors, auto host elevation, occupancy check), persistent rename overrides (`participant_name_overrides`), host badge addon (`<meet-host-badge>`), host-only recording UI (`stripRecordingUi`), screenshare resolution dialog (480p/720p), modular UI system (Toast, Modal, ConfirmDialog) | **DONE** |
| Sprint 11 | Feature-based architecture refactor (src/features/, src/shared/; tanpa perubahan behavior) | **DONE** |
| Post-Sprint 11 | Penghapusan host mute/lock (reset mic/kamera ke control bar SDK, commit `5337a37`) · meeting lifecycle contract: tombol Mulai/Akhiri/Buka Kembali + timer `started_at`/`expires_at` atomik + `MEETING_ENDED` (commit `c52aed6`) | **DONE** |
| Post-Sprint 11 (auth) | Login username **atau** email + reset password 3 langkah via kode OTP email (`@ryyr/worker-mailer`, template `emailTemplate.ts`), single-admin enforcement `ensureSingleAdmin`, drop tabel legacy `mute_state`/`mute_read_tokens` (commits `845c0d1`, `bb61847`, `f868999`) | **DONE** |
| Post-Sprint 11 (UI #52) | Redesign dashboard: topbar + sidebar collapse (persist di localStorage), shared `Tooltip` portal, tombol icon-only, konten 1536px, tabel meetings tanpa scroll horizontal, tooltip via body portal (commits `0d8ed2f`, `e6f9f00`, `fdce969`, `46a8f34`) | **DONE** |
| Post-Sprint 11 (join gate) | Hardening join gate: preview admin/tentor sebelum jadwal tidak memulai timer/gate, validasi jadwal saat PATCH = create, capacity check **fail-closed** `CAPACITY_CHECK_UNAVAILABLE`, script regression `npm run test:lifecycle` + `PetunjukTesting.md` | **DONE** |

## 30. Known Limitations

1. **Tidak ada host mute/lock** — mic/kamera dikontrol penuh oleh control bar SDK + capability preset; aplikasi tidak punya API untuk mematikan media peserta lain (fitur lama dihapus, §16). Tabel `mute_state` legacy sudah di-drop dari DB dan dihapus dari `seedAdmin`.
2. **Whiteboard tidak persistent** — strokes in-memory; state hilang jika semua peserta keluar (by design, tidak ke D1).
3. **Resolution hanya client-side policy** — `updateVideoConstraints` ideal, bukan enforcement server.
4. **Participant limit kini fail-closed** — provider check gagal → peserta **ditolak** 503 `CAPACITY_CHECK_UNAVAILABLE` (kebalikan dari perilaku lama; admin tetap lolos). Trade-off: gangguan sesaat di API RealtimeKit membuat member tidak bisa join, tapi kapasitas tidak pernah terlewat.
5. **Duration tidak memutus koneksi di dalam room** — hanya blok token baru (`MEETING_ENDED`/`MEETING_EXPIRED`) + polling status client; admin harus menekan "Akhiri Meeting" untuk menutup room.
6. **Tidak ada automated test suite** (unit/integration/e2e/CI tetap tidak ada) — yang ada hanya `scripts/test-meeting-lifecycle.mjs` (`npm run test:lifecycle`, satu berkas, D1 in-memory + provider mock) dan checklist manual `PetunjukTesting.md`.
7. **Tidak ada rate limiting / brute-force protection** pada login & `/api/tokens`; alur reset OTP punya cooldown 60 dtk + maks 3 kirim/15 menit + 5 attempts kode, tapi jumlah percobaan login tidak dibatasi.
8. **Kick detection via polling 3 dtk** — peserta yang di-kick bisa tetap terlihat sampai ±3 dtk (SDK event sebagai safety net).
9. **Chunk utama ~2.7 MB** (gzip ~711 kB) — belum code-splitting (kecuali addon background & export excel yang sudah dynamic import).
10. **Timezone hanya metadata** — konversi tampilan memakai browser local; backend membandingkan UTC murni.
11. **`seedAdmin` masih membawa seluruh DDL**, tetapi kini fast-path `schemaLooksReady()` + cache sekali per isolate — request normal hanya bayar query probe (tabel + kolom `resolution_*`/`email` + `password_reset_codes`), bukan DDL penuh. **Catatan:** `ensureSingleAdmin()` tetap dijalankan walau fast-path (beberapa SELECT/UPDATE/DELETE per isolate) — jangan mengasumsikan "nol query" setelah probe.
12. **`migrations/0001_init.sql` berisi hash+salt seed hardcoded** (user legacy) — baris-baris itu ikut terhapus oleh `ensureSingleAdmin()` saat runtime; tetap ganti password default `admin/admin123` di produksi.
13. **`db.sql` snapshot manual, bukan sumber DDL runtime** — hasil regenerate agar sesuai schema production, tetap tidak dijalankan otomatis; bisa usang lagi bila tidak ikut diregenerasi. DDL yang benar-benar jalan = `migrations/` + `seedAdmin` (deskripsi schema: §22).

## 31. Deferred Technical Debt

| ID | Issue | Reason deferred | When to address |
|---|---|---|---|
| H1 | Rate limiting login/tokens | Belum ada kasus abuse; sprint fokus fitur | Sebelum produksi publik |
| H2 | `seedAdmin` DDL dipindah ke migrasi saja (kini sudah fast-path + cache per isolate) | Sudah cukup murah; refactor menyentuh auth kritis | Saat ada downtime window / v2 |
| H3 | Perluas test suite (kini baru 1 script `test:lifecycle.mjs` untuk join gate/lifecycle; handler CRUD lain belum teruji) | Fitur masih bergerak cepat; script pertama baru dibuat | Setelah Sprint 5 stabil |
| M1 | Code-splitting bundle 2.7 MB | Belum ada keluhan perf nyata | Saat metrik page-load jadi masalah |
| M2 | Clock skew: auto-expire & countdown memakai jam masing-masing pihak | Selisih umumnya kecil | Jika laporan jadwal meleset |
| M4 | Moderator role (selain admin/member) belum ada | Tidak diminta | Roadmap |
| L1 | `console.error/warn` di worker tanpa struktur | Cukup untuk dev | Saat pasang logging service |
| L2 | README.md outdated (API list & struktur lama) | Dokumen baru PROJECT.md menggantikan | Sekali pass docs |
| L3 | Kalender planner tidak menampilkan timezone label | Minor UX | Bersama M2 |
| M5 | `AdminDashboard.tsx` masih monolith 3713 ln | State interleaved; prop drilling masif jika dipecah sekarang | Jika perlu split menjadi fitur sub-views terpisah |
| M6 | Tabel legacy `mute_state` + `db.sql` usang | **DONE** — `mute_state` + `mute_read_tokens` di-drop (local & production), dihapus dari `seedAdmin`; `db.sql` diregenerasi sesuai schema produksi | Selesai (September 2026) |

## 32. Development Rules

1. **Jangan merusak sprint yang sudah selesai** (§29). Baca §33 bug history sebelum menyentuh area terkait.
2. **Inspect existing implementation sebelum coding** — PROJECT.md adalah peta, bukan pengganti baca kode yang akan diubah.
3. **Jangan mengarang RealtimeKit API.** Hanya pakai yang ada di §19; verifikasi docs untuk yang baru.
4. **Backend authorization adalah source of truth.** Setiap endpoint baru wajib cek session di server.
5. **Jangan gunakan React state sebagai security** — state frontend hanya UX.
6. **Jangan mengubah schema DB tanpa kebutuhan**; jika perlu, tambahkan ALTER idempotent di `seedAdmin` + file migrasi.
7. **Jangan menyimpan secret di repository** (password, token, API key).
8. **Jangan hapus backward compatibility** lookup 3-bentuk ID (id/public_id/provider_meeting_id) tanpa rencana migrasi.
9. **Jangan refactor besar untuk bug kecil.**
10. **Setelah perubahan: jalankan typecheck (app+worker), lint, dan build** — semua harus lulus (standar saat ini: 0 error).
11. **Dokumentasikan limitation provider** di §30 jika menemukan perilaku SDK baru.
12. **Jangan ubah deferred debt (§31) kecuali menjadi blocker.**
13. **Host mute/lock sudah dihapus** (§16) — jangan menambah kembali endpoint `/mute-state`, broadcast `HOST_MUTE`, atau `updatePermissions` tanpa desain penuh + dokumentasi §16/§19 yang ikut diperbarui.
14. **UI text boleh campur EN/ID** (konvensi saat ini); comment kode Bahasa Inggris.
15. **Kontrak lifecycle meeting (§40):** `status`, `started_at`, `expires_at` WAJIB ditulis bersamaan dan tidak boleh saling bertentangan; jangan menambah jalur UPDATE yang hanya mengubah satu dari ketiganya.
16. **`/api/auth/forgot` harus tetap membalas generik** (`FORGOT_GENERIC`) untuk semua kasus kecuali gagal kirim/SMTP — jangan menambah balasan yang membedakan email terdaftar/tidak (anti account-enumeration, §5b).
17. **Capacity check wajib fail-closed** — jangan kembalikan `issueToken` ke fail-open; provider yang tidak bisa ditanya = kapasitas tidak terverifikasi = tolak non-admin (§10).
18. **Satu-satunya tempat kustomisasi email OTP** adalah `worker/lib/emailTemplate.ts` (`brand` + `buildResetEmail`); jangan menyisipkan HTML email di handler.

## 33. Important Bug Fix History

### Timezone Bug (Scheduler edit)
- **Masalah:** mengedit meeting tanpa mengubah jadwal menggeser waktu (double conversion UTC↔local) karena `new Date(iso)` → lokal → ISO menggeser jam.
- **Solusi:** `editOriginalScheduledAt` disimpan saat buka modal edit; saat save, jika tanggal+jam LOKAL identik dengan original → kirim original apa adanya. File: `AdminDashboard.tsx` (`handleOpenEdit`, `handleSaveEdit`).
- **Jangan rusak:** logika `origLocalMatch`; tampilan edit HARUS tetap lokal; kirim ISO hanya saat user benar-benar mengubah.

### Participant Limit
- **Behavior:** `max_participants` menghitung **guest saja** (exclude preset host); admin bypass; cek di `issueToken` (server-side via provider API), **fail-closed** (503 `CAPACITY_CHECK_UNAVAILABLE` bila provider tidak bisa ditanya — lihat §10).
- **Jangan rusak:** filter `preset_name !== 'group_call_host'`, bypass admin, dan cabang fail-closed (jangan dikembalikan ke fail-open).

### Participant Inspector Auto Refresh
- `useEffect` pada `inspectMeeting`: fetch langsung + `setInterval` 4000ms, cleanup `clearInterval` + flag `cancelled` (hindari setState setelah unmount/switch). Dependency array hanya `[inspectMeeting]`.

### Custom Meeting ID
- Optional (auto-generate jika kosong); edit diperbolehkan via PATCH dengan validasi regex 3–50 & duplikat; URL & semua lookup menerima 3 bentuk ID; legacy backfill `meet-<6char>`.

### Sprint 5 Media Control (Issue #6 — Admin Mute Peserta) — **FITUR SUDAH DIHAPUS**
- **Bug lama:** admin tidak bisa enable kembali mic/kamera peserta; peserta bisa unmute sendiri saat terkunci.
- **Fix (kala itu):** lock 3 lapis + unlock 2 arah + mute-state delta merge + tombol SDK dihapus dari UI peserta. Commit `cf1e280`, `6d4ae5d`.
- **Status sekarang:** seluruh fitur dihapus pada commit `5337a37` — lihat §16. Riwayat di atas hanya konteks; JANGAN mencoba "memulihkan" sebagian (endpoint, tabel `mute_state` — yang kini sudah di-drop dari DB & seedAdmin, atau broadcast) tanpa desain ulang penuh.

### Kick False Positive
- **Bug lama:** peserta baru dianggap di-kick saat halaman load.
- **Fix:** guard `hasJoinedRef` (deteksi hanya setelah `roomJoined`). Commit `6d4ae5d`.

### Duplicate public_id → join balas 404 "meeting does not exist" (28 Sep)
- **Bug:** klik meeting di dashboard → `/meeting/:public_id` → `POST /api/tokens` membalas **404 "This meeting does not exist or has been deleted."** padahal meeting-nya aktif.
- **Penyebab:** skema produksi berasal dari `0001_init.sql` yang **tidak punya UNIQUE** pada `public_id` (CREATE TABLE di `seedAdmin` dilewati fast-path karena tabel sudah ada). Cek duplikat di kode hanya mengebar baris `status != 'deleted'`, jadi setelah meeting lama di-soft-delete `public_id` yang sama bisa dipakai ulang → dobel (contoh: `class-gh843` = deleted, deleted, scheduled). Lookup `WHERE (id=? OR public_id=? OR provider_meeting_id=?) LIMIT 1` **tanpa ORDER BY** lalu mengambil baris `deleted` → masuk cabang 404.
- **Fix:** `tokens.ts` + `removeParticipant`/`renameParticipant` (`meetings.ts`) kini `ORDER BY CASE WHEN status = 'deleted' THEN 1 ELSE 0 END, updated_at DESC LIMIT 1` — baris hidup selalu menang, baris deleted hanya terpilih kalau memang tidak ada hidup. Pencegah: `migrations/0007_meetings_public_id_live_unique.sql` = partial unique index `ON meetings(public_id) WHERE status != 'deleted'` (baris deleted tetap boleh dobel).
- **Jangan rusak:** jangan kembalikan `LIMIT 1` polos; jangan hapus cabang `status === 'deleted'` di `tokens.ts` (dipakai untuk 404 yang benar).

### Duplicate isAdmin (build error)
- Deklarasi ganda di Meeting.tsx — sudah dihapus (`02022e9`). Pola: satu `const isAdmin = user?.role === 'admin'`.

## 34. PROJECT.md Maintenance

Perbarui PROJECT.md setiap ada perubahan besar pada: architecture, database schema, API, authentication, meeting flow, lifecycle status/timer (§40), RealtimeKit usage (§19), permission behavior, atau feature behavior. Tidak perlu update untuk typo/patch kecil yang tidak mengubah behavior. Selalu sebutkan commit/periode audit terakhir di bagian atas.

## 35. Quick Project Map

```text
Frontend
├── src/main.tsx                     # entry
├── src/App.tsx                      # routing + AuthProvider + ToastProvider + useSiteLogo
├── src/shared/                      # kode bersama antar fitur
│   ├── components/                  # Modal, ConfirmDialog, Toast, ToastContext, Tooltip (portal)
│   ├── hooks/                       # useToast
│   ├── types/                       # ui.types (ToastItem)
│   └── utils/                       # userId, siteSettings
├── src/features/
│   ├── auth/
│   │   ├── context/AuthContext.tsx  # user/status/login/logout
│   │   ├── components/AdminProtectedRoute.tsx
│   │   └── pages/AdminLogin.tsx     # login (username ATAU email) + wizard reset OTP 3 langkah
│   ├── home/
│   │   └── pages/Home.tsx           # join publik + name input
│   ├── meeting/
│   │   ├── pages/Meeting.tsx        # ruang meeting + kick/rename + name gate + self-rename + tentor host + host badge + screenshare res (tanpa mute/lock)
│   │   ├── components/Whiteboard.tsx
│   │   ├── components/AnnotationStage.tsx
│   │   ├── hooks/useScreenShare.ts
│   │   ├── lib/annotationProtocol.ts
│   │   └── utils/hostBadge.ts
│   └── dashboard/
│       ├── pages/AdminDashboard.tsx # topbar + sidebar collapse, CRUD meeting+preset+tentor + kalender + inspector + recordings + bulk import + export excel + settings
│       ├── components/PaginationControls.tsx
│       ├── components/RecordingCard.tsx
│       ├── types/dashboard.types.ts
│       └── utils/recordingHelpers.tsx

Backend
├── worker/index.ts                  # router: fetch() & scheduled()
├── worker/auth.ts                   # PBKDF2, session HMAC, ensureSeeded/seedAdmin/schema, ensureSingleAdmin, reset-token HMAC
├── worker/lib/emailTemplate.ts      # brand + buildResetEmail (kustomisasi email OTP)
├── worker/lib/utils.ts              # json, resolveMeetingId, retention helpers
└── worker/handlers/
    ├── auth.ts                      # handleLogin (username/email), handleLogout, handleMe, handleForgotPassword/Verify/Reset (§5b)
    ├── meetings.ts                  # CRUD meeting, participants, annotation, lifecycle status/timer (§40)
    ├── presets.ts                   # CRUD preset
    ├── tentors.ts                   # CRUD tentor
    ├── categories.ts                # CRUD category
    ├── settings.ts                  # settings
    ├── tokens.ts                    # issueToken
    └── recordings.ts                # recordings API + webhooks + cron

Database
├── db.sql                           # Snapshot schema produksi (di-regenerate agar sesuai D1) — referensi manual, tidak dipakai runtime
├── migrations/0001_init.sql         # users + meetings (+ seed legacy)
├── migrations/0002_allow_member_annotation.sql  # allow_member_annotation column
├── migrations/0003_categories_settings.sql      # categories + app_settings
├── migrations/0004_meeting_recording_retention.sql # recording_retention_hours column
├── migrations/0005_participant_name_overrides.sql  # participant_name_overrides table
├── migrations/0006_recording_resolution.sql  # resolution_width/height columns
├── migrations/0007_meetings_public_id_live_unique.sql  # unique public_id (live rows only)
├── migrations/0008_users_email_password_reset.sql  # users.email + password_reset_codes (OTP reset)
└── worker/auth.ts seedAdmin()       # full schema idempotent (fast-path) + presets + tentors + recordings + backfill

Configuration
├── wrangler.jsonc                   # worker panara + D1 + R2 + assets SPA + cron
├── vite.config.ts                   # react(swc) + cloudflare + tailwind
├── tsconfig.json / tsconfig.app / tsconfig.worker / tsconfig.node
├── eslint.config.js
└── .dev.vars.example                # ACCOUNT_ID (terisi) / APP_ID / CF_API_TOKEN / R2_* / SMTP_USER / SMTP_PASS

Testing
├── scripts/test-meeting-lifecycle.mjs  # `npm run test:lifecycle` — bundle worker via esbuild, D1 in-memory, provider mock
└── PetunjukTesting.md               # panduan testing manual (cara kerja aplikasi + langkah QA)

Dokumentasi lain
├── README.md                        # ringkasan singkat (fitur, stack, commands)
├── bedah.md                         # roadmap riset (iframe, rekaman R2, dsb)
├── DESIGN.md                        # palet warna
└── PROJECT.md                       # dokumentasi arsitektur ini
```

---

## 36. Recording Architecture & Audit Notes

> **Arsitektur final: rekaman sepenuhnya CLIENT-SIDE, biaya $0.**
> Jalur Cloud Recording RealtimeKit (Cloud Export, $0.010/menit) yang pernah
> di-audit untuk Sprint 6 **tidak dipakai**. Yang tersisa dari jalur itu sudah
> dihapus: tombol rekam bawaan kit disembunyikan untuk SEMUA role,
> `meeting.recording.*` tidak pernah dipanggil, dan endpoint/ritel pendukungnya
> (`POST /api/recordings`, `POST /api/webhooks/realtimekit`,
> `worker/lib/mp4.ts`, `probeRecordingResolution()`, kolom
> `provider_recording_id`/`download_url`) dibuang.

1. **Pipeline rekaman (client-side)**:
   - **Web** (`useClientRecorder.ts`): `getDisplayMedia` → mixing `AudioContext`
     (mikrofon host + audio track semua peserta dari room) → `MediaRecorder`
     (VP9/VP8 + Opus, chunk tiap 2 detik) → unggah `POST /api/recordings/upload`.
     Bila unggah/tab ditutup gagal, file disimpan lokal di browser (fallback).
   - **Android** (`ScreenRecordService.kt`): `MediaProjection` → `MediaCodec`
     H.264 (surface input) + `AudioRecord` mic + `AudioPlaybackCapture` (API 29+)
     → `MediaMuxer` MP4 **di perangkat** → unggah ke endpoint yang sama.
   - **Worker** hanya menerima dan menyimpan (`RECORDINGS_BUCKET.put` + INSERT
     D1). Tidak ada encoding/transcode di server.
2. **Cakupan konten rekaman** (konsekuensi client-side, bukan bug):
   - Video: **hanya layar yang dibagikan host** — kamera peserta lain TIDAK ikut
     terekam, karena tidak ada server yang me-render/me-mix layout ruangan.
   - Audio web: mikrofon host + audio semua peserta (digital, via `AudioContext`).
   - Audio Android: mic host + suara keluaran speaker via `AudioPlaybackCapture`
     (terbatas usage MEDIA/GAME/UNKNOWN — batasan platform Android).
   - Whiteboard (`Whiteboard.tsx`): TIDAK ikut — DOM Canvas 2D overlay terpisah
     dari WebRTC media stream.
3. **Storage pipeline**: klien → `POST /api/recordings/upload` (multipart) →
   R2 (`RECORDINGS_BUCKET`) → metadata D1 (`recordings`).
4. **Resolusi rekaman (`width × height`)**: dikirim klien saat unggah
   (`resolution_width`/`resolution_height`, mengikuti preset resolusi yang
   dipilih host) — jadi tidak perlu diparse dari file, dan seluruh jalur probe
   MP4 (dulu diperlukan karena payload webhook tidak membawa resolusi) ikut
   tidak diperlukan.
5. **Expiration & penghapusan otomatis**: tidak berubah — Worker Cron Trigger
   (`0 * * * *`) mengecek `expires_at <= NOW` pada `recordings`, menghapus object
   R2, dan mengupdate status D1 ke `'expired'`; baris lebih tua 30 hari ikut
   dibersihkan.
6. **Access control**: tidak berubah — `/api/recordings/:id/stream` &
   `/api/recordings/:id/download` terproteksi; R2 tidak dibuka untuk akses publik.
7. **Auto-record**: flag `auto_record` per meeting memicu rekaman otomatis di
   web (`maybeAutoRecord` di `Meeting.tsx`) maupun mobile (efek di
   `MeetingScreen`, dimulai setelah `roomJoined` true — tidak selama layar setup,
   karena izin MediaProjection tidak pantas muncul sebelum peserta masuk room).

## 37. Sprint 8 — Dashboard Enhancements (Categories, Export, Settings, Name Gate, Auto-Record)

### 37a. Global Link Categories
- Kategori = daftar GLOBAL (tabel `categories`): CRUD di dashboard (tab apapun → tombol "Kelola Kategori" di toolbar tabel). Meeting di-*assign* satu kategori (opsional) lewat dropdown di create/edit/bulk-import.
- `/api/categories` (GET/POST) & `/api/categories/:id` (PATCH/DELETE) — admin only. Nama unik → 409 `CATEGORY_EXISTS`. Hapus kategori → meeting terkait `category_id = NULL` (bukan cascade delete).
- Dashboard: dropdown filter `categoryFilter` ('all' = semua) + badge berwarna per baris + kolom "Category". `displayedMeetings` difilter setelah pagination-state update (deps `categoryFilter` masuk reset pagination).
- `MeetingItem` di frontend membawa `category_id/category_name/auto_record`. Create/edit/bulk-import mengirim `category_id` (null = tanpa kategori) dan `auto_record` (boolean).
- Catatan: tabel `meetings.category_id` memakai FK opsional; SQLite di D1 TIDAK meng-enforce FK tanpa `PRAGMA foreign_keys` — validasi id kategori dilakukan app-level (id tidak dikenal → 400 `INVALID_CATEGORY`).

### 37b. Export Excel (.xlsx)
- Tombol "Export Excel" di toolbar dashboard → unduh `meetings-<tanggal>.xlsx` dari daftar yang sedang DITAMPILKAN (hasil filter kategori + pagination aktif).
- Library: **`write-excel-file`** (`/browser`) — ringan dan full styling. Di-`import()` secara **dynamic** saat klik Export → **tidak menambah bundle utama** (chunk terpisah, diunduh on-demand).
- API: `writeXlsxFile(rows, { columns, sheet, showGridLines: false })` → `await writer.toFile(fileName)`. Kolom didefinisikan via `Column<MeetingItem>` (`width`, `header`, `cell`).
- **Konsistensi row & kolom:** SEMUA sel memakai `bodyCell()` yang sama (fixed `height: 20`, `fontSize: 11`, thin border `#cbd5e1`, text `#1e293b`) → tinggi baris & grid seragam, 10 kolom tetap urutan identik per baris. Header `headerCell()`: bold putih di atas fill emerald `#047857`, tinggi 24, center, border hijau tua.
- **Rapi:** grid lines Excel dimatikan (`showGridLines: false`), border sel sebagai pengganti; angka (Kapasitas/Durasi) rata kanan; Status di-center dengan **warna teks** (`scheduled` amber `#d97706`, `active` hijau `#16a34a`, `ended` slate `#64748b`, `expired` merah `#dc2626`); link join tanpa wrap pada kolom terakhir.
- Status button "Generating..." saat proses, disabled jika daftar kosong. Error → `alert()`.
- Kolom: `Nama;Public ID;Kategori;Jadwal;Status;Kapasitas;Durasi (menit);Host Res;Member Res;Link Join` (jadwal `toLocaleString('id-ID')`; link = `origin + '/meeting/' + public_id`).

### 37b2. Bulk Import (form manual + file Excel `.xlsx`)
- Modal "Bulk Import" di toolbar tabel. Isi manual (tambah baris) ATAU **upload file Excel** (`handleBulkFile`) — file **menggantikan** daftar baris yang ada, lalu tombol "Import Semua" tetap menjalankan flow lama: POST `/api/meetings` per baris (sequential + progress bar).
- Library: **`read-excel-file`** (`/browser`) — dynamic import saat pilih file → tidak menambah bundle utama. Tombol **Template** mengunduh `template-import-meetings.xlsx` (via `write-excel-file`; kolom seperti form Add Meeting — jadwal terpisah `Tanggal` + `Jam`, bukan gabungan seperti export).
- **Kolom template (17) = form Add Meeting:** `Nama, Public ID, Kategori, Tanggal, Jam, Kapasitas, Durasi (menit), Host Res, Member Res, Screen Share Res, Max Active Cameras, Auto Record, Kick Cooldown (menit), Late Join Cutoff (menit), Retention (jam), Tentor, Kode Host`. File **export lama** tetap diterima: kolom `Jadwal` gabungan (dan `Status`/`Link Join` yang diabaikan). Header dinormalisasi (lowercase, buang non-alnum) + alias (`name`, `kode`, `category`, `tanggal|date`, `jam|time`, `jadwal|schedule`, `duration`, dst). Baris tanpa Nama dilewati; kolom "Nama" tidak ada → error "pakai tombol Template".
- **Preset = default global, file bisa timpa per baris (kontrak dipilih, jangan diubah jadi per-baris-preset):** dropdown "Apply Preset to All" (`bulkPresetId`) jadi nilai default; kolom yang terisi di file menang per baris (`maxParticipants/durationMinutes/hostResolution/memberResolution`). `category_id` per baris = pencocokan **nama kategori** case-insensitive ke tabel `categories` (tidak ketemu → fallback `bulkCategoryId` + catatan). Retensi rekaman tetap global (`bulkRetentionHours`).
- **Jadwal — format baru `Tanggal` + `Jam` terpisah (sama seperti input `type="date"`/`type="time"` di form):** sel `Tanggal` memakai `parseScheduleCell` (objek `Date`, `25/9/2026`, `dd-mm-yyyy`, ISO, kosong → All Time, gagal → `scheduleWarning`); sel `Jam` lewat `cellTime` yang menampung teks `08:00`/`08.00`, **sel time Excel** (dibaca sebagai `Date`), dan **pecahan serial** `0..1` (Excel menyimpan jam sebagai angka) → `HH:MM`. Jam kosong → `00:00`; jam terisi tanpa tanggal → All Time + catatan; jam tak terbaca → catatan. Contoh baris template: `Tanggal` = sel tanggal asli (`Date` + sheet option `dateFormat: 'dd/mm/yyyy'` → tampil `25/09/2026`, date-picker Excel), `Jam` = teks `08:00`.
- **Format lama (fallback):** bila kolom `Tanggal` tidak ada, parser pakai satu kolom `Jadwal` gabungan (`parseScheduleCell`): dukung `25/9/2026 08.00.00` (format export `id-ID`), `dd-mm-yyyy HH:mm`, ISO `YYYY-MM-DD[THH:MM]`, objek `Date`, dan `Instant / Unscheduled`/kosong → All Time. Format MM/DD otomatis di-swap bila bulan > 12. Gagal parse → `scheduleWarning` (dipaksa All Time + catatan di toast & badge amber di baris).
- **Validasi sel:** kapasitas 1–500, durasi 1–1440, resolusi harus anggota `VALID_RESOLUTIONS` — nilai invalid **diabaikan** (ikut preset) + dicatat ke toast catatan (maks 3 baris ditampilkan).
- **Dropdown Excel asli** (`dataValidation type=list`, disuntik `xlsxListValidation.ts` → `addListValidations` setelah file ditulis): kolom `Host Res`/`Member Res` (`140p`–`1080p`), `Screen Share Res` (`480p`/`720p`), `Auto Record` (`Ya`/`Tidak`) baris 2–1000. Idempoten (sudah ada `dataValidation` → file dikembalikan apa adanya).
- **Dropdown `Kategori` (dinamis):** template dibuat berisi **2 sheet** — `Import Meetings` + sheet daftar `Daftar Kategori` (disembunyikan lewat feature `write-excel-file` → `xl/workbook.xml` `state="hidden"`). `formula1` Kategori = referensi sel `'Daftar Kategori'!$A$2:$A$N` (`categoryListFormula`) — **tanpa batas 255 karakter inline list, nama ber-koma/& aman**. `errorStyle="warning"` → kategori baru yang diketik setelah template diunduh tetap diterima (peringatan, bukan blokir). Belum ada kategori → sheet daftar & dropdown Kategori tidak dibuat + toast peringatan. Nama tidak dikenal saat import → fallback + catatan (lihat 37b2 parser).
- Gagal POST per baris → toast warning menyebut nama meeting (maks 3 + `…`). Setelah import, daftar baris di-reset ke 1 baris kosong.

### 37c. App Settings Tab (logo & judul)
- Tab `settings` di dashboard (`viewTab` union baru). Data dari `GET /api/settings` (admin); logo/title publik dari `GET /api/settings/public`.
- **Logo** (`app_settings.logo`): boleh data URL (`FileReader.readAsDataURL`, client cap **512KB**, server cap ~700KB → 400 `INVALID_LOGO`) atau URL eksternal (`https://...`). Tersimpan apa adanya tanpa validasi penuh URL eksternal.
- **Judul aplikasi** (`app_settings.title`): teks bebas ≤ **60 karakter** (server trim; > 60 → 400 `INVALID_TITLE`; kosong = fallback `'learnly'`). Ditampilkan di **Home header**, **navbar AdminDashboard**, dan preview di tab Settings (menggantikan teks hardcoded "learnly"). Tidak dipakai di AdminLogin (belum perlu).
- Penerapan logo/judul: `src/shared/utils/siteSettings.ts` → `useSiteLogo(version = 0)` mengembalikan `{logo, title, loading}` — fetch `/api/settings/public` (refetch otomatis saat `version` berubah, mis. setelah PUT settings). Logo dipakai di **Home header**, **AdminLogin**, **navbar AdminDashboard** (fallback `'/learnly.svg'`); judul dipakai di Home + AdminDashboard. Dashboard meng-increment `logoVersion` setelah PUT settings → refetch.
- **Identity browser (favicon + tab title)**: hook `useSiteLogo` juga menerapkan `document.title = title || 'learnly'` dan mengganti `href` semua `<link rel="icon">` / `rel="apple-touch-icon"` menjadi logo (fallback `/learnly.svg`). `App.tsx` memanggil `useSiteLogo()` sekali sehingga berlaku di SETIAP route (termasuk `/meeting/:id`), bukan cuma halaman yang merender header.
- **Retensi rekaman TIDAK di Settings** — dipindah per meeting (`meetings.recording_retention_hours`), karena tiap tentor punya preferensi sendiri (lihat 37d).

### 37d. Recording Retention (per meeting)
- Kolom `meetings.recording_retention_hours` INT **DEFAULT 48** (migrasi `migrations/0004`, seedAdmin ALTER idempotent), ditulis saat create/edit/bulk-import (input number, range 1–720, format/parse via `normalizeRetentionHours`, clamp otomatis; tanpa 400 — nilai invalid di-clamp ke 48).
- Worker memakai retensi dari **row meeting**, bukan setting global: `expires_at = created_at + retention*3600s` (POST `/api/recordings` via `getMeetingRetentionHours(env, meetingId)`; webhook via `meeting.recording_retention_hours`). Buffer "processing" webhook = `retention + 24h` (hardcode lama 72h dihapus).
- `getRetentionHours(env)` (global) **dihapus**; key `app_settings.recording_retention_hours` dari 0003 diabaikan (row lama tidak dibaca). Perubahan retensi via edit hanya berlaku untuk rekaman baru — file rekaman yang sudah ada tetap memakai `expires_at` lama.

### 37e. Scheduled Auto-Record
- Setting per-meeting `auto_record` (boolean, default off). Kapan mulai: **saat `scheduled_at` sudah terlewati** — meeting tanpa jadwal (scheduled_at null) auto-start segera setelah host pindah ke room. Meeting berjadwal yang belum waktunya TIDAK auto-start.
- Implementasi `Meeting.tsx`: `maybeAutoRecord()` — evaluasi on-dep-change + interval **15 dtk** (menutup transisi melewati batas jadwal tanpa re-render). Prasyarat: `autoRecord && canRecord && hasJoinedRef` (host perlu sudah di room).
- Guard idempoten `didAutoRecordRef` — hanya 1x auto-start per session; auto-start hanya saat `recordingState === 'IDLE'`; ref di-set HANYA setelah `start()` sukses (gagal → retry di tick berikutnya). User stop manual TIDAK menghidupkan ulang (ref tetap true).
- **Auto-stop**: saat `now >= expires_at` (via `maybeAutoRecord`) + safety net `stopRecordingSafely()` sebelum `leave()`/redirect di: countdown expiry, status-check expired/deleted, dan handler `roomLeft`. `stopRecordingSafely` hanya berhenti jika state RECORDING/STARTING/PAUSED, swallow error.
- SDK kapabilitas sama dengan manual start (`meeting.recording.start({ allowMultiple: false })`); tombol manual Start/Stop tetap ada untuk host.

### 37f. Member Name Gate (wajib nama sebelum masuk)
- **Home**: field "Your display name *" — tombol Join disabled jika kosong + error `'Nama wajib diisi sebelum masuk meeting.'`; kirim `name: name.trim()`.
- **Meeting.tsx** (direct link / reload, non-admin): jika tidak ada display name (`user?.name || user?.username || session.participantName || localStorage['learnly:name']`) → overlay modal name gate **sebelum mint token**. Submit → simpan `learnly:name` + `setActiveMeetingSession` → `window.location.reload()` (flow auto-join lanjut dengan nama terisi).
- **Admin bebas gate** (punya nama dari session). Tentor tanpa login tetap lewat gate — nama yang diketik = nama tentor terdaftar, lalu server menaikkan ke host. **Rename di dalam meeting** kini tersedia untuk admin (lihat 37g).

### 37g. In-Meeting Rename Member (admin & self-rename)
- Di drawer **Manage Participants** (admin), setiap peserta bukan-host punya tombol rename (ikon `Edit2`). Klik → modal "Ubah Nama Peserta" → `PATCH /api/meetings/:id/participants/:participantId` body `{name, customParticipantId?}`.
- Non-admin / member juga dapat mengubah nama sendiri lewat modal self-rename (`PATCH /api/meetings/:id/participants/:participantId` body `{name, customParticipantId}` — worker memverifikasi bahwa `customParticipantId` cocok dengan target).
- **Persistence:** Cloudflare RTK REST PATCH participant mengembalikan 404, sehingga perubahan nama di-persist ke tabel D1 **`participant_name_overrides`** (`ON CONFLICT(meeting_id, custom_participant_id) DO UPDATE`). Saat `getMeetingDetail` dijalankan (poll 3 dtk), daftar peserta digabung dengan name overrides tersebut.
- Setelah sukses, client melakukan broadcast `MEMBER_RENAME { participantId, name }` via `meeting.participants.broadcastMessage` dan menyimpan override sementara di `localNameOverridesRef` agar polling tidak menimpa nama sebelum D1 ter-sync.

### 37h. Share Link + Kode Kelas (admin, dalam meeting)
- Tombol **Share** (ikon `Share2`) di overlay atas `Meeting.tsx`, admin-only. Modal menampilkan **Link Meeting** (`origin + '/meeting/' + public_id`, fallback `id`) dan **Kode Kelas** (`public_id`). Masing-masing punya tombol **Salin** sekali-klik (Clipboard API + fallback `execCommand`, label berubah "Tersalin" 2 dtk), plus tombol **Salin Semua** (`Link Meeting: ...\nKode Kelas: ...`).

### 37i. Pagination (Presets & Recordings)
- Komponen bersama `PaginationControls` (`src/features/dashboard/components/PaginationControls.tsx`) dipakai tabel meetings + grid Presets + grid Recordings — konsisten dengan pagination menu "past": pilihan 10/25/50 per halaman, tombol Prev/Next, nomor halaman window 5.
- State `presetPage`/`presetPerPage` dan `recordingPage`/`recordingPerPage`; halaman otomatis di-clamp jika data berkurang. Fetch data tetap penuh dari API (pagination client-side).

## 38. Sprint 10 — Tentor System, Host Badge & UI Architecture

### 38a. Tentor System (Host tanpa login)
- **Tabel `tentors`:** `id (TEXT PK), meeting_id (TEXT NOT NULL), name (TEXT NOT NULL), created_at (DATETIME)`. Index: `idx_tentors_meeting_name UNIQUE (meeting_id, name)`.
- **Admin Dashboard Inspector:** Kelola daftar tentor per meeting (Add, Edit, Delete tentor). API: `/api/tentors` (GET `?meeting_id=:id`, POST) & `/api/tentors/:id` (PATCH, DELETE) — admin only.
- **Auto Host Elevation (`issueToken`):** Saat pengguna meminta token dengan nama tertentu, worker mengecek `tentors` untuk `meetingRecord.id` dengan case-insensitive match (`lower(name) = lower(?)`). Jika cocok:
  1. Pengguna dielevasi menjadi `isAdmin = true` dan `preset_name = 'group_call_host'`.
  2. Pengecekan jadwal (`scheduled_at`) dilewati (tentor dapat masuk lebih awal untuk persiapan).
  3. Pengecekan kuota kapasitas (`max_participants`) dilewati.
- **Occupancy Collision Protection:** Jika ada pengguna lain yang sedang aktif di room dengan nama tentor tersebut (dan bukan reconnecting sesi yang sama), elevasi host dibatalkan (`isAdmin = false, isTentor = false`) agar hak host tidak dicuri oleh peserta kedua.

### 38b. Host Badge & Host-Only Recording UI
- **Host Badge (`src/features/meeting/utils/hostBadge.ts`):**
  - Web Component `<meet-host-badge>` dengan styling pill hijau (`#10b981`, text `HOST`).
  - Addon `hostBadgeAddon` dimasukkan ke `registerAddons` pada `Meeting.tsx` untuk menyisipkan badge ke dalam `rtk-name-tag`.
  - Fungsi `startHostBadgeSync()` menjalankan sinkronisasi interval 500ms yang menembus Shadow DOM elemen `<rtk-participant>` di sidebar partisipan untuk menyisipkan badge host di samping nama host.
- **Host-Only Recording UI:**
  - `stripRecordingUi(cfg, ['rtk-recording-toggle', 'rtk-recording-indicator'])` menyaring elemen UI recording dari config RealtimeKit jika partisipan bukan host (`!isHost`).
  - Peserta biasa tidak melihat tombol atau indikator perekaman di control bar.

### 38c. Screenshare Resolution (otomatis dari setting admin)
- Pengecekan klik pada tombol `rtk-screen-share-toggle` bawaan SDK dicegat di fase capture event listener.
- TANPA modal: resolusi diambil dari `meetings.screenshare_resolution` (pilihan admin: **720p** default / **480p**, via dropdown Add/Edit Meeting atau kolom Excel `Screen Share Res`).
- Mengatur constraint resolusi pada instans `ScreenshareConstraints` yang terikat ke live reference RTK SDK sebelum memanggil `meeting.self.enableScreenShare()`.

### 38d. Reusable UI Components (`src/shared/components/`)
- Menghilangkan duplikasi kode dialog & notifikasi di dashboard dan meeting room.
- `ToastProvider` & `useToast` (`src/shared/hooks/useToast.ts`): Floating toast alert (success, error, info, warning) dengan auto-dismiss 4 dtk.
- `Modal`: Base modal dialog dengan backdrop blur dan event escape / backdrop click.
- `ConfirmDialog`: Dialog konfirmasi aksi destruktif dengan variant `danger` dan `info`.

---

## 39. Sprint 11 — Feature-Based Architecture Refactor

Refactor struktural **tanpa perubahan behavior** — tujuan: setiap fitur punya folder/module sendiri, dependency berjalan satu arah.

### Perubahan Utama

**Struktur baru:**
```text
src/
├── shared/           ← kode dipakai >1 fitur (UI, hooks, utils)
└── features/
    ├── auth/           ← login, guard, context
    ├── home/           ← halaman join publik
    ├── meeting/        ← room, whiteboard, annotation, screenshare, hostBadge
    └── dashboard/      ← admin panel, types, components ekstrak
```

**Dependency rule (jangan dilanggar):**
```text
shared/ ← features/* ← App.tsx
```
Fitur tidak boleh mengimpor fitur lain. Shared tidak mengimpor fitur.

### File yang Diekstrak (baru)

| File | Diekstrak dari |
|---|---|
| `features/dashboard/types/dashboard.types.ts` | Interface block di `AdminDashboard.tsx` (MeetingItem, PresetItem, RecordingItem, dll.) |
| `features/dashboard/components/PaginationControls.tsx` | Inline `PaginationControls` function di `AdminDashboard.tsx` |
| `features/dashboard/components/RecordingCard.tsx` | Inline `RecordingCard` component di `AdminDashboard.tsx` |
| `features/dashboard/utils/recordingHelpers.tsx` | Helper functions recording (`formatDuration`, `formatFileSize`, `getRecordingCountdown`, `getRecordingStatusBadge`, `getRecordingDisplayName`) — file `.tsx` karena ada JSX di `getRecordingStatusBadge` |

### Catatan

- `AdminDashboard.tsx` tetap monolith (3713 ln) — intentional. State & handler semuanya interleaved; memecah lebih jauh membutuhkan prop drilling masif yang menambah kompleksitas tanpa nilai. (Sejak issue #52 isinya juga berisi layout topbar/sidebar — lihat §4.)
- Tidak ada perubahan behavior, API, routing, schema, atau logic bisnis.
- `PaginationControls` sebelumnya didefinisikan inline di `AdminDashboard.tsx`; sekarang di file terpisah dan diimpor dari `dashboard/components/`.
- Import convention: gunakan `'../../../shared'` (atau `'../../shared'` dari depth yang sesuai), bukan path relatif ke file individual `shared/utils/userId` dst — barrel `shared/index.ts` mengekspos semua.

### Worker Reorganization (Backend)

`worker/` juga dipecah dari 1 file 1750+ baris menjadi module per domain:

```text
worker/
├── index.ts              # Entry: fetch() router + scheduled() saja (286 ln)
├── auth.ts               # PBKDF2, session HMAC, cookies, seedAdmin + ensureSingleAdmin (tetap)
├── lib/
│   ├── utils.ts          # json(), resolveMeetingId, generatePublicId, retention helpers
│   ├── mp4.ts            # baca resolusi video dari file MP4 recording
│   └── emailTemplate.ts  # brand + buildResetEmail (email OTP)
└── handlers/
    ├── auth.ts           # handleLogin, handleLogout, handleMe, handleForgotPassword,
    │                     # handleVerifyResetCode, handleResetPassword
    ├── meetings.ts       # listMeetings, createMeeting, getMeetingDetail, updateMeeting,
    │                     # deleteMeeting, removeParticipant, renameParticipant,
    │                     # updateAnnotationPermission
    ├── presets.ts        # listPresets, createPreset, updatePreset, deletePreset
    ├── tentors.ts        # listTentors, createTentor, updateTentor, deleteTentor
    ├── categories.ts     # listCategories, createCategory, updateCategory, deleteCategory
    ├── settings.ts       # getPublicSettings, getAllSettings, updateSettings
    ├── tokens.ts         # issueToken
    └── recordings.ts     # handleRecordingsApi,
                          # handleScheduledCleanups
```

---

## 40. Meeting Lifecycle Contract (commit `c52aed6`)

Kontrak `status` ↔ `started_at` ↔ `expires_at`. **Ketiganya selalu ditulis dalam satu `UPDATE` yang sama** (`updateMeeting` di `worker/handlers/meetings.ts`) sehingga baris tidak pernah memperlihatkan status yang bertentangan dengan timernya. Jangan menambah jalur UPDATE yang hanya mengubah salah satu.

### 40a. Tabel transisi

| Aksi | status | started_at | expires_at |
|---|---|---|---|
| Create meeting (`POST /api/meetings`) | `scheduled` | NULL | NULL |
| Token pertama (status `scheduled`/`active`, timer NULL) **setelah `scheduled_at` tercapai** | `active` | now | now + `duration_minutes` |
| Token admin/tentor **sebelum** `scheduled_at` (preview) | `scheduled` | **NULL** | **NULL** (gate member tetap tertutup) |
| Tombol **Mulai Sekarang** (`scheduled` → `active`) | `active` | now | now + `duration_minutes` |
| Tombol **Akhiri Meeting** (`active` → `ended`) | `ended` | dipertahankan | **NULL** (timer dihentikan) |
| Tombol **Buka Kembali** (`expired`/`ended` → `scheduled`) | `scheduled` | **NULL** | **NULL** |
| Durasi diubah saat meeting `active` | dipertahankan/`expired` | dipertahankan | `started_at` + durasi BARU (**bukan** `now + durasi`); bila sudah lewat → `expired` |
| `status: 'active'` tapi `expires_at <= now` (saat PATCH) | dipaksa `expired` | — | — |
| `expires_at` terlampaui saat issue token / list | `expired` | dipertahankan | dipertahankan |
| `status: 'expired'` dengan timer belum lewat (close manual) | `expired` | dipertahankan | disamakan `now` |

### 40b. Gate yang mengikutinya

- **Preview sebelum jadwal tidak membuka pintu:** `issueToken` tidak menulis `started_at`/`expires_at`/`status` selama `scheduled_at` belum tercapai, sehingga preview admin/tentor tidak mengangkat gate member (gate tetap `scheduled_at && started_at IS NULL`) dan tidak memulai durasi. Admin yang memang ingin membuka kelas lebih awal memakai tombol **Mulai Sekarang**.
- **`ended`/`expired` adalah state tertutup:** `issueToken` menolak lebih dulu (`403 MEETING_ENDED` / `403 MEETING_EXPIRED`) — timer NULL **tidak** menghidupkan kembali meeting tertutup. Hanya tombol **Buka Kembali** yang melepasnya.
- **Gate jadwal hanya sebelum mulai:** `scheduled_at` menahan non-admin **hanya selama `started_at` masih NULL**. Begitu meeting pernah dimulai, jadwal tidak lagi menahan join (berlaku di `issueToken`, pre-check `Home.tsx`, dan banner `Meeting.tsx`).
- **Client `ended` = keluar:** poll `Meeting.tsx` (3 dtk) dan pre-check `Home.tsx` menganggap `ended` sama dengan `expired`/`deleted` → stop recording, keluar room, redirect.
- **`runtimeIdRef` (Meeting.tsx):** uuid internal meeting ditangkap dari response detail pertama; semua polling & call API di room (`/api/meetings/:id`, kick, rename, PATCH annotation/whiteboard) memakainya — bukan `:id` URL yang bisa berupa `public_id` yang diubah admin di tengah meeting.

### 40c. UI aksi (AdminDashboard, modal edit)

- Tidak ada dropdown status; status dirender sebagai badge read-only + satu tombol turunan:
  - `scheduled` → **Mulai Sekarang** (`PATCH {status:'active'}`)
  - `active` → **Akhiri Meeting** (`PATCH {status:'ended'}`)
  - `expired`/`ended` → **Buka Kembali** (`PATCH {status:'scheduled'}`)
- Validasi save: kapasitas integer 1–500, durasi integer 1–1440, retensi integer 1–720 (semua dicek sebelum fetch).
- **Konfirmasi short-expiry:** jika meeting `active` berjalan dan durasi baru membuatnya langsung lewat (`started_at + durasi <= now`), klik pertama hanya mengirim state ack (`Ya, Simpan & Akhiri` muncul di klik kedua).
- Semua aksi lifecycle mengembalikan `meeting` berisi `status`, `started_at`, `expires_at` terbaru → state lokal disinkronkan lalu `fetchMeetings()`.
