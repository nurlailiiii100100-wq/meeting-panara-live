/**
 * Panara Live — aplikasi mobile React Native.
 *
 * Fase 2: screen share NATIF (Android MediaProjection) yang
 * masuk ke room Cloudflare RealtimeKit yang sama, lalu dilihat oleh peserta
 * web di layar utama aplikasi web.
 *
 * Aplikasi ini ANDROID-ONLY: proyek Xcode / broadcast extension iOS sudah
 * dihapus dari repositori (tidak dipakai).
 */

import { useCallback, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import type { JoinSession } from './src/meeting/useMeetingSession';
import JoinScreen from './src/screens/JoinScreen';
import MeetingScreen from './src/screens/MeetingScreen';

function App() {
  const [session, setSession] = useState<JoinSession | null>(null);

  const handleLeave = useCallback(() => setSession(null), []);

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="#0b0f17" />
      <View style={styles.root}>
        {session ? (
          <MeetingScreen session={session} onLeave={handleLeave} />
        ) : (
          <JoinScreen onJoined={setSession} />
        )}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0b0f17' },
});

export default App;
