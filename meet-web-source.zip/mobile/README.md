# Panara Live — Aplikasi Mobile (React Native, Android-only)

Aplikasi mobile untuk Fase 2: screen share **native** (Android MediaProjection)
yang masuk ke room Cloudflare RealtimeKit yang sama dengan
aplikasi web, sehingga peserta web melihat layar HP sebagai video pada stage.

> **Android saja.** Proyek Xcode, Podfile, dan broadcast extension iOS sudah
> dihapus dari repositori (tidak dipakai) — aplikasi ini hanya dibangun untuk
> Android.

- Lokasi: folder `mobile/` di repo ini (project mandiri, **bukan** workspace —
  `package.json` web tidak disentuh).
- SDK: `@cloudflare/realtimekit-react-native@2.0.0`,
  `@cloudflare/react-native-webrtc@137.0.1`, `@cloudflare/realtimekit@2.0.0`
  (React 19, React Native 0.86.3, Android minSdk 24).
- UI: `@cloudflare/realtimekit-react-native-ui@2.0.0` — **port resmi UI web
  (PC)**, sehingga layar mobile memakai komponen `RtkMeeting` yang sama:
  layar setup sebelum join, grid peserta, controlbar, dan tombol share
  berlabel "Share Screen"/"Stop Sharing" identik dengan aplikasi web.
  Peer deps ikut terpasang: `react-native-svg`, `react-native-webview`,
  `react-native-fs`, `react-native-file-viewer`, `react-native-sound-player`,
  `@react-native-documents/picker`.
- Backend: memakai worker yang sama (`/api/auth/*`, `/api/meetings/:id`,
  `/api/meetings/:id/host-code`, `/api/tokens`). Tidak ada API key Cloudflare
  di aplikasi — token RealtimeKit selalu diterbitkan oleh worker.

## Alur di dalam aplikasi

1. `JoinScreen` — sama dengan halaman Home web (pre-check jadwal → gate kode
   host → ambil token). **Deep link didukung**: tap link
   `https://meet.panara.id/meeting/<kode>` langsung membuka aplikasi & masuk
   room (lihat bagian "Deep link" di bawah).
   **Tidak ada login admin di mobile**: peserta cukup isi nama + kode meeting.
   Host tentor diminta kode host, dan rekaman memakai `upload_token` yang
   dikirim langsung oleh `/api/tokens` — jadi tidak ada login, cookie sesi,
   maupun penyimpanan kredensial apa pun di aplikasi.
2. `MeetingScreen` → `RtkMeeting` (UI kit) — layar **setup** tampil lebih dulu
   (preview kamera/mik), `join()` dipanggil saat peserta menekan Join, persis
   perilaku PC.
3. Di room: grid + controlbar bawaan kit. Kontrol recording bawaan kit
   disembunyikan untuk **semua role** (tombol kit = cloud recording RealtimeKit
   yang berbiaya). Rekaman mobile memakai **rekaman client-side native
   Android** (MediaProjection → MediaCodec H.264 + mic → MP4 → unggah ke
   `POST /api/recordings/upload` dengan upload_token host — paralel dengan
   `useClientRecorder` di web, biaya Export $0). Tombol "Rekam" hanya tampil
   untuk host/admin.
   Catatan: rekaman dan share layar tidak bisa bersamaan (satu MediaProjection
   per aplikasi). **Share Screen khusus host** — item `rtk-screenshare-toggle`
   disembunyikan dari menu More untuk member (`buildMobileUiConfig(isHost)`) dan
   `enableScreenShare()` dibungkus gate "Hanya host yang dapat berbagi layar" di
   `useScreenShareFeedback`. Bila host menekan Share saat rekaman berjalan, muncul
   dialog konfirmasi **"Hentikan & Share"**: rekaman dihentikan otomatis (bagian
   yang terekam tetap diunggah) lalu share dimulai. Suara peserta lain mungkin
   terekam akustik lewat speaker (batasan AudioPlaybackCapture Android).

   **Resolusi share dibatasi 720p-class @15fps** lewat patch native
   `@cloudflare/react-native-webrtc` (file `ScreenCaptureController.java`,
   patch di `patches/@cloudflare+react-native-webrtc+<versi>.patch`, otomatis
   dipasang oleh `postinstall` → `patch-package`). Tanpa patch ini, capture
   memakai resolusi native layar HP (mis. 1080×2340 / 1440×3200, portrait) →
   H.264 level 5.0 yang **tidak bisa didecode decoder hardware banyak HP
   penerima** → tile screenshare tampil **hitam** di HP (penonton PC/browser
   tetap tampil karena memakai software decoder). Sisi terpanjang diskalakan
   ke 1280 px (rasio dipertahankan, dimensi genap untuk encoder H.264).
4. Kegagalan screen share native (dibatalkan, izin ditolak, capture tak
   tersedia, dst.) muncul sebagai **banner error Indonesia** di atas UI kit —
   pesan & kode error ada di `src/meeting/screenShare/types.ts`.
5. Keluar/kick/ended ditangani layar bawaan kit + navigasi otomatis ke
   `JoinScreen` (paralel `Meeting.tsx` web).

## Prasyarat

- Node 22+, JDK 17, Android SDK (compileSdk 36) + NDK.

## 1. Siapkan backend

```sh
# dari root repo (port 8787)
npm run dev
```

**Build rilis tidak perlu diisi apa pun:** aplikasi langsung menunjuk ke URL
produksi (`DEFAULT_API_BASE_URL` di `src/config.ts` — satu domain dengan situs
web, sama seperti aplikasi web yang memakai URL relatif `/api/...` karena
worker dan frontend berbagi origin). Tidak ada API key Cloudflare di
aplikasi — token RealtimeKit selalu diterbitkan worker.

Kartu **"Pengaturan server" sengaja disembunyikan** dari user supaya tidak ada
langkah ekstra dan tidak ada kemungkinan salah isi URL. Kartu itu hanya
muncul otomatis kalau koneksi ke server gagal (`isConnectionError` di
`JoinScreen.tsx` — jaringan mati, DNS gagal, TLS ditolak, atau URL kosong),
sebagai jalan darurat; setelah diperbaiki dan koneksi berhasil, user cukup
menekan "Sembunyikan pengaturan server".

Kalau kamu mau mengubah URL yang dipakai aplikasi tanpa build ulang, satu-satunya
tempat adalah kartu tersebut (URL disimpan di AsyncStorage, atau kosongkan data
aplikasi untuk kembali ke default yang ditanem).

### Menguji dengan worker lokal (bukan deploy)

Untuk development, `__DEV__` memakai `http://10.0.2.2:8787` (emulator Android).
Untuk HP fisik di WiFi yang sama dengan laptop, isi URL
`http://<ip-laptop>:8787` sekali di kartu Pengaturan server — HP yang memakai
data seluler **tidak akan pernah bisa** menghubungi worker di laptop.

## 2. Android

```sh
cd mobile
npm install
npm start            # Metro, terminal terpisah
npm run android      # build + install ke emulator/device
```

Verifikasi build tanpa perangkat:

```sh
cd android && ./gradlew :app:assembleDebug
```

Konfigurasi yang sudah dibuat (jangan dihapus):

- `android/app/src/main/AndroidManifest.xml` — izin kamera/mikrofon,
  foreground service, dan `FOREGROUND_SERVICE_MEDIA_PROJECTION` (wajib untuk
  capture layar).
- `android/app/src/main/res/values/strings.xml` — `blob_provider_authority`
  (diminta library RealtimeKit).
- `android/gradle.properties` — `android.useFullClasspathForDexingTransform=true`.
- `android/app/proguard-rules.pro` — keep rule `realtimekit.org.webrtc.**`.

## Deep link (tap link → langsung masuk room)

Link meeting web `https://meet.panara.id/meeting/<kode>` bisa dibuka langsung
di aplikasi (bukan browser). Dua jalur di `android/app/src/main/AndroidManifest.xml`:

- **App Links** (`autoVerify=true`, host `meet.panara.id`, path `/meeting`) —
 Android membuka aplikasi tanpa dialog pilihan browser/app **hanya setelah**
 verifikasi `https://meet.panara.id/.well-known/assetlinks.json` berhasil.
 File itu ada di `public/.well-known/assetlinks.json` (disajikan worker dari
 assets) dan berisi fingerprint SHA-256 keystore + `com.learnlymeet`.
- **Skema kustom cadangan** `learnlymeet://meeting/<kode>` — dipakai bila
 App Links belum terverifikasi (install debug, domain berganti, dsb).

Perilaku di `JoinScreen` (src/meeting/deepLink.ts + efek Linking):

- Kode meeting selalu terisi otomatis dari link.
- Kalau nama sudah pernah dipakai (tersimpan di AsyncStorage) → **auto-join
 langsung**, sama seperti klik link di browser PC. Kalau nama adalah tentor
 dengan kode host aktif, tetap diminta kode host.
- Kalau nama belum ada → form tampil dengan kode sudah terisi (user isi nama).
- Server URL yang tersimpan kosong/terhapus diisi otomatis dari origin link
  (jaringan darurat saja — normalnya build rilis sudah membawa URL produksi
  dari `DEFAULT_API_BASE_URL`, lihat bagian 1).

> **Penting saat release:** fingerprint di `assetlinks.json` saat ini adalah
> keystore **debug** bawaan Android. Ganti dengan fingerprint keystore release
> (`keytool -list -v -keystore release.keystore`) dan tambahkan sebagai baris
> kedua bila ingin keduanya terverifikasi. Tanpa verifikasi, tap link https
> akan menampilkan pilihan browser/app dulu (skema kustom tetap berfungsi).

## Branding (nama & logo)

- **Nama aplikasi: "Panara Live"** — ditampilkan user di launcher.
  - `android/app/src/main/res/values/strings.xml` → `app_name` (sumber skema
    `android:label` di manifest).
  - `app.json` → `displayName: "Panara Live"` (label) dan `name: "PanaraLive"`
    (nama komponen React Native — **wajib sama** dengan
    `MainActivity.kt: getMainComponentName()`, kalau beda aplikasi crash saat
    start; `index.js` mendaftarkan keduanya dari `app.json`).
  - Label di layar: `JoinScreen` (judul) dan `useMeetingSession` (title
    notifikasi foreground) serta `ScreenRecordService.kt` (judul notifikasi
    rekaman).
- **Logo & icon launcher** dari sumber `PANARA FIX-01.png` (1000×1000, latar
  putih) — file asli milik desainer, biarkan di akar folder `mobile/`:
  - Icon launcher = `PANARA FIX-01.png` **dipotong hanya emblemnya** (tanpa
    teks "PANARA COURSE") di setiap `res/mipmap-*/ic_launcher.png` +
    `ic_launcher_round.png` (48/72/96/144/192 px). Teks tidak dipakai karena
    tak terbaca di icon 48 px.
  - Logo in-app (`src/assets/panara-logo.png`) = logo **penuh** (emblem +
    teks), ditampilkan di `JoinScreen` di dalam kartu putih membulat. Kartu
    putih wajib karena hijau logo `#125938` hanya 2.29:1 kontras terhadap latar
    gelap app — di atas latar putih kontrasnya baik.

> **Yang sengaja TIDAK diganti:** `applicationId` (`com.learnlymeet`), skema
> deep link `learnlymeet://`, dan kunci AsyncStorage `learnly:*` di
> `prefs.ts` — ketiganya bersifat identitas/penyimpanan. Menggantinya akan
> memutus deep link yang sudah jadi, merusak verifikasi `assetlinks.json`, dan
> membuat user harus mengisi ulang nama yang sudah tersimpan.

## 3. Perintah pemeriksaan

```sh
cd mobile
npm run typecheck    # tsc --noEmit
npm run lint         # eslint (mode eslintrc, konfigurasi lokal)
npm test             # jest
```

## 4. Uji interoperasi (Android → web)

1. Jalankan worker + aplikasi web di desktop, buat/jadwalkan meeting.
2. Masuk sebagai peserta dari web dengan kode meeting.
3. Di HP: masuk dengan kode meeting & nama yang sama (pakai kode host bila nama
   terdaftar sebagai tentor).
4. Tekan **Share Screen** → setujui dialog sistem (MediaProjection).
5. Layar HP harus tampil pada stage aplikasi web (badge `SCREEN`).

Status saat ini: **IMPLEMENTATION COMPLETE — PHYSICAL DEVICE VALIDATION
REQUIRED.** UI mobile memakai `RtkMeeting` dari UI kit resmi (identik PC);
terverifikasi: `typecheck` 0 error, `lint` 0 masalah, `test` 15/15.
Uji layar asli (Android → desktop web) dan rekaman client-side harus dilakukan
pada perangkat fisik/emulator dengan akses LAN ke worker.
