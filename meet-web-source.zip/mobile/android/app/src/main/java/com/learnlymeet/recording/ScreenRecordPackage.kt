package com.learnlymeet.recording

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

/** Registrasi modul rekaman native ke React Native (autolink manual). */
class ScreenRecordPackage : ReactPackage {
	override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> =
		listOf(ScreenRecordModule(reactContext))

	override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> =
		emptyList()
}
