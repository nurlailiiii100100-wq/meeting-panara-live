package com.learnlymeet.recording

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import com.facebook.react.bridge.ActivityEventListener
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.BaseActivityEventListener
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule

/**
 * Jembatan JS ↔ ScreenRecordService (rekaman client-side Android).
 *
 * JS memanggil:
 *   startRecording() → dialog izin capture layar sistem → service mulai
 *   stopRecording()  → finalisasi MP4, event "ScreenRecordStopped" berisi
 *                      { path, durationSeconds } lalu JS mengunggah ke
 *                      POST /api/recordings/upload (sama dengan web).
 *
 * Tidak ada RealtimeKit Cloud Export — rekaman murni di perangkat host.
 */
class ScreenRecordModule(private val reactContext: ReactApplicationContext) :
	ReactContextBaseJavaModule(reactContext) {

	companion object {
		const val NAME = "ScreenRecord"
		private const val REQUEST_CAPTURE = 7712
		const val EVENT_STOPPED = "ScreenRecordStopped"
		const val EVENT_ERROR = "ScreenRecordError"

		@Volatile private var pendingStartPromise: Promise? = null
		private var activeModule: ScreenRecordModule? = null

		fun emitStopped(path: String, durationSeconds: Int, reason: String) {
			val module = activeModule ?: return
			val map: WritableMap = Arguments.createMap().apply {
				putString("path", path)
				putInt("durationSeconds", durationSeconds)
				// "user_stop" = tombol stop aplikasi; "projection_revoked" =
				// sistem mencabut capture (mis. screen share lain aktif).
				putString("reason", reason)
			}
			module.sendEvent(EVENT_STOPPED, map)
		}

		fun emitError(message: String) {
			val module = activeModule ?: return
			val map: WritableMap = Arguments.createMap().apply {
				putString("message", message)
			}
			module.sendEvent(EVENT_ERROR, map)
			pendingStartPromise?.reject("RECORD_FAILED", message)
			pendingStartPromise = null
		}
	}

	private val listener: ActivityEventListener = object : BaseActivityEventListener() {
		override fun onActivityResult(
			activity: Activity, requestCode: Int, resultCode: Int, data: Intent?
		) {
			if (requestCode != REQUEST_CAPTURE) return
			val promise = pendingStartPromise
			if (resultCode != Activity.RESULT_OK || data == null) {
				pendingStartPromise = null
				promise?.reject("USER_CANCELLED", "Izin rekaman layar dibatalkan.")
				return
			}
			try {
				val intent = Intent(activity, ScreenRecordService::class.java).apply {
					action = ScreenRecordService.ACTION_START
					putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
					putExtra(ScreenRecordService.EXTRA_RESULT_DATA, data)
				}
				if (Build.VERSION.SDK_INT >= 26) {
					activity.startForegroundService(intent)
				} else {
					activity.startService(intent)
				}
				// Rekaman dianggap mulai; kegagalan service dikirim via event
				// ScreenRecordError (lihat useNativeRecorder → banner).
				pendingStartPromise = null
				// `promise` nullable (hasil `pendingStartPromise`) — sama dengan
				// cabang reject di bawah, pakai safe call.
				promise?.resolve(null)
			} catch (t: Throwable) {
				pendingStartPromise = null
				promise?.reject("SERVICE_START_FAILED", t.message ?: "Gagal memulai service rekaman.")
			}
		}
	}

	init {
		reactContext.addActivityEventListener(listener)
		activeModule = this
	}

	override fun getName(): String = NAME

	private fun sendEvent(name: String, params: WritableMap) {
		if (reactContext.hasActiveReactInstance()) {
			reactContext
				.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
				.emit(name, params)
		}
	}

	@ReactMethod
	fun startRecording(promise: Promise) {
		// `currentActivity` (tanpa qualifier) tidak valid di RN 0.86 — di kelas
		// induk getCurrentActivity() sudah berupa fun Kotlin, bukan getter
		// Java, sehingga property syntax-nya gagal. Ambil dari ReactContext
		// (ReactContext.java — Java, jadi currentActivity tetap synthetic
		// property yang valid).
		val activity = reactContext.currentActivity
		if (activity == null) {
			promise.reject("NO_ACTIVITY", "Tidak ada activity aktif untuk dialog izin rekaman.")
			return
		}
		if (pendingStartPromise != null || ScreenRecordService.instance != null) {
			promise.reject("ALREADY_RECORDING", "Rekaman sudah berlangsung.")
			return
		}
		// MEDIA_PROJECTION_SERVICE adalah static field Context — di Kotlin
		// tidak bisa diakses lewat instance (reactContext.MEDIA_PROJECTION_SERVICE).
		val manager = reactContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
			as MediaProjectionManager
		pendingStartPromise = promise
		activity.startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
	}

	@ReactMethod
	fun stopRecording(promise: Promise) {
		val service = ScreenRecordService.instance
		if (service == null) {
			promise.reject("NOT_RECORDING", "Tidak ada rekaman yang berlangsung.")
			return
		}
		// Hasil akhir (path + durasi) dikirim via event ScreenRecordStopped.
		service.stopEngine(notifyError = false)
		promise.resolve(null)
	}

	@ReactMethod
	fun addListener(eventName: String) = Unit

	@ReactMethod
	fun removeListeners(count: Int) = Unit

	override fun invalidate() {
		reactContext.removeActivityEventListener(listener)
		if (activeModule === this) activeModule = null
		super.invalidate()
	}
}
