package com.learnlymeet.recording

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

/**
 * Rekaman client-side di perangkat host (Android) — paralel dengan
 * useClientRecorder di web (src/features/meeting/hooks/useClientRecorder.ts).
 *
 * Pipeline: MediaProjection (layar) → MediaCodec H.264 (surface input) +
 * AudioRecord mic (+ AudioPlaybackCapture API 29+, bila tersedia) →
 * MediaMuxer MP4. Tidak ada RealtimeKit Cloud Export — biaya recording $0.
 *
 * Service khusus dipakai karena Android 10+ (wajib di API 34+) mengharuskan
 * MediaProjection dimperoleh di dalam foreground service bertipe
 * mediaProjection. File hasil ditulis ke filesDir/recordings/ lalu diunggah
 * ke POST /api/recordings/upload oleh lapisan JS.
 */
class ScreenRecordService : Service() {

	companion object {
		private const val TAG = "ScreenRecordService"
		const val ACTION_START = "com.learnlymeet.recording.START"
		const val ACTION_STOP = "com.learnlymeet.recording.STOP"
		const val EXTRA_RESULT_CODE = "result_code"
		const val EXTRA_RESULT_DATA = "result_data"
		const val EVENT_ERROR = "ScreenRecordError"

		// 720p @ ~2 Mbps — disamakan dengan preset '720p' useClientRecorder web.
		private const val VIDEO_WIDTH = 1280
		private const val VIDEO_HEIGHT = 720
		private const val VIDEO_BITRATE = 2_000_000
		private const val VIDEO_FPS = 30
		private const val AUDIO_BITRATE = 128_000
		private const val SAMPLE_RATE = 44100
		private const val NOTIFICATION_ID = 4660

		/** Referensi service aktif — dipakai module JS untuk stop tanpa bind. */
		@Volatile
		var instance: ScreenRecordService? = null
			private set
	}

	private var projection: MediaProjection? = null
	private var virtualDisplay: VirtualDisplay? = null
	private var muxer: MediaMuxer? = null

	private var videoEncoder: MediaCodec? = null
	private var audioEncoder: MediaCodec? = null
	private var micRecord: AudioRecord? = null
	private var playbackRecord: AudioRecord? = null

	private var videoThread: HandlerThread? = null
	private var audioThread: Thread? = null
	private var drainThread: Thread? = null

	@Volatile private var running = false
	@Volatile private var hasAudio = false
	@Volatile private var outputPath: String = ""
	@Volatile private var startedAtMs: Long = 0L

	private var videoTrack = -1
	private var audioTrack = -1
	private val muxLock = Any()

	@Volatile private var muxerStarted = false

	private val projectionCallback = object : MediaProjection.Callback() {
		override fun onStop() {
			// Sistem mencabut projection (panel notifikasi "berhenti", screen
			// cast lain, atau Android mematikan capture). Finalisasi anggun:
			// file parsial tetap divalidasi & diunggah oleh JS.
			if (running) stopEngine(notifyError = false, reason = "projection_revoked")
		}
	}

	override fun onBind(intent: Intent?): IBinder? = null

	override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
		when (intent?.action) {
			ACTION_START -> handleStart(intent)
			ACTION_STOP -> stopEngine(notifyError = false)
		}
		return START_NOT_STICKY
	}

	private fun handleStart(intent: Intent) {
		if (running) return
		val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, android.app.Activity.RESULT_CANCELED)
		val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
			intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
		} else {
			@Suppress("DEPRECATION")
			intent.getParcelableExtra(EXTRA_RESULT_DATA)
		}
		if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
			Log.w(TAG, "Projection result invalid (resultCode=$resultCode)")
			stopSelf()
			return
		}

		try {
			startForegroundWithNotification()

			val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
			val proj = manager.getMediaProjection(resultCode, resultData)
				?: throw IllegalStateException("getMediaProjection() null")
			proj.registerCallback(projectionCallback, Handler(mainLooper))
			projection = proj

			val dir = File(filesDir, "recordings").apply { mkdirs() }
			val file = File(dir, "rec_${System.currentTimeMillis()}.mp4")
			outputPath = file.absolutePath
			muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

			setupVideo(proj)
			setupAudio(proj)

			startedAtMs = System.currentTimeMillis()
			running = true
			instance = this
			Log.i(TAG, "Recording started → $outputPath")
		} catch (t: Throwable) {
			Log.e(TAG, "Failed to start recording", t)
			sendError("Gagal memulai rekaman: ${t.message ?: "kesalahan tidak diketahui"}")
			cleanup()
			stopSelf()
		}
	}

	private fun startForegroundWithNotification() {
		val channelId = "screen_record"
		val manager = getSystemService(NotificationManager::class.java)
		if (Build.VERSION.SDK_INT >= 26 &&
			manager.getNotificationChannel(channelId) == null
		) {
			manager.createNotificationChannel(
				NotificationChannel(channelId, "Rekaman meeting", NotificationManager.IMPORTANCE_LOW)
			)
		}
		val notification = Notification.Builder(this, channelId)
			.setSmallIcon(applicationInfo.icon)
			.setContentTitle("Panara Live")
			.setContentText("Rekaman meeting berjalan di latar belakang")
			.setOngoing(true)
			.build()
		if (Build.VERSION.SDK_INT >= 29) {
			startForeground(
				NOTIFICATION_ID,
				notification,
				ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
			)
		} else {
			startForeground(NOTIFICATION_ID, notification)
		}
	}

	private fun setupVideo(proj: MediaProjection) {
		val format = MediaFormat.createVideoFormat(
			MediaFormat.MIMETYPE_VIDEO_AVC, VIDEO_WIDTH, VIDEO_HEIGHT
		).apply {
			setInteger(
				MediaFormat.KEY_COLOR_FORMAT,
				MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
			)
			setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
			setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS)
			setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
		}
		val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
		encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
		val inputSurface = encoder.createInputSurface()
		encoder.start()
		videoEncoder = encoder

		virtualDisplay = proj.createVirtualDisplay(
			"learnly-record", VIDEO_WIDTH, VIDEO_HEIGHT,
			resources.displayMetrics.densityDpi,
			DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
			inputSurface, null, null
		)

		videoThread = HandlerThread("record-video-drain").apply { start() }
		val handler = Handler(videoThread!!.looper)
		handler.post { drainVideo(encoder) }
	}

	/**
	 * Audio: mic (wajib) + playback capture internal (API 29+, opsional).
	 * Catatan jujur: AudioPlaybackCapture hanya menangkap USAGE_MEDIA/GAME —
	 * audio remote WebRTC sering memakai USAGE_VOICE_COMMUNICATION yang tidak
	 * bisa di-capture, sehingga suara peserta mungkin hanya terekam secara
	 * akustik lewat speaker. Kualitas = trade-off rekaman on-device.
	 */
	private fun setupAudio(proj: MediaProjection) {
		try {
			val minBuf = AudioRecord.getMinBufferSize(
				SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
			)
			val bufSize = maxOf(minBuf, SAMPLE_RATE) // ± 1 detik
			val mic = AudioRecord(
				MediaRecorder.AudioSource.VOICE_COMMUNICATION,
				SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
				AudioFormat.ENCODING_PCM_16BIT, bufSize
			)
			if (mic.state != AudioRecord.STATE_INITIALIZED) {
				mic.release()
				throw IllegalStateException("AudioRecord mic tidak terinisialisasi")
			}
			micRecord = mic

			if (Build.VERSION.SDK_INT >= 29) {
				try {
					val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(proj)
						.addMatchingUsage(AudioAttributes.USAGE_MEDIA)
						.addMatchingUsage(AudioAttributes.USAGE_GAME)
						.addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
						.build()
					val playback = AudioRecord.Builder()
						.setAudioPlaybackCaptureConfig(playbackConfig)
						.setAudioFormat(
							AudioFormat.Builder()
								.setEncoding(AudioFormat.ENCODING_PCM_16BIT)
								.setSampleRate(SAMPLE_RATE)
								.setChannelMask(AudioFormat.CHANNEL_IN_MONO)
								.build()
						)
						.setBufferSizeInBytes(bufSize)
						.build()
					if (playback.state == AudioRecord.STATE_INITIALIZED) {
						playbackRecord = playback
					} else {
						playback.release()
					}
				} catch (t: Throwable) {
					Log.w(TAG, "Playback capture tidak tersedia (opsional)", t)
				}
			}

			val audioFormat = MediaFormat.createAudioFormat(
				MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1
			).apply {
				setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
				setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE)
				setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, bufSize * 2)
			}
			val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
			encoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
			encoder.start()
			audioEncoder = encoder

			hasAudio = true
			mic.startRecording()
			playbackRecord?.startRecording()

			drainThread = Thread({ drainAudio(encoder) }, "record-audio-drain").apply { start() }
			audioThread = Thread({ captureAudio(bufSize) }, "record-audio-capture").apply { start() }
		} catch (t: Throwable) {
			// Gagal audio tidak mematikan rekaman video — lanjut tanpa audio.
			Log.w(TAG, "Audio capture gagal — melanjutkan tanpa audio", t)
			hasAudio = false
			audioEncoder?.let { runCatching { it.stop(); it.release() } }
			audioEncoder = null
			micRecord?.let { runCatching { it.release() } }
			micRecord = null
			playbackRecord?.let { runCatching { it.release() } }
			playbackRecord = null
		}
	}

	private fun captureAudio(bufSize: Int) {
		val mic = micRecord ?: return
		val playback = playbackRecord
		val pcm = ShortArray(bufSize / 2)
		val enc = audioEncoder ?: return
		while (running) {
			val readMic = mic.read(pcm, 0, pcm.size)
			if (readMic <= 0) { Thread.sleep(10); continue }
			if (playback != null) {
				val other = ShortArray(pcm.size)
				val readOther = playback.read(other, 0, other.size)
				if (readOther > 0) {
					for (i in 0 until minOf(readMic, readOther)) {
						val mixed = pcm[i] + other[i]
						pcm[i] = mixed.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
					}
				}
			}
			feedAudioEncoder(enc, pcm, readMic)
		}
		finishAudioEncoder(enc)
	}

	private fun feedAudioEncoder(enc: MediaCodec, pcm: ShortArray, count: Int) {
		val bytes = ByteBuffer.allocate(count * 2)
		for (i in 0 until bytes.capacity() step 2) {
			val s = pcm[i / 2]
			bytes.put((s.toInt() and 0xFF).toByte())
			bytes.put(((s.toInt() shr 8) and 0xFF).toByte())
		}
		bytes.flip()
		try {
			val index = enc.dequeueInputBuffer(10_000)
			if (index >= 0) {
				val input = enc.getInputBuffer(index)
				input?.clear()
				input?.put(bytes)
				enc.queueInputBuffer(index, 0, bytes.capacity(), System.nanoTime() / 1000, 0)
			}
		} catch (t: Throwable) {
			Log.w(TAG, "feedAudioEncoder gagal", t)
		}
	}

	private fun finishAudioEncoder(enc: MediaCodec) {
		try {
			val index = enc.dequeueInputBuffer(100_000)
			if (index >= 0) {
				enc.queueInputBuffer(
					index, 0, 0, System.nanoTime() / 1000,
					MediaCodec.BUFFER_FLAG_END_OF_STREAM
				)
			}
		} catch (t: Throwable) {
			Log.w(TAG, "finishAudioEncoder gagal", t)
		}
	}

	private fun drainVideo(encoder: MediaCodec) {
		val bufferInfo = MediaCodec.BufferInfo()
		var eos = false
		while (!eos) {
			try {
				val index = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
				when {
					index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> addTrack(encoder.outputFormat, isVideo = true)
					index >= 0 -> {
					val buffer = encoder.getOutputBuffer(index)
						if (buffer != null && bufferInfo.size > 0 &&
							(bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
						) {
							writeSample(buffer, bufferInfo, videoTrack)
						}
						eos = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
						encoder.releaseOutputBuffer(index, false)
					}
				}
			} catch (t: Throwable) {
				Log.w(TAG, "drainVideo gagal", t)
				return
			}
		}
		onTrackDrained(isVideo = true)
	}

	private fun drainAudio(encoder: MediaCodec) {
		val bufferInfo = MediaCodec.BufferInfo()
		var eos = false
		while (!eos) {
			try {
				val index = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
				when {
					index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> addTrack(encoder.outputFormat, isVideo = false)
					index >= 0 -> {
						val buffer = encoder.getOutputBuffer(index)
						if (buffer != null && bufferInfo.size > 0 &&
							(bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
						) {
							writeSample(buffer, bufferInfo, audioTrack)
						}
						eos = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
						encoder.releaseOutputBuffer(index, false)
					}
				}
			} catch (t: Throwable) {
				Log.w(TAG, "drainAudio gagal", t)
				return
			}
		}
		onTrackDrained(isVideo = false)
	}

	private fun addTrack(format: MediaFormat, isVideo: Boolean) {
		synchronized(muxLock) {
			val mux = muxer ?: return
			val track = mux.addTrack(format)
			if (isVideo) videoTrack = track else audioTrack = track
			val ready = videoTrack >= 0 && (!hasAudio || audioTrack >= 0)
			if (ready && !muxerStarted) {
				try {
					mux.start()
					muxerStarted = true
				} catch (t: Throwable) {
					Log.w(TAG, "muxer.start() gagal", t)
				}
			}
		}
	}

	private fun writeSample(buffer: ByteBuffer, info: MediaCodec.BufferInfo, track: Int) {
		synchronized(muxLock) {
			val mux = muxer ?: return
			try {
				if (track >= 0 && muxerStarted) {
					mux.writeSampleData(track, buffer, info)
				}
			} catch (t: Throwable) {
				Log.w(TAG, "writeSampleData gagal", t)
			}
		}
	}

	private fun onTrackDrained(isVideo: Boolean) {
		if (isVideo) {
			// Video EOS — muxer boleh distop setelah drain selesai.
			finishMuxer()
		}
	}

	private fun finishMuxer() {
		synchronized(muxLock) {
			try {
				if (muxerStarted) {
					muxer?.stop()
					muxerStarted = false
				}
			} catch (t: Throwable) {
				Log.w(TAG, "muxer.stop() gagal", t)
			}
		}
	}

	/** Berhenti & finalisasi. Dipanggil dari module JS atau panel sistem. */
	fun stopEngine(notifyError: Boolean, reason: String = "user_stop") {
		if (!running) {
			stopSelf()
			return
		}
		running = false
		try {
			videoEncoder?.signalEndOfInputStream()
		} catch (t: Throwable) {
			Log.w(TAG, "signalEndOfInputStream gagal", t)
		}
		// Beri waktu drain thread menyelesaikan EOS.
		Thread {
			Thread.sleep(1500)
			cleanup()
			val duration = if (startedAtMs > 0) {
				((System.currentTimeMillis() - startedAtMs) / 1000).toInt()
			} else 0
			if (!notifyError) {
				ScreenRecordModule.emitStopped(outputPath, duration, reason)
			}
			stopSelf()
		}.start()
	}

	private fun cleanup() {
		instance = null
		runCatching { virtualDisplay?.release() }
		virtualDisplay = null
		runCatching { projection?.stop() }
		projection = null
		runCatching { micRecord?.stop() }
		runCatching { micRecord?.release() }
		micRecord = null
		runCatching { playbackRecord?.stop() }
		runCatching { playbackRecord?.release() }
		playbackRecord = null
		runCatching { videoEncoder?.stop() }
		runCatching { videoEncoder?.release() }
		videoEncoder = null
		runCatching { audioEncoder?.stop() }
		runCatching { audioEncoder?.release() }
		audioEncoder = null
		runCatching { muxer?.release() }
		muxer = null
		videoThread?.quitSafely()
		videoThread = null
	}

	private fun sendError(message: String) {
		ScreenRecordModule.emitError(message)
	}

	override fun onDestroy() {
		if (running) running = false
		cleanup()
		super.onDestroy()
	}
}
