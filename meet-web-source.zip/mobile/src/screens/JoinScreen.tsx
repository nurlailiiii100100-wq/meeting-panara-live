import { useCallback, useEffect, useRef, useState } from 'react';
import {
	ActivityIndicator,
	Image,
	KeyboardAvoidingView,
	Linking,
	Modal,
	Platform,
	Pressable,
	ScrollView,
	StyleSheet,
	Text,
	TextInput,
	View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
	checkHostJoinCode,
	fetchMeetingMeta,
	issueToken,
	setApiBaseUrl,
	getApiBaseUrl,
} from '../api/backend';
import { ApiError } from '../api/types';
// Aset gambar logo (ID resource statis dari Metro — lihat assets/images.d.ts).
import panaraLogo from '../assets/panara-logo.png';
import { DEFAULT_API_BASE_URL } from '../config';
import { parseMeetingCodeFromUrl, parseOriginFromUrl } from '../meeting/deepLink';
import type { JoinSession } from '../meeting/useMeetingSession';
import {
	getPersistentUserId,
	getSavedName,
	getSavedServerUrl,
	saveName,
	saveServerUrl,
} from '../storage/prefs';

interface JoinScreenProps {
	onJoined: (session: JoinSession) => void;
}

/**
 * True kalau kegagalan terjadi SEBELUM server sempat menjawab: URL server
 * belum diisi, jaringan mati, DNS gagal, TLS ditolak, atau worker tak
 * menjawab. Dipakai untuk memunculkan "Pengaturan server" otomatis sebagai
 * jalan darurat — user yang salah URL tidak perlu menebak-nebak.
 *
 * Catatan: `fetch()` React Native melempar `TypeError` ("Network request
 * failed"), bukan yang punya status HTTP, sehingga kasus itu dibedakan di
 * sini. `ApiError` berstatus 0 hanya lahir dari `apiFetch` saat URL kosong.
 */
function isConnectionError(error: unknown): boolean {
	if (error instanceof ApiError) return error.status === 0;
	return error instanceof TypeError;
}

/**
 * URL launch aplikasi hanya diproses SEKALI per proses. Tanpa flag ini,
 * saat user keluar meeting (JoinScreen mount ulang) `Linking.getInitialURL()`
 * masih mengembalikan URL yang sama dan user langsung ditarik masuk lagi.
 * Level module (bukan state) karena JoinScreen memang di-unmount/remount.
 */
let initialUrlConsumed = false;

/**
 * Layar masuk meeting mobile. Mengikuti alur yang sama dengan halaman Home
 * di aplikasi web (pre-check jadwal → gate kode host → POST /api/tokens),
 * sehingga mobile dan web memakai kontrak backend yang identik.
 */
export default function JoinScreen({ onJoined }: JoinScreenProps) {
	const [userId, setUserId] = useState('');
	const [serverUrl, setServerUrl] = useState(DEFAULT_API_BASE_URL);
	// Kartu "Pengaturan server" tersembunyi secara default — URL backend sudah
	// ditanem di build rilis (lihat config.ts). Otomatis terbuka hanya kalau
	// koneksi ke server gagal (lihat isConnectionError) atau URL belum ada.
	const [showServer, setShowServer] = useState(false);
	const [serverTrouble, setServerTrouble] = useState(false);
	const [name, setName] = useState('');
	const [meetingCode, setMeetingCode] = useState('');
	const [hostCode, setHostCode] = useState('');
	const [showHostCode, setShowHostCode] = useState(false);
	const [hostCodeError, setHostCodeError] = useState<string | null>(null);
	const [hostCodeChecking, setHostCodeChecking] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [loading, setLoading] = useState(false);

	// True setelah userId + server URL siap — auto-join deep link menunggu ini
	// agar tidak mengirim request dengan userId kosong.
	const [ready, setReady] = useState(false);

	// Safe area bawah (gesture nav / home indicator) supaya konten terakhir
	// tidak mepet area navigasi sistem.
	const insets = useSafeAreaInsets();

	useEffect(() => {
		void (async () => {
			const [id, savedName, savedUrl] = await Promise.all([
				getPersistentUserId(),
				getSavedName(),
				getSavedServerUrl(),
			]);
			setUserId(id);
			if (savedName) setName(savedName);
			const url = savedUrl || DEFAULT_API_BASE_URL;
			setServerUrl(url);
			setApiBaseUrl(url);
			setShowServer(!url);
			setReady(true);
		})();
	}, []);

	const applyServerUrl = useCallback((value: string) => {
		const trimmed = value.trim().replace(/\/+$/, '');
		setServerUrl(trimmed);
		setApiBaseUrl(trimmed);
		// User sedang memperbaiki URL — pesan "tidak bisa menghubungi server"
		// tidak relevan lagi sampai percobaan berikutnya gagal.
		setServerTrouble(false);
		void saveServerUrl(trimmed);
	}, []);

	/**
	 * Ambil token lalu masuk room. `overrides` dipakai auto-join dari deep
	 * link: kode & nama bisa dikirim langsung karena state `meetingCode` /
	 * `name` belum tentu sudah ter-update saat Linking callback berjalan.
	 */
	const join = useCallback(
		async (
			asMember = false,
			overrides?: { code?: string; name?: string },
		) => {
			const code = (overrides?.code ?? meetingCode).trim();
			const displayName = (overrides?.name ?? name).trim();
			if (!code) {
				setError('Kode meeting wajib diisi sebelum masuk.');
				return;
			}
			if (!displayName) {
				setError('Nama wajib diisi sebelum masuk meeting.');
				return;
			}
			if (loading) return;
			setError(null);
			setLoading(true);
			try {
				const hostCodeToSend = asMember ? '' : hostCode.trim();

				// Pre-check: jadwal + gate kode host (sama seperti web).
				try {
					const meta = await fetchMeetingMeta(code);
					const status = meta.status;
					if (status === 'expired' || status === 'ended' || status === 'deleted') {
						throw new Error(
							'Meeting ini sudah berakhir atau tidak tersedia.',
						);
					}
					if (meta.scheduled_at && !meta.started_at) {
						const scheduled = new Date(meta.scheduled_at).getTime();
						const now = Date.now();
						// Durasi slot kelas dari backend — sama dengan aturan web
						// (Home.tsx memakai duration_minutes || 60). Jangan hardcoded.
						const durationMs = (meta.duration_minutes || 60) * 60 * 1000;
						if (now < scheduled) {
							throw new Error(
								'Kelas ini dijadwalkan pada ' +
									new Date(meta.scheduled_at).toLocaleString() +
									'. Silakan bergabung setelah jadwal dimulai.',
							);
						}
						if (now > scheduled + durationMs) {
							throw new Error(
								'Kelas ini sudah terlewat dari jadwal. Hubungi pengajar untuk membuka kembali.',
							);
						}
					}
					const tentorNames = Array.isArray(meta.tentor_names)
						? meta.tentor_names
						: [];
					const needsHostCode =
						meta.host_code_set === true &&
						tentorNames.some(
							t =>
								String(t).trim().toLowerCase() ===
								displayName.toLowerCase(),
						);
					if (needsHostCode && !hostCodeToSend && !asMember) {
						setShowHostCode(true);
						setHostCodeError(null);
						setLoading(false);
						return;
					}
				} catch (metaError) {
					if (metaError instanceof ApiError && metaError.code === 'NOT_FOUND') {
						throw new Error('Meeting tidak ditemukan. Cek kode meeting.');
					}
					if (!(metaError instanceof ApiError)) throw metaError;
					// Error lain dari pre-check diabaikan — biarkan /api/tokens
					// yang memutuskan (server adalah sumber kebenaran).
				}

				const token = await issueToken({
					meetingId: code,
					userId,
					name: displayName,
					presetName: 'group_call_participant',
					hostCode: hostCodeToSend || undefined,
				});

				await saveName(displayName);
				onJoined({
					authToken: token.auth_token,
					meetingCode: code,
					displayName,
					userId,
					role: token.user_role === 'admin' ? 'admin' : 'member',
					// Waktu berakhir resmi dari backend — dipakai MeetingScreen
					// untuk mengeluarkan peserta tepat saat durasi habis.
					expiresAt: token.expires_at ?? null,
					uploadToken: token.upload_token ?? null,
					autoRecord: token.auto_record === true,
				});
			} catch (joinError) {
				const message =
					joinError instanceof ApiError
						? joinError.message
						: joinError instanceof Error
							? joinError.message
							: 'Unable to join with that code';
				setError(message);
				// Backend tak bisa dihubungi (bukan error meeting/kode): buka
				// pengaturan server otomatis supaya user bisa perbaiki URL.
				if (isConnectionError(joinError)) setServerTrouble(true);
			} finally {
				setLoading(false);
			}
		},
		[hostCode, loading, meetingCode, name, onJoined, userId],
	);

	// Simpan versi join terbaru agar listener deep link (yang di-subscribe
	// sekali) selalu memanggil closure paling baru.
	const joinRef = useRef(join);
	useEffect(() => {
		joinRef.current = join;
	}, [join]);

	/**
	 * Deep link meeting — supaya tap link `https://live.panaragroup.web.id/meeting/<kode>`
	 * (atau cadangan `learnlymeet://meeting/<kode>`) langsung masuk room, bukan
	 * hanya membuka layar Join dengan form kosong.
	 *
	 * - Kode meeting selalu diisi otomatis dari link.
	 * - Bila nama sudah pernah dipakai (tersimpan), join langsung dijalankan
	 *   tanpa input apa pun — sama seperti klik link di browser PC.
	 * - Bila nama belum ada, form tetap ditampilkan (user tinggal isi nama,
	 *   kode sudah terisi) — karena worker selalu butuh nama tampil.
	 */
	const appliedUrlRef = useRef<string | null>(null);
	useEffect(() => {
		if (!ready) return; // tunggu userId + server URL siap
		let mounted = true;

		const handleDeepLink = async (url: string) => {
			if (!url || appliedUrlRef.current === url) return;
			appliedUrlRef.current = url;

			const code = parseMeetingCodeFromUrl(url);
			if (!code) return;

			// Jaringan darurat: kalau URL server tersimpan kosong/terhapus,
			// pakai origin link sebagai backend (web & worker berbagi domain yang
			// sama). Build rilis normal sudah membawa URL produksi dari
			// DEFAULT_API_BASE_URL, jadi blok ini hanya untuk pemulihan.
			if (!getApiBaseUrl()) {
				const origin = parseOriginFromUrl(url);
				if (origin) applyServerUrl(origin);
			}

			setMeetingCode(code);
			setError(null);

			const savedName = (await getSavedName()).trim();
			if (!mounted || !savedName) return; // belum ada nama → tunggu input
			setName(savedName);
			// joinRef sudah ter-update pada render ini (efek joinRef dideklarasikan
			// sebelum efek ini sehingga selalu berjalan lebih dulu).
			await joinRef.current(false, { code, name: savedName });
		};

		// URL yang membuka aplikasi (cold start dari link). Hanya sekali per
		// proses — lihat initialUrlConsumed.
		if (!initialUrlConsumed) {
			initialUrlConsumed = true;
			void Linking.getInitialURL()
				.then(url => {
					if (mounted && url) void handleDeepLink(url);
				})
				.catch(() => {
					/* tidak ada URL — abaikan */
				});
		}

		// URL baru saat aplikasi sudah terbuka (tap link lagi dari chat).
		const subscription = Linking.addEventListener('url', event => {
			void handleDeepLink(event.url);
		});

		return () => {
			mounted = false;
			subscription.remove();
		};
	}, [applyServerUrl, ready]);

	const submitHostCode = useCallback(async () => {
		if (!hostCode.trim() || !name.trim() || !meetingCode.trim()) return;
		setHostCodeError(null);
		setHostCodeChecking(true);
		try {
			const result = await checkHostJoinCode(
				meetingCode.trim(),
				name.trim(),
				hostCode.trim(),
			);
			if (!result.valid) {
				if (result.reason === 'locked') {
					const minutes = Math.ceil(
						(result.retry_after_seconds ?? 600) / 60,
					);
					setHostCodeError(
						`Terlalu banyak percobaan kode host. Coba lagi dalam ${minutes} menit.`,
					);
				} else {
					setHostCodeError('Kode host salah. Coba lagi.');
				}
				return;
			}
			setShowHostCode(false);
			await join();
		} catch (hostError) {
			const code =
				hostError instanceof ApiError ? hostError.code : 'UNKNOWN';
			setHostCodeError(
				code === 'LOCKED'
					? 'Terlalu banyak percobaan kode host. Coba lagi nanti.'
					: code === 'HOST_CODE_INVALID' || code === 'INVALID'
						? 'Kode host salah. Coba lagi.'
						: 'Gagal memeriksa kode host. Coba lagi.',
			);
		} finally {
			setHostCodeChecking(false);
		}
	}, [hostCode, join, meetingCode, name]);

	// Tutup popup kode host dan reset semua state-nya (dipakai tombol ✕,
	// tap backdrop, dan tombol "Peserta").
	const closeHostCode = useCallback(() => {
		setShowHostCode(false);
		setHostCode('');
		setHostCodeError(null);
	}, []);

	return (
		<KeyboardAvoidingView style={styles.flex} behavior="height">
			<ScrollView
				contentContainerStyle={[
					styles.scroll,
					{ paddingBottom: insets.bottom + 24 },
				]}
				keyboardShouldPersistTaps="handled"
			>
				{/* Kartu putih: logo Panara berlatar putih, jadi latar kartu
				    harus putih agar menyatu — hijau #125938 pada latar gelap
				    hanya 2.29:1 kontras (nyaris tak terlihat). */}
				<View style={styles.logoCard}>
					<Image
						source={panaraLogo}
						style={styles.logo}
						accessibilityLabel="Logo Panara"
					/>
				</View>
				<Text style={styles.title}>Panara Live</Text>
				<Text style={styles.subtitle}>
					Masuk meeting dengan kode dari penyelenggara.
				</Text>

				<Text style={styles.label}>Nama</Text>
				<TextInput
					style={styles.input}
					value={name}
					onChangeText={setName}
					placeholder="Nama Anda"
					placeholderTextColor="#6b7791"
					autoCapitalize="words"
				/>

				<Text style={styles.label}>Kode Meeting</Text>
				<TextInput
					style={styles.input}
					value={meetingCode}
					onChangeText={setMeetingCode}
					placeholder="Contoh: abc123"
					placeholderTextColor="#6b7791"
					autoCapitalize="none"
					autoCorrect={false}
				/>

				{error ? <Text style={styles.error}>{error}</Text> : null}

				<Pressable
					style={[
						styles.button,
						styles.buttonPrimary,
						styles.buttonWide,
						loading && styles.buttonDisabled,
					]}
					onPress={() => void join()}
					disabled={loading}
					accessibilityRole="button"
				>
					{loading ? (
						<ActivityIndicator color="#fff" />
					) : (
						<Text style={styles.buttonText}>Masuk Meeting</Text>
					)}
				</Pressable>

				{showServer || serverTrouble || !serverUrl.trim() ? (
					<Pressable
						style={styles.linkButton}
						onPress={() => {
							setShowServer(value => !value);
							setServerTrouble(false);
						}}
					>
						<Text style={styles.linkText}>
							{showServer ? 'Sembunyikan pengaturan server' : 'Pengaturan server'}
						</Text>
					</Pressable>
				) : null}
				{showServer ? (
					<View style={styles.hostCard}>
						<Text style={styles.hostHint}>
							{serverTrouble
								? 'Tidak bisa menghubungi server. Periksa koneksi internet HP, lalu pastikan URL server di bawah sudah benar.'
								: 'URL backend yang sama dengan aplikasi web (contoh: https://meet.example.com).'}
						</Text>
						<TextInput
							style={styles.input}
							value={serverUrl}
							onChangeText={applyServerUrl}
							placeholder="https://..."
							placeholderTextColor="#6b7791"
							autoCapitalize="none"
							autoCorrect={false}
							keyboardType="url"
						/>
						<Text style={styles.hint}>Server aktif: {getApiBaseUrl() || '-'}</Text>
					</View>
				) : null}
			</ScrollView>

			{/* Popup kode host — muncul saat nama terdaftar sebagai tentor dan
			    meeting memakai kode host. Berdiri sendiri (Modal) agar form di
			    belakang tidak terdorong. */}
			<Modal
				visible={showHostCode}
				transparent
				animationType="fade"
				onRequestClose={closeHostCode}
			>
				<KeyboardAvoidingView
					style={styles.modalOverlay}
					behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
				>
					{/* Tap backdrop untuk menutup */}
					<Pressable style={styles.modalBackdrop} onPress={closeHostCode} />

					<View style={styles.modalCard}>
						{/* Judul + tombol tutup */}
						<View style={styles.modalHeader}>
							<Text style={styles.modalTitle}>Masuk sebagai Host</Text>
							<Pressable
								onPress={closeHostCode}
								hitSlop={12}
								accessibilityRole="button"
								accessibilityLabel="Tutup"
							>
								<Text style={styles.modalClose}>✕</Text>
							</Pressable>
						</View>

						<Text style={styles.modalHint}>
							Nama Anda terdaftar sebagai tentor untuk meeting ini.
						</Text>

						<Text style={styles.label}>Kode host</Text>
						<TextInput
							style={styles.input}
							value={hostCode}
							onChangeText={setHostCode}
							placeholder="Kode host"
							placeholderTextColor="#6b7791"
							autoCapitalize="none"
							autoCorrect={false}
							secureTextEntry
							autoFocus
						/>
						{hostCodeError ? (
							<Text style={styles.error}>{hostCodeError}</Text>
						) : null}

						{/* Dua tombol pendek: Peserta (ghost) & Host (utama) */}
						<View style={styles.modalRow}>
							<Pressable
								style={[styles.modalButton, styles.buttonGhost]}
								onPress={() => {
									closeHostCode();
									void join(true);
								}}
								disabled={hostCodeChecking}
							>
								<Text style={styles.buttonGhostText}>Peserta</Text>
							</Pressable>
							<Pressable
								style={[
									styles.modalButton,
									styles.buttonPrimary,
									(!hostCode.trim() || hostCodeChecking) &&
										styles.buttonDisabled,
								]}
								onPress={() => void submitHostCode()}
								disabled={hostCodeChecking || !hostCode.trim()}
							>
								{hostCodeChecking ? (
									<ActivityIndicator color="#fff" size="small" />
								) : (
									<Text style={styles.buttonText}>Host</Text>
								)}
							</Pressable>
						</View>
					</View>
				</KeyboardAvoidingView>
			</Modal>
		</KeyboardAvoidingView>
	);
}

const styles = StyleSheet.create({
	flex: { flex: 1, backgroundColor: '#0b0f17' },
	scroll: {
		padding: 24,
		paddingTop: 64,
		gap: 8,
		maxWidth: 520,
		width: '100%',
		alignSelf: 'center',
	},
	logoCard: {
		alignSelf: 'center',
		backgroundColor: '#fff',
		borderRadius: 24,
		padding: 16,
		marginBottom: 4,
		shadowColor: '#000',
		shadowOpacity: 0.4,
		shadowRadius: 14,
		shadowOffset: { width: 0, height: 6 },
		elevation: 6,
	},
	logo: {
		width: 190,
		height: 142,
		resizeMode: 'contain',
	},
	title: {
		color: '#fff',
		fontSize: 28,
		fontWeight: '800',
		textAlign: 'center',
	},
	subtitle: {
		color: '#8ea0c0',
		fontSize: 14,
		textAlign: 'center',
		marginBottom: 16,
	},
	label: { color: '#c8d3ea', fontSize: 13, fontWeight: '600', marginTop: 8 },
	input: {
		backgroundColor: '#151a24',
		borderRadius: 10,
		borderWidth: 1,
		borderColor: '#273043',
		color: '#fff',
		paddingHorizontal: 14,
		paddingVertical: 12,
		fontSize: 15,
		marginTop: 6,
	},
	button: {
		borderRadius: 10,
		paddingVertical: 14,
		alignItems: 'center',
		justifyContent: 'center',
		marginTop: 12,
	},
	buttonWide: { marginTop: 20 },
	buttonPrimary: { backgroundColor: '#2f6bff' },
	buttonGhost: { backgroundColor: '#273043', flex: 1 },
	buttonDisabled: { opacity: 0.6 },
	buttonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
	buttonGhostText: { color: '#c8d3ea', fontWeight: '600', fontSize: 13 },
	row: { flexDirection: 'row', gap: 8 },
	hostCard: {
		backgroundColor: '#151a24',
		borderRadius: 12,
		borderWidth: 1,
		borderColor: '#273043',
		padding: 14,
		marginTop: 12,
		gap: 6,
	},
	hostTitle: { color: '#fff', fontSize: 16, fontWeight: '700' },
	hostHint: { color: '#8ea0c0', fontSize: 12 },
	hint: { color: '#6b7791', fontSize: 11 },
	error: { color: '#f87171', fontSize: 13, marginTop: 8 },
	linkButton: { alignSelf: 'center', paddingVertical: 12 },
	linkText: { color: '#8ea0c0', fontSize: 13 },
	// Gaya popup kode host (Modal)
	modalOverlay: {
		flex: 1,
		justifyContent: 'center',
		paddingHorizontal: 24,
	},
	modalBackdrop: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		backgroundColor: 'rgba(0,0,0,0.6)',
	},
	modalCard: {
		backgroundColor: '#151a24',
		borderRadius: 16,
		borderWidth: 1,
		borderColor: '#273043',
		padding: 20,
		width: '100%',
		maxWidth: 380,
		alignSelf: 'center',
	},
	modalHeader: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginBottom: 4,
	},
	modalTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
	modalClose: { color: '#8ea0c0', fontSize: 18, fontWeight: '700', padding: 2 },
	modalHint: { color: '#8ea0c0', fontSize: 13, marginBottom: 8 },
	modalRow: { flexDirection: 'row', gap: 8, marginTop: 16 },
	modalButton: {
		flex: 1,
		borderRadius: 10,
		paddingVertical: 13,
		alignItems: 'center',
		justifyContent: 'center',
	},
});
