import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
	ActivityIndicator,
	AppState,
	Pressable,
	StyleSheet,
	Text,
	View,
} from 'react-native';
import { RealtimeKitProvider } from '@cloudflare/realtimekit-react-native';
import { RtkMeeting, RtkUIProvider } from '@cloudflare/realtimekit-react-native-ui';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import StatusBanner from '../components/StatusBanner';
import { fetchMeetingMeta } from '../api/backend';
import { buildMobileUiConfig } from '../meeting/mobileUiConfig';
import { useRecordingKitBridge } from '../meeting/recordingKitBridge';
import { useScreenShareFeedback } from '../meeting/screenShare/useScreenShareFeedback';
import {
	formatElapsed,
	useNativeRecorder,
} from '../meeting/useNativeRecorder';
import {
	useMeetingSession,
	type JoinSession,
	type LeaveState,
} from '../meeting/useMeetingSession';

interface MeetingScreenProps {
	session: JoinSession;
	onLeave: () => void;
}

const KICKED_MESSAGE = 'Anda telah dikeluarkan dari meeting oleh host.';
const EXPIRED_MESSAGE = 'Waktu meeting telah berakhir.';
const ENDED_MESSAGE = 'Meeting telah diakhiri oleh host.';
// Interval pemeriksaan kedaluwarsa. Keputusan selalu dihitung dari
// Date.now() vs expires_at (bukan hitungan tick), sehingga tick yang
// terlambat/terlewat saat app di background tidak membuat meeting tetap hidup.
const EXPIRY_TICK_MS = 5000;
// Interval polling status meeting dari backend (paralel checkMeetingStatus web
// yang 3 detik; mobile cukup 30 detik karena tidak melakukan deteksi kick).
const STATUS_POLL_MS = 30000;

/**
 * Layar meeting mobile. UI memakai RtkMeeting dari UI kit resmi
 * (@cloudflare/realtimekit-react-native-ui) — komponen yang sama dengan
 * aplikasi web (PC), termasuk layar setup sebelum join, grid, dan controlbar
 * dengan tombol share "Share Screen"/"Stop Sharing".
 *
 * Ditambahkan di atas UI kit:
 * - banner error screen share berbahasa Indonesia (probe native),
 * - pesan kicked + navigasi kembali ke layar masuk (paralel Meeting.tsx web).
 */
export default function MeetingScreen({ session, onLeave }: MeetingScreenProps) {
	const { meeting, errorMessage } = useMeetingSession(session);
	const [notice, setNotice] = useState<string | null>(null);
	const insets = useSafeAreaInsets();

	// Ref terkini untuk dipakai callback yang hidup lintas render (efek
	// kedaluwarsa/polling) tanpa perlu masuk dependency array.
	const meetingRef = useRef(meeting);
	meetingRef.current = meeting;
	const recorderRef = useRef<ReturnType<typeof useNativeRecorder> | null>(null);
	// Guard idempoten: teardown akhir meeting hanya boleh berjalan sekali.
	const terminatedRef = useRef(false);

	// Paralel dengan Meeting.tsx (web): roomLeft → kembali ke layar masuk;
	// state disconnected / connected-meeting dibiarkan (penanganan jaringan kit).
	// Saat akhir meeting sedang ditangani (leave() dipanggil sendiri), jalur ini
	// tidak ikut menutup layar — banner dulu, lalu onLeave().
	useEffect(() => {
		if (!meeting) return;
		const handler = ({ state }: { state?: LeaveState }) => {
			if (state === 'disconnected' || state === 'connected-meeting') return;
			if (terminatedRef.current) return;
			if (state === 'kicked') {
				setNotice(KICKED_MESSAGE);
				setTimeout(() => onLeave(), 2000);
				return;
			}
			onLeave();
		};
		meeting.self.on('roomLeft', handler);
		return () => {
			meeting.self.off('roomLeft', handler);
		};
	}, [meeting, onLeave]);

	// Akhir meeting (issue #83): sumber kebenaran adalah expires_at & status dari
	// backend — field yang sama dipakai aplikasi web, bukan hitungan lokal.
	// Saat berakhir: hentikan screen share & rekaman, keluar dari room, tampilkan
	// banner, lalu kembali ke layar masuk. Idempoten lewat terminatedRef.
	const [deadlineMs, setDeadlineMs] = useState(() =>
		session.expiresAt ? Date.parse(session.expiresAt) : NaN,
	);

	const terminate = useCallback(
		(reason: 'expired' | 'ended') => {
			if (terminatedRef.current) return;
			terminatedRef.current = true;
			const current = meetingRef.current;
			void (async () => {
				// 1. Hentikan screen share yang masih aktif (API resmi SDK).
				try {
					if (current?.self?.screenShareEnabled) {
						await current.self.disableScreenShare();
					}
				} catch { /* share mungkin sudah berhenti */ }
				// 2. Hentikan rekaman client-side (host) — best effort.
				try {
					const rec = recorderRef.current;
					if (rec && rec.recordingState !== 'IDLE') {
						await rec.stop();
					}
				} catch { /* rekaman mungkin sudah berhenti */ }
				// 3. Banner sebelum keluar room (roomLeft diblokir terminatedRef).
				setNotice(reason === 'ended' ? ENDED_MESSAGE : EXPIRED_MESSAGE);
				// 4. Keluar dari room RTK — bukan sekadar menutup tampilan.
				try {
					if (current?.self?.roomJoined) await current.leave();
				} catch { /* room mungkin sudah tertutup */ }
				// 5. Kembali ke layar masuk.
				setTimeout(() => onLeave(), 2500);
			})();
		},
		[onLeave],
	);

	// Tick lokal: keputusan selalu Date.now() vs deadline (bukan hitungan tick),
	// sehingga tick yang terlambat/terlewat saat app di background tidak membuat
	// meeting tetap hidup. AppState 'active' memicu cek segera — timer Android/JS
	// bisa tertunda saat layar terkunci atau app berpindah aplikasi.
	useEffect(() => {
		if (!Number.isFinite(deadlineMs)) return;
		const check = () => {
			if (Date.now() >= deadlineMs) terminate('expired');
		};
		check();
		const timer = setInterval(check, EXPIRY_TICK_MS);
		const appStateSub = AppState.addEventListener('change', (state) => {
			if (state === 'active') check();
		});
		return () => {
			clearInterval(timer);
			appStateSub.remove();
		};
	}, [deadlineMs, terminate]);

	// Polling status ringan (paralel checkMeetingStatus di web, interval lebih
	// longgar): menutup celah yang tidak terlihat dari token — admin mengakhiri
	// meeting dari dashboard, deadline yang baru tercatat server setelah token
	// diterbitkan, dan perubahan durasi oleh admin.
	useEffect(() => {
		let cancelled = false;
		const poll = async () => {
			if (terminatedRef.current) return;
			try {
				const meta = await fetchMeetingMeta(session.meetingCode);
				if (cancelled || terminatedRef.current) return;
				if (
					meta.status === 'expired' ||
					meta.status === 'ended' ||
					meta.status === 'deleted'
				) {
					terminate(meta.status === 'ended' ? 'ended' : 'expired');
					return;
				}
				if (meta.expires_at) {
					const ms = Date.parse(meta.expires_at);
					if (Number.isFinite(ms)) {
						setDeadlineMs((prev) => (prev === ms ? prev : ms));
					}
				}
			} catch {
				/* jaringan bermasalah — coba lagi di tick berikutnya */
			}
		};
		void poll();
		const timer = setInterval(() => void poll(), STATUS_POLL_MS);
		const appStateSub = AppState.addEventListener('change', (state) => {
			if (state === 'active') void poll();
		});
		return () => {
			cancelled = true;
			clearInterval(timer);
			appStateSub.remove();
		};
	}, [session.meetingCode, terminate]);

	const isHost =
		session.role === 'admin' ||
		meeting?.self?.presetName === 'group_call_host';
	// Config dibangun ulang saat status host diketahui: member tidak mendapat
	// item Share Screen di menu More (lihat buildMobileUiConfig).
	const config = useMemo(() => buildMobileUiConfig(isHost), [isHost]);

	// Status screen share & kesiapan room untuk eksklusif MediaProjection
	// (Android hanya mengizinkan satu capture aktif). Dipolling ringan karena
	// RealtimeKitProvider (syarat useRealtimeKitSelector) dirender di bawah
	// komponen ini.
	const [isSharing, setIsSharing] = useState(false);
	const [roomJoined, setRoomJoined] = useState(false);
	useEffect(() => {
		if (!meeting) {
			setIsSharing(false);
			setRoomJoined(false);
			return;
		}
		const read = () => {
			try {
				setIsSharing(Boolean(meeting.self.screenShareEnabled));
				setRoomJoined(Boolean(meeting.self.roomJoined));
			} catch {
				/* self belum siap */
			}
		};
		read();
		const timer = setInterval(read, 1000);
		return () => clearInterval(timer);
	}, [meeting]);

	// Rekaman client-side (Android only, host only) — paralel useClientRecorder
	// di web. Aplikasi ini Android-only; tidak ada cloud recording sama sekali,
	// jadi tidak ada biaya Export di platform mana pun.
	const recorder = useNativeRecorder({
		meetingId: session.meetingCode,
		uploadToken: session.uploadToken ?? null,
		enabled: isHost,
		isScreenShareActive: () => isSharing,
	});
	recorderRef.current = recorder;
	// Arah sebaliknya: share ditolak saat rekaman berlangsung (konfirmasi dulu),
	// dan share seluruhnya khusus host.
	const share = useScreenShareFeedback(meeting, {
		isHost: () => isHost,
		isBlocked: () =>
			recorder.recordingState === 'RECORDING' ||
			recorder.recordingState === 'STARTING',
		stopRecording: () => recorder.stop(),
	});
	const canShowRecordButton = isHost && recorder.supported;

	// Sambungkan tombol rekam di menu More kit ke rekaman client-side ini:
	// start/stop kit di-override agar memanggil recorder kita (bukan Cloud
	// Export), dan statusnya disinkronkan ke toggle More — lihat recordingKitBridge.
	useRecordingKitBridge(meeting, recorder, canShowRecordButton);

	// Indikator top bar tampil saat rekam aktif atau proses memulai/
	// menghentikan/mengunggah. IDLE/ERROR tidak menampilkan indikator.
	const showRecIndicator =
		canShowRecordButton &&
		(recorder.recordingState === 'RECORDING' ||
			recorder.recordingState === 'STARTING' ||
			recorder.recordingState === 'STOPPING' ||
			recorder.recordingState === 'UPLOADING');

	// Nilai rekaman untuk efek auto-record. Didestruksi agar dependensi efek
	// berupa primitif + fungsi stabil — objek `recorder` dibuat baru tiap render
	// sehingga tidak layak masuk dependency array.
	const {
		recordingState,
		supported: recorderSupported,
		start: startRecording,
	} = recorder;

	// Auto-record: meeting yang di-set auto_record membuat host mulai merekam
	// otomatis (paralel maybeAutoRecord di Meeting.tsx web). Dimulai SETELAH
	// roomJoined benar-benar true karena startNativeRecording() memunculkan
	// dialog izin MediaProjection — tidak pantas muncul selama layar setup.
	// Bila screen share sedang aktif, auto-record ditunda sampai share selesai
	// (eksklusif MediaProjection) — dicek lagi pada polling berikutnya.
	const didAutoRecordRef = useRef(false);
	useEffect(() => {
		if (!roomJoined || !session.autoRecord || !isHost || !recorderSupported) {
			return;
		}
		if (didAutoRecordRef.current) return;
		if (recordingState !== 'IDLE' && recordingState !== 'ERROR') return;
		if (isSharing) return;
		didAutoRecordRef.current = true;
		void startRecording();
	}, [
		roomJoined,
		session.autoRecord,
		isHost,
		recorderSupported,
		recordingState,
		startRecording,
		isSharing,
	]);

	if (errorMessage) {
		return (
			<View style={styles.center}>
				<Text style={styles.centerTitle}>Gagal memulai meeting</Text>
				<Text style={styles.centerText}>{errorMessage}</Text>
				<Pressable style={styles.centerButton} onPress={onLeave}>
					<Text style={styles.centerButtonText}>Kembali</Text>
				</Pressable>
			</View>
		);
	}

	if (!meeting) {
		return (
			<View style={styles.center}>
				<ActivityIndicator color="#2f6bff" size="large" />
				<Text style={styles.centerText}>Menghubungkan ke meeting…</Text>
			</View>
		);
	}

	return (
		<View style={styles.container}>
			<RealtimeKitProvider value={meeting}>
				<RtkUIProvider>
					<RtkMeeting
						meeting={meeting}
						config={config}
						showSetupScreen
					/>
				</RtkUIProvider>
			</RealtimeKitProvider>

			{/* Overlay top: indikator rekam (timer/status) lalu banner error —
			    ditumpuk vertikal supaya tidak tumpang tindih. Start/stop rekam
			    sendiri lewat tombol di menu More kit (rtk-recording-toggle). */}
			{showRecIndicator ||
			notice ||
			share.errorMessage ||
			recorder.errorMessage ? (
				<View
					style={[styles.overlay, { top: insets.top + 8 }]}
					pointerEvents="box-none"
				>
					{showRecIndicator ? (
						<View style={styles.recIndicator}>
							{recorder.recordingState === 'UPLOADING' ? (
								<>
									<ActivityIndicator color="#fff" size="small" />
									<Text style={styles.recIndicatorText}>
										Mengunggah {recorder.uploadProgress}%
									</Text>
								</>
							) : (
								<>
									<View
										style={[
											styles.recDot,
											recorder.recordingState !== 'RECORDING' &&
												styles.recDotMuted,
										]}
									/>
									<Text style={styles.recIndicatorText}>
										{recorder.recordingState === 'RECORDING'
											? `REC ${formatElapsed(recorder.durationSeconds)}`
											: recorder.recordingState === 'STARTING'
												? 'Memulai rekaman…'
												: 'Menghentikan rekaman…'}
									</Text>
								</>
							)}
						</View>
					) : null}
					{notice ? <StatusBanner message={notice} kind="info" /> : null}
					{share.errorMessage ? (
						<StatusBanner
							message={share.errorMessage}
							kind="error"
							onDismiss={share.dismissError}
						/>
					) : null}
					{recorder.errorMessage ? (
						<StatusBanner
							message={recorder.errorMessage}
							kind="error"
							onDismiss={recorder.clearError}
						/>
					) : null}
				</View>
			) : null}
		</View>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: '#0b0f17',
	},
	center: {
		flex: 1,
		backgroundColor: '#0b0f17',
		alignItems: 'center',
		justifyContent: 'center',
		padding: 32,
		gap: 12,
	},
	centerTitle: { color: '#fff', fontSize: 20, fontWeight: '800' },
	centerText: { color: '#8ea0c0', fontSize: 14, textAlign: 'center' },
	centerButton: {
		backgroundColor: '#2f6bff',
		paddingHorizontal: 28,
		paddingVertical: 14,
		borderRadius: 12,
		marginTop: 8,
	},
	centerButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
	overlay: {
		position: 'absolute',
		left: 12,
		right: 12,
		gap: 8,
	},
	recIndicator: {
		alignSelf: 'center',
		flexDirection: 'row',
		alignItems: 'center',
		gap: 6,
		backgroundColor: '#7f1d1de6',
		paddingHorizontal: 12,
		paddingVertical: 6,
		borderRadius: 16,
	},
	recIndicatorText: { color: '#fff', fontWeight: '700', fontSize: 12 },
	recDot: {
		width: 8,
		height: 8,
		borderRadius: 4,
		backgroundColor: '#ef4444',
	},
	recDotMuted: { backgroundColor: '#f59e0b' },
});
