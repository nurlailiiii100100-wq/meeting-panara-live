/**
 * Uji unit parser deep link meeting.
 *
 * Parser ini menentukan apakah tap link di HP langsung membuka room atau
 * hanya membuka form Join (lihat deepLink.ts).
 */
import { parseMeetingCodeFromUrl, parseOriginFromUrl } from '../deepLink';

describe('parseMeetingCodeFromUrl', () => {
	it('mengambil kode dari App Link https web', () => {
		expect(
			parseMeetingCodeFromUrl('https://meet.panara.id/meeting/abc123'),
		).toBe('abc123');
	});

	it('mengabaikan query string (authToken) & hash', () => {
		expect(
			parseMeetingCodeFromUrl(
				'https://meet.panara.id/meeting/abc123?authToken=xyz#top',
			),
		).toBe('abc123');
	});

	it('mengambil kode dari skema kustom learnlymeet', () => {
		expect(parseMeetingCodeFromUrl('learnlymeet://meeting/abc123')).toBe(
			'abc123',
		);
	});

	it('meng-handle kode ter-encode', () => {
		expect(
			parseMeetingCodeFromUrl('https://meet.panara.id/meeting/a%20b'),
		).toBe('a b');
	});

	it('meng-handle encoding rusak tanpa crash', () => {
		expect(
			parseMeetingCodeFromUrl('https://meet.panara.id/meeting/%E0%A4%A'),
		).toBe('%E0%A4%A');
	});

	it('case-insensitive pada path /meeting/', () => {
		expect(parseMeetingCodeFromUrl('https://meet.panara.id/Meeting/abc')).toBe(
			'abc',
		);
	});

	it('null / undefined / URL tanpa meeting', () => {
		expect(parseMeetingCodeFromUrl(null)).toBeNull();
		expect(parseMeetingCodeFromUrl(undefined)).toBeNull();
		expect(parseMeetingCodeFromUrl('')).toBeNull();
		expect(parseMeetingCodeFromUrl('https://meet.panara.id/')).toBeNull();
		expect(parseMeetingCodeFromUrl('https://meet.panara.id/admin')).toBeNull();
		expect(parseMeetingCodeFromUrl('learnlymeet://meeting/')).toBeNull();
	});
});

describe('parseOriginFromUrl', () => {
	it('mengambil origin dari App Link https', () => {
		expect(
			parseOriginFromUrl('https://meet.panara.id/meeting/abc123'),
		).toBe('https://meet.panara.id');
	});

	it('mempertahankan port (dev)', () => {
		expect(parseOriginFromUrl('http://10.0.2.2:8787/meeting/x')).toBe(
			'http://10.0.2.2:8787',
		);
	});

	it('null untuk skema kustom & input kosong', () => {
		expect(parseOriginFromUrl('learnlymeet://meeting/abc')).toBeNull();
		expect(parseOriginFromUrl(null)).toBeNull();
		expect(parseOriginFromUrl('bukan-url')).toBeNull();
	});
});
