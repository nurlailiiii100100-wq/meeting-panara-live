import type { RTKParticipant, RTKSelf } from '@cloudflare/realtimekit';
import type { useRealtimeKitClient } from '@cloudflare/realtimekit-react-native';

/** Tipe instance meeting RealtimeKit hasil useRealtimeKitClient(). */
export type RTKMeeting = NonNullable<ReturnType<typeof useRealtimeKitClient>[0]>;

export type { RTKParticipant, RTKSelf };
