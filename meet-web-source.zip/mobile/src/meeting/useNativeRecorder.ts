import { useCallback, useEffect, useRef, useState } from 'react';
import {
	isNativeRecordingSupported,
	onRecordingError,
	onRecordingStopped,
	startNativeRecording,
	stopNativeRecording,
	uploadRecording,
} from './nativeRecorder';

/**
 * State machine rekaman mobile (Android) — paralel dengan useClientRecorder
 * di web: idle → recording → uploading → idle, dengan fallback unggah gagal
 * (file tetap tersimpan di perangkat host).
 */
export type NativeRecordingState =
	| 'IDLE'
	| 'STARTING'
	| 'RECORDING'
	| 'STOPPING'
	| 'UPLOADING'
	| 'ERROR';

interface UseNativeRecorderOptions {
	/** id meeting (divalidasi backend saat unggah). */
	meetingId: string;
	/** Token unggah host dari response /api/tokens (hanya host yang punya). */
	uploadToken: string | null;
	/** Izinkan rekaman (host/admin). Non-host = false. */
	enabled: boolean;
	/**
	 * Eksklusif MediaProjection: true bila screen share sedang aktif —
	 * Android hanya mengizinkan satu capture per aplikasi, jadi rekaman
	 * ditolak dengan pesan jelas (paralel: share ditolak saat rekaman aktif
	 * lewat useScreenShareFeedback).
	 */
	isScreenShareActive?: () => boolean;
}

export function useNativeRecorder({
	meetingId,
	uploadToken,
	enabled,
	isScreenShareActive,
}: UseNativeRecorderOptions) {
	const [recordingState, setRecordingState] =
		useState<NativeRecordingState>('IDLE');
	const [durationSeconds, setDurationSeconds] = useState(0);
	const [uploadProgress, setUploadProgress] = useState(0);
	const [errorMessage, setErrorMessage] = useState<string | null>(null);

	const stateRef = useRef<NativeRecordingState>('IDLE');
	const durationTimerRef = useRef<number | null>(null);
	const metaRef = useRef({ meetingId, uploadToken });
	metaRef.current = { meetingId, uploadToken };
	// Selalu pakai fungsi terbaru tanpa perlu subscribe ulang effect.
	const screenShareActiveRef = useRef<() => boolean>(() => false);
	screenShareActiveRef.current = isScreenShareActive ?? (() => false);

	const applyState = useCallback((next: NativeRecordingState) => {
		stateRef.current = next;
		setRecordingState(next);
	}, []);

	const clearTimer = useCallback(() => {
		if (durationTimerRef.current !== null) {
			clearInterval(durationTimerRef.current);
			durationTimerRef.current = null;
		}
	}, []);

	// Hasil stop dari native (tombol stop ATAU panel sistem Android).
	useEffect(() => {
		if (!isNativeRecordingSupported || !enabled) return;
		const offStopped = onRecordingStopped((result) => {
			clearTimer();
			setDurationSeconds(0);
			if (!result.path) {
				applyState('ERROR');
				setErrorMessage('Rekaman tidak menghasilkan file.');
				return;
			}
			// Sistem mencabut projection (mis. screen share lain aktif) —
			// file parsial tetap diunggah, tapi beri tahu host apa yang terjadi.
			if (result.reason === 'projection_revoked') {
				setErrorMessage(
					'Rekaman dihentikan oleh sistem (capture layar dialihkan). ' +
						'Bagian yang terekam tetap diunggah.',
				);
			}
			applyState('UPLOADING');
			setUploadProgress(0);
			const meta = metaRef.current;
			uploadRecording(result, {
				meetingId: meta.meetingId,
				uploadToken: meta.uploadToken,
				onProgress: setUploadProgress,
			})
				.then(() => {
					// File lokal sengaja tidak dihapus eksplisit — lihat catatan
					// di nativeRecorder.ts (app sandbox, dibersihkan OS).
					setUploadProgress(100);
					applyState('IDLE');
				})
				.catch((error: unknown) => {
					applyState('ERROR');
					setErrorMessage(
						'Unggah rekaman gagal — file tersimpan di perangkat host. ' +
							(error instanceof Error ? error.message : ''),
					);
				});
		});
		const offError = onRecordingError((message) => {
			clearTimer();
			setDurationSeconds(0);
			applyState('ERROR');
			setErrorMessage(message);
		});
		return () => {
			offStopped();
			offError();
		};
	}, [applyState, clearTimer, enabled]);

	const start = useCallback(async () => {
		const current = stateRef.current;
		if (current !== 'IDLE' && current !== 'ERROR') return;
		// Eksklusif MediaProjection: hanya satu capture aktif per aplikasi.
		if (screenShareActiveRef.current()) {
			setErrorMessage(
				'Screen share sedang aktif. Hentikan share layar sebelum mulai merekam.',
			);
			return;
		}
		if (!metaRef.current.meetingId) {
			setErrorMessage('Meeting tidak dikenali — rekaman tidak dimulai.');
			return;
		}
		setErrorMessage(null);
		setUploadProgress(0);
		setDurationSeconds(0);
		applyState('STARTING');
		try {
			await startNativeRecording();
			applyState('RECORDING');
			const startedAt = Date.now();
			setDurationSeconds(0);
			durationTimerRef.current = setInterval(() => {
				setDurationSeconds(Math.floor((Date.now() - startedAt) / 1000));
			}, 1000);
		} catch (error) {
			clearTimer();
			applyState('IDLE');
			const code =
				typeof error === 'object' && error !== null && 'code' in error
					? String((error as { code: unknown }).code)
					: '';
			if (code !== 'USER_CANCELLED') {
				setErrorMessage(
					error instanceof Error
						? error.message
						: 'Gagal memulai rekaman.',
				);
			}
		}
	}, [applyState, clearTimer]);

	const stop = useCallback(async () => {
		const current = stateRef.current;
		if (current !== 'RECORDING' && current !== 'STARTING') return;
		applyState('STOPPING');
		try {
			await stopNativeRecording();
		} catch (error) {
			applyState('IDLE');
			setErrorMessage(
				error instanceof Error ? error.message : 'Gagal menghentikan rekaman.',
			);
		}
	}, [applyState]);

	const clearError = useCallback(() => {
		setErrorMessage(null);
		if (stateRef.current === 'ERROR') applyState('IDLE');
	}, [applyState]);

	// Safety: hentikan rekaman native saat layar dilepas (leave/kick).
	useEffect(() => {
		return () => {
			clearTimer();
			if (
				stateRef.current === 'RECORDING' ||
				stateRef.current === 'STARTING'
			) {
				stopNativeRecording().catch(() => {
					/* service mungkin sudah mati */
				});
			}
		};
	}, [clearTimer]);

	return {
		recordingState,
		durationSeconds,
		uploadProgress,
		errorMessage,
		start,
		stop,
		clearError,
		supported: isNativeRecordingSupported,
	};
}

/** Format detik → HH:MM:SS (paralel dengan web). */
export function formatElapsed(totalSeconds: number): string {
	const h = Math.floor(totalSeconds / 3600);
	const m = Math.floor((totalSeconds % 3600) / 60);
	const s = totalSeconds % 60;
	const pad = (n: number) => String(n).padStart(2, '0');
	return `${pad(h)}:${pad(m)}:${pad(s)}`;
}
