import { NativeEventEmitter, NativeModules, Platform } from 'react-native';
import { getApiBaseUrl } from '../api/backend';

/**
 * Rekaman client-side Android — paralel dengan useClientRecorder di web.
 * Native module (MediaProjection → MediaCodec H.264 + mic → MP4) hasilkan
 * file, lalu file diunggah ke POST /api/recordings/upload dengan upload_token
 * host (sama dengan web). Tidak ada RealtimeKit Cloud Export — biaya $0.
 *
 * iOS TIDAK didukung — aplikasi ini Android-only (rekaman native hanya
 * Android; lihat MeetingScreen).
 */

const Native = NativeModules.ScreenRecord as
	| {
			startRecording: () => Promise<void>;
			stopRecording: () => Promise<void>;
	  }
	| undefined;

export const isNativeRecordingSupported =
	Platform.OS === 'android' && Native != null;

export interface RecordingResult {
	path: string;
	durationSeconds: number;
	/**
	 * "user_stop" = tombol stop aplikasi; "projection_revoked" = sistem
	 * mencabut capture layar (mis. screen share lain aktif / panel sistem).
	 */
	reason?: string;
}

export interface UploadOptions {
	meetingId: string;
	uploadToken: string | null;
	resolution?: { width: number; height: number };
	onProgress?: (percent: number) => void;
}

let emitter: NativeEventEmitter | null = null;
function getEmitter(): NativeEventEmitter | null {
	if (!isNativeRecordingSupported || !Native) return null;
	if (!emitter) emitter = new NativeEventEmitter(NativeModules.ScreenRecord);
	return emitter;
}

/** Mulai rekaman; resolve saat service capture layar dimulai. */
export function startNativeRecording(): Promise<void> {
	if (!Native) return Promise.reject(new Error('Rekaman native tidak tersedia.'));
	return Native.startRecording();
}

/** Berhenti; hasil akhir (path + durasi) datang via event ScreenRecordStopped. */
export function stopNativeRecording(): Promise<void> {
	if (!Native) return Promise.reject(new Error('Rekaman native tidak tersedia.'));
	return Native.stopRecording();
}

/**
 * Berlangganan hasil stop: dipanggil saat rekaman finalisasi (baik lewat
 * tombol stop, "Berhenti merekam" panel sistem, maupun service mati).
 */
export function onRecordingStopped(
	listener: (result: RecordingResult) => void,
): () => void {
	const em = getEmitter();
	if (!em) return () => {};
	const sub = em.addListener('ScreenRecordStopped', (e: {
		path?: string;
		durationSeconds?: number;
		reason?: string;
	}) =>
		listener({
			path: e?.path ?? '',
			durationSeconds: e?.durationSeconds ?? 0,
			reason: e?.reason,
		}),
	);
	return () => sub.remove();
}

export function onRecordingError(
	listener: (message: string) => void,
): () => void {
	const em = getEmitter();
	if (!em) return () => {};
	const sub = em.addListener('ScreenRecordError', (e: { message?: string }) =>
		listener(e?.message || 'Rekaman mengalami kesalahan.'),
	);
	return () => sub.remove();
}

/**
 * Unggah hasil rekaman ke worker (multipart) — kontrak identik dengan unggah
 * rekaman web. Host tidak perlu login: autentikasi memakai `upload_token`
 * yang dikirim /api/tokens hanya untuk host/admin. Tidak ada secret R2 di sisi
 * aplikasi.
 */
export function uploadRecording(
	result: RecordingResult,
	options: UploadOptions,
): Promise<void> {
	const base = getApiBaseUrl();
	if (!base) return Promise.reject(new Error('Server URL belum diisi.'));

	const sep = base.endsWith('/') ? '' : '/';
	const url = `${base}${sep}api/recordings/upload`;
	const preset = options.resolution ?? { width: 1280, height: 720 };

	return new Promise<void>((resolve, reject) => {
		const form = new FormData();
		form.append('meeting_id', options.meetingId);
		form.append('duration_seconds', String(result.durationSeconds));
		form.append('resolution_width', String(preset.width));
		form.append('resolution_height', String(preset.height));
		if (options.uploadToken) form.append('upload_token', options.uploadToken);
		form.append('file', {
			uri: `file://${result.path}`,
			name: `recording-${Date.now()}.mp4`,
			type: 'video/mp4',
		} as unknown as Blob);

		const request = new XMLHttpRequest();
		request.open('POST', url);
		request.timeout = 15 * 60 * 1000;
		request.upload.onprogress = (event) => {
			if (event.lengthComputable && event.total > 0 && options.onProgress) {
				options.onProgress(
					Math.min(99, Math.round((event.loaded / event.total) * 100)),
				);
			}
		};
		request.onload = () => {
			if (request.status >= 200 && request.status < 300) resolve();
			else
				reject(
					new Error(`Unggah rekaman ditolak server (${request.status}).`),
				);
		};
		request.onerror = () =>
			reject(new Error('Unggah rekaman gagal — periksa koneksi.'));
		request.ontimeout = () =>
			reject(new Error('Unggah rekaman melebihi batas waktu.'));
		request.send(form);
	});
}

// Catatan: file rekaman TIDAK dihapus eksplisit setelah unggah. File berada di
// app sandbox (dibersihkan OS bila storage penuh); penghapusan eksplisit butuh
// modul fs native tambahan sehingga sengaja tidak dipakai.
