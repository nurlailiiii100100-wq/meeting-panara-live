/**
 * Parser deep link meeting untuk aplikasi mobile.
 *
 * Link yang dibagikan peserta/web selalu berbentuk
 * `https://<domain>/meeting/<kode>` (lihat Meeting.tsx web). Agar tap link
 * di HP langsung membuka aplikasi (bukan browser), Android memakai dua
 * jalur di AndroidManifest.xml:
 *
 *   1. App Links  — `https://live.panaragroup.web.id/meeting/<kode>` (autoVerify,
 *      diverifikasi lewat `/.well-known/assetlinks.json`).
 *   2. Skema kustom cadangan — `learnlymeet://meeting/<kode>`.
 *
 * Keduanya menghasilkan kode meeting yang sama lewat fungsi ini.
 */

/** Cocokkan `/meeting/<kode>` — berhenti sebelum `?`, `#`, atau `/`. */
const MEETING_PATH = /\/meeting\/([^/?#]+)/i;

/** Cocokkan skema http(s) + host — dipakai untuk menebak URL backend. */
const ORIGIN_PATH = /^(https?):\/\/([^/]+)/i;

/**
 * Ambil kode meeting dari sebuah URL deep link.
 *
 * @returns kode meeting, atau null bila URL bukan link meeting.
 */
export function parseMeetingCodeFromUrl(
	url: string | null | undefined,
): string | null {
	if (!url) return null;
	const match = MEETING_PATH.exec(url);
	if (!match) return null;
	const raw = (match[1] ?? '').trim();
	if (!raw) return null;
	try {
		// Kode bisa ter-encode (mis. %20) — kembalikan bentuk aslinya.
		return decodeURIComponent(raw).trim() || null;
	} catch {
		// Bukan encoding valid — pakai mentah apa adanya.
		return raw;
	}
}

/**
 * Ambil origin (`https://host`) dari deep link http(s).
 *
 * Jaringan darurat untuk kasus URL server kosong: build rilis sudah membawa
 * URL produksi (`DEFAULT_API_BASE_URL` di config.ts), tetapi kalau URL
 * tersimpan kosong/terhapus, user yang datang dari link meeting web bisa
 * langsung dipulihkan — backend memang ada di origin yang sama dengan link
 * tersebut, jadi origin link dipakai sebagai server URL secara otomatis.
 * (Kalau URL sudah ada, nilai lama tetap dipakai: link dari host lain —
 * mis. staging — tidak menimpa pilihan user.) Dipakai di efek deep link
 * `JoinScreen`.
 *
 * @returns origin URL, atau null bila bukan link http(s).
 */
export function parseOriginFromUrl(url: string | null | undefined): string | null {
	if (!url) return null;
	const match = ORIGIN_PATH.exec(url.trim());
	if (!match) return null;
	return `${match[1].toLowerCase()}://${match[2]}`;
}
