import type { UIConfig } from '@cloudflare/realtimekit-react-native-ui';
import { defaultConfig } from '@cloudflare/realtimekit-react-native-ui';

/**
 * Konfigurasi UI RtkMeeting untuk mobile, disamakan dengan aplikasi web:
 *
 * - Indikator recording bawaan kit (rtk-recording-indicator) disembunyikan
 *   untuk SEMUA role: timer rekam ditampilkan sendiri di top bar MeetingScreen
 *   ("REC" + elapsed).
 *
 * - Tombol rekaman kit (rtk-recording-toggle) di menu More TIDAK disembunyikan,
 *   karena sudah disambungkan ke rekaman client-side lewat useRecordingKitBridge
 *   (meeting.recording.start/stop di-override → native Android, BUKAN Cloud
 *   Export berbayar $0.010/menit). Jadi menu More kini memuat start/stop
 *   rekaman gratis, bukan Cloud Export.
 *
 *   Sisanya memakai defaultConfig bawaan kit — komponen, layout, dan label
 *   (termasuk "Share Screen"/"Stop Sharing") identik dengan UI PC.
 *
 * defaultConfig adalah object yang dibagikan modul kit dan RtkMeeting
 * meng-merge konfigurasi kita ke dalamnya, jadi selalu di-clone dulu supaya
 * tidak ada mutasi silang antar instance.
 */
function stripRecordingUi(config: UIConfig, tags: string[]): void {
	const root = config.root;
	if (!root) return;
	const isTagged = (child: unknown): boolean =>
		(typeof child === 'string' && tags.includes(child)) ||
		(Array.isArray(child) &&
			typeof child[0] === 'string' &&
			tags.includes(child[0]));
	for (const [key, entry] of Object.entries(root)) {
		if (Array.isArray(entry)) {
			root[key] = entry.filter(child => !isTagged(child));
		} else if (entry && typeof entry === 'object') {
			if (Array.isArray(entry.children)) {
				entry.children = entry.children.filter(child => !isTagged(child));
			}
		}
	}
}

export function buildMobileUiConfig(isHost: boolean): UIConfig {
	const config = JSON.parse(JSON.stringify(defaultConfig)) as UIConfig;
	// rtk-recording-indicator disembunyikan: timer rekam ditampilkan sendiri di
	// top bar (indicator "REC" di MeetingScreen). rtk-recording-toggle TIDAK
	// disembunyikan lagi — tombolnya di menu More kita sambungkan ke rekaman
	// client-side lewat useRecordingKitBridge (bukan Cloud Export).
	stripRecordingUi(config, ['rtk-recording-indicator']);
	// Share Screen khusus host: item rtk-screenshare-toggle (menu More) hanya
	// dipasang untuk host; member tidak mendapat tombol share sama sekali.
	// Gate lapis kedua ada di useScreenShareFeedback (enableScreenShare).
	if (!isHost) stripRecordingUi(config, ['rtk-screenshare-toggle']);
	return config;
}
