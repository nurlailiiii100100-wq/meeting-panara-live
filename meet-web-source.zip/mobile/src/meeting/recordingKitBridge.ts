import { useEffect } from 'react';

// State rekaman yang dikenali kit RealtimeKit (RecordingState di SDK core).
// Kita hanya memakai sebagian — PAUSED tidak dipakai rekaman client-side.
type KitRecordingState =
	| 'IDLE'
	| 'STARTING'
	| 'RECORDING'
	| 'PAUSED'
	| 'STOPPING';

interface RecorderLike {
	recordingState: string;
	start: () => Promise<void>;
	stop: () => Promise<void>;
}

// Bentuk minimal objek meeting yang dipakai bridge. Sengaja bukan tipe penuh
// SDK (Readonly<Recording> dll) agar tidak bergantung pada detail internal —
// pemanggil cukup memberikan objek meeting apa adanya.
interface BridgeMeeting {
	self: { permissions: object };
	recording: object;
}

/**
 * Petakan state recorder client-side → state kit yang dibaca
 * rtk-recording-toggle (menu More).
 *
 * - UPLOADING dipetakan ke STOPPING agar tombol More nonaktif saat unggah
 *   berlangsung (mencegah memulai rekaman ganda sebelum file lama terkirim).
 * - ERROR dipetakan ke IDLE agar host bisa langsung mencoba rekam ulang.
 */
function toKitState(state: string): KitRecordingState {
	switch (state) {
		case 'STARTING':
		case 'RECORDING':
		case 'STOPPING':
			return state;
		case 'UPLOADING':
			return 'STOPPING';
		default:
			return 'IDLE';
	}
}

/**
 * Menyambungkan tombol rekaman bawaan kit (rtk-recording-toggle di menu More)
 * ke rekaman client-side mobile, TANPA menyentuh Cloud Export RealtimeKit.
 *
 * Penting: meeting.recording.start()/stop() asli SDK = Cloud Export berbayar
 * ($0.010/menit). Rekaman kita client-side (native Android → upload
 * /api/recordings/upload), jadi method asli itu TIDAK BOLEH terpanggil.
 *
 * Tiga penyambungan yang dilakukan — semuanya pada objek meeting yang stabil:
 * 1. permissions.canRecord dipaksa true untuk host agar toggle More tampil.
 *    Kit menyembunyikan toggle bila canRecord false; sementara web memakai
 *    `isAdmin || canRecord` tapi kit mobile hanya `canRecord` murni.
 * 2. recording.start/stop di-override → recorder.start/stop kita, sehingga
 *    menekan tombol More TIDAK memicu Cloud Export.
 * 3. recordingState yang dibaca toggle disinkronkan dari recorder kita lewat
 *    updateRecordings() (method resmi SDK; emit "recordingUpdate" → wildcard
 *    '*' di bus updates → toggle re-render dengan status terbaru).
 */
export function useRecordingKitBridge(
	meeting: BridgeMeeting | undefined,
	recorder: RecorderLike,
	enabled: boolean,
) {
	// Destruksi jadi identifier stabil agar dependensi effect eksplisit
	// (start/stop dari useCallback sudah stabil; recordingState berubah per
	// status) dan lolos analisis react-hooks/exhaustive-deps.
	const { recordingState, start, stop } = recorder;

	// (1)+(2): paksa canRecord & alihkan start/stop jadi milik kita.
	useEffect(() => {
		if (!meeting || !enabled) return;
		const permissions = (
			meeting.self as unknown as { permissions: Record<string, unknown> }
		).permissions;
		const recording = meeting.recording as unknown as {
			start: () => Promise<void>;
			stop: () => Promise<void>;
		};

		// Paksa canRecord → true hanya selama patch aktif (host+supported).
		const hadOwnCanRecord = Object.prototype.hasOwnProperty.call(
			permissions,
			'canRecord',
		);
		const originalCanRecord = permissions.canRecord;
		Object.defineProperty(permissions, 'canRecord', {
			configurable: true,
			enumerable: true,
			get: () => true,
		});

		// Alihkan start/stop ke rekaman client-side kita (tanpa Cloud Export).
		const originalStart = recording.start;
		const originalStop = recording.stop;
		recording.start = () => start();
		recording.stop = () => stop();

		return () => {
			recording.start = originalStart;
			recording.stop = originalStop;
			// Kembalikan canRecord seperti semula.
			delete (permissions as Record<string, unknown>).canRecord;
			if (hadOwnCanRecord) {
				Object.defineProperty(permissions, 'canRecord', {
					configurable: true,
					enumerable: true,
					value: originalCanRecord,
				});
			}
		};
	}, [meeting, enabled, start, stop]);

	// (3): sinkronkan status rekam client-side → recordingState toggle More.
	useEffect(() => {
		if (!meeting || !enabled) return;
		const recording = meeting.recording as unknown as {
			updateRecordings: (
				r: {
					state: KitRecordingState;
					id: string;
					type: 'COMPOSITE';
				}[],
			) => void;
		};
		const kitState = toKitState(recordingState);
		const recordings =
			kitState === 'IDLE'
				? []
				: [
						{
							state: kitState,
							id: 'client-side-recording',
							type: 'COMPOSITE' as const,
						},
					];
		try {
			recording.updateRecordings(recordings);
		} catch {
			/* meeting mungkin sedang bubar — abaikan */
		}
	}, [meeting, enabled, recordingState]);
}
