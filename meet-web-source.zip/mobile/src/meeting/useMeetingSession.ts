import { useEffect, useRef, useState } from 'react';
import type { LeaveRoomState } from '@cloudflare/realtimekit';
import { useRealtimeKitClient } from '@cloudflare/realtimekit-react-native';
import { MAX_SUBSCRIBED_STREAMS } from '../config';
import type { RTKMeeting } from './rtkTypes';

export interface JoinSession {
	authToken: string;
	meetingCode: string;
	displayName: string;
	userId: string;
	role: 'admin' | 'member';
	/**
	 * Waktu berakhir resmi meeting (ISO) dari /api/tokens — sumber kebenaran
	 * yang sama dipakai aplikasi web. Null bila backend belum menetapkannya.
	 */
	expiresAt?: string | null;
	/**
	 * Token unggah rekaman client-side dari /api/tokens — hanya host/admin.
	 * Disimpan di memori saja (tidak ke storage), sama seperti cookie sesi.
	 */
	uploadToken?: string | null;
	/**
	 * Flag auto_record meeting dari /api/tokens — host otomatis mulai merekam
	 * saat sudah benar-benar masuk room (paralel maybeAutoRecord di web).
	 */
	autoRecord?: boolean;
}

export type LeaveState = LeaveRoomState;

export interface MeetingSessionController {
	meeting: RTKMeeting | undefined;
	errorMessage: string | null;
}

/**
 * Lifecycle meeting mobile:
 *   initMeeting(authToken) → RtkMeeting (setup screen) → join() → leave().
 *
 * Satu instance client per token. Join TIDAK dipanggil di sini: layar setup
 * bawaan RtkMeeting (sama seperti aplikasi web) yang memanggil join() ketika
 * peserta menekan tombol Join, sehingga alur mobile identik dengan PC.
 * Semua jalur keluar (tombol Keluar di kit, kick, meeting ended) tetap
 * berujung ke leave() / roomLeft sehingga capture screen share ikut dibersihkan.
 */
export function useMeetingSession(
	session: JoinSession,
): MeetingSessionController {
	const [meeting, initMeeting] = useRealtimeKitClient({
		resetOnLeave: true,
		keepAliveService: {
			enabled: true,
			title: 'Panara Live',
			text: 'Ketuk untuk kembali ke meeting',
		},
	});

	const [errorMessage, setErrorMessage] = useState<string | null>(null);

	const didInitRef = useRef<string>('');
	const meetingRef = useRef<RTKMeeting | undefined>(undefined);
	meetingRef.current = meeting;

	// 1. Inisialisasi client dengan auth token dari backend.
	useEffect(() => {
		const key = `${session.meetingCode}:${session.authToken}`;
		if (didInitRef.current === key) return;
		didInitRef.current = key;
		setErrorMessage(null);

		let cancelled = false;
		initMeeting({
			authToken: session.authToken,
			defaults: {
				audio: true,
				video: true,
				// Batasan sama dengan aplikasi web (Meeting.tsx) agar stream dari
				// mobile dan web memakai profil encode yang identik.
				mediaConfiguration: {
					screenshare: {
						width: { max: 1280 },
						height: { max: 720 },
						frameRate: { ideal: 5, max: 5 },
					},
				},
			},
		}).catch((error: unknown) => {
			if (cancelled) return;
			setErrorMessage(describeError(error));
		});
		return () => {
			cancelled = true;
		};
	}, [initMeeting, session.authToken, session.meetingCode]);

	// 2. Batasi jumlah langganan stream (paralel dengan aplikasi web).
	useEffect(() => {
		if (!meeting?.self?.roomJoined) return;
		try {
			if (
				meeting.participants.maxActiveParticipantsCount <
				MAX_SUBSCRIBED_STREAMS
			) {
				meeting.participants.setMaxActiveParticipantsCount(
					MAX_SUBSCRIBED_STREAMS,
				);
			}
		} catch (error) {
			console.warn('Unable to raise subscription limit:', error);
		}
	}, [meeting, meeting?.self?.roomJoined]);

	// 3. Pemulihan screen share (paralel dengan efek share-heal di Meeting.tsx
	//    web): peserta bisa terlihat `screenShareEnabled` tapi track video tidak
	//    sampai ke client ini — akibatnya tile share tampil HITAM. Umumnya
	//    subscription stream share nyangkut (terutama saat HP sedang berat, mis.
	//    sambil merekam). Nudge berkala memaksa ulang subscription tanpa perlu
	//    join ulang.
	useEffect(() => {
		if (!meeting?.self?.roomJoined) return;
		const SHARE_HEAL_INTERVAL_MS = 15000;
		const SHARE_WATCH_TICK_MS = 5000;
		let lastShareHeal = 0;
		const timer = setInterval(() => {
			try {
				const selfId = meeting.self.id;
				const stuckShare = meeting.participants.joined
					.toArray()
					.some(
						(p) =>
							p.id !== selfId &&
							p.screenShareEnabled &&
							!p.screenShareTracks?.video,
					);
				if (!stuckShare) return;
				const now = Date.now();
				if (now - lastShareHeal < SHARE_HEAL_INTERVAL_MS) return;
				lastShareHeal = now;
				// Menyentuh ulang nilai subscription memicu SFU mengirimkan
				// kembali track screenshare yang belum turun ke client ini.
				meeting.participants.setMaxActiveParticipantsCount(
					meeting.participants.maxActiveParticipantsCount,
				);
			} catch (error) {
				console.warn('Screen share recovery failed:', error);
			}
		}, SHARE_WATCH_TICK_MS);
		return () => clearInterval(timer);
	}, [meeting, meeting?.self?.roomJoined]);

	// 4. Safety net saat komponen dilepas: tidak boleh ada capture atau room
	//    yang tertinggal (mis. layar ditutup tanpa lewat tombol Keluar).
	useEffect(() => {
		return () => {
			const current = meetingRef.current;
			if (current?.self?.roomJoined) {
				current
					.leave()
					.catch((error: unknown) =>
						console.warn('leave() failed on unmount:', error),
					);
			}
		};
	}, []);

	return { meeting, errorMessage };
}

function describeError(error: unknown): string {
	if (typeof error === 'string') return error;
	if (error instanceof Error) return error.message;
	return 'Terjadi kesalahan saat memulai meeting.';
}
