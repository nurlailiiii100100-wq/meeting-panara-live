import { mediaDevices } from '@cloudflare/react-native-webrtc';
import type { MediaStream, MediaStreamTrack } from '@cloudflare/react-native-webrtc';

/**
 * Probe error native screen capture (Android).
 *
 * Kenapa perlu: LocalMediaHandler.enableScreenShare() pada SDK React Native
 * menangkap error getDisplayMedia() hanya dengan console.warn() lalu men-set
 * screenShareEnabled = false (lihat node_modules/@cloudflare/realtimekit-react-native/
 * lib/module/LocalMediaHandler.js → blok try/catch Android). Artinya promise
 * meeting.self.enableScreenShare() selalu resolve dan aplikasi kehilangan
 * informasi "user membatalkan dialog" vs "capture gagal".
 *
 * Probe ini membungkus mediaDevices.getDisplayMedia() dengan aman (tanpa
 * mengubah perilaku) untuk merekam error terakhir, sehingga
 * useScreenShareFeedback bisa mengklasifikasikan USER_CANCELLED /
 * SCREEN_CAPTURE_UNAVAILABLE / NATIVE_MODULE_ERROR dengan jujur — termasuk
 * ketika tombol share di UI kit (RtkScreenShareToggle) yang memicunya.
 */
let lastNativeError: unknown = null;
let installed = false;

type FailureListener = (error: unknown) => void;
const failureListeners = new Set<FailureListener>();

/**
 * Dapatkan notifikasi setiap kali getDisplayMedia() gagal (error sudah juga
 * direkam oleh consumeScreenShareError()). Return function untuk berlangganan.
 */
export function onScreenShareFailure(listener: FailureListener): () => void {
	failureListeners.add(listener);
	return () => {
		failureListeners.delete(listener);
	};
}

export function installScreenShareErrorProbe(): void {
	if (installed) return;
	installed = true;
	const original = mediaDevices.getDisplayMedia.bind(mediaDevices);
	const wrapped = async (): Promise<MediaStream> => {
		try {
			return await original();
		} catch (error) {
			lastNativeError = error;
			for (const listener of failureListeners) {
				try {
					listener(error);
				} catch {
					// listener rusak tidak boleh menggagalkan capture
				}
			}
			throw error;
		}
	};
	mediaDevices.getDisplayMedia = wrapped;
}

export function clearScreenShareError(): void {
	lastNativeError = null;
}

/** Ambil + bersihkan error native terakhir. */
export function consumeScreenShareError(): unknown {
	const error = lastNativeError;
	lastNativeError = null;
	return error;
}

function describeError(error: unknown): string {
	if (error == null) return '';
	if (typeof error === 'string') return error;
	if (error instanceof Error) return `${error.name} ${error.message}`;
	const record = error as { name?: unknown; message?: unknown; code?: unknown };
	return [record.name, record.message, record.code]
		.filter(part => typeof part === 'string')
		.join(' ');
}

export type NativeScreenShareFailure =
	| 'USER_CANCELLED'
	| 'PERMISSION_DENIED'
	| 'SCREEN_CAPTURE_UNAVAILABLE'
	| 'NATIVE_MODULE_ERROR'
	| 'UNKNOWN_ERROR';

export function classifyNativeScreenShareError(
	error: unknown,
): NativeScreenShareFailure {
	const text = describeError(error);
	// Android: promise.reject("DOMException", "NotAllowedError") ketika user
	// menekan Cancel pada dialog MediaProjection (GetUserMediaImpl.java).
	if (text.includes('NotAllowedError')) return 'USER_CANCELLED';
	// Dialog sistem tidak bisa ditampilkan / proyeksi tidak tersedia.
	if (
		text.includes('No current Activity') ||
		text.includes('MediaProjectionManager is null') ||
		text.includes('Another operation is pending') ||
		text.includes('ScreenTrack is null')
	) {
		return 'SCREEN_CAPTURE_UNAVAILABLE';
	}
	if (text.includes('SecurityException')) return 'PERMISSION_DENIED';
	return 'UNKNOWN_ERROR';
}

export type { MediaStreamTrack };
