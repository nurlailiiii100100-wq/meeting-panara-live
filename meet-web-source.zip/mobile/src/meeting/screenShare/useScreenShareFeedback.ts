import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import type { RTKMeeting } from '../rtkTypes';
import {
	classifyNativeScreenShareError,
	clearScreenShareError,
	consumeScreenShareError,
	installScreenShareErrorProbe,
} from './nativeScreenShareProbe';
import { SCREEN_SHARE_MESSAGES, type ScreenShareErrorCode } from './types';

interface MediaPermissionErrorPayload {
	message?: string;
	kind?: string;
}

export interface ScreenShareFeedback {
	/** Pesan error Indonesia dari percobaan share terakhir, null bila tidak ada. */
	errorMessage: string | null;
	dismissError: () => void;
}

interface ScreenShareFeedbackOptions {
	/**
	 * Share Screen khusus host. Bila mengembalikan false, permintaan share
	 * ditolak dengan pesan (tombol kit sudah disembunyikan untuk member lewat
	 * buildMobileUiConfig; gate ini menutup jalur bypass).
	 */
	isHost?: () => boolean;
	/**
	 * Eksklusif MediaProjection: bila mengembalikan true, permintaan share
	 * ditawarkan lewat dialog konfirmasi — rekaman dihentikan dulu, baru share
	 * dimulai (Android hanya mengizinkan satu capture aktif).
	 */
	isBlocked?: () => boolean;
	/**
	 * Hentikan rekaman client-side. Dikonfirmasi pengguna lewat dialog sebelum
	 * dipanggil; bila tidak disediakan, share ditolak dengan pesan seperti
	 * perilaku lama.
	 */
	stopRecording?: () => Promise<void>;
}

function describeThrown(error: unknown): string {
	if (error == null) return '';
	if (typeof error === 'string') return error;
	if (error instanceof Error) return `${error.name} ${error.message}`;
	return String(error);
}

/**
 * Membaca kesehatan koneksi RTK dari sumber otoritatif `meta.socketState`
 * (diverifikasi dari tipe SDK: Meta.socketState & MetaEvents
 * ['socketConnectionUpdate']). `roomJoined` diambil dari self.
 *
 * navigator.onLine TIDAK dipakai sebagai bukti koneksi pulih (issue #82).
 */
function readConnectionHealthy(meeting: RTKMeeting | undefined): boolean {
	if (!meeting) return false;
	let socketConnected = true; // default longgar bila meta belum siap
	try {
		const raw = (meeting as unknown as {
			meta?: { socketState?: { state?: string } };
		})?.meta?.socketState?.state;
		if (
			raw === 'disconnected' ||
			raw === 'reconnecting' ||
			raw === 'failed'
		) {
			socketConnected = false;
		}
	} catch {
		/* meta belum siap — jangan blokir */
	}
	let roomJoined = false;
	try {
		roomJoined =
			(meeting as unknown as { self?: { roomJoined?: boolean } })?.self
				?.roomJoined === true;
	} catch {
		roomJoined = false;
	}
	return socketConnected && roomJoined;
}

const CONNECTION_BLOCKED_MESSAGE =
	'Koneksi internet terputus. Hubungkan kembali jaringan sebelum membagikan layar.';

/**
 * Konfirmasi saat rekaman berlangsung dan host ingin memulai Share Screen.
 * Android hanya mengizinkan satu capture aktif, jadi rekaman dihentikan dulu
 * (file yang sudah terekam tetap tersimpan & diunggah), baru share dimulai.
 * true = lanjut (hentikan rekaman → share), false = batal.
 */
function confirmStopRecordingAndShare(): Promise<boolean> {
	return new Promise((resolve) => {
		Alert.alert(
			'Rekaman sedang berlangsung',
			'Share Screen membutuhkan perekaman layar, dan Android hanya mengizinkan satu capture. Rekaman akan dihentikan (hasil yang sudah berjalan tetap tersimpan dan diunggah), lalu Share Screen dimulai.',
			[
				{ text: 'Batal', style: 'cancel', onPress: () => resolve(false) },
				{ text: 'Hentikan & Share', onPress: () => resolve(true) },
			],
			{ cancelable: true, onDismiss: () => resolve(false) },
		);
	});
}

/**
 * Klasifikasi kegagalan start. Urutan penting:
 * 1. error yang dilempar SDK (belum join / timeout iOS / jaringan),
 * 2. mediaPermissionError dari RealtimeKit (kind === 'screenshare'),
 * 3. error native dari probe getDisplayMedia (Android),
 * 4. fallback jujur UNKNOWN_ERROR.
 */
function classifyStartFailure(
	thrown: unknown,
	nativeError: unknown,
	permissionError: MediaPermissionErrorPayload | null,
): ScreenShareErrorCode {
	const text = describeThrown(thrown);
	if (text.includes('without joining room') || text.includes('1105')) {
		return 'MEETING_NOT_JOINED';
	}
	// iOS: LocalMediaHandler.enableScreenShare() reject bila broadcast tidak
	// dimulai dalam 20 detik (user menutup picker / tidak menekan Start).
	if (text.includes('Timeout exceeded for enableScreenShare')) {
		return 'USER_CANCELLED';
	}
	if (permissionError?.message) {
		if (permissionError.message === 'SYSTEM_DENIED') return 'SYSTEM_DENIED';
		if (permissionError.message === 'DENIED') return 'PERMISSION_DENIED';
		if (permissionError.message === 'CANCELED') return 'USER_CANCELLED';
		if (permissionError.message === 'NO_DEVICES_AVAILABLE') {
			return 'SCREEN_CAPTURE_UNAVAILABLE';
		}
		if (permissionError.message === 'COULD_NOT_START') return 'PUBLISH_FAILED';
	}
	if (nativeError != null) {
		const classified = classifyNativeScreenShareError(nativeError);
		return classified === 'UNKNOWN_ERROR' ? 'NATIVE_MODULE_ERROR' : classified;
	}
	if (/network|fetch|socket|timed? ?out/i.test(text)) return 'NETWORK_ERROR';
	if (text.trim().length > 0) return 'NATIVE_MODULE_ERROR';
	return 'UNKNOWN_ERROR';
}

/**
 * Feedback error screen share untuk UI kit.
 *
 * Tombol share di RtkMeeting (RtkScreenShareToggle) memanggil
 * meeting.self.enableScreenShare() sendiri, sehingga hook ini TIDAK mengendalikan
 * mulai/berhenti — hanya mengamati hasilnya:
 *
 * - membungkus enableScreenShare() sekali per instance untuk menangkap error
 *   yang dilempar SDK (iOS timeout) tanpa menjadi unhandled rejection di kit,
 * - membaca error native dari probe getDisplayMedia (Android; error ditelan
 *   core SDK dengan console.warn),
 * - menangani event mediaPermissionError kind === 'screenshare',
 *
 * lalu menampilkannya sebagai pesan Indonesia via errorMessage (dipajang oleh
 * MeetingScreen sebagai banner di atas UI kit).
 */
export function useScreenShareFeedback(
	meeting?: RTKMeeting,
	options?: ScreenShareFeedbackOptions,
): ScreenShareFeedback {
	const [errorMessage, setErrorMessage] = useState<string | null>(null);

	const meetingRef = useRef<RTKMeeting | undefined>(meeting);
	const permissionErrorRef = useRef<MediaPermissionErrorPayload | null>(null);
	const thrownRef = useRef<unknown>(null);
	const inFlightRef = useRef<boolean>(false);
	meetingRef.current = meeting;
	// Fungsi terbaru tanpa subscribe ulang effect (mirror pola useNativeRecorder).
	const hostRef = useRef<(() => boolean) | undefined>(options?.isHost);
	hostRef.current = options?.isHost;
	const blockedRef = useRef<(() => boolean) | undefined>(options?.isBlocked);
	blockedRef.current = options?.isBlocked;
	const stopRecordingRef = useRef<(() => Promise<void>) | undefined>(
		options?.stopRecording,
	);
	stopRecordingRef.current = options?.stopRecording;

	// Pasang probe sekali (idempotent).
	useEffect(() => {
		installScreenShareErrorProbe();
	}, []);

	useEffect(() => {
		if (!meeting) return;
		const self = meeting.self;
		const original = self.enableScreenShare.bind(self);
		// RTKSelf bertipe Readonly<Self> di SDK, tapi instance sebenarnya objek
		// biasa — pembungkus ditulis lewat alias writable.
		const writableSelf = self as unknown as {
			enableScreenShare: () => Promise<void>;
		};
		let evaluateTimer: ReturnType<typeof setTimeout> | null = null;

		const clearTimer = () => {
			if (evaluateTimer) {
				clearTimeout(evaluateTimer);
				evaluateTimer = null;
			}
		};

		const evaluate = () => {
			clearTimer();
			if (inFlightRef.current) {
				// Percobaan masih berjalan (iOS menunggu broadcast sampai 20 dtk);
				// jangan mengklasifikasi terlalu dini.
				evaluateTimer = setTimeout(evaluate, 400);
				return;
			}
			const current = meetingRef.current;
			if (!current) return;
			if (current.self.screenShareEnabled) {
				setErrorMessage(null);
				return;
			}
			const code = classifyStartFailure(
				thrownRef.current,
				consumeScreenShareError(),
				permissionErrorRef.current,
			);
			setErrorMessage(SCREEN_SHARE_MESSAGES[code]);
		};

		const scheduleEvaluate = () => {
			clearTimer();
			// Beri waktu agar state publish RealtimeKit sempat ter-update.
			evaluateTimer = setTimeout(evaluate, 400);
		};

		const wrapped = async (): Promise<void> => {
			// Share Screen khusus host. Tombol kit sudah disembunyikan untuk
			// member (buildMobileUiConfig); gate ini menutup jalur bypass
			// berupa panggilan enableScreenShare() langsung.
			if (hostRef.current && !hostRef.current()) {
				setErrorMessage('Hanya host yang dapat berbagi layar.');
				return;
			}
			// Issue #82: tolak mulai share bila koneksi RTK belum sehat
			// (offline / belum join room / sedang reconnect).
			if (!readConnectionHealthy(meetingRef.current)) {
				setErrorMessage(CONNECTION_BLOCKED_MESSAGE);
				return;
			}
			// Eksklusif MediaProjection: rekaman dan share tidak bisa bersamaan.
			// Daripada memaksa user berhenti manual lewat menu More, tawarkan
			// auto-stop di sini lalu lanjut share.
			if (blockedRef.current?.()) {
				const stopRecording = stopRecordingRef.current;
				if (!stopRecording) {
					setErrorMessage(
						'Rekaman sedang berlangsung. Hentikan rekaman sebelum memulai screen share.',
					);
					return;
				}
				const proceed = await confirmStopRecordingAndShare();
				if (!proceed) {
					setErrorMessage('Rekaman sedang berlangsung — Share Screen dibatalkan.');
					return;
				}
				try {
					await stopRecording();
				} catch {
					setErrorMessage('Gagal menghentikan rekaman. Share Screen dibatalkan.');
					return;
				}
			}
			thrownRef.current = null;
			permissionErrorRef.current = null;
			clearScreenShareError();
			setErrorMessage(null);
			inFlightRef.current = true;
			try {
				await original();
			} catch (error) {
				// Rekor dulu tanpa rethrow: tombol share di UI kit tidak menangkap
				// error, dan rethrow hanya menimbulkan unhandled rejection.
				thrownRef.current = error;
			}
			inFlightRef.current = false;
			scheduleEvaluate();
		};
		writableSelf.enableScreenShare = wrapped;

		const onPermissionError = (payload?: MediaPermissionErrorPayload) => {
			if (payload?.kind === 'screenshare') {
				permissionErrorRef.current = payload;
				scheduleEvaluate();
			}
		};

		const onRoomLeft = () => {
			clearTimer();
			inFlightRef.current = false;
			thrownRef.current = null;
			permissionErrorRef.current = null;
			clearScreenShareError();
			setErrorMessage(null);
		};

		// Issue #82: saat koneksi RTK hilang, hentikan screen share yang sedang
		// berjalan secara lokal (best-effort). Cleanup tidak menunggu respons
		// server karena koneksi memang sedang putus.
		let wasHealthy = readConnectionHealthy(meetingRef.current);
		const meta = (
			meeting as unknown as {
				meta?: {
					on?: (e: string, h: () => void) => void;
					off?: (e: string, h: () => void) => void;
				};
			}
		)?.meta;
		const onSocketUpdate = () => {
			const healthy = readConnectionHealthy(meetingRef.current);
			if (wasHealthy && !healthy) {
				const current = meetingRef.current;
				if (current?.self?.screenShareEnabled) {
					current.self.disableScreenShare().catch(() => undefined);
				}
			}
			wasHealthy = healthy;
		};
		meta?.on?.('socketConnectionUpdate', onSocketUpdate);

		meeting.self.on('mediaPermissionError', onPermissionError);
		meeting.self.on('roomLeft', onRoomLeft);

		return () => {
			meeting.self.off('mediaPermissionError', onPermissionError);
			meeting.self.off('roomLeft', onRoomLeft);
			try {
				meta?.off?.('socketConnectionUpdate', onSocketUpdate);
			} catch {
				/* ignore */
			}
			clearTimer();
			if (writableSelf.enableScreenShare === wrapped) {
				writableSelf.enableScreenShare = original;
			}
		};
	}, [meeting]);

	// Cleanup saat komponen dilepas: tidak boleh ada capture yang tertinggal.
	useEffect(() => {
		return () => {
			const current = meetingRef.current;
			if (current?.self?.screenShareEnabled) {
				current.self.disableScreenShare().catch(() => undefined);
			}
		};
	}, []);

	const dismissError = useCallback(() => {
		setErrorMessage(null);
	}, []);

	return { errorMessage, dismissError };
}
