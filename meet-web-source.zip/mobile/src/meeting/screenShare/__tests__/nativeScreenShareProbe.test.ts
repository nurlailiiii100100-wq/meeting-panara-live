/**
 * Uji unit klasifikasi error screen share native.
 *
 * Probe menutup celah di SDK React Native: LocalMediaHandler.enableScreenShare()
 * hanya console.warn() ketika getDisplayMedia() gagal, sehingga promise resolve
 * tanpa informasi error (lihat nativeScreenShareProbe.ts).
 */
import { mediaDevices } from '@cloudflare/react-native-webrtc';
import {
	classifyNativeScreenShareError,
	clearScreenShareError,
	consumeScreenShareError,
	installScreenShareErrorProbe,
} from '../nativeScreenShareProbe';

describe('native screen share error probe', () => {
	beforeEach(() => {
		clearScreenShareError();
	});

	it('menangkap error yang dilempar getDisplayMedia()', async () => {
		// Install dilakukan SETELAH stub supaya probe membungkus fungsi ini
		// (install hanya terjadi sekali per process — idempotent).
		const stub = jest.fn(async () => {
			throw new Error('NotAllowedError');
		});
		mediaDevices.getDisplayMedia = stub as unknown as typeof mediaDevices.getDisplayMedia;
		installScreenShareErrorProbe();

		await expect(mediaDevices.getDisplayMedia()).rejects.toThrow();
		expect(stub).toHaveBeenCalled();
		expect(consumeScreenShareError()).toBeInstanceOf(Error);
		// Konsumsi bersifat sekali baca.
		expect(consumeScreenShareError()).toBeNull();
	});

	it('mengklasifikasikan pembatalan user (Android) sebagai USER_CANCELLED', () => {
		expect(
			classifyNativeScreenShareError({
				name: 'DOMException',
				message: 'NotAllowedError',
			}),
		).toBe('USER_CANCELLED');
		expect(
			classifyNativeScreenShareError(new Error('NotAllowedError')),
		).toBe('USER_CANCELLED');
	});

	it('mengklasifikasikan MediaProjection tidak tersedia', () => {
		expect(
			classifyNativeScreenShareError(new Error('No current Activity')),
		).toBe('SCREEN_CAPTURE_UNAVAILABLE');
		expect(
			classifyNativeScreenShareError(
				new Error('MediaProjectionManager is null'),
			),
		).toBe('SCREEN_CAPTURE_UNAVAILABLE');
		expect(
			classifyNativeScreenShareError(
				new Error('Another operation is pending'),
			),
		).toBe('SCREEN_CAPTURE_UNAVAILABLE');
		expect(
			classifyNativeScreenShareError(new Error('SecurityException: no')),
		).toBe('PERMISSION_DENIED');
	});

	it('tidak mengarang kelas error untuk error yang tidak dikenal', () => {
		expect(
			classifyNativeScreenShareError(new Error('k.something odd')),
		).toBe('UNKNOWN_ERROR');
		expect(classifyNativeScreenShareError(undefined)).toBe('UNKNOWN_ERROR');
	});
});
