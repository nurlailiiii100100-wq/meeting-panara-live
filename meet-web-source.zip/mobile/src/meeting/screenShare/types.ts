/**
 * Klasifikasi error + pesan Indonesia untuk screen share mobile.
 *
 * Sumber kebenaran status publish = RealtimeKit (`meeting.self.screenShareEnabled`).
 * Tombol share/stop dikelola UI kit (RtkScreenShareToggle) dengan label bawaan
 * "Share Screen"/"Stop Sharing" — sama persis dengan aplikasi web; file ini
 * hanya menyediakan pesan error yang dipajang sebagai banner (lihat
 * useScreenShareFeedback.ts).
 */
export type ScreenShareErrorCode =
	| 'USER_CANCELLED'
	| 'PERMISSION_DENIED'
	| 'SYSTEM_DENIED'
	| 'SCREEN_CAPTURE_UNAVAILABLE'
	| 'MEETING_NOT_JOINED'
	| 'PUBLISH_FAILED'
	| 'NETWORK_ERROR'
	| 'CAPTURE_INTERRUPTED'
	| 'NATIVE_MODULE_ERROR'
	| 'UNKNOWN_ERROR';

export const SCREEN_SHARE_MESSAGES: Record<ScreenShareErrorCode, string> = {
	USER_CANCELLED: 'Screen sharing dibatalkan.',
	PERMISSION_DENIED: 'Anda menolak izin screen recording.',
	SYSTEM_DENIED:
		'Screen sharing diizinkan oleh sistem. Aktifkan izin Screen Recording di Pengaturan.',
	SCREEN_CAPTURE_UNAVAILABLE:
		'Screen capture tidak tersedia di perangkat ini.',
	MEETING_NOT_JOINED: 'Anda belum bergabung ke meeting.',
	PUBLISH_FAILED: 'Screen sharing gagal dimulai. Silakan coba lagi.',
	NETWORK_ERROR: 'Koneksi bermasalah saat memulai screen sharing.',
	CAPTURE_INTERRUPTED: 'Screen sharing dihentikan oleh sistem.',
	NATIVE_MODULE_ERROR:
		'Modul screen capture bermasalah. Coba muat ulang aplikasi.',
	UNKNOWN_ERROR: 'Screen sharing gagal dimulai. Silakan coba lagi.',
};
