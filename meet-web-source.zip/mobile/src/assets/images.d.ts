// Deklarasi modul untuk aset gambar. React Native (Metro) menangani
// `import gambar from './file.png'` — hasilnya nomor ID resource statis yang
// dipakai sebagai Image `source` — tapi TypeScript perlu tahu tipenya.
declare module '*.png' {
  const resource: number;
  export default resource;
}
