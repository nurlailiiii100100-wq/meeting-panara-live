import { Pressable, StyleSheet, Text, View } from 'react-native';

interface StatusBannerProps {
	message: string;
	kind?: 'error' | 'info' | 'success';
	onDismiss?: () => void;
}

/** Banner status di atas kontrol (error screen share / status room). */
export default function StatusBanner({
	message,
	kind = 'error',
	onDismiss,
}: StatusBannerProps) {
	const tone =
		kind === 'error' ? '#dc2626' : kind === 'success' ? '#16a34a' : '#2f6bff';
	return (
		<View style={[styles.banner, { backgroundColor: tone }]}>
			<Text style={styles.text}>{message}</Text>
			{onDismiss ? (
				<Pressable onPress={onDismiss} hitSlop={12} accessibilityRole="button">
					<Text style={styles.close}>✕</Text>
				</Pressable>
			) : null}
		</View>
	);
}

const styles = StyleSheet.create({
	banner: {
		flexDirection: 'row',
		alignItems: 'center',
		gap: 8,
		paddingHorizontal: 12,
		paddingVertical: 10,
		borderRadius: 10,
	},
	text: {
		color: '#fff',
		fontSize: 13,
		flex: 1,
	},
	close: {
		color: '#fff',
		fontSize: 14,
		fontWeight: '700',
	},
});
