import AsyncStorage from '@react-native-async-storage/async-storage';

const USER_ID_KEY = 'learnly:userId';
const NAME_KEY = 'learnly:name';
const SERVER_URL_KEY = 'learnly:apiBaseUrl';

function randomUuid(): string {
	// UUID v4 tanpa dependensi crypto (Hermes tidak selalu punya crypto.randomUUID).
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
		const r = (Math.random() * 16) | 0;
		const v = c === 'x' ? r : (r & 0x3) | 0x8;
		return v.toString(16);
	});
}

/** Persistensi user id — paralel dengan localStorage 'learnly:userId' di web. */
export async function getPersistentUserId(): Promise<string> {
	const existing = await AsyncStorage.getItem(USER_ID_KEY);
	if (existing) return existing;
	const id = randomUuid();
	await AsyncStorage.setItem(USER_ID_KEY, id);
	return id;
}

export async function getSavedName(): Promise<string> {
	return (await AsyncStorage.getItem(NAME_KEY)) ?? '';
}

export async function saveName(name: string): Promise<void> {
	await AsyncStorage.setItem(NAME_KEY, name);
}

export async function getSavedServerUrl(): Promise<string> {
	return (await AsyncStorage.getItem(SERVER_URL_KEY)) ?? '';
}

export async function saveServerUrl(url: string): Promise<void> {
	await AsyncStorage.setItem(SERVER_URL_KEY, url.trim());
}
