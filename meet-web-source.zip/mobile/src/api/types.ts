/** Respons POST /api/tokens (worker/handlers/tokens.ts). */
export interface IssueTokenResponse {
	auth_token: string;
	meeting_id: string;
	public_id: string | null;
	provider_meeting_id: string;
	expires_at: string | null;
	duration_minutes: number | null;
	host_resolution: string;
	member_resolution: string;
	max_allowed_resolution: string;
	allow_member_whiteboard: boolean;
	allow_member_annotation: boolean;
	auto_record: boolean;
	recording_retention_hours: number | null;
	scheduled_at: string | null;
	user_role: 'admin' | 'member';
	/** Token unggah rekaman client-side (hanya host/admin yang menerimanya). */
	upload_token?: string | null;
	host_code_error?: 'locked' | 'required' | 'invalid';
}

/** Respons GET /api/meetings/:id (sebagian field opsional). */
export interface MeetingMeta {
	id?: string;
	public_id?: string;
	name?: string;
	status?: string;
	host_code_set?: boolean;
	tentor_names?: string[];
	scheduled_at?: string | null;
	started_at?: string | null;
	/** Waktu berakhir resmi dari backend — sumber kebenaran durasi meeting. */
	expires_at?: string | null;
	duration_minutes?: number | null;
}

export interface TokenRequest {
	meetingId: string;
	userId: string;
	name: string;
	presetName?: 'group_call_host' | 'group_call_participant';
	hostCode?: string;
}

export class ApiError extends Error {
	readonly status: number;
	readonly code: string;

	constructor(status: number, code: string, message: string) {
		super(message);
		this.name = 'ApiError';
		this.status = status;
		this.code = code;
	}
}
