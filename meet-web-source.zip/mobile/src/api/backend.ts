import { ApiError } from './types';
import type {
	IssueTokenResponse,
	MeetingMeta,
	TokenRequest,
} from './types';

let apiBaseUrl = '';

export function setApiBaseUrl(url: string): void {
	const trimmed = url.trim().replace(/\/+$/, '');
	apiBaseUrl = trimmed;
}

export function getApiBaseUrl(): string {
	return apiBaseUrl;
}

async function apiFetch(
	path: string,
	init: RequestInit = {},
): Promise<Response> {
	if (!apiBaseUrl) {
		throw new ApiError(0, 'SERVER_NOT_CONFIGURED', 'Server URL belum diisi.');
	}
	const headers = new Headers(init.headers);
	headers.set('content-type', 'application/json');
	return fetch(`${apiBaseUrl}${path}`, {
		...init,
		headers,
	});
}

async function readError(response: Response): Promise<ApiError> {
	let code = 'UNKNOWN_ERROR';
	let message = `Request failed (${response.status})`;
	try {
		const body = (await response.json()) as { error?: string; message?: string };
		if (body?.error) code = body.error;
		if (body?.message) message = body.message;
	} catch {
		/* respons bukan JSON — pakai default */
	}
	return new ApiError(response.status, code, message);
}

/**
 * Detail meeting (publik). Bentuk respons worker:
 * `{ meeting, tentor_names, host_code_set, participants }` — diratakan agar
 * pemakaian di layar Join sama dengan yang dibaca aplikasi web.
 */
export async function fetchMeetingMeta(meetingId: string): Promise<MeetingMeta> {
	const response = await apiFetch(
		`/api/meetings/${encodeURIComponent(meetingId)}`,
	);
	if (!response.ok) throw await readError(response);
	const body = (await response.json()) as {
		meeting?: MeetingMeta;
		tentor_names?: string[];
		host_code_set?: boolean;
	};
	return {
		...(body.meeting ?? {}),
		tentor_names: body.tentor_names,
		host_code_set: body.host_code_set,
	};
}

export interface HostCodeResult {
	valid: boolean;
	required?: boolean;
	reason?: string;
	retry_after_seconds?: number;
}

/** Cek kode host (publik) — POST /api/meetings/:id/host-code. */
export async function checkHostJoinCode(
	meetingId: string,
	name: string,
	code: string,
): Promise<HostCodeResult> {
	const response = await apiFetch(
		`/api/meetings/${encodeURIComponent(meetingId)}/host-code`,
		{
			method: 'POST',
			body: JSON.stringify({ name, code }),
		},
	);
	const data = (await response.json().catch(() => ({}))) as HostCodeResult & {
		error?: string;
		message?: string;
	};
	if (!response.ok) {
		throw new ApiError(
			response.status,
			(data.error || 'HOST_CODE_INVALID').toUpperCase(),
			data.message || 'Kode host salah atau terkunci. Coba lagi.',
		);
	}
	return {
		valid: data.valid !== false,
		required: data.required,
		reason: data.reason,
		retry_after_seconds: data.retry_after_seconds,
	};
}

/**
 * Minta auth token RealtimeKit ke backend (mobile → backend → RealtimeKit).
 * Tidak ada API key Cloudflare di sisi aplikasi.
 */
export async function issueToken(
	request: TokenRequest,
): Promise<IssueTokenResponse> {
	const response = await apiFetch('/api/tokens', {
		method: 'POST',
		body: JSON.stringify(request),
	});
	const data = (await response.json().catch(() => ({}))) as Partial<IssueTokenResponse> & {
		error?: string;
		message?: string;
	};
	if (!response.ok || !data.auth_token) {
		throw new ApiError(
			response.status,
			data.error || 'TOKEN_ISSUE_FAILED',
			data.message || 'Gagal mendapatkan token meeting.',
		);
	}
	return data as IssueTokenResponse;
}
