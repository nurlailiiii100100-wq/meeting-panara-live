import { Platform } from 'react-native';

/**
 * Base URL Cloudflare Worker yang melayani API yang sama dengan aplikasi web
 * (auth, meeting metadata, penerbitan token RealtimeKit).
 *
 * Tidak ada API key Cloudflare yang disimpan di aplikasi — worker-lah yang
 * memegang ACCOUNT_ID / APP_ID / CF_API_TOKEN dan menerbitkan auth token.
 */
export const DEV_HOST_MACHINE_URL =
	Platform.OS === 'android' ? 'http://10.0.2.2:8787' : 'http://localhost:8787';

/**
 * URL produksi — worker dan situs web berbagi domain yang sama, persis seperti
 * aplikasi web yang memakai URL relatif (`/api/...`) karena satu origin.
 *
 * Nilai ini DITANEM di build rilis supaya user tidak perlu mengisi apa pun:
 * aplikasi langsung menunjuk ke backend yang benar, tidak ada kemungkinan typo
 * atau URL kosong di HP user.
 *
 * Konsekuensinya: kalau domain backend berubah, ganti nilai ini lalu build APK
 * ulang — aplikasi di-sideload (bukan Play Store), jadi tidak ada update jarak
 * jauh. `__DEV__` tetap memakai `DEV_HOST_MACHINE_URL` untuk tes lokal.
 */
export const PRODUCTION_API_BASE_URL = 'https://live.panaragroup.web.id';

/**
 * Default: build dev/emulator → worker di laptop (`npm run dev` di root repo);
 * build rilis → URL produksi di atas.
 */
export const DEFAULT_API_BASE_URL = __DEV__
	? DEV_HOST_MACHINE_URL
	: PRODUCTION_API_BASE_URL;

/** Batas stream yang di-subscribe — sama dengan aplikasi web (Meeting.tsx). */
export const MAX_SUBSCRIBED_STREAMS = 24;
