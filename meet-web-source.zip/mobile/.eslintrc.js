module.exports = {
  root: true,
  extends: '@react-native',
  rules: {
    // `void promise` dipakai untuk fire-and-forget handler UI; bitwise dibutuhkan
    // oleh generator UUID lokal (crypto.randomUUID tidak ada di Hermes).
    'no-void': 'off',
    'no-bitwise': 'off',
  },
};
