/* global jest */

/**
 * Setup Jest untuk aplikasi mobile.
 *
 * Modul native (AsyncStorage, WebRTC, RealtimeKit) tidak tersedia di Jest,
 * jadi disediakan mock sesuai dokumentasi masing-masing package.
 */

jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock'),
);

jest.mock('react-native-safe-area-context', () => {
  const mockModule = require('react-native-safe-area-context/jest/mock');
  // Mock package mengekspor komponen lewat `default`; aplikasi memakai named import.
  const mock = mockModule.default ?? mockModule;
  return {...mock, __esModule: true};
});

jest.mock('@cloudflare/react-native-webrtc', () => {
  class MediaStream {
    constructor(tracks = []) {
      this._tracks = tracks;
    }

    toURL() {
      return 'mock-stream';
    }

    getTracks() {
      return this._tracks;
    }
  }

  return {
    __esModule: true,
    MediaStream,
    RTCView: 'RTCView',
    mediaDevices: {
      getDisplayMedia: jest.fn(async () => {
        throw new Error('NotAllowedError');
      }),
      getUserMedia: jest.fn(async () => new MediaStream()),
      getDevices: jest.fn(async () => []),
    },
  };
});

jest.mock('@cloudflare/realtimekit-react-native', () => ({
  __esModule: true,
  RealtimeKitProvider: ({children}) => children,
  useRealtimeKitClient: jest.fn(() => [undefined, jest.fn()]),
  useRealtimeKitSelector: jest.fn(),
  useRTKSelector: jest.fn(),
  useRealtimeKitMeeting: jest.fn(() => ({meeting: undefined})),
}));

// Dependensi native UI kit RealtimeKit: cukup di-mock datar karena test hanya
// me-render lapisan atas (react-native-fs membuat NativeEventEmitter saat
// import, yang gagal tanpa modul native asli).
jest.mock('react-native-fs', () => ({
  __esModule: true,
  exists: jest.fn(async () => false),
  mkdir: jest.fn(async () => undefined),
  unlink: jest.fn(async () => undefined),
  copyFile: jest.fn(async () => undefined),
  readFile: jest.fn(async () => ''),
  writeFile: jest.fn(async () => undefined),
  stat: jest.fn(async () => ({})),
  readDir: jest.fn(async () => []),
  MainBundlePath: '',
  CachesDirectoryPath: '',
  DocumentDirectoryPath: '',
}));

jest.mock('react-native-sound-player', () => ({
  __esModule: true,
  playUrl: jest.fn(),
  playSoundFile: jest.fn(),
  stop: jest.fn(),
  addEventListener: jest.fn(() => ({remove: jest.fn()})),
}));

jest.mock('react-native-file-viewer', () => ({
  __esModule: true,
  default: {open: jest.fn(async () => undefined)},
}));

jest.mock('@react-native-documents/picker', () => ({
  __esModule: true,
  open: jest.fn(async () => []),
  openDocument: jest.fn(async () => []),
}));

jest.mock('react-native-webview', () => {
  const React = require('react');
  const {View} = require('react-native');
  return {__esModule: true, default: props => React.createElement(View, props)};
});
