module.exports = {
  preset: '@react-native/jest-preset',
  // setupFiles dari preset sudah berisi setup milik React Native, sehingga
  // setup aplikasi diletakkan di setupFilesAfterEnv (tidak menimpa preset).
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  // Transformasi pertama kali (React Native + RealtimeKit) lebih lama dari 5 dtk.
  testTimeout: 30000,
  // Dependensi pihak ketiga dengan Flow/TS (react-native-fs, UI kit RealtimeKit,
  // dsb.) tetap di-transform agar bisa dibaca Jest.
  transformIgnorePatterns: [
    'node_modules/(?!(@react-native|react-native|@cloudflare)([-/]))',
  ],
};
